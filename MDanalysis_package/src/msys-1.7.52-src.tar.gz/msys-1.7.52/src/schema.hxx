/* 
Copyright 2012-2014, D. E. Shaw Research.
All rights reserved.

Redistribution and use in source and binary forms, with or without
modification, are permitted provided that the following conditions are
met:

* Redistributions of source code must retain the above copyright
  notice, this list of conditions, and the following disclaimer.

* Redistributions in binary form must reproduce the above copyright
  notice, this list of conditions, and the following disclaimer in the
  documentation and/or other materials provided with the distribution.

* Neither the name of D. E. Shaw Research nor the names of its
  contributors may be used to endorse or promote products derived from
  this software without specific prior written permission.

THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
"AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR
A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT
OWNER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,
SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT
LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE,
DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY
THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
(INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE
OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
*/
#ifndef msys_schema_hxx
#define msys_schema_hxx

#include "system.hxx"

namespace desres { namespace msys {

    /* Names of available table schemas. */
    std::vector<std::string> TableSchemas();

    /* Names of available nonbonded schemas. */
    std::vector<std::string> NonbondedSchemas();

    /* Add a table to the system if it not already present,
     * returning it.  If optional name field is provided, the table
     * will be added with the given name; otherwise the name is taken
     * from the table schema. */
    TermTablePtr AddTable(SystemPtr sys, const std::string& type,
                                         const std::string& name="");

    /* Add a nonbonded table to the system, and configure the nonbonded
     * info according to funct and rule.  funct must be the name of recognized
     * nonbonded type.  rule is not checked; at some point in the future we
     * might start requiring that it be one of the valid combining rules for
     * the specified funct.  If nonbonded_info's vdw_funct and vdw_rule 
     * are empty, they are overridden by the provided values; otherwise, the
     * corresponding values must agree if funct and rule are not empty.
     * A nonbonded table is returned.  */
    TermTablePtr AddNonbonded(SystemPtr sys, 
                              const std::string& funct,
                              const std::string& rule);
}}

#endif
