/* 
Copyright 2012-2014, D. E. Shaw Research.
All rights reserved.

Redistribution and use in source and binary forms, with or without
modification, are permitted provided that the following conditions are
met:

* Redistributions of source code must retain the above copyright
  notice, this list of conditions, and the following disclaimer.

* Redistributions in binary form must reproduce the above copyright
  notice, this list of conditions, and the following disclaimer in the
  documentation and/or other materials provided with the distribution.

* Neither the name of D. E. Shaw Research nor the names of its
  contributors may be used to endorse or promote products derived from
  this software without specific prior written permission.

THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
"AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR
A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT
OWNER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,
SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT
LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE,
DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY
THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
(INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE
OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
*/
#include "keyword_predicate.hxx"
#include <stdexcept>

namespace {
  using namespace desres::msys::atomsel;

  class KeywordPredicate : public Predicate {
    KeywordPtr key;
    TargetList* targets;

  public:
    KeywordPredicate(KeywordPtr key, TargetList* targets) 
    : key(key), targets(targets) {}

    ~KeywordPredicate() { delete targets; }

    void eval(Selection& s) {
      targets->select(s, key);
    }

    void dump(std::ostream& str) const {
      str << key->name << " <values>"; 
    }
  };

  class SamePredicate : public Predicate {
    KeywordPtr key;
    Selection all;
    PredicatePtr sub;
    public:
    SamePredicate( KeywordPtr _key, const Selection& _all, PredicatePtr _sub)
      : key(_key), all(_all), sub(_sub) {}

    void eval(Selection& s);
    void dump(std::ostream& str) const {
      str << "same " << key->name << " as ";
      sub->dump(str);
    }
  };
}

template <typename T>
static void select( const std::vector<T>& vals,
    const Selection& x,
    Selection& s ) {

  std::set<T> u;
  int i,n=x.size();
  for (i=0; i<n; i++) if (x[i]) u.insert(vals[i]);
  for (i=0; i<n; i++) s[i] &= u.count(vals[i]);
}

void SamePredicate::eval( Selection& s ) {
  /* evaluate full subselection */
  Selection x(all);
  sub->eval(x);

  /* we'll need values from the union of x and s */
  Selection xs(x);
  xs.add(s);

  if (key->type==KEY_INT) {
    std::vector<Int> vals(xs.size());
    key->iget(xs,vals);
    select( vals, x, s );
  } else if (key->type==KEY_DBL) {
    std::vector<Dbl> vals(xs.size());
    key->dget(xs,vals);
    select( vals, x, s );
  } else if (key->type==KEY_STR) {
    std::vector<Str> vals(xs.size());
    key->sget(xs,vals);
    select( vals, x, s );
  } else {
    throw std::runtime_error("bad keyword type");
  }
}

namespace desres { namespace msys { namespace atomsel {

  PredicatePtr keyword_predicate(KeywordPtr key, TargetList* targets) {
    return PredicatePtr(new KeywordPredicate(key,targets));
  }

  PredicatePtr boolean_predicate( KeywordPtr key ) {
    KeywordPredicate * pred = new KeywordPredicate(key, new IntList(1));
    return PredicatePtr(pred);
  }

  PredicatePtr same_keyword_predicate( KeywordPtr key, 
                                       const Selection& all,
                                       PredicatePtr pred ) {
    return PredicatePtr(new SamePredicate(key,all,pred));
  }

}}}

