/* 
Copyright 2012-2014, D. E. Shaw Research.
All rights reserved.

Redistribution and use in source and binary forms, with or without
modification, are permitted provided that the following conditions are
met:

* Redistributions of source code must retain the above copyright
  notice, this list of conditions, and the following disclaimer.

* Redistributions in binary form must reproduce the above copyright
  notice, this list of conditions, and the following disclaimer in the
  documentation and/or other materials provided with the distribution.

* Neither the name of D. E. Shaw Research nor the names of its
  contributors may be used to endorse or promote products derived from
  this software without specific prior written permission.

THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
"AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR
A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT
OWNER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,
SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT
LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE,
DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY
THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
(INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE
OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
*/
#ifndef msys_atomsel_context_hxx
#define msys_atomsel_context_hxx

#include "expression.hxx"
#include "msys_keyword.hxx"

namespace desres { namespace msys { namespace atomsel {

    class VMD {
        /* defined in vmd.l */
        void init_scanner();
        void destroy_scanner();
    
        SystemPtr sys;
        const char* txt;

        /* containers to keep pointers alive */
        std::vector<PredicatePtr> predicates;
        std::vector<ExpressionPtr> expressions;
        std::vector<KeywordPtr> keywords;

        Predicate* add(PredicatePtr p);
        Expression* add(ExpressionPtr e);

    public:
        void* scanner;
        Predicate* result;
        std::string error;
    
        VMD(SystemPtr ptr) 
        : sys(ptr), txt(), scanner(), result()
        {}

        inline char getc() { return *txt++; }

        PredicatePtr parse(std::string const& txt);

        /* internal parser interface */
        Keyword* find_key(const char* s);
        Keyword* find_single(const char* s);
        Predicate* find_macro(const char* s);
        StringPredicate* find_strfctn(const char* s);
        Predicate* make_strfctn(StringPredicate* p, StringList* targets);
        bool find_function(const char* s);
        Predicate* make_not(Predicate* sub);
        Predicate* make_and(Predicate* lhs, Predicate* rhs);
        Predicate* make_or(Predicate* lhs, Predicate* rhs);
        Predicate* make_single(Keyword* key);
        Predicate* make_key(Keyword* key, TargetList* targets);
        Predicate* make_within(double r, Predicate* sub);
        Predicate* make_exwithin(double r, Predicate* sub);
        Predicate* make_pbwithin(double r, Predicate* sub);
        Predicate* make_withinbonds(int n, Predicate* sub);
        Predicate* make_same(Keyword* key, Predicate* sub);
        Predicate* make_nearest(int r, Predicate* sub);
        Predicate* make_compare(int cmp, Expression* lhs, Expression* rhs);

        Expression* make_exp(Dbl x);
        Expression* make_exp(int x);
        Expression* make_exp(Keyword* key);
        Expression* make_binexp(const char* s, Expression* L, Expression* R);
        Expression* make_unaexp(const char* s, Expression* S);
    };

}}}

#endif
