/* 
Copyright 2012-2014, D. E. Shaw Research.
All rights reserved.

Redistribution and use in source and binary forms, with or without
modification, are permitted provided that the following conditions are
met:

* Redistributions of source code must retain the above copyright
  notice, this list of conditions, and the following disclaimer.

* Redistributions in binary form must reproduce the above copyright
  notice, this list of conditions, and the following disclaimer in the
  documentation and/or other materials provided with the distribution.

* Neither the name of D. E. Shaw Research nor the names of its
  contributors may be used to endorse or promote products derived from
  this software without specific prior written permission.

THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
"AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR
A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT
OWNER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,
SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT
LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE,
DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY
THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
(INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE
OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
*/
#ifndef desres_msys_atomsel_keyword_hxx
#define desres_msys_atomsel_keyword_hxx

#include "selection.hxx"
#include "regex.hxx"
#include <set>
#include <string>
#include <boost/shared_ptr.hpp>
#include <boost/enable_shared_from_this.hpp>

namespace desres { namespace msys { namespace atomsel {

    enum KeywordType {
        KEY_INT=1, KEY_DBL=2, KEY_STR=4
    };

    typedef int Int;
    typedef double Dbl;
    typedef std::string Str;

    struct Keyword : public boost::enable_shared_from_this<Keyword> {
        const std::string name;
        const KeywordType type;

        explicit Keyword(const std::string& n, KeywordType t) 
        : name(n), type(t) {}
        virtual ~Keyword() {}

        virtual void iget(const Selection& s, std::vector<Int>& ) const;
        virtual void dget(const Selection& s, std::vector<Dbl>& ) const;
        virtual void sget(const Selection& s, std::vector<Str>& ) const;
    };

    typedef boost::shared_ptr<Keyword> KeywordPtr;

    struct TargetList {
        virtual ~TargetList() {}
        virtual void select(Selection& s, KeywordPtr k) = 0;
    };

    struct IntList : TargetList {
        typedef std::pair<Int,Int> Range;

        std::vector<Int>    values;
        std::vector<Range>  ranges;

        IntList() {}
        IntList(int i)          { add(i); }
        IntList(int i, int j)   { add(i,j); }
        void add(int i) { values.push_back(i); }
        void add(int i, int j) { ranges.push_back(Range(i,j)); }

        void select(Selection& s, KeywordPtr k);
    };

    struct FloatList : TargetList {
        typedef std::pair<Dbl,Dbl> Range;
        std::vector<Dbl>    values;
        std::vector<Range>  ranges;

        FloatList() {}
        FloatList(Dbl i) { add(i); }
        FloatList(Dbl i, Dbl j) { add(i,j); }
        void add(Dbl i) { values.push_back(i); }
        void add(Dbl i, Dbl j) { ranges.push_back(Range(i,j)); }

        void select(Selection& s, KeywordPtr k);
    };

    struct StringList : TargetList {
        std::vector<Str> values;
        std::vector<Regex*> regexes;

        StringList() {}
        StringList(Str const& s) { add(s); }
        StringList(Regex* r) { add(r); }
        void add(Str const& s) { values.push_back(s); }
        void add(Regex* r)  { regexes.push_back(r); }

        ~StringList() {
            for (unsigned i=0; i<regexes.size(); i++) delete regexes[i];
        }
        void select(Selection& s, KeywordPtr k);
    };

    Int parse_int(std::string const& s);
    Dbl parse_dbl(std::string const& s);

}}} // ns

#endif
