/* 
Copyright 2012-2014, D. E. Shaw Research.
All rights reserved.

Redistribution and use in source and binary forms, with or without
modification, are permitted provided that the following conditions are
met:

* Redistributions of source code must retain the above copyright
  notice, this list of conditions, and the following disclaimer.

* Redistributions in binary form must reproduce the above copyright
  notice, this list of conditions, and the following disclaimer in the
  documentation and/or other materials provided with the distribution.

* Neither the name of D. E. Shaw Research nor the names of its
  contributors may be used to endorse or promote products derived from
  this software without specific prior written permission.

THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
"AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR
A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT
OWNER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,
SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT
LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE,
DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY
THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
(INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE
OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
*/
#include "predicate.hxx"

namespace {
  using namespace desres::msys::atomsel;

  struct AllPredicate : Predicate {
    void eval(Selection& s) {}
    void dump(std::ostream& str) const { str << "all"; }
  };

  struct NonePredicate : Predicate {
    void eval(Selection& s) { s.clear(); }
    void dump(std::ostream& str) const { str << "none"; }
  };

  struct AndPredicate : Predicate {
    PredicatePtr left, right;
    AndPredicate( PredicatePtr A, PredicatePtr B ) : left(A), right(B) {}
    void eval(Selection& s) {
      left->eval(s);
      right->eval(s);
    }
    void dump(std::ostream& str) const {
      str << "[";
      left->dump(str);
      str << "] and [";
      right->dump(str);
      str << "]";
    }
  };
  struct OrPredicate : Predicate {
    PredicatePtr left, right;
    OrPredicate( PredicatePtr A, PredicatePtr B ) : left(A), right(B) {}
    void eval(Selection& s) {
      Selection s2(s);
      left->eval(s);
      right->eval(s2);
      s.add(s2);
    }
    void dump(std::ostream& str) const {
      str << "[";
      left->dump(str);
      str << "] or [";
      right->dump(str);
      str << "]";
    }
  };
  struct NotPredicate : Predicate {
    PredicatePtr sub;
    NotPredicate( PredicatePtr A ) : sub(A) {}
    void eval(Selection& s) {
      Selection s2(s);
      sub->eval(s2);
      s.subtract(s2);
    }
    void dump(std::ostream& str) const {
      str << "not [";
      sub->dump(str);
      str << "]";
    }
  };
}

namespace desres { namespace msys { namespace atomsel {

  PredicatePtr all_predicate() {
      static PredicatePtr p(new AllPredicate);
      return p;
  }

  PredicatePtr none_predicate() {
      static PredicatePtr p(new NonePredicate);
      return p;
  }

  PredicatePtr and_predicate( PredicatePtr L, PredicatePtr R ) {
      if (!L || !R) return PredicatePtr();
      return PredicatePtr(new AndPredicate(L,R));
  }

  PredicatePtr or_predicate( PredicatePtr L, PredicatePtr R ) {
      if (!L || !R) return PredicatePtr();
      return PredicatePtr(new OrPredicate(L,R));
  }

  PredicatePtr not_predicate( PredicatePtr X ) {
      if (!X) return PredicatePtr();
      return PredicatePtr(new NotPredicate(X));
  }

}}}
