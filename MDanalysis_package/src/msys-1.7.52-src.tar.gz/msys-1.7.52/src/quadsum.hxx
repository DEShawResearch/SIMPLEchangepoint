/* 
Copyright 2012-2014, D. E. Shaw Research.
All rights reserved.

Redistribution and use in source and binary forms, with or without
modification, are permitted provided that the following conditions are
met:

* Redistributions of source code must retain the above copyright
  notice, this list of conditions, and the following disclaimer.

* Redistributions in binary form must reproduce the above copyright
  notice, this list of conditions, and the following disclaimer in the
  documentation and/or other materials provided with the distribution.

* Neither the name of D. E. Shaw Research nor the names of its
  contributors may be used to endorse or promote products derived from
  this software without specific prior written permission.

THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
"AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR
A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT
OWNER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,
SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT
LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE,
DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY
THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
(INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE
OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
*/
#ifndef desres_msys_quadsum_hxx
#define desres_msys_quadsum_hxx

namespace desres { namespace msys {

    // compensated summation (sumXBLAS from "ACCURATE SUM AND DOT PRODUCT")
    class Quadsum {
    public:
        Quadsum(): total(0), err(0.0){};
        Quadsum(double t): total(t),err(0.0){};
        Quadsum(double t, double e): total(t),err(e){};
        Quadsum(const Quadsum &qs): total(qs.total),err(qs.err){};
    
        Quadsum & operator+=(const double val){
            double t1,t2;
            t1=twosum(total,val,t2);
            t2+=err;
            total=fasttwosum(t1,t2,err);
            return *this;
        }
        Quadsum & operator+=(const Quadsum val){
            double t1,t2;
            t1=twosum(total,val.total,t2);
            t2+=err+val.err;
            total=fasttwosum(t1,t2,err);
            return *this;
        }
        Quadsum operator+(const double val) const{
            Quadsum tmp(total,err);
            tmp+=val;
            return tmp;
        }
        Quadsum operator+(const Quadsum val) const{
            Quadsum tmp(total,err);
            tmp+=val;
            return tmp;
        }
    
        Quadsum & operator=(const double val){
            total=val;
            err=0;
            return *this;
        }
        Quadsum & operator=(const Quadsum &val){
            total=val.total;
            err=val.err;
            return *this;
        }
        double result(){return total;}
        void reset(){total=0.0;err=0.0;}
    private:
        double total, err;
        /* "ACCURATE SUM AND DOT PRODUCT", SIAM Journal on 
           Scientific Computing 26(6):1955-1988, 2005 */
        double twosum(const double a, const double b, double &y){
            double xt,zt;
            xt=a+b;
            zt=xt-a;
            y=(a-(xt-zt)+(b-zt));
            return xt;
        }
        double fasttwosum(const double a, const double b, double &y){
            double xt=a+b;
            y=(a-xt)+b;
            return xt;
        }
    };

}}

#endif

