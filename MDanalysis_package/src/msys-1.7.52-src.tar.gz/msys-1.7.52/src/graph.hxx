/* 
Copyright 2012-2014, D. E. Shaw Research.
All rights reserved.

Redistribution and use in source and binary forms, with or without
modification, are permitted provided that the following conditions are
met:

* Redistributions of source code must retain the above copyright
  notice, this list of conditions, and the following disclaimer.

* Redistributions in binary form must reproduce the above copyright
  notice, this list of conditions, and the following disclaimer in the
  documentation and/or other materials provided with the distribution.

* Neither the name of D. E. Shaw Research nor the names of its
  contributors may be used to endorse or promote products derived from
  this software without specific prior written permission.

THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
"AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR
A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT
OWNER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,
SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT
LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE,
DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY
THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
(INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE
OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
*/
#ifndef desres_msys_graph_hxx
#define desres_msys_graph_hxx

#include "system.hxx"
#include <vector>
#include <map>
#include <boost/noncopyable.hpp>

namespace desres { namespace msys {

    /* Checks graph isomorphism for two sets of atoms */ 
    class Graph : boost::noncopyable {

    private:
        struct Node {
            int attr;   /* two bytes for atomic number, two for
                           degree (including external bonds) */
            int nnbr;   /* number of bonds within the template */
            int* nbr;   /* 0-based index of neighbors */
        };

        std::vector<Node> _nodes; /* nodes */
        std::vector<int> _nbrs;  /* storage for neighbors */
        IdList _ids; /* keep track of original IDs */
        SystemPtr _sys; /* keep track of original system */

        /* Helper functions for isomorphism match */
        static bool match_node(const Node& g, const Node& h,
                const std::vector<int>& GtoH, const std::vector<int>& HtoG,
                bool include_nnbr=true);
        bool match_common(const boost::shared_ptr<Graph> other, int this_root,
                int other_root, std::vector<IdPair>& matches) const;

        /* Constructor is private; must use create() function */
        Graph(SystemPtr sys, const IdList& atoms);

    public:

        typedef std::vector<IdPair> MatchList;

        /* string hash of attributes in the nodes of the graph */
        static std::string hash(SystemPtr sys, IdList const& atoms);

        /* construct an isomorphism topology using the given atoms.
         * Atoms outside the atom set count towards the degree of
         * the internal atoms but are also not part of the graph.
         * Atoms with atomic_number 0 are ignored. */
        static boost::shared_ptr<Graph> create(SystemPtr sys,
                const IdList& atoms);

        /* number of particles used in the isomorphism check */
        unsigned size() const { return _nodes.size(); }

        /* On success, return true and store a list of (this_id, other_id)
         * matched pairs in matches. Stored IDs are the original atom IDs
         * in the two systems, and external atoms (with atomic number 0) are not
         * included. */
        bool match(const boost::shared_ptr<Graph> other,
                MatchList& matches) const;

        /* Match under the constraint that atom this_root of this graph must
         * match atom other_root of other graph */
        bool match(const boost::shared_ptr<Graph> other, Id this_root,
                Id other_root, MatchList& matches) const;

        /* Find all permutations that match, returning the number of matches
         * and storing list of all matched permutations. If substructure is
         * true, will return matches of this graph to all matching subgraphs
         * of other without requiring that this graph and the other graph are of
         * the same size. */
        unsigned matchAll(const boost::shared_ptr<Graph> other,
                std::vector<MatchList>& matches, bool substructure=false) const;
        
        /* Ordering of atoms in the graph structure... Used in conjuntion with 
         * setNodeAttributes */
        IdList const& atoms() const {return _ids;}
        SystemPtr system() const {return _sys;}

        /* Overides the default node attribute (int) with user supplied value.
         * Must specify attributes for all atoms in the same order as returned 
         * from atoms() */      
        void setNodeAttributes(std::vector<int> const& newattr);
        
    };
    typedef boost::shared_ptr<Graph> GraphPtr;

}}

#endif
