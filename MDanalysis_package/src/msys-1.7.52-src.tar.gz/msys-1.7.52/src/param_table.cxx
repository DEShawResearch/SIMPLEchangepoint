/* 
Copyright 2012-2014, D. E. Shaw Research.
All rights reserved.

Redistribution and use in source and binary forms, with or without
modification, are permitted provided that the following conditions are
met:

* Redistributions of source code must retain the above copyright
  notice, this list of conditions, and the following disclaimer.

* Redistributions in binary form must reproduce the above copyright
  notice, this list of conditions, and the following disclaimer in the
  documentation and/or other materials provided with the distribution.

* Neither the name of D. E. Shaw Research nor the names of its
  contributors may be used to endorse or promote products derived from
  this software without specific prior written permission.

THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
"AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR
A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT
OWNER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,
SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT
LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE,
DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY
THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
(INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE
OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
*/
#include "param_table.hxx"
#include <stdexcept>
#include <sstream>
#include <string.h>
#include <cstdio>

using namespace desres::msys;

ParamTablePtr ParamTable::create() {
    return ParamTablePtr(new ParamTable);
}

ParamTable::ParamTable()
: _nrows(0)
{}

ParamTable::~ParamTable() {
    for (Id i=0; i<_props.size(); i++) {
        if (_props[i].type==StringType) {
            ValueList& vals=_props[i].vals;
            Id j,n = vals.size();
            for (j=0; j<n; j++) free(vals[j].s);
        }
    }
}

Id ParamTable::propIndex(const String& name) const {
    Id i,n = _props.size();
    for (i=0; i<n; i++) {
        if (_props[i].name==name) return i;
    }
    return BadId;
}

void ParamTable::Property::update_index() {
    for (Id i=maxIndexId; i<vals.size(); i++) {
        ValueRef r(type, vals[i]);
        index[r].push_back(i);
    }
    maxIndexId = vals.size();
}

void ParamTable::Property::extend() {
    Value v;
    memset(&v, 0, sizeof(v));
    vals.push_back(v);
}

Id ParamTable::addProp( const String& name, ValueType type) {
    Id index = propIndex(name);
    if (!bad(index)) {
        if (propType(index)!=type) {
            throw std::runtime_error("attempt to change type of prop");
        }
        return index;
    }

    _props.push_back(Property());
    Property& prop = _props.back();
    prop.name = name;
    prop.type = type;
    for (Id i=0; i<_nrows; i++) prop.extend();
    return _props.size()-1;
}

Id ParamTable::addParam() {
    for (Id i=0; i<_props.size(); i++) _props[i].extend();
    _paramrefs.push_back(0);
    return _nrows++;
}

void ParamTable::incref(Id p) {
    if (bad(p)) return;
    if (p>=_paramrefs.size()) {
        MSYS_FAIL("Could not incref param " << p << " in ParamTable of size " << _paramrefs.size());
    }
    ++_paramrefs[p];
}

void ParamTable::decref(Id p) {
    if (bad(p)) return;
    if (p>=_paramrefs.size()) {
        MSYS_FAIL("Invalid param " << p << " in ParamTable of size " << _paramrefs.size());
    }
    if (_paramrefs[p]==0) {
        MSYS_FAIL("param " << p << " already has refcount 0");
    }
    --_paramrefs[p];
}

Id ParamTable::duplicate(Id param) {
    if (bad(param)) return addParam();
    if (!hasParam(param)) {
        std::stringstream ss;
        ss << "ParamTable::duplicate: no such param " << param;
        throw std::runtime_error(ss.str());
    }
    Id dst = addParam();
    for (unsigned i=0; i<_props.size(); i++) {
        _props[i].vals[dst] = _props[i].vals[param];
        if (_props[i].type == StringType) {
            char* s = _props[i].vals[param].s;
            if (s) s=strdup(s);
            _props[i].vals[dst].s = s;
        }

    }
    return dst;
}

int ParamTable::compare(Id L, Id R) {
    if (!(hasParam(L) && hasParam(R))) {
        throw std::runtime_error("comparison of invalid param ids");
    }
    Id prop, nprops = propCount();
    for (prop=0; prop<nprops; prop++) {
        int c=value(L, prop).compare(value(R, prop));
        if (c<0) return -1;
        if (c>0) return  1;
    }
    return 0;
}

void ParamTable::delProp(Id index) {
    if (bad(index)) return;
    if (index>=_props.size()) {
        std::stringstream ss;
        ss << "delProp: no such index " << index;
        throw std::runtime_error(ss.str());
    }
    _props.erase(_props.begin()+index);
}

ValueRef ParamTable::value(Id row, String const& name)  { 
    Id col = propIndex(name);
    if (bad(col)) MSYS_FAIL("No such property '" << name << "'");
    return value(row, col);
}

IdList ParamTable::findInt(Id col, Int const& val) {
    Value v;
    v.i=val;
    ValueRef r(IntType, v);
    return findValue(col,r);
}

IdList ParamTable::findFloat(Id col, Float const& val) {
    Value v;
    v.f=val;
    ValueRef r(FloatType, v);
    return findValue(col,r);
}

IdList ParamTable::findString(Id col, String const& val) {
    Value v;
    v.s=const_cast<char *>(val.c_str());
    ValueRef r(StringType, v);
    return findValue(col,r);
}

IdList ParamTable::findValue(Id col, ValueRef const& v) {
    if (col>=_props.size()) {
        MSYS_FAIL("no such column " << col);
    }
    Property& prop = _props[col];
    prop.update_index();
    Property::Index::iterator p = prop.index.find(v);
    if (p==prop.index.end()) return IdList();
    return p->second;
}
