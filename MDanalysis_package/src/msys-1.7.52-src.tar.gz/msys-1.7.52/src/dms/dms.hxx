/* 
Copyright 2012-2014, D. E. Shaw Research.
All rights reserved.

Redistribution and use in source and binary forms, with or without
modification, are permitted provided that the following conditions are
met:

* Redistributions of source code must retain the above copyright
  notice, this list of conditions, and the following disclaimer.

* Redistributions in binary form must reproduce the above copyright
  notice, this list of conditions, and the following disclaimer in the
  documentation and/or other materials provided with the distribution.

* Neither the name of D. E. Shaw Research nor the names of its
  contributors may be used to endorse or promote products derived from
  this software without specific prior written permission.

THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
"AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR
A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT
OWNER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,
SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT
LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE,
DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY
THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
(INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE
OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
*/
#ifndef desres_msys_dms_dms_hxx 
#define desres_msys_dms_dms_hxx 

#include "../value.hxx"
#include <boost/shared_ptr.hpp>

struct sqlite3;
struct sqlite3_stmt;

namespace desres { namespace msys {

    class Reader;
    class Writer;

    class Sqlite {
        boost::shared_ptr<sqlite3> _db;

        const char* errmsg() const;

    public:
        Sqlite() {}

        Sqlite(boost::shared_ptr<sqlite3> db)
        : _db(db) {}

        static Sqlite read(std::string const& path);
        static Sqlite read_bytes(const char* bytes, int64_t len);
        static Sqlite write(std::string const& path);

        void exec(std::string const& sql);

        bool has(std::string const& table) const;
        int size(std::string const& table) const;
        Reader fetch(std::string const& table, bool strict_types=true) const;
        Writer insert(std::string const& table) const;
    };

    class Reader {
        boost::shared_ptr<sqlite3> _db;
        boost::shared_ptr<sqlite3_stmt> _stmt;
        std::string _table;

        typedef std::pair<std::string, ValueType> column_t;
        std::vector<column_t> _cols;
        bool _strict_types;

        const char* errmsg() const;

    public:
        Reader(boost::shared_ptr<sqlite3> db, std::string const& table,
               bool strict_types);
        bool strict_types() const { return _strict_types; }
        void next();
        bool done() const { return !_stmt; }
        operator bool() const { return !done(); }
        int size() const { return _cols.size(); }
        std::string name(int col) const;
        ValueType type(int col) const;
        int column(std::string const& name) const;
        int get_int(int col) const;
        double get_flt(int col) const;
        const char* get_str(int col) const;
    };

    class Writer {
        boost::shared_ptr<sqlite3> _db;
        boost::shared_ptr<sqlite3_stmt> _stmt;

    public:
        Writer(boost::shared_ptr<sqlite3> db, std::string const& table);
        void next();
        void bind_int(int col, int v);
        void bind_flt(int col, double v);
        void bind_str(int col, std::string const& v);
    };
}}

#endif
