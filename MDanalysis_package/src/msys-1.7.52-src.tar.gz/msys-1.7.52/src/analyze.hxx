/* 
Copyright 2012-2014, D. E. Shaw Research.
All rights reserved.

Redistribution and use in source and binary forms, with or without
modification, are permitted provided that the following conditions are
met:

* Redistributions of source code must retain the above copyright
  notice, this list of conditions, and the following disclaimer.

* Redistributions in binary form must reproduce the above copyright
  notice, this list of conditions, and the following disclaimer in the
  documentation and/or other materials provided with the distribution.

* Neither the name of D. E. Shaw Research nor the names of its
  contributors may be used to endorse or promote products derived from
  this software without specific prior written permission.

THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
"AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR
A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT
OWNER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,
SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT
LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE,
DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY
THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
(INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE
OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
*/
#ifndef desres_msys_analyze_hxx
#define desres_msys_analyze_hxx

#include "system.hxx"
#include <limits.h>

namespace desres { namespace msys {

    /* Assign bond order and formal charges to all fragments */
    void AssignBondOrderAndFormalCharge(SystemPtr mol);

    /* Assign bond order and formal charges to the given atoms, all
     * of which should belong to the same fragment (i.e. they should
     * all be connected by bonds).  If total_charge is not supplied,
     * it will be guessed. */
    void AssignBondOrderAndFormalCharge(SystemPtr mol,
                                        IdList const& atoms,
                                        int total_charge = INT_MAX);

    /* Compute topology ids.  FIXME definition please */
    IdList ComputeTopologicalIds(SystemPtr mol);

    /* Add bonds based on estimated VDW radii determined from atomic
     * number (Bondi radii). */
    void GuessBondConnectivity(SystemPtr mol);

    /* Find representative fragments representing the complete set of
     * topologically distinct fragments, as determined by atomic number. */
    IdList FindDistinctFragments(SystemPtr mol, MultiIdList const& fragments);

    /* Add hydrogens to the given parent atoms, assuming current bond order 
     * and formal charges are correct.  Returns the ids of the added 
     * hydrogens. */
    IdList AddHydrogens(SystemPtr mol, IdList const& parents);

    void GuessHydrogenPositions(SystemPtr mol, IdList const& hatoms);
}}

#endif
