/* 
Copyright 2012-2014, D. E. Shaw Research.
All rights reserved.

Redistribution and use in source and binary forms, with or without
modification, are permitted provided that the following conditions are
met:

* Redistributions of source code must retain the above copyright
  notice, this list of conditions, and the following disclaimer.

* Redistributions in binary form must reproduce the above copyright
  notice, this list of conditions, and the following disclaimer in the
  documentation and/or other materials provided with the distribution.

* Neither the name of D. E. Shaw Research nor the names of its
  contributors may be used to endorse or promote products derived from
  this software without specific prior written permission.

THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
"AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR
A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT
OWNER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,
SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT
LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE,
DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY
THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
(INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE
OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
*/
#ifndef desres_msys_annotated_system_hxx
#define desres_msys_annotated_system_hxx

#include "system.hxx"

namespace desres { namespace msys {

    class AnnotatedSystem :
        public boost::enable_shared_from_this<AnnotatedSystem> {

        private:
            struct atom_data_t {
                bool aromatic;
                unsigned char hcount;
                unsigned char valence;
                unsigned char degree;
                unsigned char lone_electrons;
                unsigned char ring_bonds;
                unsigned char hybridization;
                IdList rings_idx;

                atom_data_t() 
                : aromatic(), hcount(), valence(), degree(),
                  lone_electrons(), ring_bonds(), hybridization()
                {}
            };
            struct bond_data_t {
                bool aromatic;
                IdList rings_idx;

                bond_data_t()
                : aromatic()
                {}
            };
            struct ring_t {
                IdList atoms;
                IdList bonds;
            };
            struct ring_system_t {
                IdList atoms;
                IdList bonds;
                IdList rings;
            };

            SystemPtr _sys;
            std::vector<atom_data_t> _atoms;
            std::vector<bond_data_t> _bonds;
            std::vector<ring_t> _rings;
            std::vector<ring_system_t> _ring_systems;

            AnnotatedSystem(SystemPtr sys);

            /* Helper functions for constructor */
            void compute_ring_systems();
            bool is_aromatic(const IdList& atoms, const IdList& bonds);
            void compute_aromaticity();

        public:
            /* Create an annotated system. sys must have correct bond orders
             * and formal charges (assigned using AssignBondOrderAndFormalCharge
             * or otherwise) */
            static boost::shared_ptr<AnnotatedSystem> create(SystemPtr sys) {
                return boost::shared_ptr<AnnotatedSystem>(
                        new AnnotatedSystem(sys));
            }
            SystemPtr system() const { return _sys; }

            /* Is atom aromatic */
            bool atomAromatic(Id atom) const {
                return _atoms.at(atom).aromatic; }
            /* Number of attached hydrogens */
            int atomHcount(Id atom) const {
                return _atoms.at(atom).hcount; }
            /* Sum of bond orders of non-pseudo bonds */
            int atomValence(Id atom) const {
                return _atoms.at(atom).valence; }
            /* Total number of non-pseudo bonds */
            int atomDegree(Id atom) const {
                return _atoms.at(atom).degree; }
            int atomLoneElectrons(Id atom) const {
                return _atoms.at(atom).lone_electrons; }
            /* Hybridization (1 = sp, 2 = sp2, 3 = sp3, 4 = sp3d, etc.) */
            int atomHybridization(Id atom) const {
                return _atoms.at(atom).hybridization; }
            /* Total number of ring bonds */
            int atomRingBonds(Id atom) const {
                return _atoms.at(atom).ring_bonds; }
            /* Total number of rings */
            int atomRingCount(Id atom) const {
                return _atoms.at(atom).rings_idx.size(); }
            /* Is atom in ring of particular size */
            bool atomInRingSize(Id atom, unsigned size) const {
                BOOST_FOREACH(Id ring, _atoms.at(atom).rings_idx)
                    if (_rings.at(ring).atoms.size() == size) return true;
                return false;
            }
            /* SSSR rings containing this atom */
            void atomRings(Id atom, MultiIdList& rings) const {
                rings.clear();
                BOOST_FOREACH(Id ring, _atoms.at(atom).rings_idx)
                    rings.push_back(_rings.at(ring).atoms);
            }

            /* Is bond aromatic */
            bool bondAromatic(Id bond) const {
                return _bonds.at(bond).aromatic; }
            /* Total number of rings */
            int bondRingCount(Id bond) const {
                return _bonds.at(bond).rings_idx.size(); }
            bool bondInRingSize(Id bond, unsigned size) const {
                BOOST_FOREACH(Id ring, _bonds.at(bond).rings_idx)
                    if (_rings.at(ring).atoms.size() == size) return true;
                return false;
            }
            /* SSSR rings containing this bond */
            void bondRings(Id bond, MultiIdList& rings) const {
                rings.clear();
                BOOST_FOREACH(Id ring, _bonds.at(bond).rings_idx)
                    rings.push_back(_rings.at(ring).atoms);
            }

            /* All SSSR rings */
            int ringCount() const {
                return _rings.size(); }
            void rings(MultiIdList& rings) const {
                rings.clear();
                BOOST_FOREACH(const ring_t& ring, _rings)
                    rings.push_back(ring.atoms);
            }
    };
    typedef boost::shared_ptr<AnnotatedSystem> AnnotatedSystemPtr;
}}

#endif
