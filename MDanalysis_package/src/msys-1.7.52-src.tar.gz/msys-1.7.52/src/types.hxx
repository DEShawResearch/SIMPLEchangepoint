/* 
Copyright 2012-2014, D. E. Shaw Research.
All rights reserved.

Redistribution and use in source and binary forms, with or without
modification, are permitted provided that the following conditions are
met:

* Redistributions of source code must retain the above copyright
  notice, this list of conditions, and the following disclaimer.

* Redistributions in binary form must reproduce the above copyright
  notice, this list of conditions, and the following disclaimer in the
  documentation and/or other materials provided with the distribution.

* Neither the name of D. E. Shaw Research nor the names of its
  contributors may be used to endorse or promote products derived from
  this software without specific prior written permission.

THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
"AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR
A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT
OWNER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,
SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT
LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE,
DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY
THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
(INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE
OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
*/
#ifndef MOL_TYPES_HXX
#define MOL_TYPES_HXX

#include <string>
#include <set>
#include <vector>
#include <stdint.h>
#include <sstream>
#include <stdexcept>
#include <algorithm>

#include "version.hxx"

#ifdef _MSC_VER
#define MSYS_LOC __FILE__ << ":" << __LINE__ << "\n" << __FUNCSIG__
#else
#define MSYS_LOC __FILE__ << ":" << __LINE__ << "\n" << __PRETTY_FUNCTION__
#endif

namespace desres { namespace msys {

    typedef uint32_t Id;
    typedef int64_t  Int;
    typedef double   Float;
    typedef std::string String;
    typedef std::set<Id> IdSet;
    typedef std::vector<Id> IdList;
    typedef std::pair<Id,Id> IdPair;
    typedef std::vector<IdList> MultiIdList;

    static const Id BadId = -1;
    inline bool bad(const Id& id) { return id==BadId; }

    struct Failure : public std::exception {
        explicit Failure(std::string const& msg) throw() : _msg(msg) {}
        virtual ~Failure() throw() {}
        virtual const char* what() const throw() { return _msg.c_str(); }

    private:
        std::string _msg;
    };

    /* make the given container hold only unique elements in sorted order.
     * Return the number of non-unique elements (i.e. difference in size
     * between original and final container). */
    template <typename T>
    static Id sort_unique(T& t) {
        Id oldsize = t.size();
        std::sort(t.begin(), t.end());
        t.resize(std::unique(t.begin(), t.end()) - t.begin());
        return oldsize - t.size();
    }

    /* gettimeofday() */
    double now();

}}

#define MSYS_FAIL(args) do { \
    std::stringstream ss; \
    ss << args << "\nversion: " << MSYS_VERSION << "\nlocation: " << MSYS_LOC; \
    throw desres::msys::Failure(ss.str()); \
} while(0)

#endif
