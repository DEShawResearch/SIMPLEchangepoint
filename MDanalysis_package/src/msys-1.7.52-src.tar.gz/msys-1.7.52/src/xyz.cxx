/* 
Copyright 2012-2014, D. E. Shaw Research.
All rights reserved.

Redistribution and use in source and binary forms, with or without
modification, are permitted provided that the following conditions are
met:

* Redistributions of source code must retain the above copyright
  notice, this list of conditions, and the following disclaimer.

* Redistributions in binary form must reproduce the above copyright
  notice, this list of conditions, and the following disclaimer in the
  documentation and/or other materials provided with the distribution.

* Neither the name of D. E. Shaw Research nor the names of its
  contributors may be used to endorse or promote products derived from
  this software without specific prior written permission.

THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
"AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR
A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT
OWNER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,
SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT
LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE,
DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY
THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
(INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE
OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
*/
#include "xyz.hxx"
#include "elements.hxx"
#include "analyze.hxx"
#include <errno.h>
#include <stdio.h>
#include <boost/algorithm/string.hpp>
#include <fastjson/print.hxx>
#include <string.h>

namespace desres { namespace msys {

    void ExportXYZ( SystemPtr mol, std::string const& path ) {
        FILE* fd = fopen(path.c_str(), "wb");
        if (!fd) {
            MSYS_FAIL("Error opening '" << path << "' for writing: " << strerror(errno));
        }
        boost::shared_ptr<FILE> dtor(fd, fclose);
        char x[20], y[20], z[20];

        fprintf(fd, "%u\n", mol->atomCount());
        fprintf(fd, "%s\n", mol->name.c_str());
        for (Id i=0; i<mol->maxAtomId(); i++) {
            if (!mol->hasAtom(i)) continue;
            desres::fastjson::floatify(mol->atom(i).x, x);
            desres::fastjson::floatify(mol->atom(i).y, y);
            desres::fastjson::floatify(mol->atom(i).z, z);
            fprintf(fd, "%d %s %s %s\n", mol->atom(i).atomic_number, x, y, z);
        }
    }

    SystemPtr ImportXYZ( std::string const& path ) {
        FILE* fd = fopen(path.c_str(), "rb");
        if (!fd) {
            MSYS_FAIL("Error opening '" << path << "' for reading: " << strerror(errno));
        }
        boost::shared_ptr<FILE> dtor(fd, fclose);
        int natoms;
        char buf[256];

        /* read #atoms */
        if (!fgets(buf, sizeof(buf), fd) || sscanf(buf, "%d", &natoms)!=1) {
            MSYS_FAIL("Failed reading number of atoms in xyz file " << path);
        }

        SystemPtr mol = System::create();
        mol->addChain();
        mol->addResidue(0);
        mol->residue(0).resid = 1;
        for (int i=0; i<natoms; i++) mol->addAtom(0);

        /* read molecule name */
        if (!fgets(buf, sizeof(buf), fd)) {
            MSYS_FAIL("Failed reading molecule name in xyz file " << path);
        }
        mol->name = buf;
        boost::trim(mol->name);

        /* read atoms */
        for (int i=0; i<natoms; i++) {
            if (!fgets(buf, sizeof(buf), fd)) {
                MSYS_FAIL("Failed reading atom " << i+1 << " in xyz file " << path);
            }
            double x,y,z;
            char name[256];
            if (4!=sscanf(buf, "%s %lf %lf %lf", name, &x, &y, &z)) {
                MSYS_FAIL("Failed parsing atom " << i+1 << " in xyz file " << path);
            }
            atom_t& atom = mol->atom(i);
            atom.x = x;
            atom.y = y;
            atom.z = z;

            /* guess atomic number: if name is a number, assume it's the
             * atomic number; otherwise treat as element name. */
            if (isalpha(name[0])) {
                atom.atomic_number = ElementForAbbreviation(name);
                atom.name = name;
            } else {
                atom.atomic_number = atoi(name);
                atom.name = AbbreviationForElement(atom.atomic_number);
            }
        }

        GuessBondConnectivity(mol);
        mol->analyze();
        return mol;
    }

}}

