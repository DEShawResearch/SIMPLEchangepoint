/* 
Copyright 2012-2014, D. E. Shaw Research.
All rights reserved.

Redistribution and use in source and binary forms, with or without
modification, are permitted provided that the following conditions are
met:

* Redistributions of source code must retain the above copyright
  notice, this list of conditions, and the following disclaimer.

* Redistributions in binary form must reproduce the above copyright
  notice, this list of conditions, and the following disclaimer in the
  documentation and/or other materials provided with the distribution.

* Neither the name of D. E. Shaw Research nor the names of its
  contributors may be used to endorse or promote products derived from
  this software without specific prior written permission.

THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
"AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR
A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT
OWNER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,
SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT
LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE,
DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY
THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
(INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE
OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
*/
#include "inchi.hxx"
#include "clone.hxx"
#include "elements.hxx"
#include <string.h>

using namespace desres::msys;

#ifdef MSYS_WITHOUT_INCHI
InChI InChI::create(SystemPtr mol, unsigned options) {
    MSYS_FAIL("No InChI support");
}
String InChI::key() const {
    MSYS_FAIL("No InChI support");
}
#else

#include <inchi/inchi_api.h>

InChI InChI::create(SystemPtr mol, unsigned options) {

    if (mol->atomCount() >= 1024) {
        MSYS_FAIL("Too many atoms: " << mol->atomCount() << " >= 1024");
    }

    /* make the atoms contiguous */
    if (mol->maxAtomId() != mol->atomCount()) {
        mol = Clone(mol, mol->atoms());
    }

    inchi_Input  input[1];
    inchi_Output output[1];
    memset(input,0,sizeof(input));
    memset(output,0,sizeof(output));

    std::vector<inchi_Atom> atoms(mol->atomCount());

    for (Id i=0; i<mol->maxAtomId(); i++) {
        inchi_Atom& iatom = atoms[i];
        atom_t const& matom = mol->atom(i);

        iatom.x = matom.x;
        iatom.y = matom.y;
        iatom.z = matom.z;
        iatom.num_bonds = mol->bondCountForAtom(i);
        Id j=0;
        BOOST_FOREACH(Id b, mol->bondsForAtom(i)) {
            bond_t const& bond = mol->bond(b);
            iatom.neighbor[j] = bond.other(i);
            iatom.bond_type[j]= bond.order;
            ++j;
        }
        strcpy(iatom.elname, AbbreviationForElement(matom.atomic_number));
        iatom.charge = matom.formal_charge;
    }

    if (atoms.size()) input->atom = &atoms[0];
    input->num_atoms = atoms.size();

    std::string ioptions;
    if (options) {
        if (options & DoNotAddH) ioptions += " -DoNotAddH";
        if (options & SNon)      ioptions += " -SNon";
        if (options & FixedH)    ioptions += " -FixedH";

        input->szOptions = &ioptions[0];
    }

    int rc = GetINCHI(input, output);
    boost::shared_ptr<inchi_Output> dtor(output, FreeINCHI);

    if (!(rc==0 || rc==1)) {
        MSYS_FAIL("InChI failed: " << output->szMessage);
    }
    return InChI(rc, output->szInChI, output->szAuxInfo, output->szMessage);
}

String InChI::key() const {
    char buf[32];
    GetINCHIKeyFromINCHI(_string.c_str(), 0,0, buf, NULL, NULL);
    return buf;
}
#endif

