/* 
Copyright 2012-2014, D. E. Shaw Research.
All rights reserved.

Redistribution and use in source and binary forms, with or without
modification, are permitted provided that the following conditions are
met:

* Redistributions of source code must retain the above copyright
  notice, this list of conditions, and the following disclaimer.

* Redistributions in binary form must reproduce the above copyright
  notice, this list of conditions, and the following disclaimer in the
  documentation and/or other materials provided with the distribution.

* Neither the name of D. E. Shaw Research nor the names of its
  contributors may be used to endorse or promote products derived from
  this software without specific prior written permission.

THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
"AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR
A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT
OWNER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,
SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT
LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE,
DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY
THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
(INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE
OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
*/
#ifndef desres_msys_sssr_hxx
#define desres_msys_sssr_hxx

#include "system.hxx"

namespace desres { namespace msys {

    /* Find the smallest set of smallest rings for a fragment in a system.
     * The SSSR is not unique; if all_relevant is true, returns the union of 
     * all such sets. */
    MultiIdList GetSSSR(SystemPtr mol, IdList const& atoms,
            bool all_relevant=false);

    /* Partition the input rings into 'ring systems' such that members of
     * the same system are connected by shared bonds.  Single-ring systems
     * will be returned as well.  Return the list of ring systems. */
    MultiIdList RingSystems(SystemPtr mol, MultiIdList const& rings);

    /* Helper functions and data structures for SSSR determination, exposed here
     * for testing/debugging purposes */
    namespace SSSR {

        /* We index vertices of a graph as 0,...,n-1. We represent an edge as an
         * index pair, a graph as a list of edges and a vertex-edge adjacency
         * list, and a subgraph as an indicator vector over edges plus an
         * optional vertex list (used to store an ordered path). */
        typedef std::pair<int, int> Edge;
        struct GraphRepr {
            std::vector<Edge> edges;
            std::vector<std::vector<int> > v_to_e;
            int other(int edge, int vertex) const {
                return ((edges[edge].first == vertex)
                        ? edges[edge].second : edges[edge].first);
            }
        };
        struct Subgraph {
            std::vector<bool> edges;
            std::vector<int> vertex_list;
            Subgraph() {}
            Subgraph(unsigned size, bool value) :
                edges(size, value), vertex_list() {}
            bool operator<(const Subgraph& other) const {
                return (vertex_list < other.vertex_list)
                    || ((vertex_list == other.vertex_list)
                            && (edges < other.edges));
            }
        };

        void get_biconnected_components(const GraphRepr& graph,
                std::vector<GraphRepr>& components,
                std::vector<std::vector<int> >& components_idx);
        void get_subgraph_path(const GraphRepr& graph,
                const Subgraph& subgraph, int start, int end, Subgraph& path,
                Subgraph& path_no_clear);
        void get_odd_path(const GraphRepr& graph, const Subgraph& odd_edges,
                int start, int end, bool return_multiple, int max_length,
                std::vector<Subgraph>& paths);
        unsigned get_cycle_basis(const GraphRepr& graph,
                std::deque<Subgraph>& basis, std::deque<int>& pivots,
                std::vector<int>& non_pivots);
        void minimize_cycle_basis(const GraphRepr& graph,
                std::deque<Subgraph>& basis, const std::deque<int>& pivots,
                unsigned nfixed, const std::vector<int>& non_pivots,
                std::vector<Subgraph>& min_basis);
        void get_relevant_cycles(const GraphRepr& graph,
                std::vector<Subgraph>& min_basis, const std::deque<int>& pivots,
                const std::vector<int>& non_pivots,
                std::set<Subgraph>& relevant_cycles);
    }

}}

#endif 
