/* 
Copyright 2012-2014, D. E. Shaw Research.
All rights reserved.

Redistribution and use in source and binary forms, with or without
modification, are permitted provided that the following conditions are
met:

* Redistributions of source code must retain the above copyright
  notice, this list of conditions, and the following disclaimer.

* Redistributions in binary form must reproduce the above copyright
  notice, this list of conditions, and the following disclaimer in the
  documentation and/or other materials provided with the distribution.

* Neither the name of D. E. Shaw Research nor the names of its
  contributors may be used to endorse or promote products derived from
  this software without specific prior written permission.

THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
"AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR
A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT
OWNER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,
SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT
LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE,
DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY
THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
(INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE
OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
*/
#include "override.hxx"

using namespace desres::msys;

OverrideTable::OverrideTable(ParamTablePtr target)
: _target(target), _params(ParamTable::create()) {
}

OverrideTablePtr OverrideTable::create(ParamTablePtr target) {
    return OverrideTablePtr(new OverrideTable(target));
}

void OverrideTable::clear() {
    for (OverrideMap::const_iterator it=_map.begin(); it!=_map.end(); ++it) {
        _target->decref(it->first.first);
        _target->decref(it->first.second);
        _params->decref(it->second);
    }
    _map.clear();
}

void OverrideTable::resetParams(ParamTablePtr params) {
    clear();
    _params = params;
}

Id OverrideTable::get(IdPair params) const {
    if (params.first>params.second) std::swap(params.first, params.second);
    OverrideMap::const_iterator it=_map.find(params);
    if (it!=_map.end()) return it->second;
    return BadId;
}

void OverrideTable::del(IdPair params) {
    if (params.first>params.second) std::swap(params.first, params.second);
    OverrideMap::iterator it=_map.find(params);
    if (it!=_map.end()) {
        _target->decref(it->first.first);
        _target->decref(it->first.second);
        _params->decref(it->second);
        _map.erase(it);
    }
}

void OverrideTable::set(IdPair params, Id param) {
    if (!_target->hasParam(params.first) ||
        !_target->hasParam(params.second)) {
        MSYS_FAIL("Invalid params: " << params.first << ", " << params.second);
    }
    if (!_params->hasParam(param)) {
        MSYS_FAIL("Invalid override param " << param);
    }
    if (params.first>params.second) std::swap(params.first, params.second);
    std::pair<OverrideMap::iterator,bool> ret;
    ret = _map.insert(std::make_pair(params, param));
    OverrideMap::iterator it = ret.first;
    if (ret.second) {
        _target->incref(it->first.first);
        _target->incref(it->first.second);
    } else {
        _params->decref(it->second);
    }
    _params->incref(param);
    it->second = param;
}

Id OverrideTable::count() const {
    return _map.size();
}

std::vector<IdPair> OverrideTable::list() const {
    std::vector<IdPair> p;
    for (OverrideMap::const_iterator it=_map.begin(); it!=_map.end(); ++it) {
        p.push_back(it->first);
    }
    return p;
}

