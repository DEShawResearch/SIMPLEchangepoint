#!/usr/bin/env python

msys_version = '1.7.52'
if __name__=="__main__":
    print msys_version

