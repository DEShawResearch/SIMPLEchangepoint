/* 
Copyright 2012-2014, D. E. Shaw Research.
All rights reserved.

Redistribution and use in source and binary forms, with or without
modification, are permitted provided that the following conditions are
met:

* Redistributions of source code must retain the above copyright
  notice, this list of conditions, and the following disclaimer.

* Redistributions in binary form must reproduce the above copyright
  notice, this list of conditions, and the following disclaimer in the
  documentation and/or other materials provided with the distribution.

* Neither the name of D. E. Shaw Research nor the names of its
  contributors may be used to endorse or promote products derived from
  this software without specific prior written permission.

THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
"AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR
A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT
OWNER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,
SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT
LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE,
DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY
THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
(INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE
OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
*/
#ifndef desres_msys_elements_hxx
#define desres_msys_elements_hxx

namespace desres { namespace msys {

    int GuessAtomicNumber( double mass );
    const char* AbbreviationForElement(int anum);
    double MassForElement(int anum);

    int ElementForAbbreviationSlow(const char* abbr);

    inline int ElementForAbbreviation(const char* abbr) {
        const char c0 = *abbr;
        if (abbr[1]==0) switch (c0) { 
            case 'H': return 1;
            case 'C': return 6;
            case 'N': return 7;
            case 'O': return 8;
            case 'P': return 15;
            case 'S': return 16;
        };
        return ElementForAbbreviationSlow(abbr);
    }

    double RadiusForElement(int anum);

    int PeriodForElement(int anum);
    int GroupForElement(int anum);


    struct ChemData {
        float eneg;    // Electronegativities (Allen Scale)
        unsigned nValence;  // Number of valence electrons present in atom
        unsigned maxOct;    // max electrons for 'satisfied' octet (hypervalent>8)
        unsigned maxFree;   // max free (non-bonding) electron pairs allowed...
        unsigned maxCoord;  // max coordinated atoms (prevent over-bonding of 1-2 row elements)

        ChemData() 
        : eneg(), nValence(), maxOct(), maxFree(), maxCoord()
        {}

        ChemData(float const& e, unsigned const& v, unsigned const& o, 
                 unsigned const& f, unsigned const& c)
        : eneg(e), nValence(v), maxOct(o), maxFree(f), maxCoord(c)
        {}

        bool nodata() const { return eneg==0; }
    };

    /* return ChemData for the given atomic number, or invalid ChemData
     * (nodata()==true) if not available */
    ChemData const& DataForElement(int anum);
}}

#endif
