/* 
Copyright 2012-2014, D. E. Shaw Research.
All rights reserved.

Redistribution and use in source and binary forms, with or without
modification, are permitted provided that the following conditions are
met:

* Redistributions of source code must retain the above copyright
  notice, this list of conditions, and the following disclaimer.

* Redistributions in binary form must reproduce the above copyright
  notice, this list of conditions, and the following disclaimer in the
  documentation and/or other materials provided with the distribution.

* Neither the name of D. E. Shaw Research nor the names of its
  contributors may be used to endorse or promote products derived from
  this software without specific prior written permission.

THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
"AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR
A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT
OWNER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,
SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT
LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE,
DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY
THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
(INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE
OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
*/
#ifndef desres_msys_mae_ff_hxx
#define desres_msys_mae_ff_hxx

#include "sitemap.hxx"
#include "vdwmap.hxx"
#include "../term_table.hxx"
#include "../schema.hxx"
#include <stdexcept>
#include <sstream>
#include <boost/algorithm/string.hpp>

using namespace desres::msys;
using namespace desres::msys::mae;
using desres::fastjson::Json;

#define FFIO_ERROR( x ) do { \
    std::stringstream ss; \
    ss << x; \
    throw std::runtime_error(ss.str()); \
} while (0)

namespace desres { namespace msys { namespace mae { 

    using desres::fastjson::Json;

    struct Ffio {
        virtual ~Ffio() {}

        /* register an importer */
        static void put( const std::string& name, const Ffio * p );

        /* get importer for block, or NULL if none registered */
        static const Ffio* get( const std::string& name );

        /* if true, then the entire ffio_ff block is provided, not just
         * the block under which the importer is registered */
        virtual bool wants_all() const { return false; }

        virtual void apply( SystemPtr h,
                            const Json& blk, 
                            const SiteMap& sitemap,
                            const VdwMap&  vdwmap ) const = 0;
    };

    /* statically construct one of these for each plugin; e.g.,
     * namespace { RegisterFfio<VdwTypes> _("ffio_vdwtypes"); }
     */
    template <typename T>
    class RegisterFfio {
        Ffio * plugin;
    public:
        explicit RegisterFfio(const std::string& name ) {
            plugin = new T;
            Ffio::put( name, plugin );
        }
        ~RegisterFfio() { delete plugin; }
    };

    /* list of parameter values */
    typedef std::vector<double> ParamList;

    /* mae column names */
    typedef std::vector<std::string> StringList;

    /* mae columns */
    typedef std::vector<const Json *> ColumnList;

    /* This class supplies a hash on the actual parameter values for a
     * ParamTable, assuming they are all of FloatType. */
    class ParamMap {

        typedef std::map<ParamList, Id> ParamDict;

        ParamTablePtr   _params;        /* the tracked parameter table */
        ColumnList      _columns;       /* mae columns */
        ParamDict       _pdict;         /* map param values to param id */

    public:
        /* construct from param table, forcefield block, and names of the
         * columns to use for parameters.  If maecols is empty, then
         * "canonical" mae columns will be used, one for each property. */
        ParamMap( ParamTablePtr params, 
                  const Json& blk,
                  unsigned ncols,
                  const char** maecols );
        ParamMap( ParamTablePtr params, 
                  const Json& blk, 
                  bool alchemical=false);

        /* the parma table */
        ParamTablePtr params() const { return _params; }

        /* read the values from the given row in the forcefield block */
        Id add(int row);

        /* add a parameter with specified values not necessarily derived
         * from any row */
        Id add(const ParamList& param);
    };

    typedef boost::shared_ptr<ParamMap> ParamMapPtr;

}}}

#endif
