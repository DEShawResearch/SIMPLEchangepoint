/* 
Copyright 2012-2014, D. E. Shaw Research.
All rights reserved.

Redistribution and use in source and binary forms, with or without
modification, are permitted provided that the following conditions are
met:

* Redistributions of source code must retain the above copyright
  notice, this list of conditions, and the following disclaimer.

* Redistributions in binary form must reproduce the above copyright
  notice, this list of conditions, and the following disclaimer in the
  documentation and/or other materials provided with the distribution.

* Neither the name of D. E. Shaw Research nor the names of its
  contributors may be used to endorse or promote products derived from
  this software without specific prior written permission.

THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
"AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR
A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT
OWNER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,
SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT
LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE,
DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY
THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
(INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE
OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
*/
#include "maeatoms.hxx"
#include <cstdio>

using namespace desres::msys;
using namespace desres::msys::mae;
using desres::fastjson::Json;

MaeAtoms::MaeAtoms( const Json& blk) {

    _name = blk.get("__name__").as_string();
    _nrows = blk.get("__size__").as_int();
    const Json& pseudo = blk.get("ffio_index");
    if (pseudo.valid()) {
        _columns.push_back( &pseudo);
        if (_columns[0]->kind()!=Json::Array) {
            FFIO_ERROR("Bad ffio_index column in " << _name);
        }
    }
    for (int i=0; ; i++) {
        char colname[32];
        sprintf(colname, "ffio_a%c", 'i'+i);
        const Json& col = blk.get(colname);
        if (!col) break;
        if (col.kind()!=Json::Array) {
            FFIO_ERROR("Expected array for column " << colname 
                    << " in block " << _name << "; got " << col.kindstr());
        }
        _columns.push_back(&blk.get(colname));
    }
    _ids.resize(_columns.size());
    _ncols = _ids.size();
}

const IdList& MaeAtoms::ids(int row, int nsites) {
    if (row<0 || row>=_nrows) {
        FFIO_ERROR("Invalid row " << row << " for block " << _name);
    }
    if (nsites<0) nsites=_ncols;
    else if (nsites>_ncols) {
        FFIO_ERROR("Invalid nsites " << nsites << " > " << _ncols 
                << " in " << _name);
    }
    _ids.resize(nsites);
    for (int i=0; i<nsites; i++) {
        try {
            _ids[i] = _columns[i]->elem(row).as_int();
        }
        catch (std::exception& e) {
            const char * colname = _columns[i]->get("__name__").as_string();
            FFIO_ERROR("column " << colname << " row " << row 
                    << " is not an int");
        }
    }
    return _ids;
}

