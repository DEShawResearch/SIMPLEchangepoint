/* 
Copyright 2012-2014, D. E. Shaw Research.
All rights reserved.

Redistribution and use in source and binary forms, with or without
modification, are permitted provided that the following conditions are
met:

* Redistributions of source code must retain the above copyright
  notice, this list of conditions, and the following disclaimer.

* Redistributions in binary form must reproduce the above copyright
  notice, this list of conditions, and the following disclaimer in the
  documentation and/or other materials provided with the distribution.

* Neither the name of D. E. Shaw Research nor the names of its
  contributors may be used to endorse or promote products derived from
  this software without specific prior written permission.

THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
"AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR
A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT
OWNER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,
SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT
LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE,
DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY
THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
(INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE
OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
*/
#include "../maeatoms.hxx"
#include <cstdio>

namespace {

    void write_table( const Json& ff,
                      int cmapid,
                      SystemPtr h ) {

        char buf[32];
        sprintf(buf, "ffio_cmap%d", cmapid);
        const Json& blk = ff.get(buf);

        ParamTablePtr d(ParamTable::create());
        d->addProp("phi", FloatType);
        d->addProp("psi", FloatType);
        d->addProp("energy", FloatType);

        const Json& ai = blk.get("ffio_ai");
        const Json& aj = blk.get("ffio_aj");
        const Json& c1 = blk.get("ffio_c1");
        int i,n = blk.get("__size__").as_int();
        for (i=0; i<n; i++) {
            Id row = d->addParam();
            d->value(row,0)=ai.elem(i).as_float();
            d->value(row,1)=aj.elem(i).as_float();
            d->value(row,2)=c1.elem(i).as_float();
        }
        const char * name = buf+5;
        h->addAuxTable(name, d);
    }

    struct Cmap : public Ffio {

        virtual bool wants_all() const { return true; }

        void apply( SystemPtr h,
                    const Json& ff,
                    const SiteMap& sitemap,
                    const VdwMap& ) const {

            const Json& blk = ff.get("ffio_torsion_torsion");
            const Json& c1 = blk.get("ffio_c1");
            if (!c1) throw std::runtime_error(
                    "ffio_torsion_torsion missing ffio_c1");

            TermTablePtr table = AddTable(h,"torsiontorsion_cmap");
            ParamTablePtr params = table->params();
            MaeAtoms atoms(blk);
            std::map<int,Id> pmap;

            int i,n = blk.get("__size__").as_int();
            for (i=0; i<n; i++) {
                int cmapid = c1.elem(i).as_int();
                if (!pmap.count(cmapid)) {
                    Id param = params->addParam();
                    char val[32];
                    sprintf(val, "cmap%d", cmapid);
                    params->value(param,0)=val;
                    pmap[cmapid]=param;
                    write_table(ff, cmapid, h);
                }
                sitemap.addUnrolledTerms(table, pmap[cmapid], atoms.ids(i));
            }
        }
    };

    struct Dummy : public Ffio {

        void apply( SystemPtr h,
                    const Json& blk,
                    const SiteMap& sitemap,
                    const VdwMap& ) const {
        }
    };

    RegisterFfio<Cmap> _("ffio_torsion_torsion");
    RegisterFfio<Dummy> _1("ffio_cmap1");
    RegisterFfio<Dummy> _2("ffio_cmap2");
    RegisterFfio<Dummy> _3("ffio_cmap3");
    RegisterFfio<Dummy> _4("ffio_cmap4");
    RegisterFfio<Dummy> _5("ffio_cmap5");
    RegisterFfio<Dummy> _6("ffio_cmap6");
}

