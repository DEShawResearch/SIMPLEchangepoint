/* 
Copyright 2012-2014, D. E. Shaw Research.
All rights reserved.

Redistribution and use in source and binary forms, with or without
modification, are permitted provided that the following conditions are
met:

* Redistributions of source code must retain the above copyright
  notice, this list of conditions, and the following disclaimer.

* Redistributions in binary form must reproduce the above copyright
  notice, this list of conditions, and the following disclaimer in the
  documentation and/or other materials provided with the distribution.

* Neither the name of D. E. Shaw Research nor the names of its
  contributors may be used to endorse or promote products derived from
  this software without specific prior written permission.

THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
"AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR
A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT
OWNER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,
SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT
LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE,
DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY
THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
(INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE
OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
*/

#include <fastjson/fastjson.hxx>
#include "../istream.hxx"

/* Import an mae file into a json.  Both blocks and array blocks are 
 * represented as objects (dictionaries); array blocks are dictionaries
 * of lists, while regular blocks are dictionaries of atoms, arrays,
 * and other blocks.  Array blocks are distinguished from regular blocks
 * by the presence of a __size__ member.  The first block at the top level 
 * is the "meta" * block; the rest are "f_m_ct" blocks.  So we have 
 * something like:
 
 [
    { "m_m2io_version" : "2.0.0" },
    { "m_title" : "title in water",
      "chorus_box_ax" : 25.0,
      "m_atom" : {
        "__size__" : 3,
        "m_x_coord" : [ 1,2,3 ],
        "m_y_coord" : [ 4,5,6 ] },
      "ffio_ff" : {
        "ffio_name" : "OPLS",
        "ffio_vdwtypes" : {
            "__size__" : 2,
            "ffio_funct" : [ "LJ12_6_sig_epsilon", "LJ12_6_sig_epsilon"],
            "ff_c1" : [ 3.5, 2.5 ] }
        }
    }
]
     

 */

namespace desres { namespace msys { namespace mae {

    using fastjson::Json;

    void import_mae( std::istream& in, Json& js );
    void export_mae( const Json& js, std::ostream& out );

    struct tokenizer;

    class import_iterator {
        istream* in;
        tokenizer* tk;
        std::streamsize _offset;

    public:
        explicit import_iterator(std::istream& file);
        ~import_iterator();

        /* read the next ct block; return true on success or false on EOF */
        bool next(Json& js);
        std::streamsize offset() const { return _offset; }
    };

}}}

