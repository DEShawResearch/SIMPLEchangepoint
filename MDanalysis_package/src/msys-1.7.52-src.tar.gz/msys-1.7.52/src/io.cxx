/* 
Copyright 2012-2014, D. E. Shaw Research.
All rights reserved.

Redistribution and use in source and binary forms, with or without
modification, are permitted provided that the following conditions are
met:

* Redistributions of source code must retain the above copyright
  notice, this list of conditions, and the following disclaimer.

* Redistributions in binary form must reproduce the above copyright
  notice, this list of conditions, and the following disclaimer in the
  documentation and/or other materials provided with the distribution.

* Neither the name of D. E. Shaw Research nor the names of its
  contributors may be used to endorse or promote products derived from
  this software without specific prior written permission.

THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
"AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR
A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT
OWNER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,
SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT
LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE,
DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY
THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
(INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE
OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
*/
#include "io.hxx"
#include "atomsel/regex.hxx"
#include "dms.hxx"
#include "mae.hxx"
#include "pdb.hxx"
#include "amber.hxx"
#include "mol2.hxx"
#include "xyz.hxx"
#include "sdf.hxx"

#include <boost/algorithm/string.hpp>

using namespace desres::msys;

namespace {
    bool match(std::string const& path, std::string const& expr) {
        std::vector<std::string> endings;
        boost::split(endings, expr, boost::is_any_of(","));
        for (unsigned i=0; i<endings.size(); i++) {
            std::string p(".+\\.");
            p += endings[i];
            if (regex_match(path,atomsel::Regex(p))) {
                return true;
            }
        }
        return false;
    }

    bool match_web(std::string const& path) {
        return regex_match(path, atomsel::Regex("[0-9][a-z][a-z0-9][a-z0-9]"));
    }

    const char *format_names[] = {
        "UNRECOGNIZED",
        "DMS",
        "MAE",
        "PDB",
        "PARM7",
        "MOL2",
        "XYZ",
        "SDF",
        "WEBPDB"
    };

    class DefaultIterator : public LoadIterator {
        SystemPtr mol;
    public:
        DefaultIterator(std::string const& path, FileFormat format,
                        bool structure_only) {
            mol = LoadWithFormat(path, format, structure_only);
        }
        SystemPtr next() {
            /* returns original mol the first time, then NULL */
            SystemPtr ptr;
            ptr.swap(mol);
            return ptr;
        }
    };
}

namespace desres { namespace msys {

    FileFormat GuessFileFormat(std::string const& _path) {

        std::string path(_path);
        boost::to_lower(path);
        const char* DMS = "dms,dms.gz";
        const char* MAE = "mae,mae.gz,maegz,maeff,maeff.gz,cms,cms.gz";
        const char* PDB = "pdb";
        const char* PRM = "prmtop,prm7";
        const char* MOL2= "mol2";
        const char* XYZ = "xyz";
        const char* SDF = "sdf,sdf.gz,sdfgz";

        if (match(path, DMS)) return DmsFileFormat;
        if (match(path, MAE)) return MaeFileFormat;
        if (match(path, PDB)) return PdbFileFormat;
        if (match(path, PRM)) return ParmTopFileFormat;
        if (match(path,MOL2)) return Mol2FileFormat;
        if (match(path, XYZ)) return XyzFileFormat;
        if (match(path, SDF)) return SdfFileFormat;
        if (match_web(path))  return WebPdbFileFormat;
        return UnrecognizedFileFormat;
    }

    std::string FileFormatAsString(FileFormat format) {
        return format_names[format];
    }

    FileFormat FileFormatFromString(std::string const& name) {
        unsigned i,n = sizeof(format_names)/sizeof(format_names[0]);
        for (i=0; i<n; i++) {
            if (name==format_names[i]) {
                return FileFormat(i);
            }
        }
        return UnrecognizedFileFormat;
    }

    SystemPtr LoadWithFormat(std::string const& path, FileFormat format,
                             bool structure_only) {
        SystemPtr m;
        switch (format) {
            case DmsFileFormat: 
                m=ImportDMS(path, structure_only); 
                break;
            case MaeFileFormat: 
                m=ImportMAE(path, false, structure_only); 
                break;
            case PdbFileFormat: 
                m=ImportPDB(path); 
                break;
            case ParmTopFileFormat: 
                m=ImportPrmTop(path, structure_only); 
                break;
            case Mol2FileFormat: 
                m=ImportMol2(path); 
                break;
            case XyzFileFormat: 
                m=ImportXYZ(path); 
                break;
            case SdfFileFormat:
                m=ImportSdf(path);
                break;
            case WebPdbFileFormat:
                m=ImportWebPDB(path);
            default:
                ;
        }
        return m;
    }

    SystemPtr Load(std::string const& path, bool structure_only,
                   FileFormat* opt_format) {
        FileFormat format = GuessFileFormat(path);
        if (opt_format) *opt_format = format;
        return LoadWithFormat(path, format, structure_only);
    }

    LoadIteratorPtr LoadIterator::create(std::string const& path,
                                         bool structure_only,
                                         FileFormat* opt_format) {

        FileFormat format = opt_format ? *opt_format : UnrecognizedFileFormat;
        if (!format) format=GuessFileFormat(path);
        if (opt_format) *opt_format = format;
        switch(format) {
            default:
                return LoadIteratorPtr(
                        new DefaultIterator(path, format, structure_only));
            case Mol2FileFormat:
                    return Mol2Iterator(path);
            case MaeFileFormat:
                    return MaeIterator(path, structure_only);
            case SdfFileFormat:
                    return SdfIterator(path);
            case UnrecognizedFileFormat:
                MSYS_FAIL("Unable to determine format of '" << path << "'");
        }
    }

    void SaveWithFormat(SystemPtr mol, 
                        std::string const& path, 
                        Provenance const& prov,
                        FileFormat format,
                        unsigned flags) {

        switch (format) {
            case DmsFileFormat: 
                ExportDMS(mol, path, prov, 
                    ( flags & SaveOptions::Append ? DMSExport::Append : 0)
                  | (flags & SaveOptions::StructureOnly ? DMSExport::StructureOnly : 0)
                    );
                break;
            case MaeFileFormat: 
                ExportMAE(mol, path, prov, 
                      (flags & SaveOptions::Append ? MaeExport::Append : 0) 
                    | (flags & SaveOptions::StructureOnly ? MaeExport::StructureOnly : 0)
                    );
                break;
            case PdbFileFormat: 
                if (flags != 0) {
                    MSYS_FAIL("PDB export supports only default save option");
                }
                ExportPDB(mol, path);
                break;
            case ParmTopFileFormat: 
                MSYS_FAIL("PRM/TOP export not supported");
                break;
            case Mol2FileFormat: 
                ExportMol2(mol, path, prov,
                      (flags & SaveOptions::Append ? Mol2Export::Append : 0)
                    );
                break;
            case XyzFileFormat: 
                if (flags != 0) {
                    MSYS_FAIL("XYZ export supports only default save option");
                }
                ExportXYZ(mol, path);
                break;
            case SdfFileFormat:
                ExportSdf(mol, path,
                      (flags & SaveOptions::Append ? SdfExport::Append : 0)
                    );
                break;
            default:
                ;
        }
    }

    void Save(SystemPtr mol, 
              std::string const& path, 
              Provenance const& prov,
              unsigned flags) {
        FileFormat fmt = GuessFileFormat(path);
        if (fmt == UnrecognizedFileFormat) {
            MSYS_FAIL("Unable to determine format of '" << path << "'");
        }
        SaveWithFormat(mol, path, prov, fmt, flags);
    }


}}
