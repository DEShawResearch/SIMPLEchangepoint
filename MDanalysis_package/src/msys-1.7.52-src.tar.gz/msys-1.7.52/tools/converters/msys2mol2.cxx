/* 
Copyright 2012-2014, D. E. Shaw Research.
All rights reserved.

Redistribution and use in source and binary forms, with or without
modification, are permitted provided that the following conditions are
met:

* Redistributions of source code must retain the above copyright
  notice, this list of conditions, and the following disclaimer.

* Redistributions in binary form must reproduce the above copyright
  notice, this list of conditions, and the following disclaimer in the
  documentation and/or other materials provided with the distribution.

* Neither the name of D. E. Shaw Research nor the names of its
  contributors may be used to endorse or promote products derived from
  this software without specific prior written permission.

THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
"AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR
A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT
OWNER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,
SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT
LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE,
DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY
THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
(INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE
OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
*/
#include "io.hxx"
#include "analyze.hxx"
#include "mol2.hxx"
#include <cstdio>

using namespace desres::msys;

static bool assign_bondorder = true;
static bool assign_sybyltypes = true;

static void usage(FILE *fd) {
    fprintf(fd,
"**msys2mol2 input_file output.mol2**\n"
"\n"
"  Creates a mol2 file from the given input file.\n"
"\n"
"Options:\n"
"   -h, --help       show this help message and exit\n"
"   --preserve-bondorder\n"
"       By default, msys2mol2 will recompute bond orders using the\n"
"       AssignBondOrderAndFormalCharge function.  This option causes\n"
"       msys2mol2 to use whatever bond order information is already\n"
"       present in the file.\n"
"   --preserve-sybyltypes\n"
"       By default, msys2mol2 will assign sybyl types to each atom using\n"
"       the AssignSybylTypes function.  This option causes msys2mol2 to\n"
"       use the sybyl atom and bond types in the file.\n"
    );
}

void parse_cmdline( int *pargc, char ***pargv ) {
    int i,j=0;
                           
    for (i=0; i<pargc[0]; i++) {
        pargv[0][j] = pargv[0][i];
        if ( !strcmp(pargv[0][j], "-h") ||
             !strcmp(pargv[0][j], "--help")) {
            usage(stdout);
            exit(0);
        } else if ( !strcmp(pargv[0][j], "--preserve-bondorder")) {
            assign_bondorder = false;
        } else if ( !strcmp(pargv[0][j], "--preserve-sybyltypes")) {
            assign_sybyltypes = false;
        }  else {
            j++;
        }
    }
    pargc[0]=j;
    pargv[0][j]=NULL;
}

int main(int argc, char *argv[]) {
    parse_cmdline(&argc, &argv);
    if (argc!=3) {
        usage(stderr);
        exit(1);
    }
    SystemPtr h = Load(argv[1]);
    if (assign_bondorder)  AssignBondOrderAndFormalCharge(h);
    if (assign_sybyltypes) AssignSybylTypes(h);
    ExportMol2(h, argv[2], Provenance::fromArgs(argc,argv));
    return 0;
}
