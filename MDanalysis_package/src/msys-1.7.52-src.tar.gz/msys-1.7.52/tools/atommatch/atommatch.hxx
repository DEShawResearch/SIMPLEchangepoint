/* 
Copyright 2012-2014, D. E. Shaw Research.
All rights reserved.

Redistribution and use in source and binary forms, with or without
modification, are permitted provided that the following conditions are
met:

* Redistributions of source code must retain the above copyright
  notice, this list of conditions, and the following disclaimer.

* Redistributions in binary form must reproduce the above copyright
  notice, this list of conditions, and the following disclaimer in the
  documentation and/or other materials provided with the distribution.

* Neither the name of D. E. Shaw Research nor the names of its
  contributors may be used to endorse or promote products derived from
  this software without specific prior written permission.

THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
"AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR
A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT
OWNER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,
SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT
LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE,
DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY
THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
(INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE
OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
*/
#ifndef desres_msys_atommatch_hxx
#define desres_msys_atommatch_hxx

#include <msys/system.hxx>
#include <boost/shared_ptr.hpp>

namespace desres { namespace msys { namespace atommatch {

    /* Interface for a function that assigns numeric scores to isomorphisms
     * between biconnected components */
    struct ScoreFct {
        virtual double apply(SystemPtr mol1, const IdList& atoms1,
                SystemPtr mol2, const IdList& atoms2) const = 0;
        virtual ~ScoreFct() { }
    };
    typedef boost::shared_ptr<ScoreFct> ScoreFctPtr;

    /* AtomMatch
     *
     * Arguments:
     *   mol1 -- first system with a single molecule
     *   mol2 -- second system with a single molecule
     *   score_fct -- user-defined function to score component isomorphisms
     *   atom1 -- optional atom in mol1 that must be matched to atom2
     *   atom2 -- optional atom in mol2 that must be matched to atom1
     *
     * Returns:
     *   match -- list of ID pairs where the first ID is an atom in mol1 and
     *       the second is the matching atom in mol2
     *
     * This function returns the "best" isomorphism between subgraphs in mol1
     * and mol2, where "best" is determined by the following rules:
     * (1) Each subgraph is a union of complete biconnected components of the
     *     molecule (so we cannot match only part of a ring system).
     * (2) The match has the highest score among all possible subgraph matches,
     *     where the score of a match is the sum of scores over matching
     *     biconnected components as determined by 'score_fct'.
     * (3) Among multiple matches satisfying (2), the match contains the most
     *     matched atoms.
     * (4) Among multiple matches satisfying (3), the match minimizes RMSD
     *     between the matched atoms.
     *
     * Rules (1)-(3) are enforced exactly. As the number of matches that satisfy
     * rules (1)-(3) may increase exponentially in the number of
     * symmetries of the molecule, rule (4) is not enforced exactly but rather
     * is implemented by a heuristic search.
     */
    typedef std::vector<std::pair<int, int> > MatchList;
    void AtomMatch(SystemPtr mol1, SystemPtr mol2, ScoreFctPtr score_fct,
            MatchList& match, Id atom1=BadId, Id atom2=BadId);

}}}

#endif
