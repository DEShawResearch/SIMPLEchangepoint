/* 
Copyright 2012-2014, D. E. Shaw Research.
All rights reserved.

Redistribution and use in source and binary forms, with or without
modification, are permitted provided that the following conditions are
met:

* Redistributions of source code must retain the above copyright
  notice, this list of conditions, and the following disclaimer.

* Redistributions in binary form must reproduce the above copyright
  notice, this list of conditions, and the following disclaimer in the
  documentation and/or other materials provided with the distribution.

* Neither the name of D. E. Shaw Research nor the names of its
  contributors may be used to endorse or promote products derived from
  this software without specific prior written permission.

THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
"AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR
A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT
OWNER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,
SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT
LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE,
DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY
THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
(INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE
OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
*/
#include <boost/python.hpp>
#include <msys/version.hxx>
#include "atommatch.hxx"

using namespace desres::msys;
using namespace desres::msys::atommatch;
using namespace boost::python;

namespace {

    class ScoreFctPy : public ScoreFct {
        public:
            static ScoreFctPtr create(const object& py_apply) {
                return ScoreFctPtr(new ScoreFctPy(py_apply));
            }
            virtual double apply(SystemPtr mol1, const IdList& atoms1,
                    SystemPtr mol2, const IdList& atoms2) const {
                list L1;
                list L2;
                BOOST_FOREACH(Id id, atoms1) { L1.append(id); }
                BOOST_FOREACH(Id id, atoms2) { L2.append(id); }
                double output;
                try {
                    output = extract<double>(_py_apply(mol1, L1, mol2, L2));
                } catch (std::exception& e) {
                    MSYS_FAIL("Error calling Python function: " + std::string(e.what()));
                }
                return output;
            }
        private:
            ScoreFctPy(const object& py_apply) : _py_apply(py_apply) { }
            object _py_apply;
    };

    list atom_match(SystemPtr mol1, SystemPtr mol2, ScoreFctPtr rep, Id atom1, Id atom2) {
        MatchList match;
        AtomMatch(mol1, mol2, rep, match, atom1, atom2);
        list L;
        for (unsigned i = 0; i < match.size(); ++i)
            L.append(make_tuple(match[i].first, match[i].second));
        return L;
    }

}

BOOST_PYTHON_MODULE(_atommatch) {
    boost::python::def("AtomMatch", atom_match);
    class_<ScoreFct, ScoreFctPtr, boost::noncopyable>("ScoreFct", no_init)
        .def("__init__", make_constructor(&ScoreFctPy::create))
        .def("apply", &ScoreFctPy::apply)
        ;
}
