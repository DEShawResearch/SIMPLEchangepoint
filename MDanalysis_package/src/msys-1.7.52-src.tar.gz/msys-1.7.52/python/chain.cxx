/* 
Copyright 2012-2014, D. E. Shaw Research.
All rights reserved.

Redistribution and use in source and binary forms, with or without
modification, are permitted provided that the following conditions are
met:

* Redistributions of source code must retain the above copyright
  notice, this list of conditions, and the following disclaimer.

* Redistributions in binary form must reproduce the above copyright
  notice, this list of conditions, and the following disclaimer in the
  documentation and/or other materials provided with the distribution.

* Neither the name of D. E. Shaw Research nor the names of its
  contributors may be used to endorse or promote products derived from
  this software without specific prior written permission.

THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
"AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR
A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT
OWNER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,
SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT
LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE,
DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY
THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
(INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE
OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
*/
#include "wrap_obj.hxx"

namespace {
    list ct_keys(component_t& ct) {
        list L;
        BOOST_FOREACH(String const& key, ct.keys()) {
            L.append(key);
        }
        return L;
    }
    object ct_get(component_t& ct, String const& key) {
        if (!ct.has(key)) {
            PyErr_Format(PyExc_KeyError, "No property '%s' in ct", key.c_str());
            throw_error_already_set();
        }
        return from_value_ref(ct.value(key));
    }

    void ct_add(component_t& ct, String const& key, object obj) {
        ct.add(key,as_value_type(obj));
    }

    void ct_set(component_t& ct, String const& key, object obj) {
        to_value_ref(obj, ct.value(key));
    }
    
    PyObject* ct_type(component_t& ct, String const& key) {
        if (!ct.has(key)) {
            Py_INCREF(Py_None);
            return Py_None;
        }
        return from_value_type(ct.type(key));
    }
}

namespace desres { namespace msys { 

    void export_chain() {

        class_<chain_t>("chain_t", no_init)
            .def_readonly("ct", &chain_t::ct)
            .def_readwrite("name", &chain_t::name)
            .def_readwrite("segid", &chain_t::segid)
            ;

        class_<component_t>("component_t", no_init)
            .add_property("name", &component_t::name, &component_t::setName)
            .def("keys",ct_keys)
            .def("get", ct_get)
            .def("add", ct_add)
            .def("set", ct_set)
            .def("type", ct_type)
            ;
    }
}}

