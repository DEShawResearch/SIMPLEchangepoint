/* 
Copyright 2012-2014, D. E. Shaw Research.
All rights reserved.

Redistribution and use in source and binary forms, with or without
modification, are permitted provided that the following conditions are
met:

* Redistributions of source code must retain the above copyright
  notice, this list of conditions, and the following disclaimer.

* Redistributions in binary form must reproduce the above copyright
  notice, this list of conditions, and the following disclaimer in the
  documentation and/or other materials provided with the distribution.

* Neither the name of D. E. Shaw Research nor the names of its
  contributors may be used to endorse or promote products derived from
  this software without specific prior written permission.

THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
"AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR
A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT
OWNER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,
SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT
LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE,
DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY
THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
(INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE
OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
*/
#include "wrap_obj.hxx"

using namespace boost::python;

namespace desres { namespace msys {

    /* TODO: make a to-python converter instead */
    object from_value_ref(const ValueRef& val) {
        if (val.type()==IntType) return object(val.asInt());
        if (val.type()==FloatType) return object(val.asFloat());
        if (val.type()==StringType) return object(val.asString());
        return object();
    }

    /* TODO: make a from-python converter instead */
    void to_value_ref(object& obj, ValueRef val) {
        if (val.type()==IntType) val.fromInt(extract<Int>(obj));
        if (val.type()==FloatType) val.fromFloat(extract<Float>(obj));
        if (val.type()==StringType) val.fromString(extract<String>(obj));
    }

    ValueType as_value_type(object& typeobj) {
        ValueType type = IntType;   /* silence compiler warning */
        if ((char *)typeobj.ptr()==(char *)&PyFloat_Type) {
            type=FloatType;
        } else if ((char *)typeobj.ptr()==(char *)&PyInt_Type) {
            type=IntType;
        } else if ((char *)typeobj.ptr()==(char *)&PyString_Type) {
            type=StringType;
        } else {
            PyErr_Format(PyExc_ValueError,
                    "Expected int, float or string as type argument");
            throw_error_already_set();
        }
        return type;
    }

    PyObject* from_value_type(ValueType type) {
        PyTypeObject* typeobj=NULL;
        switch (type) {
            case IntType: typeobj=&PyInt_Type; break;
            case FloatType: typeobj=&PyFloat_Type; break;
            case StringType: typeobj=&PyString_Type; break;
            default: throw std::runtime_error("unrecognized type");
        }
        PyObject* obj = (PyObject*)typeobj;
        Py_INCREF(obj);
        return obj;
    }

}}

