/* 
Copyright 2012-2014, D. E. Shaw Research.
All rights reserved.

Redistribution and use in source and binary forms, with or without
modification, are permitted provided that the following conditions are
met:

* Redistributions of source code must retain the above copyright
  notice, this list of conditions, and the following disclaimer.

* Redistributions in binary form must reproduce the above copyright
  notice, this list of conditions, and the following disclaimer in the
  documentation and/or other materials provided with the distribution.

* Neither the name of D. E. Shaw Research nor the names of its
  contributors may be used to endorse or promote products derived from
  this software without specific prior written permission.

THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
"AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR
A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT
OWNER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,
SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT
LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE,
DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY
THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
(INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE
OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
*/
#include "wrap_obj.hxx"
#include "term_table.hxx"
#include "override.hxx"

using namespace desres::msys;

namespace {

    Id add_term(TermTable& table, object atoms, object param) {
        Id id=BadId;
        if (param.ptr()!=Py_None) id=extract<Id>(param);
        list L(atoms);
        IdList ids(len(L));
        for (unsigned i=0; i<ids.size(); i++) ids[i]=extract<Id>(L[i]);
        return table.addTerm(ids, id);
    }

    void set_param(TermTable& table, Id term, object param) {
        Id id=BadId;
        if (param.ptr()!=Py_None) id=extract<Id>(param);
        table.setParam(term,id);
    }

    PyObject* term_prop_type(TermTable& table, Id col) {
        return from_value_type(table.termPropType(col));
    }
    Id add_term_prop( TermTable& table, String const& name, object type ) {
        return table.addTermProp(name, as_value_type(type));
    }

    /* TODO: permit col to be provided as string */
    object get_term_prop(TermTable& p, Id row, Id col) {
        return from_value_ref(p.termPropValue(row,col));
    }
    void set_term_prop(TermTable& p, Id row, Id col, object newval) {
        to_value_ref(newval, p.termPropValue(row,col));
    }

    object get_prop(TermTable& p, Id row, Id col) {
        return from_value_ref(p.propValue(row,col));
    }
    void set_prop(TermTable& p, Id row, Id col, object newval) {
        to_value_ref(newval, p.propValue(row,col));
    }
}

namespace desres { namespace msys { 

    void export_term() {

        enum_<Category>("Category")
            .value("none", NO_CATEGORY)
            .value("bond", BOND)
            .value("constraint", CONSTRAINT)
            .value("virtual", VIRTUAL)
            .value("polar", POLAR)
            .value("nonbonded", NONBONDED)
            .value("exclusion", EXCLUSION)
            ;

        def("parse_category", parse);
        def("print_category", print);

        class_<TermTable, TermTablePtr>("TermTablePtr", no_init)
            .def("__eq__",      list_eq<TermTablePtr>)
            .def("__ne__",      list_ne<TermTablePtr>)
            .def("__hash__",    obj_hash<TermTablePtr>)
            .def("destroy",     &TermTable::destroy)
            .def("system",      &TermTable::system)
            .def("atomCount",   &TermTable::atomCount)
            .def("termCount",   &TermTable::termCount)
            .def_readwrite("category", &TermTable::category)
            .def("name",        &TermTable::name)
            .def("rename",      &TermTable::rename)
            .def("terms",       &TermTable::terms)
            .def("addTerm",     add_term)
            .def("hasTerm",     &TermTable::hasTerm)
            .def("delTerm",     &TermTable::delTerm)
            .def("atoms",       &TermTable::atoms)
            .def("atom",        &TermTable::atom)
            .def("params",      &TermTable::params)
            .def("param",       &TermTable::param)
            .def("setParam",    set_param)

            /* param properties */
            .def("getProp",     get_prop)
            .def("setProp",     set_prop)

            /* term properties */
            .def("termPropCount",&TermTable::termPropCount)
            .def("termPropName", &TermTable::termPropName)
            .def("termPropIndex",&TermTable::termPropIndex)
            .def("termPropType", term_prop_type)
            .def("addTermProp",  add_term_prop)
            .def("delTermProp",  &TermTable::delTermProp)
            .def("getTermProp",  get_term_prop)
            .def("setTermProp",  set_term_prop)

            /* lookup terms based on atom */
            .def("delTermsWithAtom",    &TermTable::delTermsWithAtom)
            .def("findWithAll", &TermTable::findWithAll)
            .def("findWithAny", &TermTable::findWithAny)
            .def("findWithOnly",&TermTable::findWithOnly)
            .def("findExact",   &TermTable::findExact)

            /* coalesce */
            .def("coalesce",    &TermTable::coalesce)

            /* overrides */
            .def("overrides",   &TermTable::overrides)

            /* misc */
            .def("resetParams", &TermTable::resetParams)
            ;
    }

}}
