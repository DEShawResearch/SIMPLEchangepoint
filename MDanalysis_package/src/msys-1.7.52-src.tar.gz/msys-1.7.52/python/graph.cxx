/* 
Copyright 2012-2014, D. E. Shaw Research.
All rights reserved.

Redistribution and use in source and binary forms, with or without
modification, are permitted provided that the following conditions are
met:

* Redistributions of source code must retain the above copyright
  notice, this list of conditions, and the following disclaimer.

* Redistributions in binary form must reproduce the above copyright
  notice, this list of conditions, and the following disclaimer in the
  documentation and/or other materials provided with the distribution.

* Neither the name of D. E. Shaw Research nor the names of its
  contributors may be used to endorse or promote products derived from
  this software without specific prior written permission.

THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
"AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR
A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT
OWNER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,
SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT
LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE,
DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY
THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
(INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE
OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
*/
#include "wrap_obj.hxx"
#include "graph.hxx"

using namespace desres::msys;

namespace {

    std::string hash(Graph const& self) {
        return Graph::hash(self.system(), self.atoms());
    }

    object match(Graph const& self, GraphPtr other) {
        std::vector<IdPair> matches;
        if (self.match(other, matches)) {
            list L;
            BOOST_FOREACH(IdPair const& p, matches) {
                L.append(make_tuple(p.first, p.second));
            }
            return L;
        }
        return object();
    }

    object matchAll(Graph const& self, GraphPtr other, bool substructure) {
        std::vector<std::vector<IdPair> > matches;
        self.matchAll(other, matches, substructure);
        list outer_L;
        BOOST_FOREACH(std::vector<IdPair> const& v, matches) {
            list L;
            BOOST_FOREACH(IdPair const& p, v)
                L.append(make_tuple(p.first, p.second));
            outer_L.append(L);
        }
        return outer_L;
    }
}

namespace desres { namespace msys { 

    void export_graph() {

        class_<Graph, GraphPtr, boost::noncopyable>("GraphPtr", no_init)
            .def("__eq__",      list_eq<GraphPtr>)
            .def("__ne__",      list_ne<GraphPtr>)
            .def("__hash__",    obj_hash<GraphPtr>)
            .def("create",  &Graph::create).staticmethod("create")
            .def("hash", hash)
            .def("size", &Graph::size)
            .def("atoms", &Graph::atoms, return_const())
            .def("system", &Graph::system)
            .def("match", match)
            .def("matchAll", matchAll)
            ;
    }
}}

