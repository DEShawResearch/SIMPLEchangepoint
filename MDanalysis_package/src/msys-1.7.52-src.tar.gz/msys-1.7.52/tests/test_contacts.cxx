/* 
Copyright 2012-2014, D. E. Shaw Research.
All rights reserved.

Redistribution and use in source and binary forms, with or without
modification, are permitted provided that the following conditions are
met:

* Redistributions of source code must retain the above copyright
  notice, this list of conditions, and the following disclaimer.

* Redistributions in binary form must reproduce the above copyright
  notice, this list of conditions, and the following disclaimer in the
  documentation and/or other materials provided with the distribution.

* Neither the name of D. E. Shaw Research nor the names of its
  contributors may be used to endorse or promote products derived from
  this software without specific prior written permission.

THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
"AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR
A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT
OWNER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,
SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT
LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE,
DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY
THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
(INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE
OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
*/
#include "contacts.hxx"
#include "io.hxx"

using namespace desres::msys;

struct Output {
    bool exclude(Id i, Id j) const { return false; }
    void operator()(Id i, Id j, double r2) const {
        printf("%u %u %8.3f\n", i, j, sqrt(r2));
    }
};

int main(int argc, char *argv[]) {
    for (int arg=1; arg<argc; arg++) {
        const char* path = argv[arg];
        printf("%s\n", path);
        SystemPtr mol = Load(path);
        Id i,n = mol->atomCount();
        if (!n) continue;
        std::vector<double> pos(3*n);
        IdList A, B;
        for (i=0; i<3; i++) {
            //A.push_back(i);
            //B.push_back(i+3);
        }
        A.push_back(3030);
        B.push_back(4679);
        for (i=0; i<n; i++) {
            memcpy(&pos[3*i], &mol->atom(i).x, 3*sizeof(double));
        }
        printf("  NON-PERIODIC\n");
        find_contacts(12.0, &pos[0], (Float *)NULL,
                A.begin(), A.end(), B.begin(), B.end(), Output());
        printf("  PERIODIC\n");
        find_contacts(12.0, &pos[0], mol->global_cell[0], 
                A.begin(), A.end(), B.begin(), B.end(), Output());
    }
    return 0;
}

