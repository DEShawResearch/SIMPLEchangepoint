/* 
Copyright 2012-2014, D. E. Shaw Research.
All rights reserved.

Redistribution and use in source and binary forms, with or without
modification, are permitted provided that the following conditions are
met:

* Redistributions of source code must retain the above copyright
  notice, this list of conditions, and the following disclaimer.

* Redistributions in binary form must reproduce the above copyright
  notice, this list of conditions, and the following disclaimer in the
  documentation and/or other materials provided with the distribution.

* Neither the name of D. E. Shaw Research nor the names of its
  contributors may be used to endorse or promote products derived from
  this software without specific prior written permission.

THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
"AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR
A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT
OWNER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,
SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT
LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE,
DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY
THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
(INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE
OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
*/
#include "param_table.hxx"
#include <assert.h>
#include <stdio.h>

using namespace desres::msys;

int main(int argc, char *argv[]) {

    ParamTablePtr p = ParamTable::create();

    assert(p->paramCount()==0); assert(p->propCount()==0);

    /* add some properties */
    p->addProp("fc", FloatType);
    Id r0=p->addProp("r0", FloatType);
    r0=p->addProp("r0", FloatType);
    p->addProp("foo", IntType);

    assert(p->paramCount()==0);
    assert(p->propCount()==3);

    /* instantiate some params */
    Id param = p->addParam();
    assert(param==0);
    assert(p->propType(0)==FloatType);
    assert(p->propType(1)==FloatType);
    assert(p->propType(2)==IntType);
    assert(p->propName(0)=="fc");
    assert(p->propName(1)=="r0");
    assert(p->propName(2)=="foo");

    bool caught=false;
    try {
        p->value(0,"fcx");
    } catch (Failure& e) {
        caught=true;
    } 
    assert(caught);

    assert(p->value(param,0).asFloat()==0.0);
    assert(p->value(param,r0).asFloat()==0.0);
    assert(p->value(param,2).asFloat()==0.0);
    assert(p->value(param,2).asInt()==0.0);

    assert(p->value(param,0)==p->value(param,0));

    p->value(param,0).fromFloat(435.5);
    assert(p->value(param,0).asFloat()==435.5);

    p->value(param,0).fromInt(200);

    assert(p->value(param,0).asFloat()==200);
    assert(p->value(param,0)==200);
    assert(p->value(param,0)==200.);
    assert(p->value(param,0)==200.f);

    ValueRef ref = p->value(param,0);
    assert(ref==200);

    /* check that our refs aren't invalidated by additions */
    for (int i=0; i<1000; i++) p->addParam();
    assert(p->value(param,0)==200);
    assert(ref==200);

    for (int i=0; i<100; i++) {
        char buf[32];
        sprintf(buf, "%d", i);
        p->addProp(buf, StringType);
    }
    assert(p->value(param,0)==200);
    assert(ref==200);

    assert(p->value(param,0)!=201.f);

    /* test direct assignment */
    p->value(param,0)=32;
    assert(p->value(param,0)==32);

    return 0;
}
