/* 
Copyright 2012-2014, D. E. Shaw Research.
All rights reserved.

Redistribution and use in source and binary forms, with or without
modification, are permitted provided that the following conditions are
met:

* Redistributions of source code must retain the above copyright
  notice, this list of conditions, and the following disclaimer.

* Redistributions in binary form must reproduce the above copyright
  notice, this list of conditions, and the following disclaimer in the
  documentation and/or other materials provided with the distribution.

* Neither the name of D. E. Shaw Research nor the names of its
  contributors may be used to endorse or promote products derived from
  this software without specific prior written permission.

THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
"AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR
A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT
OWNER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,
SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT
LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE,
DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY
THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
(INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE
OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
*/
#include "value.hxx"
#include <string.h>
#include <assert.h>
#include <cstdlib>

using namespace desres::msys;

int main() {

    Int i1=1;
    Float f1=1;
    char* s1 = strdup("1");

    Int i2=2;
    Float f2=1.5;
    char* s2 = strdup("1.5");

    Value vi1, vf1, vs1;
    vi1.i=i1;
    vf1.f=f1;
    vs1.s=s1;

    Value vi2, vf2, vs2;
    vi2.i=i2;
    vf2.f=f2;
    vs2.s=s2;

    ValueRef ri1(IntType, vi1);
    ValueRef rf1(FloatType, vf1);
    ValueRef rs1(StringType, vs1);

    ValueRef ri2(IntType, vi2);
    ValueRef rf2(FloatType, vf2);
    ValueRef rs2(StringType, vs2);


    /* self equivalence */
    assert(ri1==ri1);
    assert(rf1==rf1);
    assert(rs1==rs1);

    /* comparison */
    assert(ri1!=ri2);
    assert(rf1!=rf2);
    assert(rs1!=rs2);

    /* ints and floats interconvert */
    assert(rf1==ri1);
    assert(ri1==rf1);

    assert(ri1!=rf2);
    assert(rf1!=ri2);
    assert(rf2!=ri1);
    assert(ri2!=rf1);

    /* strings don't interconvert */
    assert(rs1!=ri1);
    assert(ri1!=rs1);
    assert(rs1!=rf1);
    assert(rf1!=rs1);

    free(s1);
    free(s2);
    return 0;
}
