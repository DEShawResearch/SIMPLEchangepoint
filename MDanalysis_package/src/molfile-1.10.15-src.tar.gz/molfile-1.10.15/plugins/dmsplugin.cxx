/*
Copyright 2009, D. E. Shaw Research, LLC
All rights reserved.

Redistribution and use in source and binary forms, with or without
modification, are permitted provided that the following conditions are
met:

* Redistributions of source code must retain the above copyright
  notice, this list of conditions, and the following disclaimer.

* Redistributions in binary form must reproduce the above copyright
  notice, this list of conditions, and the following disclaimer in the
  documentation and/or other materials provided with the distribution.

* Neither the name of D. E. Shaw Research, LLC nor the names of its
  contributors may be used to endorse or promote products derived from
  this software without specific prior written permission.

THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
"AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR
A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT
OWNER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,
SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT
LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE,
DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY
THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
(INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE
OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.

*/

#include "molfile_plugin.h"
#include "periodic_table.h"

#include <sqlite3.h>

#include <ctype.h> /* for isspace() */
#include <stdio.h>
#include <stdlib.h>
#include <math.h>
#include <string.h>
#include <vector>
#include <map>

#if defined(DESRES_READ_TIMESTEP2)

#include <sstream>
#include <boost/shared_ptr.hpp>
#include <boost/scoped_ptr.hpp>

#include <boost/iostreams/filtering_stream.hpp>
#include <boost/iostreams/filter/gzip.hpp>

#include <sys/stat.h>
#include <fcntl.h>
#include <errno.h>

namespace bio = boost::iostreams;

#define THROW_FAILURE( args ) do { \
    std::stringstream ss; \
    ss << args; \
    throw std::runtime_error(ss.str()); \
} while (0)

namespace {
    struct dms_file : sqlite3_file {
        char * contents;
        sqlite3_int64 size;
        char * path;
    };

    /* sqlite seems to ignore the return value from this function!  Hence
     * we throw an exception on I/O error */
    int dms_xClose(sqlite3_file *file) {
        dms_file *dms = (dms_file *)file;

        /* ensure the contents get freed even if we throw */
        boost::shared_ptr<char> cp;
        if (dms->contents) cp.reset(dms->contents, free);

        /* if path is non-NULL, we need to write the contents */
        if (dms->path) {
            boost::shared_ptr<char> pp(dms->path, free);
            int fd=open(dms->path, O_WRONLY | O_CREAT, 0644);
            if (fd<0 ||
                write(fd, dms->contents, dms->size)!=dms->size ||
                close(fd)!=0) {
                THROW_FAILURE("Error writing file '" 
                        << std::string(dms->path) << "': "
                        << std::string(strerror(errno)));
            }
        }
        return SQLITE_OK;
    }

    int dms_xRead(sqlite3_file *file, void *pBuf, int iAmt, sqlite3_int64 offset) {
        dms_file *dms = (dms_file *)file;
        const char *ptr = dms->contents;
        sqlite3_int64 size=dms->size;

        int max=size-offset;  // max allowable read
        if (max<0) max=0;
        int amt=iAmt < max ? iAmt : max;
        memcpy(pBuf, ptr+offset, amt);
        if (amt < max) return SQLITE_OK;
        /* Unread parts of the buffer must be zero-filled */
        memset(&((char *)pBuf)[amt], 0, amt-max);
        return SQLITE_IOERR_SHORT_READ;
    }

    int dms_xWrite(sqlite3_file*file, const void*pBuf, int iAmt, sqlite3_int64 offset) {
        dms_file *dms = (dms_file *)file;
        sqlite3_int64 last=offset+iAmt;
        if (dms->size < last) {
            dms->contents = (char *)realloc(dms->contents, last);
            dms->size = last;
        }
        memcpy(dms->contents+offset, pBuf, iAmt);
        return SQLITE_OK;
    }

    int dms_xLock(sqlite3_file*file, int lockType) {
        return SQLITE_OK;
    }
    int dms_xUnlock(sqlite3_file*file, int) {
        return SQLITE_OK;
    }

    int dms_xSync(sqlite3_file* file, int flags) {
        return SQLITE_OK;
    }
    int dms_xFileControl(sqlite3_file*, int op, void *pArg) {
        return SQLITE_NOTFOUND;
    }

    int dms_xFileSize(sqlite3_file *file, sqlite3_int64 *pSize) {
        dms_file *dms = (dms_file *)file;
        *pSize = dms->size;
        return SQLITE_OK;
    }

    int dms_xDeviceCharacteristics(sqlite3_file *file) {
        return 0;
    }
  
    sqlite3_io_methods iomethods = {
        1, //int iVersion;
        dms_xClose,
        dms_xRead,
        dms_xWrite,
        0, // int (*xTruncate)(sqlite3_file*, sqlite3_int64 size);
        dms_xSync,
        dms_xFileSize,
        dms_xLock,
        dms_xUnlock, // int (*xUnlock)(sqlite3_file*, int);
        0, // int (*xCheckReservedLock)(sqlite3_file*, int *pResOut);
        dms_xFileControl,
        0, // int (*xSectorSize)(sqlite3_file*);
        dms_xDeviceCharacteristics //int (*xDeviceCharacteristics)(sqlite3_file*);
    };

    // static variables for passing buffer through the open call
    char *g_tmpbuf = NULL;
    sqlite3_int64 g_tmpsize = -1;

    /* if buf looks like gzipped data, decompress it, and update *sz.  
     * Return buf, which may now point to new space. */
    char* maybe_decompress(char* buf, sqlite3_int64 *sz) {
        if (*sz<2) return buf;
        /* check for gzip magic number */
        unsigned char s0 = buf[0];
        unsigned char s1 = buf[1];
        if (s0==0x1f && s1==0x8b) {
            bio::filtering_istream in;
            in.push(bio::gzip_decompressor());
            std::istringstream file;
            file.rdbuf()->pubsetbuf(buf, *sz);
            in.push(file);
            std::stringstream ss;
            ss << in.rdbuf();
            std::string s = ss.str();
            buf = (char *)realloc(buf, s.size());
            *sz = s.size();
            memcpy(buf, s.data(), *sz);
        }
        return buf;
    }

    struct dms_vfs : sqlite3_vfs {

        dms_vfs() {
            zName = "dms";
            xOpen = dms_xOpen;
            xDelete = dms_xDelete;
            xAccess = dms_xAccess;
            xFullPathname = dms_xFullPathname;
            xAccess = dms_xAccess;
            mxPathname=1024;
            szOsFile=sizeof(dms_file);
        }

        static int dms_xOpen(sqlite3_vfs* self, const char *zName, 
                sqlite3_file*file, int flags, int *pOutFlags) {
            dms_file *dms = (dms_file *)file;
            dms->pMethods = &iomethods;
            dms->path = NULL;
            if (flags & SQLITE_OPEN_CREATE) {
                dms->contents = NULL;
                dms->size = 0;
                if (flags & SQLITE_OPEN_MAIN_DB) {
                    dms->path = strdup(zName);
                }
            } else {
                g_tmpbuf = maybe_decompress(g_tmpbuf, &g_tmpsize);
                dms->contents = g_tmpbuf;
                dms->size     = g_tmpsize;
                g_tmpbuf = NULL;
                g_tmpsize = -1;
            }
            return SQLITE_OK;
        }

        static int dms_xDelete(sqlite3_vfs*, const char *zName, int syncDir) {
            return SQLITE_OK;
        }

        static int dms_xAccess(sqlite3_vfs*, const char *zName, int flags, 
                int *pResOut) {
            switch (flags) {
                case SQLITE_ACCESS_EXISTS:    *pResOut=0; break;
                case SQLITE_ACCESS_READWRITE: *pResOut=0; break;
                case SQLITE_ACCESS_READ:      *pResOut=0; break;
                default:
                                              return SQLITE_ERROR;
            }
            return SQLITE_OK;
        }

        static int dms_xFullPathname(sqlite3_vfs*, const char *zName, int nOut, 
                char *zOut) {
            strncpy(zOut, zName, nOut);
            return 0;
        }
    } vfs[1];
}

#endif


#ifdef _MSC_VER
#include <windows.h>
static int fs_remove_file( const char * path ) {
  DeleteFileA( path );
  return 1; /* FIXME: check for failure */
}
#else
#include <unistd.h>
#include <errno.h>
static int fs_remove_file( const char * path ) {
    if (unlink(path)!=0 && errno!=ENOENT) {
        fprintf(stderr, "Removing %s failed: %s\n", path, strerror(errno));
        return 0;
    }
    return 1;
}
#endif

#ifndef M_PI
#define M_PI (3.1415926535897932385)
#endif

#ifndef M_PI_2
#define M_PI_2 (1.5707963267948966192)
#endif

static const char * 
find_element_by_atomic_number(int target) {
    return get_pte_label(target);
}

static int 
find_element_by_amu(double target) {
    return get_pte_idx_from_mass(target);
}

static int table_size( sqlite3 * db, const char * tname, 
                       sqlite_int64 * count ) {
    sqlite3_stmt *stmt;
    char * buf;

    if (!tname) return 0;
    buf = (char *)malloc(strlen(tname) + 100);
    sprintf(buf, "select count() from '%s'", tname);
    if (sqlite3_prepare_v2(db, buf, -1, &stmt, NULL)) {
        free(buf);
        return 0;
    }
    if (SQLITE_ROW != sqlite3_step(stmt)) {
        sqlite3_finalize(stmt);
        free(buf);
        return 0;
    }
    if (count) *count = sqlite3_column_int64(stmt, 0);
    sqlite3_finalize(stmt);
    return 1; /* success */
}

static molfile_plugin_t plugin;
static molfile_plugin_t ffplugin;

namespace {
    struct Handle {
        sqlite3 * db;
        int natoms;
        int frames_read;
        bool ff;
        std::vector<int> from, to, gids, angles, dihedrals, impropers, cmaps;
        std::vector<int> glue_from, glue_to;
        std::vector<float> order;
        Handle(sqlite3 * _db, int n) 
        : db(_db), natoms(n), frames_read(0), ff(false) {}
            
        ~Handle() {
            if (db && sqlite3_close(db)) 
                fprintf(stderr, "Error closing db: %s\n", sqlite3_errmsg(db));
        }
    };
}


  static void *open_file_read( const char *filename, const char *filetype,
                        int *natoms ) {

      sqlite3 * db;
      sqlite_int64 count;
      Handle * h;
#if defined(DESRES_READ_TIMESTEP2)
    sqlite3_vfs_register(vfs, 0);

    int fd=open(filename, O_RDONLY);
    if (fd<0) {
        fprintf(stderr, "Failed opening DMS file at '%s'\n", filename);
        return NULL;
    }
    struct stat statbuf[1];
    if (fstat(fd, statbuf)!=0) {
        close(fd);
        fprintf(stderr, "Failed getting size of DMS file at '%s': %s\n",
                filename, strerror(errno));
        return NULL;
    }
    g_tmpsize = statbuf->st_size;
    if (g_tmpsize==0) {
        close(fd);
        fprintf(stderr, "DMS file at '%s' has zero size\n", filename);
        return NULL;
    }
    g_tmpbuf = (char *)malloc(g_tmpsize);
    if (!g_tmpbuf) {
        close(fd);
        fprintf(stderr, "Failed to allocate read buffer for DMS file at '%s' of size %lu\n", filename, g_tmpsize);
        return NULL;
    }
    ssize_t readcount = read(fd, g_tmpbuf, g_tmpsize);
    close(fd);
    if (readcount!=g_tmpsize) {
        free(g_tmpbuf);
        fprintf(stderr, "Failed reading DMS file contents at '%s': %s\n",
                filename, strerror(errno));
        return NULL;
    }
    int rc = sqlite3_open_v2( "::dms::", &db, SQLITE_OPEN_READONLY, 
            vfs->zName);
    if (g_tmpbuf) free(g_tmpbuf);
    if (rc!=SQLITE_OK) {
        fprintf(stderr, "Error parsing dms file at %s: %s\n",
                filename, sqlite3_errmsg(db));
    }
#else
      if (sqlite3_open_v2( filename, &db, SQLITE_OPEN_READONLY, NULL)) {
          fprintf(stderr, "Error opening dms at %s: %s", 
                  filename, sqlite3_errmsg(db));
          return NULL;
      }
#endif
      if (!table_size( db, "particle", &count )) {
          fprintf(stderr, "Empty particle table in DMS file '%s'\n",
                  filename);
          return NULL;
      }
      h = new Handle(db, count);
      *natoms = count;
      return h;
  }

static void close_file_read(void *v) { delete (Handle *)v; }

static int has_nonwhitespace( const char * p ) {
    for (; *p; ++p) {
        if (!isspace(*p)) return 1;
    }
    return 0;
}

#define GET_STRING( col, field ) do { \
    if ( col >= 0 ) { \
        const char * val = (const char *)sqlite3_column_text(stmt, col); \
        if (val) { \
            strncpy( atom->field, val, sizeof(atom->field) ); \
            atom->field[sizeof(atom->field)-1] = '\0'; \
        } \
    } \
} while(0)

#define GET_INT( col, field ) do { \
    if ( col >= 0 ) { \
        atom->field = sqlite3_column_int(stmt, col); \
    } \
} while (0)

#define GET_DOUBLE( col, field ) do { \
    if ( col >= 0 ) { \
        atom->field = sqlite3_column_double(stmt, col); \
    } \
} while (0)

  static
  int read_structure( void *v, int *optflags, molfile_atom_t *atoms ) {
      Handle *h = (Handle *)v;
      sqlite3 * db = h->db;
      sqlite3_stmt * stmt;
      static const char infosql[] = "pragma table_info(particle)";

      int gid_col = -1;
      int name_col = -1;
      int anum_col = -1;
      int resid_col = -1;
      int resname_col = -1;
      int chain_col = -1;
      int segid_col = -1;
      int mass_col = -1;
      int charge_col = -1;
      int occ_col = -1;
      int ins_col = -1;
  
      *optflags = 0;
      memset(atoms, 0, h->natoms * sizeof(*atoms));
  
      if (sqlite3_prepare_v2(db, infosql, -1, &stmt, NULL)) {
          fprintf(stderr, "Error getting particle info: %s", 
                  sqlite3_errmsg(db));
          return MOLFILE_ERROR;
      }
      std::string loadsql = "select id";
      int ncols=1;
      while (SQLITE_ROW==sqlite3_step(stmt)) {
          const char * name = (const char *)sqlite3_column_text(stmt,1);
          if        (!strcmp(name, "anum")) {
              loadsql += ", anum";
              anum_col = ncols;
              *optflags |= MOLFILE_ATOMICNUMBER;
          } else if (!strcmp(name, "name")) {
              loadsql += ", name";
              name_col = ncols;
          } else if (!strcmp(name, "resid")) {
              loadsql += ", resid";
              resid_col = ncols;
          } else if (!strcmp(name, "resname")) {
              loadsql += ", resname";
              resname_col = ncols;
          } else if (!strcmp(name, "chain")) {
              loadsql += ", chain";
              chain_col = ncols;
          } else if (!strcmp(name, "segid")) {
              loadsql += ", segid";
              segid_col = ncols;
          } else if (!strcmp(name, "mass")) {
              loadsql += ", mass";
              mass_col = ncols;
              *optflags |= MOLFILE_MASS;
          } else if (!strcmp(name, "charge")) {
              loadsql += ", charge";
              charge_col = ncols;
              *optflags |= MOLFILE_CHARGE;
          } else if (!strcmp(name, "occupancy")) {
              loadsql += ", occupancy";
              occ_col = ncols;
              *optflags |= MOLFILE_OCCUPANCY;
          } else if (!strcmp(name, "insertion")) {
              loadsql += ", insertion";
              ins_col = ncols;
              *optflags |= MOLFILE_INSERTION;
          } else continue;
          ++ncols;
      }  
      sqlite3_finalize(stmt);

      *optflags |= MOLFILE_RADIUS;

      loadsql += " from particle";

      if (sqlite3_prepare_v2(db, loadsql.c_str(), -1, &stmt, NULL)) {
          fprintf(stderr, "Error loading particle structure: %s\n",
                  sqlite3_errmsg(db));
          return MOLFILE_ERROR;
      }
      molfile_atom_t * atom = atoms;
      while (SQLITE_ROW==sqlite3_step(stmt)) {
          GET_STRING(    name_col, name );
          GET_INT(       anum_col, atomicnumber );
          GET_INT(      resid_col, resid );
          GET_STRING( resname_col, resname );
          GET_DOUBLE(    mass_col, mass );
          GET_DOUBLE(  charge_col, charge );
          GET_DOUBLE(     occ_col, occupancy );
          GET_STRING(   chain_col, chain );
          GET_STRING(   segid_col, segid );
          GET_STRING(     ins_col, insertion );

          strcpy(atom->type, atom->name);

          atom->radius = get_pte_vdw_radius(atom->atomicnumber);

          h->gids.push_back(sqlite3_column_int(stmt, 0));

          /* if the name is all space, and we have an atomic number, use the
          element name instead. */
          if (atom->atomicnumber) {
            if (!has_nonwhitespace(atom->name)) {
              const char *nm = 
                find_element_by_atomic_number(atom->atomicnumber);
              strncpy( atom->name, nm, sizeof(atom->name));
            }
          }
          ++atom;
      }
      sqlite3_finalize(stmt);
      return MOLFILE_SUCCESS;
  }

static
#if vmdplugin_ABIVERSION > 14
int read_bonds(void *v, int *nbonds, int **from, int **to, float** order,
               int **bondtype, int *nbondtypes, char ***bondtypename) {
#else
int read_bonds(void *v, int *nbonds, int **from, int **to, float** order) {
#endif
    Handle *h = (Handle *)v;
    sqlite3 * db = h->db;
    sqlite_int64 count = 0;
    if (table_size(h->db, "bond", &count) && count>0) {
        sqlite3_stmt * stmt;
        int with_order = 1;
        /* Try including order first */
        static const char * sql = "select p0,p1,\"order\" from bond";
        if (sqlite3_prepare_v2(db, sql, -1, &stmt, NULL)) {
            /* Fall back to just p0, p1 */
            static const char * sql = "select p0,p1 from bond";
            with_order = 0;
            if (sqlite3_prepare_v2(db, sql, -1, &stmt, NULL)) {
                fprintf(stderr, "Error reading bonds: %s", sqlite3_errmsg(db));
                return MOLFILE_ERROR;
            }
        }
        h->from.resize(count);
        h->to.resize(count);
        h->order.resize(count);

        *from = &h->from[0];
        *to   = &h->to[0];
        *order = &h->order[0];
#if vmdplugin_ABIVERSION > 14
        *bondtype = NULL;
        *nbondtypes = 0;
        *bondtypename = NULL;
  #endif

        std::map<int,int> gidmap;
        for (unsigned i=0; i<h->gids.size(); i++) gidmap[h->gids[i]]=i+1;

        for (int i=0; sqlite3_step(stmt)==SQLITE_ROW; i++) {
            std::map<int,int>::const_iterator iter;

            int from = sqlite3_column_int(stmt,0);
            int to   = sqlite3_column_int(stmt,1);
            h->order[i] = with_order ? sqlite3_column_int(stmt,2) : 1;
            if ((iter=gidmap.find(from))==gidmap.end()) {
                fprintf(stderr, "Illegal bond in row %d: %d-%d\n", 
                        i+1, from, to);
                return MOLFILE_ERROR;
            }
            h->from[i] = iter->second;
            if ((iter=gidmap.find(to))==gidmap.end()) {
                fprintf(stderr, "Illegal bond in row %d: %d-%d\n", 
                        i+1, from, to);
                return MOLFILE_ERROR;
            }
            h->to[i] = iter->second;
        }
        sqlite3_finalize(stmt);
    }
    *nbonds = count;
    return MOLFILE_SUCCESS;
}

static
int read_fictitious_bonds(void *v, int *nbonds, int **from, int **to) {
    Handle *h = (Handle *)v;
    sqlite3 * db = h->db;
    sqlite_int64 count = 0;
    if (table_size(h->db, "glue", &count) && count>0) {
        sqlite3_stmt * stmt;
        static const char * sql = "select p0,p1 from glue";
        if (sqlite3_prepare_v2(db, sql, -1, &stmt, NULL)) {
            fprintf(stderr, "Error reading bonds: %s", sqlite3_errmsg(db));
            return MOLFILE_ERROR;
        }
        h->glue_from.resize(count);
        h->glue_to.resize(count);

        *from = &h->glue_from[0];
        *to   = &h->glue_to[0];

        std::map<int,int> gidmap;
        for (unsigned i=0; i<h->gids.size(); i++) gidmap[h->gids[i]]=i+1;

        for (int i=0; sqlite3_step(stmt)==SQLITE_ROW; i++) {
            std::map<int,int>::const_iterator iter;

            int from = sqlite3_column_int(stmt,0);
            int to   = sqlite3_column_int(stmt,1);
            if ((iter=gidmap.find(from))==gidmap.end()) {
                fprintf(stderr, "Illegal glue in row %d: %d-%d\n", 
                        i+1, from, to);
                return MOLFILE_ERROR;
            }
            h->glue_from[i] = iter->second;
            if ((iter=gidmap.find(to))==gidmap.end()) {
                fprintf(stderr, "Illegal glue in row %d: %d-%d\n", 
                        i+1, from, to);
                return MOLFILE_ERROR;
            }
            h->glue_to[i] = iter->second;
        }
        sqlite3_finalize(stmt);
    }
    *nbonds = count;
    return MOLFILE_SUCCESS;
}

  static
  double dotprod(const double *x, const double *y) {
    return x[0]*y[0] + x[1]*y[1] + x[2]*y[2];
  }

  static
  int read_global_cell(Handle * h, molfile_timestep_t * ts) {
      sqlite3_stmt * stmt;
      sqlite_int64 count;
      int i,j;
      if (!table_size(h->db, "global_cell", &count)) return MOLFILE_SUCCESS;
      if (count != 3) {
          fprintf(stderr, "Error: expected global_cell size of 3, got %d",
                  (int)count);
          return MOLFILE_ERROR;
      }
      if (sqlite3_prepare_v2(h->db,"select x,y,z from global_cell", -1, &stmt, NULL))  {
          fprintf(stderr, "Error compiling global_cell reader: %s",
                  sqlite3_errmsg(h->db));
          return MOLFILE_ERROR;
      }
      for (i=0; i<3; i++) {
          sqlite3_step(stmt);
          for (j=0; j<3; j++) {
              ts->unit_cell[3*i+j] = sqlite3_column_double(stmt,j);
          }
      }
      sqlite3_finalize(stmt);
      return MOLFILE_SUCCESS;
  }

  static
  int read_timestep(Handle * h, molfile_timestep_t *ts) {

      sqlite3_stmt * stmt;
      float * fpos = ts->coords;
      float * fvel = ts->velocities;
      double* dpos = ts->dcoords;
      double* dvel = ts->dvelocities;
      const char * sql = (fvel || dvel) ? "select x,y,z,vx,vy,vz from particle"
                                        : "select x,y,z          from particle";
      if (sqlite3_prepare_v2( h->db, sql, -1, &stmt, NULL)) {
          fprintf(stderr, "Error reading timestep: %s\n", 
                  sqlite3_errmsg(h->db));
          return MOLFILE_ERROR;
      }
      while (SQLITE_ROW==sqlite3_step(stmt)) {
          int i;
          if (fpos) {
            for (i=0; i<3; i++) *fpos++ = sqlite3_column_double(stmt,i);
          }
          if (fvel) {
            for (i=0; i<3; i++) *fvel++ = sqlite3_column_double(stmt,i+3);
          }
          if (dpos) {
            for (i=0; i<3; i++) *dpos++ = sqlite3_column_double(stmt,i);
          }
          if (dvel) {
            for (i=0; i<3; i++) *dvel++ = sqlite3_column_double(stmt,i+3);
          }
      }
      sqlite3_finalize(stmt);
      return read_global_cell(h,ts);
  }


  static
  int read_next_timestep( void *v, int atoms, molfile_timestep_t *ts) {
    Handle *h = (Handle *)v;
    if (h->frames_read++) return MOLFILE_EOF;
    return read_timestep(h, ts);
  }

  static
  int read_timestep2(void *v, ssize_t n, molfile_timestep_t *ts) {
    Handle *h = (Handle *)v;
    if (n!=0) return MOLFILE_EOF;
    return read_timestep(h, ts);
  }

  static
  int read_timestep_metadata( void *v, molfile_timestep_metadata_t *m) {
    /* FIXME: assume velocities */
    m->has_velocities = 1;
    m->count = 1; /* number of timesteps */
    m->avg_bytes_per_timestep = 10000; /* FIXME */
    m->supports_double_precision = true;
    return MOLFILE_SUCCESS;
  }

  static
  void *open_file_write(const char *path, const char *type, int natoms) {

      sqlite3* db;
      Handle *h=NULL;

      /* delete existing file so we don't just append */
      if (!fs_remove_file(path)) return NULL;

#if defined(DESRES_READ_TIMESTEP2)
      sqlite3_vfs_register(vfs, 0);

      int rc = sqlite3_open_v2(path, &db, 
              SQLITE_OPEN_READWRITE | SQLITE_OPEN_CREATE, vfs->zName);
#else
      int rc = sqlite3_open(path, &db);
#endif
      if (rc!=SQLITE_OK) {
          fprintf(stderr, "Error opening DMS file at '%s' for writing: %s\n",
            path, sqlite3_errmsg(db));
          return NULL;
      }
      h = new Handle(db, natoms);
      h->ff = !strcmp(type, "dmsff");
      return h;
  }

  static
#if vmdplugin_ABIVERSION > 14
  int write_bonds(void *v, int nbonds, int *from, int *to, float *order,
                  int *bondtype, int nbondtypes, char **bondtypename) {
#else
  int write_bonds(void *v, int nbonds, int *from, int *to, float *order) {
#endif
      Handle *h = (Handle *)v;
      h->from.resize(nbonds);
      h->to.resize(nbonds);
      
      std::copy(from, from+nbonds, h->from.begin());
      std::copy(to,   to+nbonds,   h->to.begin());
      if (order) {
          h->order.resize(nbonds);
          std::copy(order, order+nbonds, h->order.begin());
      } else {
          h->order.clear();
          h->order.insert(h->order.begin(), nbonds, 1);
      }
      return MOLFILE_SUCCESS;
  }

  static int write_angles(void * v, int numangles, const int *angles,
                        const int *angletypes, int numangletypes,
                        const char **angletypenames, int numdihedrals, 
                        const int *dihedrals, const int *dihedraltype,
                        int numdihedraltypes, const char **dihedraltypenames,
                        int numimpropers, const int *impropers, 
                        const int *impropertypes, int numimpropertypes, 
                        const char **impropertypenames, int numcterms, 
                        const int *cterms, int ctermcols, int ctermrows) {

      Handle *h = (Handle *)v;
      h->angles.resize(3*numangles);
      std::copy(angles, angles+3*numangles, h->angles.begin());
      h->dihedrals.resize(4*numdihedrals);
      std::copy(dihedrals, dihedrals+4*numdihedrals, h->dihedrals.begin());
      h->impropers.resize(4*numimpropers);
      std::copy(impropers, impropers+4*numimpropers, h->impropers.begin());
      h->cmaps.resize(8*numcterms);
      std::copy(cterms, cterms+8*numcterms, h->cmaps.begin());

      return MOLFILE_SUCCESS;
}

  static
  int write_structure(void *v, int optflags, const molfile_atom_t *atoms) {
    Handle *h = (Handle *)v;
    sqlite3 * db = h->db;
    sqlite3_stmt * stmt;
    int i;

    sqlite3_exec(db, "begin", NULL, NULL, NULL);
    if (sqlite3_exec(db, 
        " create table if not exists particle (\n"
        "id integer primary key, \n"
        "anum integer,\n"
        "x float, y float, z float,\n"
        "vx float, vy float, vz float,\n"
        "mass float, charge float,\n"
        "name text, resname text, resid integer, chain text, segid text)", 
        NULL, NULL, NULL)) {
        fprintf(stderr, "Error creating particle table %s\n",
                sqlite3_errmsg(db));
        return MOLFILE_ERROR;
    }
    if (sqlite3_prepare_v2(db, "insert into particle values ("
                "?," /* id */
                "?," /* anum */
                "?,?,?,?,?,?," /* x,y,z, vx,vy,vz */
                "?,?,"  /* mass, charge */
                "?,?,?,?,?)", /* name, resname, resid, chain, segid */
                -1, &stmt, NULL)) {
        fprintf(stderr, "Error compiling insert particle statement %s\n",
                sqlite3_errmsg(db));
        return MOLFILE_ERROR;
    }
    for (i=0; i<h->natoms; i++) {
        const molfile_atom_t * a = atoms+i;
        int anum=0;
        if (optflags & MOLFILE_ATOMICNUMBER) {
            anum=a->atomicnumber;
        } else if (optflags & MOLFILE_MASS) {
            anum=find_element_by_amu(a->mass);
        }

        sqlite3_bind_int(stmt, 1, i );
        sqlite3_bind_int(stmt, 2, anum );
        sqlite3_bind_double( stmt, 9, 
                optflags & MOLFILE_MASS ?  a->mass : 0.0 );
        sqlite3_bind_double( stmt, 10, 
                optflags & MOLFILE_CHARGE ? a->charge : 0.0 );
        sqlite3_bind_text( stmt, 11, a->name, -1, SQLITE_STATIC );
        sqlite3_bind_text( stmt, 12, a->resname, -1, SQLITE_STATIC );
        sqlite3_bind_int(  stmt, 13, a->resid );
        sqlite3_bind_text( stmt, 14, a->chain, -1, SQLITE_STATIC );
        sqlite3_bind_text( stmt, 15, a->segid, -1, SQLITE_STATIC );
        
        if (sqlite3_step(stmt)!=SQLITE_DONE) {
            fprintf(stderr, "Error adding particle: %s\n",
                    sqlite3_errmsg(db));
            sqlite3_finalize(stmt);
            return MOLFILE_ERROR;
        }
        sqlite3_reset(stmt);
    }
    sqlite3_finalize(stmt);
    
    /* bonds */
    if (sqlite3_exec(db,
        "  create table if not exists bond (\n"
        "    p0 integer, p1 integer, 'order' integer)", NULL, NULL, NULL )) {
        fprintf(stderr, "Error creating bond table: %s\n",
                sqlite3_errmsg(db));
        return MOLFILE_ERROR;
    }
    if (sqlite3_prepare_v2(db, "insert into bond values (?,?,?)", -1, &stmt, NULL)) {
        fprintf(stderr, "Error compiling bond insert statement: %s\n",
                sqlite3_errmsg(db));
        return MOLFILE_ERROR;
    }
    for (unsigned i=0; i<h->from.size(); i++) {
        sqlite3_bind_int( stmt, 1, h->from[i]-1);
        sqlite3_bind_int( stmt, 2, h->to[i]-1);
        sqlite3_bind_int( stmt, 3, h->order[i]);
        if (sqlite3_step(stmt)!=SQLITE_DONE) {
            fprintf(stderr, "Error adding bond: %s\n", 
                    sqlite3_errmsg(db));
            sqlite3_finalize(stmt);
            return MOLFILE_ERROR;
        }
        sqlite3_reset(stmt);
    }
    sqlite3_finalize(stmt);
    sqlite3_exec(db, "commit", NULL, NULL, NULL);

    /* forcefield information, if requested */
    if (h->ff) {
        /* find the unique types, and sort them */
        std::vector<std::string> types;
        for (int i=0; i<h->natoms; i++) types.push_back(atoms[i].type);
        std::sort(types.begin(), types.end());
        types.resize(std::unique(types.begin(), types.end())-types.begin());

        /* add nbtype to particle table, and create nonbonded table, which
         * someone else will fill in. */
        sqlite3_exec(db, "alter table particle add column nbtype integer",
                NULL, NULL, NULL);
        sqlite3_exec(db, "create table nonbonded_param (\n"
                         "  id integer primary key, type char)", NULL, NULL, NULL);
        if (sqlite3_prepare_v2(db, 
                    "update particle set nbtype=? where id=?", -1, &stmt, NULL)) {
            fprintf(stderr, "Error compiling update nbtype statement: %s\n",
                    sqlite3_errmsg(db));
            return MOLFILE_ERROR;
        }
        sqlite3_exec(db, "begin", NULL, NULL, NULL);
        for (int i=0; i<h->natoms; i++) {
            int nbtype = std::lower_bound( 
                    types.begin(), types.end(), std::string(atoms[i].type)) 
                - types.begin();
            sqlite3_bind_int(stmt, 1, nbtype);
            sqlite3_bind_int(stmt, 2, i);
            sqlite3_step(stmt);
            sqlite3_reset(stmt);
        }
        sqlite3_finalize(stmt);
        sqlite3_exec(db, "commit", NULL, NULL, NULL);

        /* write type column to nonbonded table */
        if (sqlite3_prepare_v2(db, 
                    "insert into nonbonded_param values (?,?)", -1, &stmt, NULL)) {
            fprintf(stderr, "Error compiling insert into nonbonded_param: %s\n",
                    sqlite3_errmsg(db));
            return MOLFILE_ERROR;
        }
        sqlite3_exec(db, "begin", NULL, NULL, NULL);
        for (unsigned i=0; i<types.size(); i++) {
            sqlite3_bind_int(stmt, 1, i);
            sqlite3_bind_text(stmt, 2, types[i].c_str(), -1, SQLITE_STATIC);
            sqlite3_step(stmt);
            sqlite3_reset(stmt);
        }
        sqlite3_finalize(stmt);
        sqlite3_exec(db, "commit", NULL, NULL, NULL);

        /* write angles */
        sqlite3_exec(db, "create table angles (\n"
                         "  p0 integer not null,\n"
                         "  p1 integer not null,\n"
                         "  p2 integer not null)", NULL, NULL, NULL);
        if (sqlite3_prepare_v2(db, 
                    "insert into angles values (?,?,?)", -1, &stmt, NULL)) {
            fprintf(stderr, "Error compiling insert into angles: %s\n",
                    sqlite3_errmsg(db));
            return MOLFILE_ERROR;
        }
        for (unsigned i=0; i<h->angles.size(); i+=3) {
            sqlite3_bind_int(stmt, 1, h->angles[i  ]-1);
            sqlite3_bind_int(stmt, 2, h->angles[i+1]-1);
            sqlite3_bind_int(stmt, 3, h->angles[i+2]-1);
            sqlite3_step(stmt);
            sqlite3_reset(stmt);
        }
        sqlite3_finalize(stmt);
        sqlite3_exec(db, "commit", NULL, NULL, NULL);

        /* write dihedrals */
        sqlite3_exec(db, "create table dihedrals (\n"
                         "  p0 integer not null,\n"
                         "  p1 integer not null,\n"
                         "  p2 integer not null,\n"
                         "  p3 integer not null)", NULL, NULL, NULL);
        if (sqlite3_prepare_v2(db, 
                    "insert into dihedrals values (?,?,?,?)", -1, &stmt, NULL)) {
            fprintf(stderr, "Error compiling insert into dihedrals: %s\n",
                    sqlite3_errmsg(db));
            return MOLFILE_ERROR;
        }
        for (unsigned i=0; i<h->dihedrals.size(); i+=4) {
            sqlite3_bind_int(stmt, 1, h->dihedrals[i  ]-1);
            sqlite3_bind_int(stmt, 2, h->dihedrals[i+1]-1);
            sqlite3_bind_int(stmt, 3, h->dihedrals[i+2]-1);
            sqlite3_bind_int(stmt, 4, h->dihedrals[i+3]-1);
            sqlite3_step(stmt);
            sqlite3_reset(stmt);
        }
        sqlite3_finalize(stmt);
        sqlite3_exec(db, "commit", NULL, NULL, NULL);

        /* write impropers */
        sqlite3_exec(db, "create table impropers (\n"
                         "  p0 integer not null,\n"
                         "  p1 integer not null,\n"
                         "  p2 integer not null,\n"
                         "  p3 integer not null)", NULL, NULL, NULL);
        if (sqlite3_prepare_v2(db, 
                    "insert into impropers values (?,?,?,?)", -1, &stmt, NULL)) {
            fprintf(stderr, "Error compiling insert into impropers: %s\n",
                    sqlite3_errmsg(db));
            return MOLFILE_ERROR;
        }
        for (unsigned i=0; i<h->impropers.size(); i+=4) {
            sqlite3_bind_int(stmt, 1, h->impropers[i  ]-1);
            sqlite3_bind_int(stmt, 2, h->impropers[i+1]-1);
            sqlite3_bind_int(stmt, 3, h->impropers[i+2]-1);
            sqlite3_bind_int(stmt, 4, h->impropers[i+3]-1);
            sqlite3_step(stmt);
            sqlite3_reset(stmt);
        }
        sqlite3_finalize(stmt);
        sqlite3_exec(db, "commit", NULL, NULL, NULL);

        /* write cmaps */
        sqlite3_exec(db, "create table cmaps (\n"
                         "  p0 integer not null,\n"
                         "  p1 integer not null,\n"
                         "  p2 integer not null,\n"
                         "  p3 integer not null,\n"
                         "  p4 integer not null,\n"
                         "  p5 integer not null,\n"
                         "  p6 integer not null,\n"
                         "  p7 integer not null)", NULL, NULL, NULL);
        if (sqlite3_prepare_v2(db, 
                    "insert into cmaps values (?,?,?,?,?,?,?,?)", -1, &stmt, NULL)) {
            fprintf(stderr, "Error compiling insert into cmaps: %s\n",
                    sqlite3_errmsg(db));
            return MOLFILE_ERROR;
        }
        for (unsigned i=0; i<h->cmaps.size(); i+=8) {
            sqlite3_bind_int(stmt, 1, h->cmaps[i  ]-1);
            sqlite3_bind_int(stmt, 2, h->cmaps[i+1]-1);
            sqlite3_bind_int(stmt, 3, h->cmaps[i+2]-1);
            sqlite3_bind_int(stmt, 4, h->cmaps[i+3]-1);
            sqlite3_bind_int(stmt, 5, h->cmaps[i+4]-1);
            sqlite3_bind_int(stmt, 6, h->cmaps[i+5]-1);
            sqlite3_bind_int(stmt, 7, h->cmaps[i+6]-1);
            sqlite3_bind_int(stmt, 8, h->cmaps[i+7]-1);
            sqlite3_step(stmt);
            sqlite3_reset(stmt);
        }
        sqlite3_finalize(stmt);
        sqlite3_exec(db, "commit", NULL, NULL, NULL);
    }

    return MOLFILE_SUCCESS;
  }

  static
  int write_timestep(void *v, const molfile_timestep_t *ts) {
    Handle *h = (Handle *)v;
    sqlite3 * db = h->db;
    sqlite3_stmt * stmt;
    if (h->frames_read) return MOLFILE_EOF;
    static const char sql[]=
        "update particle set x=?,y=?,z=?,vx=?,vy=?,vz=? where id=?";
    if (sqlite3_prepare_v2(db, sql, -1, &stmt, NULL)) {
        fprintf(stderr, "Error compiling update positions statement: %s\n",
                sqlite3_errmsg(db));
        return MOLFILE_ERROR;
    }
    sqlite3_exec(db, "begin", NULL, NULL, NULL);
    for (int i=0; i<h->natoms; i++) {
        sqlite3_bind_double( stmt, 1, ts->coords[3*i  ] );
        sqlite3_bind_double( stmt, 2, ts->coords[3*i+1] );
        sqlite3_bind_double( stmt, 3, ts->coords[3*i+2] );
        double vx=0, vy=0, vz=0;
        if (ts->velocities) {
            vx=ts->velocities[3*i];
            vy=ts->velocities[3*i+1];
            vz=ts->velocities[3*i+2];
        }
        sqlite3_bind_double( stmt, 4, vx );
        sqlite3_bind_double( stmt, 5, vy );
        sqlite3_bind_double( stmt, 6, vz );
        sqlite3_bind_int( stmt, 7, i );
        if (sqlite3_step(stmt)!=SQLITE_DONE) {
            fprintf(stderr, "Error updating position: %s\n",
                    sqlite3_errmsg(db));
            sqlite3_finalize(stmt);
            return MOLFILE_ERROR;
        }
        sqlite3_reset(stmt);
    }
    sqlite3_finalize(stmt);

    if (sqlite3_exec(db,
        "  create table if not exists global_cell (\n"
        "  id integer primary key, x float, y float, z float)",
        NULL, NULL, NULL)) {
        fprintf(stderr, "Error creating global cell table %s\n",
                sqlite3_errmsg(db));
        return MOLFILE_ERROR;
    }
    sqlite3_exec(db, "delete from global_cell", NULL, NULL, NULL);
    if (sqlite3_prepare_v2(db, "insert into global_cell (x,y,z) values (?,?,?)",
                -1, &stmt, NULL)) {
        fprintf(stderr, "Error compiling global_cell statement: %s\n",
                sqlite3_errmsg(db));
        return MOLFILE_ERROR;
    }
    const double* box = ts->unit_cell;
    for (int i=0; i<3; i++) {
        sqlite3_bind_double(stmt, 1, box[3*i  ]);
        sqlite3_bind_double(stmt, 2, box[3*i+1]);
        sqlite3_bind_double(stmt, 3, box[3*i+2]);
        if (sqlite3_step(stmt)!=SQLITE_DONE) {
            fprintf(stderr, "Error updating global cell: %s\n", 
                    sqlite3_errmsg(db));
            sqlite3_finalize(stmt);
            return MOLFILE_ERROR;
        }
        sqlite3_reset(stmt);
    }
    sqlite3_finalize(stmt);
    sqlite3_exec(db, "commit", NULL, NULL, NULL);
    return MOLFILE_SUCCESS;
  }

  static void close_file_write(void *v) { delete (Handle *)v; }


VMDPLUGIN_API int VMDPLUGIN_init(void) {
  memset(&plugin, 0, sizeof(plugin));
  plugin.abiversion = vmdplugin_ABIVERSION;
  plugin.type = MOLFILE_PLUGIN_TYPE;
  plugin.name = "dms";
  plugin.prettyname = "DESRES Molecular Structure";
  plugin.author = "D.E. Shaw Research, LLC: Justin Gullingsrud";
  plugin.majorv = 1;
  plugin.minorv = 0;
  plugin.is_reentrant = VMDPLUGIN_THREADSAFE;

  plugin.filename_extension = "dms,dms.gz";
  plugin.open_file_read = open_file_read;
  plugin.read_structure = read_structure;
  plugin.read_bonds = read_bonds;
  plugin.read_next_timestep = read_next_timestep;
#if defined(DESRES_READ_TIMESTEP2)
  plugin.read_timestep2 = read_timestep2;
  plugin.read_fictitious_bonds = read_fictitious_bonds;
#endif
  plugin.close_file_read = close_file_read;

  plugin.read_timestep_metadata = read_timestep_metadata;

  plugin.open_file_write = open_file_write;
  plugin.write_structure = write_structure;
  plugin.write_bonds = write_bonds;
  plugin.write_timestep = write_timestep;
  plugin.close_file_write = close_file_write;

  memcpy(&ffplugin, &plugin, sizeof(plugin));
  ffplugin.name="dmsff";
  ffplugin.prettyname = "DMS with forcefield terms";
  ffplugin.filename_extension = "";
  ffplugin.write_angles = write_angles;

  return VMDPLUGIN_SUCCESS;
}

VMDPLUGIN_API int VMDPLUGIN_register( void *v, vmdplugin_register_cb cb) {
  cb( v, (vmdplugin_t *)&plugin);
  cb( v, (vmdplugin_t *)&ffplugin);
  return VMDPLUGIN_SUCCESS;
}

VMDPLUGIN_API int VMDPLUGIN_fini(void) {
  return VMDPLUGIN_SUCCESS;
}

