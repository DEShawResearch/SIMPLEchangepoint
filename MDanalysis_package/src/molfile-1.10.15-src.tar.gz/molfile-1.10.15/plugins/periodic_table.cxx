#include "periodic_table.h"
#include <algorithm>

namespace {
    struct Element {
        double mass;
        int    anum;
        Element() {}
        explicit Element(double m) : mass(m), anum(0) {}
        bool operator<(Element const& e) const { return mass<e.mass; }
    };

    Element elems[nr_pte_entries];

    struct ElementInit {
        ElementInit() {
            for (int i=0; i<nr_pte_entries; i++) {
                elems[i].mass = pte_mass[i];
                elems[i].anum = i;
            }
            std::sort(elems, elems+nr_pte_entries);
        }
    } _init_;
}

int get_pte_idx_from_mass(double mass) {
    const Element* begin=elems, *end = elems+nr_pte_entries;
    /* first element which is not less than mass */
    const Element* rhs = std::lower_bound(begin, end, Element(mass));
    /* greater than last value */
    if (rhs==end) return 0;
    /* zero or negative mass? */
    if (rhs==begin) return 0;
    /* take the closest */
    const Element* lhs = rhs-1;
    double ldiff = mass-lhs->mass;
    double rdiff = rhs->mass-mass;
    return ldiff < rdiff ? lhs->anum : rhs->anum;
}
