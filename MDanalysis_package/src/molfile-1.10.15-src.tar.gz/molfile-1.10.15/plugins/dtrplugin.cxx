//
// Version info for VMD plugin tree:
//   $Id: //depot/desrad/main/sw/libs/molfile/plugins/dtrplugin.cxx#66 $
//
// Version info for last sync with D. E. Shaw Research:
//  //depot/desrad/main/sw/libs/molfile/plugins/dtrplugin.cxx#30
//

/*
Copyright 2009, D. E. Shaw Research, LLC
All rights reserved.

Redistribution and use in source and binary forms, with or without
modification, are permitted provided that the following conditions are
met:

* Redistributions of source code must retain the above copyright
  notice, this list of conditions, and the following disclaimer.

* Redistributions in binary form must reproduce the above copyright
  notice, this list of conditions, and the following disclaimer in the
  documentation and/or other materials provided with the distribution.

* Neither the name of D. E. Shaw Research, LLC nor the names of its
  contributors may be used to endorse or promote products derived from
  this software without specific prior written permission.

THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
"AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR
A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT
OWNER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,
SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT
LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE,
DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY
THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
(INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE
OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.

*/

#include "dtrplugin.hxx"

using namespace desres::molfile;

#include <sstream>
#include <ios>
#include <iomanip>
#include <math.h>
#include <errno.h>
#include <stdexcept>
#include <string>
#include <map>
#include <vector>
#include <ios>
#include <set>
#include <iostream>
#include <fstream>
#include <algorithm>
#include <sys/types.h>
#include <sys/stat.h>
#include <sys/stat.h>
#include <sys/types.h>

#include "vmddir.h"
#include "endianswap.h"

#define BOOST_FILESYSTEM_VERSION 3
#include <boost/filesystem.hpp>
#include <boost/iostreams/filtering_stream.hpp>
#include <boost/iostreams/device/file_descriptor.hpp>
#include <boost/iostreams/filter/gzip.hpp>

namespace bfs = boost::filesystem;
namespace bio = boost::iostreams;

static const char SERIALIZED_VERSION[] = "0007";
const char * desres::molfile::dtr_serialized_version() {
  return SERIALIZED_VERSION;
}

static bool badversion(const std::string& version) {
    return version != SERIALIZED_VERSION;
}

#ifdef _MSC_VER
#define DTR_LOC __FILE__ << ":" << __LINE__ << "\n" << __FUNCSIG__
#else
#define DTR_LOC __FILE__ << ":" << __LINE__ << "\n" << __PRETTY_FUNCTION__
#endif

#define DTR_FAILURE(args) do { \
    std::stringstream ss; \
    ss << args << "\nlocation: " << DTR_LOC; \
    throw std::runtime_error(ss.str()); \
} while (0)


#ifndef DESRES_WIN32
static const char s_sep = '/';
#include <sys/mman.h>

#include <netinet/in.h> /* for htonl */
#if defined(_AIX)
#include <fcntl.h>
#else
#include <sys/fcntl.h>
#endif

#if defined(__sun)
#include <sys/types.h>
#include <sys/stat.h>
#include <fcntl.h>
#endif

#else
/// windows version

#define M_PI (3.1415926535897932385)
#define M_PI_2 (1.5707963267948966192)

#ifndef S_ISREG
#define S_ISREG(x) (((x) & S_IFMT) == S_IFREG)
#endif

#ifndef S_ISDIR
#define S_ISDIR(x) (((x) & S_IFMT) == S_IFDIR)
#endif

static const char s_sep = '\\';

#endif

static const uint32_t magic_timekey = 0x4445534b;
static const uint32_t magic_frame   = 0x4445534d;
static const uint32_t s_version     = 0x00000100;
static const uint32_t s_irosetta    = 0x12345678;
static const float    s_frosetta    = 1234.5;
static const double   s_drosetta    = 1234.5e6;
static const uint32_t s_lrosetta_lo = 0x89abcdef;
static const uint32_t s_lrosetta_hi = 0x01234567;
static const uint32_t s_blocksize   = 4096;
static const uint32_t s_alignsize   = 8;

namespace {

  const double PEAKmassInAmu = 418.4;

  double sfxp_ulp32flt(int32_t x) {
    return ldexp(((double) x),-31);
  }


  uint64_t assemble64( uint32_t lo, uint32_t hi) {
    uint64_t hi64 = hi; 
    return (hi64 << 32) | lo; 
  }
  
  double assembleDouble(uint32_t lo, uint32_t hi) {
    union {
      uint64_t ival;
      double   dval;
    } u;
    u.ival = assemble64(lo,hi);
    return u.dval;
  }

  /// definitions of binary representation of frameset files

  typedef struct {
    uint32_t magic;           //!< Magic number
    uint32_t version;         //!< Version of creator
    uint32_t framesize_lo;    //!< bytes in frame (low)
    uint32_t framesize_hi;    //!< bytes in frame (high)
  } required_header_t;

  //! Header structure within file.
  typedef struct {
    required_header_t required; //!< 4 word mini-header

    uint32_t size_header_block; //!< Size of this header
    uint32_t unused0;         //!< not used in current implementation
    uint32_t irosetta;        //!< 32-bit integer rosetta value.
    float    frosetta;        //!< 32-bit float rosetta

    uint32_t drosetta_lo;     //!< 64-bit float rosetta (low)
    uint32_t drosetta_hi;     //!< 64-bit float rosetta (high)
    uint32_t lrosetta_lo;     //!< 64-bit integer rosetta (low)
    uint32_t lrosetta_hi;     //!< 64-bit integer rosetta (high)

    uint32_t endianism;       //!< Endianism of writer machine.
    uint32_t nlabels;         //!< Number of labeled fields.
    uint32_t size_meta_block; //!< Number of bytes of meta information (padded)
    uint32_t size_typename_block; //!< Number of bytes of typenames (padded)

    uint32_t size_label_block; //!< Number of bytes to store label strings (padded)
    uint32_t size_scalar_block; //!< Number of bytes of scalar storage (padded)
    uint32_t size_field_block_lo; //!< Number of bytes of field storage (padded)
    uint32_t size_field_block_hi; //!< Number of bytes of field storage (padded)

    uint32_t size_crc_block;  //!< Size of the trailing CRC field (unused!)
    uint32_t size_padding_block; //!< Number of ignored bytes to pad to pagesize boundary.
    uint32_t unused1;         //!< Not used in current implementation.
    uint32_t unused2;         //!< Not used in current implementation.

  } header_t;

  typedef struct {
    uint32_t type;            //!< \brief Typecode for this type.
    uint32_t elementsize;     //!< \brief Number of bytes in an element
    uint32_t count_lo;        //!< \brief Number of elements (low)
    uint32_t count_hi;        //!< \brief Number of elements (high)
  } metadisk_t;

  typedef struct key_prologue {
    uint32_t magic;           /* Magic number for frames */
    uint32_t frames_per_file; /* Number of frames in each file */
    uint32_t key_record_size; /* The size of each key record */
  } key_prologue_t;


  //// utility routines

  /*!
   * Extracts the low 32 bits of a 64 bit integer by masking.
   */
  uint32_t lobytes(const uint64_t& x) {
    uint32_t mask = 0xffffffff;
    return x & mask;
  }

  /*!
   * Extract the high 32 bits of a 64 bit integer by shifting.
   */
  uint32_t hibytes(const uint64_t& x) {
    return x >> 32;
  }

  /*!
   * Extract the low 32 bits of a 64 bit float as an integer.
   */
  uint32_t lobytes(const double& x) {
    union {
      uint64_t ival;
      double   dval;
    } u;
    u.dval = x;
    return lobytes(u.ival);
  }

  /*!
   * Extract the high 32 bits of a 64 bit float as an integer.
   */
  uint32_t hibytes(const double& x) {
    union {
      uint64_t ival;
      double   dval;
    } u;
    u.dval = x;
    return hibytes(u.ival);
  }

  /*!
   * The byte order associated with this machine.  We use
   * 1234 for little endian, 4321 for big endian, and
   * 3412 for the unlikely PDB endianism.
   */
  uint32_t machineEndianism() {
#if __BYTE_ORDER == __LITTLE_ENDIAN
    uint32_t byteorder = 1234;
#else
#if __BYTE_ORDER == __BIG_ENDIAN
    uint32_t byteorder = 4321;
#else
#ifdef PDB_ENDIAN
#if __BYTE_ORDER == __PDB_ENDIAN
    uint32_t byteorder = 3412;
#endif
#endif
#endif
#endif
    // If we get a compile error here, then __BYTE_ORDER
    // has an unexpected value.
    return byteorder;
  }

  uint64_t alignInteger( const uint64_t &x, unsigned border) {
    return x + (border - x%border)%border;
  }


  /*!
   * See RFC 1146 for Fletcher's Checksum (http://tools.ietf.org/html/rfc1146)
   */
  uint32_t fletcher( const uint16_t *data, size_t len ) {
    uint32_t sum1 = 0xffff, sum2 = 0xffff;
 
    while (len) {
      unsigned tlen = len > 360 ? 360 : len;
      len -= tlen;
      do {
        sum1 += *data++;
        sum2 += sum1;
      } while (--tlen);
      sum1 = (sum1 & 0xffff) + (sum1 >> 16);
      sum2 = (sum2 & 0xffff) + (sum2 >> 16);
    }
    /* Second reduction step to reduce sums to 16 bits */
    sum1 = (sum1 & 0xffff) + (sum1 >> 16);
    sum2 = (sum2 & 0xffff) + (sum2 >> 16);
    return sum2 << 16 | sum1;
  }

  bool isfile(const std::string &name) {
    struct stat statbuf;
    return (stat(name.c_str(),&statbuf) == 0 && S_ISREG(statbuf.st_mode));
  }

  bool exists(const std::string& path) {
    struct stat statbuf;
#ifdef DESRES_WIN32
    // Use ::stat instead of ::lstat on windows since there are no symlinks
    return (stat(path.c_str(),&statbuf) == 0);
#else
    return (::lstat(path.c_str(),&statbuf) == 0);
#endif
  }

  /*!
   * Remove a file or directory.  For directories,
   * we recurse through subfiles and remove those
   * before attempting the ::rmdir();
   */
  void recursivelyRemove(std::string path) {
    struct stat statbuf;

    // -----------------------------------------------
    // Only try to unlink if the file exists
    // We recurse through directories and unlink
    // other files.
    // -----------------------------------------------

#ifdef DESRES_WIN32
    // Use ::stat instead of ::lstat on windows since there are no symlinks
    if (stat(path.c_str(),&statbuf) == 0) {
#else
    if (::lstat(path.c_str(),&statbuf) == 0) {
#endif
      if (!S_ISDIR(statbuf.st_mode)) {
        if (::unlink(path.c_str()) != 0) {
            throw std::runtime_error(strerror(errno));
        }
      } else {
        VMDDIR* directory = NULL;
        try {
          directory = vmd_opendir(path.c_str());
          if (directory) {
            // Remove subfiles
            char * entry;
            while( (entry=vmd_readdir(directory)) != NULL ) {
              // Don't unlink . or ..
              if (entry[0] == '.') {
                if (entry[1] == 0) continue;
                if (entry[1] == '.' && entry[2] == 0) continue;
              }
              recursivelyRemove(path + s_sep + entry);
            }
            vmd_closedir(directory);
            directory = NULL;

            // Remove the actual directory
            if (::rmdir(path.c_str()) != 0) {
              throw std::runtime_error(strerror(errno));
            }
          }
        } catch(...) {
          if (directory) vmd_closedir(directory);
          throw;
        }
      }
    }
  }


  ////////
  // CRC
  ////////
  
  typedef uint32_t crc;
  
  #define POLYNOMIAL 0x04C11DB7
  #define WIDTH  (8 * sizeof(crc))
  #define TOPBIT (1 << (WIDTH - 1))
  #define FINAL_XOR_VALUE 0xFFFFFFFF

  crc processByte( crc remainder, char msg ) {
        remainder ^= (msg << (WIDTH - 8));
        for (uint8_t bit = 8; bit > 0; --bit)
        {
            if (remainder & TOPBIT) {
                remainder = (remainder << 1) ^ POLYNOMIAL;
            } else {
                remainder = (remainder << 1);
            }
        }
        return remainder;
  }

  crc processBytes(const char *message, int nBytes) {
    crc  remainder = 0;	
    for (int byte = 0; byte < nBytes; ++byte) {
        remainder = processByte( remainder, message[byte] );
    }
    return remainder;
  } 

  int32_t cksum(const std::string &s) {
    ssize_t len = s.size();
    int32_t result = processBytes( s.c_str(), len );
  
    for ( ; len; len >>= 8) {
      result = processByte( result, len & 0xff );
    }
    return result ^ FINAL_XOR_VALUE;
  }

}

namespace {
    struct defer_close {
        int _fd;
        explicit defer_close(int fd) : _fd(fd) {}
        ~defer_close() { close(_fd); }
    };
}

/* read bytes from the given file at the given offset.  If buffer.size()==0,
 * read all the remaining bytes after the offset and resize buffer.  Otherwise,
 * read only buffer.size() bytes into buffer. */
static void read_file( std::string const& path, 
                       std::vector<char>& buffer,
                       off_t offset = 0) {

    int fd = open( path.c_str(), O_RDONLY|O_BINARY);
    if (fd<=0) {
        DTR_FAILURE("Unable to read file at " << path << "\n  " << strerror(errno));
    }
    defer_close _(fd);
    if (buffer.size()==0) {
        struct stat statbuf;
        if (fstat(fd,&statbuf)!=0) {
            DTR_FAILURE("Could not stat file: " << strerror(errno));
        }
        if (statbuf.st_size < offset) {
            DTR_FAILURE("offset " << offset << " is greater than size " << statbuf.st_size << " of file " << path);
        }
        buffer.resize(statbuf.st_size-offset);
    }

    ssize_t rc = pread(fd, &buffer[0], buffer.size(), offset);
    if (rc<0) {
        DTR_FAILURE("reading " << path << ": " << strerror(errno));
    }
    if (size_t(rc) != buffer.size()) {
        DTR_FAILURE("unexpected short read of file " << path);
    }
}

void Timekeys::init(const std::string& path ) {
    std::string timekeys_path = path;
    timekeys_path += s_sep;
    timekeys_path += "timekeys";
    std::vector<char> buffer;
    try {
        read_file(timekeys_path, buffer);
        initWithBytes(buffer.size(), &buffer[0]);
    } catch (std::exception& e) {
        DTR_FAILURE("failed reading timekeys at " << timekeys_path << ": " << e.what());
    }
}

void Timekeys::initWithBytes(size_t tksize, void* bytes) {
  
    const bool verbose = getenv("DTRPLUGIN_VERBOSE");
    key_prologue_t* prologue = static_cast<key_prologue_t*>(bytes);
    /* check the magic number */
    if (tksize<(sizeof(key_prologue_t))) {
        DTR_FAILURE("timekeys file is too small");
    }
    prologue->magic = htonl(prologue->magic);
    if (prologue->magic != magic_timekey) {
        char buf[100];
        sprintf(buf, "timekeys magic number %x doesn't match %x", 
                          prologue->magic, magic_timekey);
        DTR_FAILURE(buf);
    }
  
    /* get frames per file and key record size */
    prologue->frames_per_file = ntohl( prologue->frames_per_file );
    prologue->key_record_size = ntohl( prologue->key_record_size );
    m_fpf = prologue->frames_per_file;
  
    /* read all key records */
    size_t nframes = (tksize-sizeof(key_prologue_t))/sizeof(key_record_t);
    size_t nbytes = nframes * sizeof(key_record_t);
    if (nbytes + sizeof(key_prologue_t) != tksize) {
        DTR_FAILURE("Invalid size of timekeys records");
    }
  
    keys.resize(nframes);
    if (nframes>0) {
        memcpy(&keys[0], prologue+1, nbytes);
    }

    /* Check that we didn't get zero-length frames; this would be a strong
     * indicator of file corruption! */
    int warning_count=0;
    size_t i;
    for (i=0; i<nframes; i++) {
        if (keys[i].size()==0) {
            if (++warning_count<10) {
              if (verbose) 
                fprintf(stderr, "dtrplugin -- WARNING: timekey %d reports 0-length frame; file corruption likely.\n", (int)i);
            }
            if (warning_count==10) {
              if (verbose)
                fprintf(stderr, 
                        "dtrplugin -- WARNING: skipping remaining warnings\n");
            }
        }
    }
    if (warning_count) {
      if (verbose) 
        fprintf(stderr, "dtrplugin -- WARNING: found %d likely corrupt timekeys\n",
                warning_count);
    }

    m_size = m_fullsize = keys.size();
    if (!keys.size()) return;

    m_first = keys[0].time();
    m_framesize = keys[0].size();
    if (keys.size()==1) {
        m_interval=0;
        keys.clear();
    } else if (keys.size()>1) {
        m_interval=keys[1].time()-keys[0].time();
    }

    int time_interval_warnings = 0;
    for (i=1; i<keys.size(); i++) {
        if (keys[i].size() == 0) {
            /* ignore obviously corrupt frames */
            continue;
        }
        /* constant frame size */
        if (keys[i].size() != m_framesize) {
            if (verbose) {
                fprintf(stderr, "non-constant framesize at frame %ld\n", i);
                fprintf(stderr, "  size %d framesize %d\n\n",
                        keys[i].size(), m_framesize);
            }
            m_framesize = 0;
            return;
        }
        /* constant offset */
        if (keys[i].offset() != m_framesize*( i % m_fpf)) {
            if (verbose) {
                fprintf(stderr, "unexpected offset for frame %ld\n", i);
            }
            m_framesize = 0;
            return;
        }
        /* constant time interval */
        if (m_interval>0) {
          if (((keys[i].time()-keys[i-1].time())-m_interval) > 1e-3) {
            if (++time_interval_warnings<=10 && verbose)
                printf("non-constant time interval at frame %ld\n", i);
          }
          /* make sure that m_interval precisely equals the given time */
          double computed_time = m_first + i * m_interval;
          if (keys[i].time() != computed_time) {
            /* keep checking for constant framesize, but record that
            * the interval is not constant */
            if (verbose)
              printf("frame %lu time %g != computed %g\n",
                i, keys[i].time(), computed_time);
            m_interval=0;
          }
        }
    }
    /* If we still have good m_interval and m_framesize, we don't need
     * the explicit key records anymore. */
    if (m_interval>0 && m_framesize>0) {
      if (verbose) {
        printf("all times computable from interval %g\n", m_interval);
      }
      keys.clear();
    }
}

key_record_t Timekeys::operator[](uint64_t i) const {
    if (i>=m_fullsize) {
        DTR_FAILURE("Frame index " << i << " must be less than " << m_fullsize);
    }
    if (keys.size()) return keys.at(i);

    key_record_t timekey;
#if defined(_MSC_VER)
    double time = m_first + ((__int64) i)*m_interval;
#else
    double time = m_first + i*m_interval;
#endif
    uint64_t offset = (i % m_fpf) * m_framesize;

    timekey.time_lo = htonl(lobytes(time));
    timekey.time_hi = htonl(hibytes(time));
    timekey.offset_lo = htonl(lobytes(offset));
    timekey.offset_hi = htonl(hibytes(offset));
    timekey.framesize_lo = htonl(lobytes(m_framesize));
    timekey.framesize_hi = htonl(hibytes(m_framesize));
    return timekey;
}

namespace {
    template <typename T> 
    void rawdump(std::ostream& out, const T& v) {
        out.write((char *)&v, sizeof(v));
    }

    template <typename T> 
    void rawload(std::istream& in, T& v) {
        in.read((char *)&v, sizeof(v));
    }
}

void Timekeys::dump(std::ostream& out) const {
    rawdump(out, m_first);
    rawdump(out, m_interval);
    rawdump(out, m_framesize);
    rawdump(out, m_size);
    rawdump(out, m_fullsize);
    rawdump(out, m_fpf);
    rawdump(out, keys.size());
    if (keys.size()) {
        out.write((const char *)&keys[0], keys.size()*sizeof(keys[0]));
    }
}

void Timekeys::load(std::istream& in) {
    size_t sz;
    rawload(in, m_first);
    rawload(in, m_interval);
    rawload(in, m_framesize);
    rawload(in, m_size);
    rawload(in, m_fullsize);
    rawload(in, m_fpf);
    rawload(in, sz);
    if (sz) {
        keys.resize(sz);
        in.read((char *)&keys[0], keys.size()*sizeof(keys[0]));
    }
}

namespace {
  struct Blob {
    std::string type;
    uint64_t count;
    const void *data;
    bool byteswap;

    Blob() : count(0), data(0) {}
    Blob( const std::string &type_, uint64_t count_, const void *data_,
          uint32_t frame_endianism )
    : type(type_), count(count_), data(data_), byteswap(false) {
      uint32_t my_endianism = machineEndianism();
      if (frame_endianism != my_endianism) {
        if ( (frame_endianism==1234 && my_endianism==4321) || 
             (frame_endianism==4321 && my_endianism==1234) ) {
          byteswap=true;
        } else {
          throw std::runtime_error("Unable to handle frame endianness");
        }
      }
    }

    std::string str() const {
      if (type=="char" && count>0) {
        const char *s=(const char *)data;
        return std::string(s, s+count);
      }
      return "";
    }
    void get_float(float *buf) const {
      if (type=="float") {
        memcpy(buf, data, count*sizeof(float));
      } else if (type=="double") {
        const double *p = reinterpret_cast<const double *>(data);
        for (uint64_t i=0; i<count; i++) buf[i] = p[i];
      } else {
        memset(buf, 0, count*sizeof(float));
      }
      if (byteswap) swap4_unaligned(buf, count);
    }
    void get_double(double *buf) const {
      if (type=="double") {
        memcpy(buf, data, count*sizeof(double));
      } else if (type=="float") {
        const float *p = reinterpret_cast<const float *>(data);
        for (uint64_t i=0; i<count; i++) buf[i] = p[i];
      } else {
        memset(buf, 0, count*sizeof(double));
      }
      if (byteswap) swap8_unaligned(buf, count);
    }
    void get_int32(int32_t *buf) const {
      if (type=="int32_t") {
        memcpy(buf, data, count*sizeof(int32_t));
      } else {
        memset(buf, 0, count*sizeof(int32_t));
      }
      if (byteswap) swap4_unaligned(buf, count);
    }
    void get_uint32(uint32_t *buf) const {
      if (type=="uint32_t") {
        memcpy(buf, data, count*sizeof(uint32_t));
      } else {
        memset(buf, 0, count*sizeof(uint32_t));
      }
      if (byteswap) swap4_unaligned(buf, count);
    }
  };

  typedef std::map<std::string, Blob> BlobMap;
}

static inline std::string addslash(const std::string& s){
    return (s.rbegin()[0] == '/') ? s : s + "/";
}

#define DD_RELPATH_MAXLEN (9) 
static std::string 
DDreldir(const std::string& fname, int ndir1, int ndir2){
    if( fname.find('/', 0) != std::string::npos ) {
        DTR_FAILURE("filename '" << fname << "' must not contain '/'");
    }

    uint32_t hash = cksum(fname);

    // uint32_t u1 = ndir1;
    // uint32_t u2 = ndir2;
    uint32_t d1, d2;
    char answer[DD_RELPATH_MAXLEN];
    if(ndir1 > 0){
	d1 = hash%ndir1;
	if(ndir2 > 0){
	    d2 = (hash/ndir1)%ndir2;
	    sprintf(answer, "%03x/%03x/", d1, d2);
	}else{
	    sprintf(answer, "%03x/", d1);
	}
    }else{
	sprintf(answer, "./");
    }
    return std::string(answer);
}

namespace {
  class DDException : public std::runtime_error{
  public:
      int eno;
      DDException(const std::string &text, int _eno=0) 
      : std::runtime_error(text + strerror(eno)), eno(_eno){}
  };
}

void DDmkdir(const std::string &dirpath, mode_t mode, int ndir1, int ndir2){
    std::string dpslash(addslash(dirpath));

    mode_t openmode = mode | 0300; // make sure we can write into the directory
    if( mkdir(dpslash.c_str(), openmode) < 0 )
	throw DDException("mkdir", errno);
	
    if( mkdir((dpslash + "not_hashed").c_str(), openmode) < 0 )
        throw DDException("mkdir not_hashed subdirectory", errno);

    FILE *fp = fopen((dpslash + "not_hashed/.ddparams").c_str(), "w");
    if(fp == NULL)
	throw DDException("fopen( .ddparams, \"w\" )", errno);
    if( fprintf(fp, "%d %d\n", ndir1, ndir2) < 0 ){
        fclose(fp);
	throw DDException("fprintf(.ddparams ...)", errno);
    }
    if( fclose(fp) )
	throw DDException("fclose(.ddparams)", errno);

    for(int i=0; i<ndir1; ++i){
	char sub[6];
	sprintf(sub, "%03x/", i);
	std::string dirsub = dpslash + sub;
        {
	    if( mkdir(dirsub.c_str(), openmode) < 0 )
		throw DDException("mkdir " + dirsub, errno);
	}
	for(int j=0; j<ndir2; ++j){
	    char subsub[6];
	    sprintf(subsub, "%03x", j);
	    std::string dirsubsub = dirsub + subsub;
	    if( mkdir(dirsubsub.c_str(), mode) < 0 ) // NOT openmode!
		throw DDException("mkdir " + dirsubsub, errno);
	}
        if( mode != openmode ){
            // change the mode back to what the user requested now
            // that we're done creating stuff...
            if( chmod(dirsub.c_str(), mode) < 0 )
                throw DDException("chmod " + dirsub, errno);
        }
    }
    if( mode != openmode ){
        // change the mode back to what the user requested now
        // that we're done creating stuff...
        if( chmod(dpslash.c_str(), mode) < 0 )
            throw DDException("chmod " + dpslash, errno);
        if( chmod((dpslash + "not_hashed").c_str(), mode) < 0 )
          throw DDException("chmod " + dpslash + "not_hashed", errno);
    }
}


static void 
DDgetparams(const std::string& dirpath, int *ndir1, int *ndir2) {
  // get ddparams, or assume (0,0) and let the frame file opens fail.
  *ndir1 = *ndir2 = 0;
  std::string dirslash(addslash(dirpath));
  // New convention - .ddparams is in not_hashed/.
  FILE *fp = fopen((dirslash + "not_hashed/.ddparams").c_str(), "r");
  // Allow the old convention of placing .ddparams in the top-level.
  if( fp == NULL && errno == ENOENT ) {
      fp = fopen((dirslash + ".ddparams").c_str(), "r");
  }
  if(fp != NULL) {
    if( fscanf(fp, "%d%d", ndir1, ndir2) != 2 ) 
      DTR_FAILURE("Failed to parse .ddparams");
    if( fclose(fp) ) {
      DTR_FAILURE("Warning: Failed to close .ddparams file: " << strerror(errno));
    }
  }
}

static std::string framefile( const std::string &dtr,
                              size_t frameno, 
                              size_t frames_per_file,
                              int ndir1,
                              int ndir2) {
  unsigned frame_file = frameno / frames_per_file;
  std::ostringstream filename;
  filename << "frame" << std::setfill('0') << std::setw(9)
           << frame_file;
  std::string fname = filename.str();

  std::string fullpath(dtr);
  fullpath += "/";
  fullpath += DDreldir(fname, ndir1, ndir2);
  fullpath += fname;
  return fullpath;
}

static BlobMap read_frame( const void *mapping, uint64_t len ) {

    const char *base = reinterpret_cast<const char *>(mapping);
    const header_t *header = reinterpret_cast<const header_t*>(base);
    if (len<sizeof(header_t)) {
        std::stringstream ss;
        ss << "Frame size (" << len << ") "
           << "is smaller than sizeof(header_t) ("
           << sizeof(header_t) << ")";
        throw std::runtime_error(ss.str());
    }
    if (ntohl(header->required.magic) != magic_frame) {
        char buf[256];
        sprintf(buf, "invalid magic number: expected %d, got %d\n",
                magic_frame, ntohl(header->required.magic));
        throw std::runtime_error(buf);
    }

    uint32_t size_header_block = ntohl(header->size_header_block);
    uint32_t frames_endianism = ntohl(header->endianism);
    uint32_t frames_nlabels = ntohl(header->nlabels);
    uint32_t size_meta_block = ntohl(header->size_meta_block);
    uint32_t size_typename_block = ntohl(header->size_typename_block);
    uint32_t size_label_block = ntohl(header->size_label_block);
    uint32_t size_scalar_block = ntohl(header->size_scalar_block);
    uint32_t size_field_block_lo = ntohl(header->size_field_block_lo);
    uint32_t size_field_block_hi = ntohl(header->size_field_block_hi);
    uint64_t size_field_block = assemble64(size_field_block_lo,
                                           size_field_block_hi);

    uint64_t offset_header_block = 0;
    uint64_t offset_meta_block = offset_header_block + size_header_block;
    uint64_t offset_typename_block = offset_meta_block + size_meta_block;
    uint64_t offset_label_block = offset_typename_block + size_typename_block;
    uint64_t offset_scalar_block = offset_label_block + size_label_block;
    uint64_t offset_field_block = offset_scalar_block + size_scalar_block;
    uint64_t offset_crc_block = offset_field_block + size_field_block;

    const metadisk_t* diskmeta  = reinterpret_cast<const metadisk_t*>(base+offset_meta_block);
    const char* typenames = reinterpret_cast<const char*>(base+offset_typename_block);
    const char* labels    = reinterpret_cast<const char*>(base+offset_label_block); 
    const char* scalars   = reinterpret_cast<const char*>(base+offset_scalar_block);
    const char* fields    = reinterpret_cast<const char*>(base+offset_field_block);
    const uint32_t  * crc = reinterpret_cast<const uint32_t*>(base+offset_crc_block);
    if (*crc != 0) {
        uint32_t frame_crc = fletcher(reinterpret_cast<const uint16_t*>(base),offset_crc_block/2);
        if (frame_crc != *crc) {
            throw std::runtime_error("Checksum did not match");
        }
    }
    /* More sanity checks */
    if (len<offset_meta_block+size_meta_block)
        throw std::runtime_error("Frame size cannot contain meta block");
    if (len<offset_typename_block+size_typename_block)
        throw std::runtime_error("F size cannot contain meta block");
    if (len<offset_label_block+size_label_block)
        throw std::runtime_error("F size cannot contain meta block");
    if (len<offset_scalar_block+size_scalar_block)
        throw std::runtime_error("F size cannot contain meta block");
    if (len<offset_field_block+size_field_block)
        throw std::runtime_error("Frame size cannot contain meta block");

    std::vector<std::string> types;
    while(*typenames) {
      if (typenames >= labels) {
          DTR_FAILURE("More typenames than labels!");
      }
      std::string type(typenames);
      types.push_back(type);
      typenames += type.size()+1;
    }

    BlobMap blobs;

    for (size_t ii=0; ii<frames_nlabels; ++ii) {
      std::string label(labels);
      labels += label.size()+1;
      // Pull out the typecode, elementsize, and count
      uint32_t code = ntohl(diskmeta[ii].type);
      uint32_t elementsize = ntohl(diskmeta[ii].elementsize);
      uint32_t count_lo = ntohl(diskmeta[ii].count_lo);
      uint32_t count_hi = ntohl(diskmeta[ii].count_hi);
      uint64_t count = assemble64(count_lo,count_hi);
      uint64_t nbytes = elementsize*count;

      const char *addr=0;
      if (count <= 1) {
        addr=scalars;
        scalars += alignInteger(nbytes, s_alignsize);
      } else {
        addr=fields;
        fields += alignInteger(nbytes, s_alignsize);
      }
      try {
        blobs[label] = Blob( types.at(code), count, addr, frames_endianism );
      }
      catch (std::exception &e) {
          DTR_FAILURE("Failed fetching '" << label << "' data from frame: " << e.what());
      }
    }
    return blobs;
}

uint64_t key_record_t::size() const {
  return assemble64(ntohl(framesize_lo), ntohl(framesize_hi));
}
uint64_t key_record_t::offset() const {
  return assemble64(ntohl(offset_lo), ntohl(offset_hi));
}
double key_record_t::time() const {
  return assembleDouble(ntohl(time_lo), ntohl(time_hi));
}

static metadata_t * read_meta( const std::string& metafile, unsigned natoms,
                               bool with_invmass ) {

  std::vector<char> buffer;
  metadata_t *meta = new metadata_t;
  try {
    read_file(metafile, buffer);
  } catch (std::exception &e) {
    // If the metadata file cannot be read, we return an empty metadata.
    return meta;
  }
  BlobMap meta_blobs = read_frame(&buffer[0], buffer.size());
  if (with_invmass && meta_blobs.find("INVMASS")!=meta_blobs.end()) {
    Blob blob=meta_blobs["INVMASS"];
    if (blob.count != natoms) {
      delete meta;
      DTR_FAILURE("bad rmass count in metadata: " << blob.count << " != " << natoms);
    } else {
      meta->invmass.resize(natoms);
      blob.get_float(&meta->invmass[0]);
    }
  }
  return meta;
}

bool StkReader::recognizes(const std::string &path) {
      return path.size()>4 && 
             path.substr(path.size()-4)==".stk" &&
             isfile(path);
}

StkReader::StkReader(DtrReader *reader) {
  dtr=reader->path();
  framesets.push_back(reader);
  curframeset=0;
}

static std::string filename_to_cache_location(std::string const& stk) {
  const char*        cache_prefix = getenv("MOLFILE_STKCACHE_LOCATION");
  // Note : cache_prefix is "/d/en/cache-0/molfile_stk/" at DESRES
  if (!cache_prefix) cache_prefix = "/tmp/"; 

  std::stringstream ss;
  ss << cache_prefix;
  ss << SERIALIZED_VERSION;

  bfs::path fullpath = bfs::system_complete(stk);
  for (bfs::path::iterator it=fullpath.begin(); it!=fullpath.end(); ++it) {
    std::string s = it->string();
    if (s=="/") continue; /* for first component */
    ss << "#" << s;
  }
  ss << ".dump";
  return ss.str();
}

bool StkReader::has_velocities() const {
    if (!framesets.size()) return false;
    return framesets[0]->has_velocities();
}

uint32_t StkReader::natoms() const {
    if (!framesets.size()) return false;
    return framesets[0]->natoms();
}

void StkReader::init(int* changed) {

    curframeset=0;
    if (changed) *changed = 0;
    bool stale_ddparams = false;
    const bool verbose = getenv("DTRPLUGIN_VERBOSE");
    const bool use_cache = getenv("DESRES_ROOT") && 
                          !getenv("MOLFILE_STKCACHE_DISABLE");
    
    /* get location of cache directory */
    std::string cachepath;
    bool cache_found = false;

    /* use an stk cache if running in DESRES */
    if (use_cache) {
        /* construct path to cache file */
        cachepath = filename_to_cache_location(dtr);
        if (verbose) printf("StkReader: cachepath %s\n", cachepath.c_str());

        /* attempt to read the cache file */
        std::ifstream file(cachepath.c_str());
        if (file) {
            if (verbose) printf("StkReader: cache file found\n");
            bio::filtering_istream in;
            in.push(bio::gzip_decompressor());
            in.push(file);
            /* hold on to the original path that was used to open the file */
            std::string mypath = dtr;
            try {
                load(in);
            }
            catch (std::exception& e) {
                if (verbose) 
                    printf("StkReader: Reading cache file failed, %s\n",
                        e.what());
                in.setstate(std::ios::failbit);
            }
            if (!in) {
                if (verbose) printf("StkReader: reading cache file failed.\n");
                /* reading failed for some reason.  Clear out any dtrs we
                 * might have loaded and start over */
                framesets.clear();
            } else {
              cache_found = true;
                if (verbose) printf("StkReader: reading cache file suceeded.\n");
            }
            dtr = mypath;
        } else {
            if (verbose) printf("StkReader: no cache file found\n");
        }
    }

    /* read stk file */
    std::ifstream input(path().c_str());
    if (!input) {
        DTR_FAILURE("Could not open stk file");
    }
    std::string fname;
    std::vector<std::string> fnames;
    while (std::getline(input, fname)) {
        /* strip whitespace?  ignore comment lines? */
        if (fname.size()) fnames.push_back(fname);
    }
    input.close();

    if (!fnames.size()) {
        DTR_FAILURE("Empty stk file");
    }

    /* find which framesets have already been loaded */
    unsigned i=0;
    for (; i<fnames.size(); i++) {
        if (i==framesets.size() || fnames[i]!=framesets[i]->path()) break;
        if (verbose)
            printf("StkReader: Reusing dtr at %s\n", fnames[i].c_str());

        /* previous versions did lazy loading of the ddparams.  We now
         * wish we hadn't done that because previously cached dtrs will
         * never get updated.  So we force the update here, and check
         * whether anything changed, necessitating a cache update. */
        stale_ddparams |= framesets[i]->update_ddparams();
    }
    /* delete any remaining framesets */
    for (unsigned j=i; j<framesets.size(); j++) delete framesets[j];
    framesets.erase(framesets.begin()+i, framesets.end());

    /* delete the filenames we've already loaded */
    fnames.erase(fnames.begin(), fnames.begin()+i);

    /* The set of overlapping frames may have changed!  Restore the keys
     * to their full, non-overlapping glory.  */
    for (i=0; i<framesets.size(); i++) {
        DtrReader * r = framesets[i];
        r->keys.restore_full_size();
    }

    /* read the unread timekeys files */
    std::vector<Timekeys> timekeys(fnames.size());
    for (unsigned i=0; i<timekeys.size(); i++) {
        if (verbose)
            printf("StkReader: Loading timekeys from dtr at %s\n", 
                    fnames[i].c_str());
        timekeys[i].init(fnames[i]);
    }

    if (changed) *changed = fnames.size();
    append(fnames, timekeys);

    if ((fnames.size() || stale_ddparams || !cache_found) && use_cache) {

        /* update the cache */
        if (verbose) printf("StkReader: updating cache\n");

        /* create temporary file.  We don't care about errors writing
         * the file because we'll detect any error on rename */
        std::string tmpfile(
                bfs::unique_path(
                    cachepath+"-%%%%-%%%%").string());
        int fd = open(tmpfile.c_str(), O_WRONLY|O_CREAT|O_BINARY, 0666);
        if (fd<0) {
          if (verbose)
            printf("StkReader: warning, creation of cache tmpfile at %s failed: %s\n",
            tmpfile.c_str(), strerror(errno));
        } else {
          bio::filtering_ostream out;
          bio::file_descriptor_sink file(fd, bio::close_handle);
          out.push(bio::gzip_compressor());
          out.push(file);
          dump(out);
        }

        /* do the rename, check for failure */
        boost::system::error_code ec;
        bfs::rename(bfs::path(tmpfile), bfs::path(cachepath), ec);
        if (ec) {
            if (verbose)
                /* FIXME: this should probably be more noticeable... */
                printf("StkReader: rename of tmpfile to %s failed: %s\n",
                    cachepath.c_str(), strerror(errno));
        } else {
            if (verbose)
                printf("StkReader: cache update succeeded.\n");
        }
    }
}

void StkReader::append(std::vector<std::string> fnames,
                       std::vector<Timekeys> const& timekeys ) {

  /* instantiate dtr readers */
  for (unsigned i=0; i<fnames.size(); i++) {
      DtrReader *reader = new DtrReader(fnames[i]);
      if (framesets.size()>0) {
        const DtrReader * first = framesets[0];
        /* reuse information from earlier readers */
        reader->set_natoms(first->natoms());
        reader->set_has_velocities(first->has_velocities());
        reader->set_meta(first->get_meta());
      }
      try {
        reader->initWithTimekeys(timekeys[i]);
      } catch (std::exception &e) {
          delete reader;
          DTR_FAILURE("Failed opening frameset at " << fnames[i] << ": " << e.what());
      }
      framesets.push_back(reader);
  }

  // now remove overlaps
  while (!framesets.empty() && !framesets.back()->size()) {
      delete framesets.back();
      framesets.pop_back();
  }
  if (framesets.size()) {
    double first=framesets.back()->keys[0].time();
    size_t i=framesets.size()-1;
    while (i--) {
        /* find out how many frames to keep in frameset[i] */
        Timekeys& cur = framesets[i]->keys;
        size_t n = cur.size();
        while (n && cur[n-1].time() >= first) --n;
        cur.truncate( n );
        if (cur.size()) {
          double c0t = cur[0].time();
          first = (first < c0t) ? first : c0t;
        }
    }
  }
}

ssize_t StkReader::size() const {
  ssize_t result=0;
  for (size_t i=0; i<framesets.size(); i++) 
    result += framesets[i]->keys.size();
  return result;
}

bool StkReader::next(molfile_timestep_t *ts) {
  int rc=false;
  while (curframeset < framesets.size() && 
         (rc=framesets[curframeset]->next(ts))==false) {
    ++curframeset;
  }
  return rc;
}

const DtrReader * StkReader::component(ssize_t &n) const {
  for (size_t i=0; i<framesets.size(); i++) {
    ssize_t size = framesets[i]->size();
    if (n < size) return framesets[i];
    n -= size;
  }
  return NULL;
}

void StkReader::frame(ssize_t n, molfile_timestep_t *ts) const {
  const DtrReader *comp = component(n);
  if (!comp) DTR_FAILURE("Bad frame index " << n);
  comp->frame(n, ts);
}

StkReader::~StkReader() {
  for (size_t i=0; i<framesets.size(); i++) 
    delete framesets[i];
}

std::string DtrReader::framefile(ssize_t n) const {
  return ::framefile( dtr, n, framesperfile(), ndir1(), ndir2() );
}

void DtrReader::initWithTimekeys(Timekeys const& tk) {
  keys = tk;
  init_common();
}

void DtrReader::init(int* changed) {
  keys.init(path());
  if (changed) *changed=1;
  init_common();
}

bool DtrReader::init_common() {

  bool with_momentum = false;

  /* update the ddparams if we haven't read them already */
  update_ddparams();

  // read the first frame to see how many atoms there are, and whether 
  // there are any velocities.
  // Do this only if n_atoms isn't already set
  if (keys.size()>0 && _natoms==0) {
    if (getenv("DTRPLUGIN_VERBOSE")) {
      printf("DtrReader: reading first frame to get atom count\n");
    }
    std::string fname=::framefile(dtr, 0, keys.framesperfile(), 
            ndir1(), ndir2());
    std::vector<char> buffer;
    read_file(fname, buffer);
    BlobMap blobs = read_frame(&buffer[0], buffer.size());
    with_momentum = blobs.find("MOMENTUM")!=blobs.end();

    // I'm aware of these sources of atom count: 
    //  "POSN" (the original frameset format)
    //  "POSITION" (the wrapped frameset formats)
    //  "POS" (anton trajectories)
    //  "FORCES" (forces)
    const char *posnames[] = { "POSN", "POSITION", "POS", "FORCES" };
    for (int i=0; i<sizeof(posnames)/sizeof(posnames)[0]; i++) {
      if (blobs.find(posnames[i])!=blobs.end()) {
        _natoms = blobs[posnames[i]].count / 3;
        break;
      }
    }
    // similar for velocities
    const char *velnames[] = { "MOMENTUM", "VELOCITY" };
    for (int i=0; i<2; i++) {
      if (blobs.find(velnames[i])!=blobs.end()) {
        with_velocity=true;
        break;
      }
    }
  }

  if (_natoms>0 && meta==NULL && owns_meta==false) {
    meta=read_meta( dtr + s_sep + "metadata",natoms(), with_momentum );
    owns_meta = true;
  }
}

bool DtrReader::update_ddparams() {
  if (m_ndir1<0 || m_ndir2<0) {
      if (getenv("DTRPLUGIN_VERBOSE")) 
          printf("DtrReader: reading ddparams for %s\n", dtr.c_str());
      DDgetparams(dtr, &m_ndir1, &m_ndir2);
      return true;
  }
  return false;
}

ssize_t DtrReader::times(ssize_t start, ssize_t count, double *t) const {
    ssize_t remaining = keys.size()-start;
    count = (count < remaining) ? count : remaining;
    for (ssize_t j=0; j<count; j++) {
        t[j]=keys[start++].time();
    }
    return count;
}

ssize_t StkReader::times(ssize_t start, ssize_t count, double *t) const {
    ssize_t nread=0;
    size_t i=0,n=framesets.size();
    if (start<0) return 0;
    if (count<=0) return 0;
    /* Find the first frameset containing frames in the desired range */
    /* FIXME: could do this using a binary search... */
    for (; i<n; i++) {
        ssize_t sz = framesets[i]->size();
        if (start<sz) break;
        start -= sz;
    }
    /* Read times from framesets until count times are read. */
    for (; i<n; i++) {
        ssize_t sz = framesets[i]->times(start, count, t+nread);
        nread += sz;
        count -= sz;
        start=0;
        if (!count) break;
    }
    return nread;
}

static void read_homebox( const double *box,
                          molfile_timestep_t *ts ) {

  for (int i=0; i<3; i++) {
    for (int j=0; j<3; j++) {
      ts->unit_cell[3*i+j] = box[3*j+i];
    }
  }
}

void write_homebox( const molfile_timestep_t * ts,
                    float * box ) {

  for (int i=0; i<3; i++) {
    for (int j=0; j<3; j++) {
      box[3*i+j] = ts->unit_cell[3*j+i];
    }
  }
}

static void read_scalars(
    BlobMap &blobs,
    molfile_timestep_t *ts ) {

#if defined(DESRES_READ_TIMESTEP2)
  if (blobs.find("ENERGY")!=blobs.end()) {
      blobs["ENERGY"].get_double(&ts->total_energy);
  }

  if (blobs.find("POT_ENERGY")!=blobs.end()) {
      blobs["POT_ENERGY"].get_double(&ts->potential_energy);
  }
  if (blobs.find("POTENTIALENERGY")!=blobs.end()) {
      blobs["POTENTIALENERGY"].get_double(&ts->potential_energy);
  }

  if (blobs.find("KIN_ENERGY")!=blobs.end()) {
      blobs["KIN_ENERGY"].get_double(&ts->kinetic_energy);
  }
  if (blobs.find("KINETICENERGY")!=blobs.end()) {
      blobs["KINETICENERGY"].get_double(&ts->kinetic_energy);
  }

  if (blobs.find("EX_ENERGY")!=blobs.end()) {
      blobs["EX_ENERGY"].get_double(&ts->extended_energy);
  }

  if (blobs.find("PRESSURE")!=blobs.end()) {
      blobs["PRESSURE"].get_double(&ts->pressure);
  }

  if (blobs.find("TEMPERATURE")!=blobs.end()) {
      blobs["TEMPERATURE"].get_double(&ts->temperature);
  }
  if (blobs.find("PRESSURETENSOR")!=blobs.end()) {
      blobs["PRESSURETENSOR"].get_double(ts->pressure_tensor);
  }
  if (blobs.find("VIRIALTENSOR")!=blobs.end()) {
      blobs["VIRIALTENSOR"].get_double(ts->virial_tensor);
  }
#endif
}

static void handle_force_v1(
    BlobMap &blobs,
    uint32_t natoms,
    bool with_velocity, 
    molfile_timestep_t *ts ) {

    if (blobs.find("FORCES")==blobs.end()) {
        DTR_FAILURE("Missing FORCES field in frame");
    }
    Blob frc=blobs["FORCES"];
    if (frc.count != 3*natoms) {
        DTR_FAILURE("Expected " << 3*natoms  << " elements in FORCES; got " << frc.count);
    }
  if (ts->dcoords) frc.get_double(ts->dcoords);
  if (ts->coords)  frc.get_float(ts->coords);

  read_scalars(blobs, ts);
}

static void handle_wrapped_v2(
    BlobMap &blobs,
    uint32_t natoms,
    bool with_velocity, 
    molfile_timestep_t *ts ) {

  // just read POSITION in either single or double precision
  if (blobs.find("POSITION")==blobs.end()) {
      DTR_FAILURE("Missing POSITION field in frame");
  }
  Blob pos=blobs["POSITION"];
  if (pos.count != 3*natoms) {
      DTR_FAILURE("Expected " << 3*natoms  << " elements in POSITION; got " << pos.count);
  }
  if (ts->dcoords) pos.get_double(ts->dcoords);
  if (ts->coords)     pos.get_float(ts->coords);

  if (with_velocity && (ts->velocities || ts->dvelocities) 
                    && blobs.find("VELOCITY")!=blobs.end()) {
    Blob vel=blobs["VELOCITY"];
    if (vel.count != 3*natoms) {
      DTR_FAILURE("Expected " << 3*natoms  << " elements in VELOCITY; got " << vel.count);
    }
    if (ts->dvelocities) vel.get_double(ts->dvelocities);
    if (ts->velocities)     vel.get_float(ts->velocities);
  }

  if (blobs.find("UNITCELL")!=blobs.end()) {
    double box[9];
    blobs["UNITCELL"].get_double(box);
    read_homebox( box, ts );
  }

  read_scalars(blobs, ts);
}

namespace {

  inline void
  compute_center(int partition,
                 int nx, int ny, int nz,
                 float b0, float b1, float b2,
                 float b3, float b4, float b5,
                 float b6, float b7, float b8,
                 float* cx, float* cy, float* cz) {
    double nu, nv, nw, mu, mv, mw;
    double xc, yc, zc;

    // -----------------------------------------------
    // Map the partition number to its "mesh" position
    // (see define_mesh_collective in topology.c)
    // -----------------------------------------------
    int hmx = partition;
    int hmy  = hmx / nx;     /* y = y + ny*( z + nz*r ) */
    int hmz  = hmy / ny;     /* z = z + nz*r */
    hmx -= hmy * nx;         /* x = x */
    hmy -= hmz * ny;         /* y = y */

    nu = (double)nx;
    nv = (double)ny;
    nw = (double)nz;

    // -----------------------------------------------
    // Code adapted from configure_global_cell in
    // topology.c
    // -----------------------------------------------
    mu = -0.5*(nu-1) + (double)hmx;
    mv = -0.5*(nv-1) + (double)hmy;
    mw = -0.5*(nw-1) + (double)hmz;

    // We used to do FORCE_PRECISION(xc,float) here, but that
    // seems unnecessary in the context of trajectory writing.
    xc = b0*mu + b1*mv + b2*mw; 
    yc = b3*mu + b4*mv + b5*mw; 
    zc = b6*mu + b7*mv + b8*mw; 

    *cx = xc;
    *cy = yc;
    *cz = zc;
  }

  inline void
  posn_momentum_v_1(int32_t nx, int32_t ny, int32_t nz,
                    uint64_t nparticles,
                    const double  * home_box,
                    const uint32_t* gid,
                    const uint32_t* npp,
                    const float   * rm, // reciprocal mass
                    const float* posn, const float* momentum,
                    /* returns */
                    float *position, float *velocity, double *box) {

    // bounding box is a straight multiple of the home box
    if (box) {
      box[0] = home_box[0]*nx;
      box[1] = home_box[1]*ny;
      box[2] = home_box[2]*nz;
        
      box[3] = home_box[3]*nx;
      box[4] = home_box[4]*ny;
      box[5] = home_box[5]*nz;

      box[6] = home_box[6]*nx;
      box[7] = home_box[7]*ny;
      box[8] = home_box[8]*nz;
    }


    int partition = 0;
    int remaining = 0;
    float cx = 0;
    float cy = 0;
    float cz = 0;
    float ux = home_box[0];
    float vx = home_box[1];
    float wx = home_box[2];
    float uy = home_box[3];
    float vy = home_box[4];
    float wy = home_box[5];
    float uz = home_box[6];
    float vz = home_box[7];
    float wz = home_box[8];

    for(uint64_t i=0; i<nparticles; ++i) {
      if (remaining == 0) {
        do {
          remaining = npp[partition];
          ++partition;
        } while (!remaining); // skip empty partitions
          compute_center(partition-1, nx,ny,nz, ux,vx,wx, uy,vy,wy, uz,vz,wz,
                        &cx,&cy,&cz);
      }
      uint32_t id = gid[i];
      if (id >= nparticles) {
          DTR_FAILURE("non-contiguous particles");
      }

      if (posn) {
        float x = posn[3*i+0];
        float y = posn[3*i+1];
        float z = posn[3*i+2];

        position[3*id+0] = ux*x + vx*y + wx*z + cx;
        position[3*id+1] = uy*x + vy*y + wy*z + cy;
        position[3*id+2] = uz*x + vz*y + wz*z + cz;
      }

      if (velocity && momentum && rm) {
        velocity[3*id+0] = momentum[3*i+0]*rm[id];
        velocity[3*id+1] = momentum[3*i+1]*rm[id];
        velocity[3*id+2] = momentum[3*i+2]*rm[id];
      } else if (velocity) {
        velocity[3*id+0] = 0.0;
        velocity[3*id+1] = 0.0;
        velocity[3*id+2] = 0.0;
      }
      --remaining;
    }
  }
}

static void handle_posn_momentum_v1(
    BlobMap &blobs,
    uint32_t natoms,
    bool with_velocity, 
    const float * rmass,
    molfile_timestep_t *ts ) {

  if (ts->dcoords) {
      DTR_FAILURE("Sorry, can't load double precision coordinates from this frameset format");
  }
  int32_t nx, ny, nz;
  double home_box[9], box[9];
  blobs["HOME_BOX"].get_double(home_box);
  blobs["NX"].get_int32(&nx);
  blobs["NY"].get_int32(&ny);
  blobs["NZ"].get_int32(&nz);
  
  std::vector<uint32_t> gid, npp;
  std::vector<float> pos, mtm;
  Blob gidblob=blobs["GID"];
  Blob nppblob=blobs["NPP"];
  Blob posblob=blobs["POSN"];
  Blob mtmblob=blobs["MOMENTUM"];

  if (gidblob.count != natoms) {
      DTR_FAILURE("Missing GID field");
  }
  if (posblob.count != 3*natoms) {
      DTR_FAILURE("Missing POSN field");
  }
  gid.resize(gidblob.count);
  npp.resize(nppblob.count);
  pos.resize(posblob.count);
  mtm.resize(mtmblob.count);

  gidblob.get_uint32(&gid[0]);
  nppblob.get_uint32(&npp[0]);
  posblob.get_float(&pos[0]);

  if (rmass && with_velocity) mtmblob.get_float(&mtm[0]);

  posn_momentum_v_1( nx, ny, nz, natoms, home_box, 
                     &gid[0], &npp[0], rmass,
                     &pos[0],
                     &mtm[0],
                     ts->coords,
                     ts->velocities,
                     box );

  read_homebox( box, ts );
}

static void handle_wrapped_v1(
    BlobMap &blobs,
    uint32_t natoms,
    bool with_velocity, 
    molfile_timestep_t *ts ) {

  if (ts->dcoords) {
      DTR_FAILURE("Sorry, can't load double precision coordinates from this frameset format");
  }
  {
    // homebox
    double home_box[9], box[9];
    int32_t nx, ny, nz;
    blobs["HOME_BOX"].get_double(home_box);
    blobs["NX"].get_int32(&nx);
    blobs["NY"].get_int32(&ny);
    blobs["NZ"].get_int32(&nz);
    box[0] = home_box[0]*nx;
    box[1] = home_box[1]*ny;
    box[2] = home_box[2]*nz;
      
    box[3] = home_box[3]*nx;
    box[4] = home_box[4]*ny;
    box[5] = home_box[5]*nz;
 
    box[6] = home_box[6]*nx;
    box[7] = home_box[7]*ny;
    box[8] = home_box[8]*nz;
    read_homebox( box, ts );
  }

  Blob posblob=blobs["POSN"];
  Blob velblob=blobs["VELOCITY"];

  // get positions
  if (posblob.count != 3*natoms) {
      DTR_FAILURE("Missing POSN field");
  }
  posblob.get_float(ts->coords);
  
  // if required, get velocities
  if (ts->velocities && velblob.count > 0) {
    if (velblob.count != 3*natoms) {
      DTR_FAILURE("Expected " << 3*natoms  << " elements in VELOCITY; got " << velblob.count);
    }
    velblob.get_float(ts->velocities);
  }
}

static void handle_anton_sfxp_v3(
    BlobMap &blobs,
    uint32_t natoms,
    bool with_velocity, 
    const float * rmass,
    molfile_timestep_t *ts ) {

  double positionScale=0, momentumScale=0;
  // position scale...
  {
    Blob blob = blobs["POSITIONSCALE"];
    if (blob.count != 1) {
        DTR_FAILURE("Missing POSITIONSCALE field");
    }
    blob.get_double(&positionScale);
  }
  // momentum scale
  if (ts->velocities || ts->dvelocities) {
    if (!rmass) {
        DTR_FAILURE("Cannot read anton_sfxp_v3 velocities without rmass");
    }

    Blob blob = blobs["MOMENTUMSCALE"];
    if (blob.count != 1) {
        DTR_FAILURE("Missing MOMENTUMSCALE field");
    }
    blob.get_double(&momentumScale);
    momentumScale *= PEAKmassInAmu;
  }

  // box
  {
    double box[9] = { 0,0,0, 0,0,0, 0,0,0 };
    uint32_t anton_box[3];
    Blob boxblob = blobs["BOX"];
    if (boxblob.count != 3) {
        DTR_FAILURE("Missing BOX field");
    }
    boxblob.get_uint32(anton_box);
    box[0] = sfxp_ulp32flt(anton_box[0])*positionScale;
    box[4] = sfxp_ulp32flt(anton_box[1])*positionScale;
    box[8] = sfxp_ulp32flt(anton_box[2])*positionScale;
    read_homebox( box, ts );
  }

  // velocities
  std::vector<int32_t> vel;
  if (ts->velocities || ts->dvelocities) {
    Blob velblob = blobs["MOMENTUM"];
    if (velblob.count != 3*natoms) {
        DTR_FAILURE("Missing or wrong size MOMENTUM field");
    }
    vel.resize(3*natoms);
    velblob.get_int32(&vel[0]);
  }

  // positions
  std::vector<int32_t> pos(3*natoms);
  {
    Blob posblob = blobs["POS"];
    if (posblob.count != 3*natoms) {
        DTR_FAILURE("Missing or wrong size POS field");
    }
    posblob.get_int32(&pos[0]);
  }
  // convert and read into supplied storage
  if (ts->coords) for (unsigned i=0; i<natoms; i++) {
    ts->coords[3*i  ] = sfxp_ulp32flt(pos[3*i+0])*positionScale;
    ts->coords[3*i+1] = sfxp_ulp32flt(pos[3*i+1])*positionScale;
    ts->coords[3*i+2] = sfxp_ulp32flt(pos[3*i+2])*positionScale;
    if (ts->velocities) {
      const double rm = rmass[i] * momentumScale; // includes PEAKmassInAmu
      ts->velocities[3*i  ] = (float)(rm * sfxp_ulp32flt(vel[3*i  ]));
      ts->velocities[3*i+1] = (float)(rm * sfxp_ulp32flt(vel[3*i+1]));
      ts->velocities[3*i+2] = (float)(rm * sfxp_ulp32flt(vel[3*i+2]));
    }
  }
  if (ts->dcoords) for (unsigned i=0; i<natoms; i++) {
    ts->dcoords[3*i  ] = sfxp_ulp32flt(pos[3*i+0])*positionScale;
    ts->dcoords[3*i+1] = sfxp_ulp32flt(pos[3*i+1])*positionScale;
    ts->dcoords[3*i+2] = sfxp_ulp32flt(pos[3*i+2])*positionScale;
  }
  if (ts->dvelocities) for (unsigned i=0; i<natoms; i++) {
    const double rm = rmass[i] * momentumScale; // includes PEAKmassInAmu
    ts->dvelocities[3*i  ] = (rm * sfxp_ulp32flt(vel[3*i  ]));
    ts->dvelocities[3*i+1] = (rm * sfxp_ulp32flt(vel[3*i+1]));
    ts->dvelocities[3*i+2] = (rm * sfxp_ulp32flt(vel[3*i+2]));
  }
}

bool DtrReader::next(molfile_timestep_t *ts) {

  if (eof()) return false;
  if (!ts) {
    ++m_curframe;
    return true;
  }
  ssize_t iframe = m_curframe;
  ++m_curframe;
  frame(iframe, ts);
  return true;
}

void DtrReader::frame(ssize_t iframe, molfile_timestep_t *ts) const {
    off_t offset=0;
    ssize_t framesize=0;
    if (iframe<0 || iframe>=keys.full_size()) {
        DTR_FAILURE("dtr " << dtr << " has no frame " << iframe << ": nframes=" << keys.full_size());
    }
    if (framesperfile() != 1) {
      offset = assemble64( ntohl(keys[iframe].offset_lo), 
                           ntohl(keys[iframe].offset_hi) );
      framesize = assemble64( ntohl(keys[iframe].framesize_lo), 
                              ntohl(keys[iframe].framesize_hi) );

    }
    ts->physical_time = keys[iframe].time();
    std::string fname=::framefile(dtr, iframe, framesperfile(), ndir1(), ndir2());
    std::vector<char> buffer(framesize);
    read_file(fname, buffer, offset);
    frame_from_bytes( &buffer[0], buffer.size(), ts );
}

void DtrReader::frame_from_bytes(const void *buf, uint64_t len, 
                                molfile_timestep_t *ts) const {

  BlobMap blobs = read_frame(buf, len);

  const float * rmass = meta && meta->invmass.size() ? 
      &meta->invmass[0] : NULL;

  // Now, dispatch to routines based on format
  std::string format = blobs["FORMAT"].str();
  if (format=="WRAPPED_V_2" || format == "DBL_WRAPPED_V_2") {
    handle_wrapped_v2(blobs, _natoms, with_velocity, ts);

  } else if (format=="POSN_MOMENTUM_V_1" || format=="DBL_POSN_MOMENTUM_V_1") {
    handle_posn_momentum_v1(blobs, _natoms, with_velocity, rmass, ts);

  } else if (format=="WRAPPED_V_1" || format == "DBL_WRAPPED_V_1") {
    handle_wrapped_v1(blobs, _natoms, with_velocity, ts);

  } else if (format=="ANTON_SFXP_V3") {
    handle_anton_sfxp_v3(blobs, _natoms, with_velocity, rmass, ts);

  } else if (format=="FORCE_V_1" || format == "DBL_FORCE_V_1") {
      handle_force_v1(blobs, _natoms, with_velocity, ts);

  } else {
    DTR_FAILURE("can't handle format " << format);
  }
}


namespace {
  struct meta_t {
    std::string label;
    std::string typecode;
    uint32_t elementsize;
    uint64_t count;
    const char *bytes;
    meta_t() {}
    meta_t(const std::string &l, const std::string &t, uint32_t e, uint32_t c,
           const void *b)
    : label(l), typecode(t), elementsize(e), count(c), 
    bytes(reinterpret_cast<const char *>(b)) {}
  };
  typedef std::vector<meta_t> MetaList;

  uint64_t typename_size(const MetaList &meta) {
    // just the set of distinct types
    uint64_t sz=0;
    typedef std::set<std::string> Typemap;
    Typemap types;
    for (MetaList::const_iterator m=meta.begin(); m!=meta.end(); ++m)
      types.insert(m->typecode);
    for (Typemap::const_iterator s=types.begin(); s!=types.end();++s)
      sz += s->size() + 1;
    sz += 1;
    return alignInteger(sz, s_alignsize);
  }

  uint64_t label_size(const MetaList &meta) {
    uint64_t sz=0;
    for (MetaList::const_iterator m=meta.begin(); m!=meta.end(); ++m)
      sz += m->label.size() + 1;
    sz += 1;
    return alignInteger(sz, s_alignsize);
  }

  uint64_t scalar_size(const MetaList &meta) {
    uint64_t sz=0;
    for (MetaList::const_iterator m=meta.begin(); m!=meta.end(); ++m)
      if (m->count <= 1) 
        sz += alignInteger( m->elementsize * m->count, s_alignsize );
    return sz;
  }
  uint64_t field_size(const MetaList &meta) {
    uint64_t sz=0;
    for (MetaList::const_iterator m=meta.begin(); m!=meta.end(); ++m)
      if (m->count > 1) 
        sz += alignInteger( m->elementsize * m->count, s_alignsize );
    return sz;
  }

  void construct_frame( const std::vector<meta_t>& meta, 
                        std::vector<char>& bytes ) {
    uint64_t offset_header_block = 0;
    uint64_t size_header_block =
      alignInteger( sizeof(header_t), s_alignsize );

    uint64_t offset_meta_block = offset_header_block + size_header_block;
    uint64_t size_meta_block = 
      alignInteger( meta.size()*sizeof(metadisk_t), s_alignsize );

    uint64_t offset_typename_block = offset_meta_block + size_meta_block;
    uint64_t size_typename_block = typename_size(meta);

    uint64_t offset_label_block = offset_typename_block + size_typename_block;
    uint64_t size_label_block = label_size(meta);

    uint64_t offset_scalar_block = offset_label_block + size_label_block;
    uint64_t size_scalar_block = scalar_size(meta);

    uint64_t offset_field_block = offset_scalar_block + size_scalar_block;
    uint64_t size_field_block = field_size(meta);

    uint64_t offset_crc_block = offset_field_block + size_field_block;
    uint64_t size_crc_block = sizeof(uint32_t);

    uint64_t offset_padding_block = offset_crc_block + size_crc_block;
    uint64_t size_padding_block = 
      alignInteger(offset_padding_block,s_blocksize) - offset_padding_block;

    uint64_t framesize = offset_padding_block + size_padding_block;

    // construct the frame
    bytes.resize(framesize);
    char * base = &bytes[0];
    memset( base, 0, framesize );

    header_t *header = reinterpret_cast<header_t*>(base+offset_header_block);
    metadisk_t* diskmeta  = reinterpret_cast<metadisk_t*>(base+offset_meta_block);
    char*       typenames = reinterpret_cast<char*>(base+offset_typename_block);
    char*       labels    = reinterpret_cast<char*>(base+offset_label_block);
    char*       scalars   = reinterpret_cast<char*>(base+offset_scalar_block);
    char*       fields    = reinterpret_cast<char*>(base+offset_field_block);
    uint32_t*   crc       = reinterpret_cast<uint32_t*>(base+offset_crc_block);
    //char*       padding   = reinterpret_cast<char*>(base+offset_padding_block);

    /*** header ***/
    memset(header,0,sizeof(header_t));
    header->required.magic = htonl(magic_frame);
    header->required.version = htonl(s_version);

    header->required.framesize_lo = htonl(lobytes(framesize));
    header->required.framesize_hi = htonl(hibytes(framesize));

    header->size_header_block = htonl(size_header_block);
    header->unused0 = 0;
    uint64_t lrosetta = assemble64(s_lrosetta_lo,s_lrosetta_hi);
    header->irosetta = s_irosetta;
    header->frosetta = s_frosetta;

    header->drosetta_lo = lobytes(s_drosetta);
    header->drosetta_hi = hibytes(s_drosetta);
    header->lrosetta_lo = lobytes(lrosetta);
    header->lrosetta_hi = hibytes(lrosetta);

    header->endianism = htonl(machineEndianism());
    header->nlabels = htonl(meta.size());
    header->size_meta_block = htonl(size_meta_block);
    header->size_typename_block = htonl(size_typename_block);

    header->size_label_block = htonl(size_label_block);
    header->size_scalar_block = htonl(size_scalar_block);
    header->size_field_block_lo = htonl(lobytes(size_field_block));
    header->size_field_block_hi = htonl(hibytes(size_field_block));

    header->size_crc_block = htonl(size_crc_block);
    header->size_padding_block = htonl(size_padding_block);
    header->unused1 = 0;
    header->unused2 = 0;

    std::map<std::string,unsigned> typemap;

    for (MetaList::const_iterator m=meta.begin(); m!=meta.end(); ++m) {

      if (typemap.find(m->typecode)==typemap.end()) {
        unsigned code=typemap.size();
        typemap[m->typecode]=code;
        typenames=std::copy(m->typecode.begin(), m->typecode.end(), typenames);
        *typenames++ = 0;
      }

      diskmeta->type = htonl( typemap[m->typecode] );
      diskmeta->elementsize = htonl( m->elementsize );
      diskmeta->count_lo = htonl( lobytes( m->count ));
      diskmeta->count_hi = htonl( hibytes( m->count ));
      diskmeta++;

      labels=std::copy(m->label.begin(), m->label.end(), labels);
      *labels++ = 0;

      uint64_t nbytes = m->count*m->elementsize;
      if (m->count <= 1) {
        memcpy( scalars, m->bytes, nbytes );
        scalars += alignInteger( nbytes, s_alignsize );
      } else {
        memcpy( fields, m->bytes, nbytes );
        fields += alignInteger( nbytes, s_alignsize );
      }
    }
    *crc = fletcher(reinterpret_cast<uint16_t*>(base),offset_crc_block/2);
  }
}

void write_all( int fd, const char * buf, ssize_t count ) {
    while (count) {
        ssize_t n = ::write(fd, buf, count);
        if (n<0) {
            if (errno==EINTR) continue;
            throw std::runtime_error(strerror(errno));
        }
        buf += n;
        count -= n;
    }
}

void DtrWriter::init(const std::string &path, DtrWriter::Mode mode) {

    dtr=path;
    m_directory=path;
    char cwd[4096];

    while(m_directory.size() > 0 && m_directory[m_directory.size()-1] == s_sep) {
      m_directory.erase(m_directory.size()-1);
    }

    if ( m_directory[0] != s_sep) {
      if (! ::getcwd(cwd,sizeof(cwd))) {
        throw std::runtime_error(strerror(errno));
      }
      m_directory = std::string(cwd) + s_sep + m_directory;
    }

    std::string timekeys_path = dtr + s_sep + "timekeys";

    if (mode==NOCLOBBER && exists(m_directory)) {
        DTR_FAILURE("path '" << m_directory << "' already exists and mode is NOCLOBBER");
    } else if (mode==APPEND && exists(m_directory)) {
        /* read existing timekeys */
        Timekeys tk;
        tk.init(dtr);
        frames_per_file = tk.framesperfile();
        nwritten = tk.size();
        if (nwritten==0) {
            last_time=0;
            framefile_offset = 0;
            frame_fd = 0;
        } else {
            key_record_t last = tk[nwritten-1];
            last_time = last.time();
            framefile_offset = last.offset() + last.size();
            std::string filepath=framefile(dtr, nwritten, frames_per_file,0,0);
            frame_fd = open(filepath.c_str(),O_WRONLY|O_APPEND|O_BINARY,0666);
        }
        timekeys_file = fopen(timekeys_path.c_str(), "a");
        if (!timekeys_file) {
            DTR_FAILURE("Opening timekeys failed: " << strerror(errno));
        }

    } else {
        /* start afresh */
        recursivelyRemove(m_directory);
        ::DDmkdir(m_directory,0777,0, 0);

        // craft an empty metadata frame
        std::vector<meta_t> meta;
        std::vector<char> bytes;
        construct_frame( meta, bytes );

        {
          std::string metadata_file = m_directory + s_sep + "metadata";
          FILE *fd = fopen(metadata_file.c_str(), "wb");
          fwrite( &bytes[0], bytes.size(), 1, fd );
          fclose(fd);
        }

        // start writing timekeys file */
        timekeys_file = fopen( timekeys_path.c_str(), "wb" );
        if (!timekeys_file) {
            DTR_FAILURE("Opening timekeys failed: " << strerror(errno));
        } else {
          key_prologue_t prologue[1];
          prologue->magic = htonl(magic_timekey);
          prologue->frames_per_file = htonl(frames_per_file);
          prologue->key_record_size = htonl(sizeof(key_record_t));
          fwrite( prologue, sizeof(key_prologue_t), 1, timekeys_file );
        }
    }
}

void DtrWriter::next(const molfile_timestep_t *ts) {

    static const char *format = "WRAPPED_V_2";
    static const char *title = "written by molfile/VMD";
    float box[9];
    write_homebox( ts, box );

    double time = ts->physical_time;

    /* require increasing times (DESRESCode#1053) */
    if (last_time != HUGE_VAL && time <= last_time) {
        DTR_FAILURE("framesets require increasing times. previous " << last_time << " current " << time);
    }

    std::vector<meta_t> meta;
    meta.push_back( 
        meta_t( "FORMAT", "char", sizeof(char), strlen(format), format ));
    meta.push_back( 
        meta_t( "TITLE", "char", sizeof(char), strlen(title), title ));
    meta.push_back( 
        meta_t( "CHEMICAL_TIME", "double", sizeof(double), 1, &time));
    meta.push_back( 
        meta_t( "UNITCELL", "float", sizeof(float), 9, box ));
    meta.push_back( 
        meta_t( "POSITION", "float", sizeof(float), 3*natoms, ts->coords ));
    if (ts->velocities) meta.push_back(
        meta_t( "VELOCITY", "float", sizeof(float), 3*natoms, ts->velocities ));
#if defined(DESRES_READ_TIMESTEP2)
    meta.push_back(
        meta_t( "ENERGY", "double", sizeof(double), 1, &ts->total_energy ));
    meta.push_back(
        meta_t( "POT_ENERGY", "double", sizeof(double), 1, &ts->potential_energy ));
    meta.push_back(
        meta_t( "KIN_ENERGY", "double", sizeof(double), 1, &ts->kinetic_energy ));
    meta.push_back(
        meta_t( "EX_ENERGY", "double", sizeof(double), 1, &ts->extended_energy ));
    meta.push_back(
        meta_t( "TEMPERATURE", "double", sizeof(double), 1, &ts->temperature));
    meta.push_back(
        meta_t( "PRESSURE", "double", sizeof(double), 1, &ts->pressure));
    meta.push_back(
        meta_t( "PRESSURETENSOR", "double", sizeof(double), 9, ts->pressure_tensor));
    meta.push_back(
        meta_t( "VIRIALTENSOR", "double", sizeof(double), 9, ts->virial_tensor));

#endif

    std::vector<char> base;
    construct_frame(meta, base);
    uint64_t framesize = base.size();
    uint64_t keys_in_file = nwritten % frames_per_file;

    if (!keys_in_file) {
      if (frame_fd>0) ::close(frame_fd);

      framefile_offset = 0;
      std::string filepath=framefile(dtr, nwritten, frames_per_file, 0, 0);
      frame_fd = open(filepath.c_str(),O_WRONLY|O_CREAT|O_BINARY,0666);
      if (frame_fd<0) throw std::runtime_error(strerror(errno));
    }

    // write the data to disk
    write_all( frame_fd, &base[0], framesize );

    // add an entry to the keyfile list
    key_record_t timekey;
    timekey.time_lo = htonl(lobytes(time));
    timekey.time_hi = htonl(hibytes(time));
    timekey.offset_lo = htonl(lobytes(framefile_offset));
    timekey.offset_hi = htonl(hibytes(framefile_offset));
    timekey.framesize_lo = htonl(lobytes(framesize));
    timekey.framesize_hi = htonl(hibytes(framesize));

    if (fwrite(&timekey, sizeof(timekey), 1, timekeys_file)!=1) {
        DTR_FAILURE("Writing timekey failed: " << strerror(errno));
    }

#if defined(_MSC_VER)
    _commit(frame_fd);
#else
    fsync(frame_fd);
#endif
    fflush(timekeys_file);
#if defined(_MSC_VER)
    _commit(fileno(timekeys_file));
#else
    fsync(fileno(timekeys_file));
#endif

    ++nwritten;
    framefile_offset += framesize;
}

DtrWriter::~DtrWriter() {
  if (frame_fd>0) ::close(frame_fd);
  if (timekeys_file) fclose(timekeys_file);
}

/* compressed form: first write a -1 to indicate the new format.  Then
 * write number of ranges n, followed by (start, count) pairs. */
std::ostream& operator<<(std::ostream& out, const metadata_t& meta) {
    out << meta.invmass.size() << ' ';
    if (meta.invmass.size()) {
        out.write( (const char *)&meta.invmass[0], meta.invmass.size()*sizeof(meta.invmass[0]));
    }
    return out;
}

std::istream& operator>>(std::istream& in, metadata_t& meta) {
    uint32_t sz;
    char c;
    in >> sz;
    in.get(c);
    meta.invmass.resize(sz);
    if (sz) {
        in.read((char *)&meta.invmass[0], sz*sizeof(meta.invmass[0]));
    }
    return in;
}

std::ostream& DtrReader::dump(std::ostream &out) const {
  bool has_meta = meta!=NULL;
  out << SERIALIZED_VERSION << ' '
      << dtr << ' '
      << _natoms << ' '
      << with_velocity << ' '
      << owns_meta << ' '
      << has_meta << ' ';
  if (owns_meta && has_meta) {
      out << *meta;
  }
  /* write raw m_ndir values so that we don't read them from .ddparams
   * if they haven't been read yet */
  out << m_ndir1 << ' '
      << m_ndir2 << ' ';
  keys.dump(out);
  return out;
}
std::istream& DtrReader::load(std::istream &in) {
  char c;
  bool has_meta;
  std::string version;
  in >> version;
  if (badversion(version)) {
      DTR_FAILURE("Bad version string: " << version);
  }
  in >> dtr
     >> _natoms
     >> with_velocity
     >> owns_meta
     >> has_meta;
  if (owns_meta && has_meta) {
    delete meta;
    meta = new metadata_t;
    in.get(c);
    in >> *meta;
  }
  in >> m_ndir1
     >> m_ndir2;
  in.get(c);
  keys.load(in);
  return in;
}

std::ostream& StkReader::dump(std::ostream &out) const {
  out << dtr << ' '
      << framesets.size() << ' ';
  for (size_t i=0; i<framesets.size(); i++) framesets[i]->dump(out);
  return out;
}

std::istream& StkReader::load(std::istream &in) {
  in >> dtr;
  size_t size; in >> size; framesets.resize(size);
  char c; in.get(c);
  for (size_t i=0; i<framesets.size(); i++) {
    delete framesets[i];
    framesets[i] = new DtrReader("<no file>");
    framesets[i]->load(in);
    if (i>0) framesets[i]->set_meta(framesets[0]->get_meta());
  }
  return in;
}

///////////////////////////////////////////////////////////////////
//
// Plugin Interface
//
// ////////////////////////////////////////////////////////////////

static void *
open_file_read( const char *filename, const char *filetype, int *natoms ) {

  FrameSetReader *h = NULL;

  // check for .stk file
  if (StkReader::recognizes(filename)) {
    h = new StkReader(filename);

  } else {
    // check for "clickme.dtr"
      std::string fname=filename;
    std::string::size_type pos = fname.rfind( "clickme.dtr" );
    if (pos != std::string::npos) {
      fname.resize(pos);
      filename = fname.c_str();
    }
    h = new DtrReader(fname);
  }

  try {
      h->init();
  }
  catch (std::exception &e) {
      delete h;
      fprintf(stderr, "Failed to open %s file at %s: %s\n", 
              filetype, filename, e.what());
      return NULL;
  }
  *natoms = h->natoms();
  return h;
}

static int 
read_timestep_metadata(void *v, molfile_timestep_metadata *m) {
  FrameSetReader* handle = reinterpret_cast<FrameSetReader*>(v);
  m->has_velocities = handle->has_velocities();
  m->count = handle->size();
  m->supports_double_precision = true;
  return MOLFILE_SUCCESS;
}

static int read_next_timestep(void *v, int natoms, molfile_timestep_t *ts) {
  FrameSetReader *h = reinterpret_cast<FrameSetReader *>(v);
  try {
    if (h->next(ts)) return MOLFILE_SUCCESS;
  }
  catch (std::exception &e) {
      fprintf(stderr, "Failed reading timestep: %s\n", e.what());
  }
  return MOLFILE_ERROR;
}

#if defined(DESRES_READ_TIMESTEP2)
static int read_timestep2(void *v, ssize_t n, molfile_timestep_t *ts) {
  FrameSetReader *h = reinterpret_cast<FrameSetReader *>(v);
  try {
    h->frame(n, ts);
    return MOLFILE_SUCCESS;
  }
  catch (std::exception &e) {
      fprintf(stderr, "Failed reading timestep: %s\n", e.what());
  }
  return MOLFILE_ERROR;
}

static molfile_ssize_t read_times(void *v, 
                                  molfile_ssize_t start, 
                                  molfile_ssize_t count,
                                  double * times) {
  FrameSetReader *h = reinterpret_cast<FrameSetReader *>(v);
  return h->times(start, count, times);
}
#endif

static void close_file_read( void *v ) {
  FrameSetReader *h = reinterpret_cast<FrameSetReader *>(v);
  delete h;
}

static void *open_file_write(const char *path, const char *type, int natoms) {
  DtrWriter::Mode mode;
  if (!strcmp(type, "dtr") || !strcmp(type, "dtr_clobber")) {
      mode = DtrWriter::CLOBBER;
  } else if (!strcmp(type, "dtr_append")) {
      mode = DtrWriter::APPEND;
  } else if (!strcmp(type, "dtr_noclobber")) {
      mode = DtrWriter::NOCLOBBER;
  } else {
      fprintf(stderr, "Unrecognized filetype '%s'\n", type);
      return NULL;
  }

  DtrWriter *h = new DtrWriter(natoms);

  try {
      h->init(path, mode);
  }
  catch (std::exception &e) {
      delete h;
      h = NULL;
      fprintf(stderr, "Failed to open file of type %s at %s for writing: %s\n",
              type, path, e.what());
  }
  return h;
}

static int write_timestep(void *v, const molfile_timestep_t *ts) {
  DtrWriter *h = reinterpret_cast<DtrWriter *>(v);
  try {
      h->next(ts);
      return MOLFILE_SUCCESS;
  }
  catch (std::exception &e) {
      fprintf(stderr, "Failed writing timestep: %s\n", e.what());
  }
  return MOLFILE_ERROR;
}

static void close_file_write( void * v ) {
  DtrWriter *h = reinterpret_cast<DtrWriter *>(v);
  delete h;
}


static molfile_plugin_t desmond;
static molfile_plugin_t dtr_append;
static molfile_plugin_t dtr_clobber;
static molfile_plugin_t dtr_noclobber;

VMDPLUGIN_API int VMDPLUGIN_init (void) {
  /* Plugin for desmond trajectory files */
  ::memset(&desmond,0,sizeof(desmond));
  desmond.abiversion = vmdplugin_ABIVERSION;
  desmond.type = MOLFILE_PLUGIN_TYPE;
  desmond.name = "dtr";
  desmond.prettyname = "DESRES Trajectory, clobber";
  desmond.author = "D.E. Shaw Research";
  desmond.majorv = 4;
  desmond.minorv = 0;
  desmond.is_reentrant = VMDPLUGIN_THREADUNSAFE;

  desmond.filename_extension = "dtr,dtr/,stk,atr,atr/";
  desmond.open_file_read = open_file_read;
  desmond.read_timestep_metadata = read_timestep_metadata;
  desmond.read_next_timestep = read_next_timestep;
#if defined(DESRES_READ_TIMESTEP2)
  desmond.read_timestep2 = read_timestep2;
  desmond.read_times = read_times;
#endif
  desmond.close_file_read = close_file_read;

  desmond.open_file_write = open_file_write;
  desmond.write_timestep = write_timestep;
  desmond.close_file_write = close_file_write;

  memcpy(&dtr_append, &desmond, sizeof(desmond));
  memcpy(&dtr_clobber, &desmond, sizeof(desmond));
  memcpy(&dtr_noclobber, &desmond, sizeof(desmond));
  dtr_append.name="dtr_append";
  dtr_append.prettyname = "DESRES Trajectory, append";
  dtr_clobber.name="dtr_clobber";
  dtr_noclobber.name="dtr_noclobber";
  dtr_noclobber.prettyname = "DESRES Trajectory, no-clobber";

  return VMDPLUGIN_SUCCESS;
}

VMDPLUGIN_API int VMDPLUGIN_register(void *v, vmdplugin_register_cb cb) {
  cb(v,reinterpret_cast<vmdplugin_t*>(&desmond));
  cb(v,reinterpret_cast<vmdplugin_t*>(&dtr_append));
  cb(v,reinterpret_cast<vmdplugin_t*>(&dtr_clobber));
  cb(v,reinterpret_cast<vmdplugin_t*>(&dtr_noclobber));
  return VMDPLUGIN_SUCCESS;
}

VMDPLUGIN_API int VMDPLUGIN_fini(void) {
  return VMDPLUGIN_SUCCESS;
}

