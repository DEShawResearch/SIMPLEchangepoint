#include "periodic_table.h"
#include <stdlib.h>
#include <stdio.h>

int main(int argc, char *argv[]) {
    int i;
    for (i=1; i<argc; i++) {
        double mass = atof(argv[i]);
        int anum = get_pte_idx_from_mass(mass);
        printf("mass %f -> anum %d\n", mass, anum);
    }
    return 0;
}

