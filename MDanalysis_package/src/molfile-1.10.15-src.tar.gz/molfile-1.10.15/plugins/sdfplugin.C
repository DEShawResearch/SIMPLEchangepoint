/***************************************************************************
 *cr
 *cr            (C) Copyright 1995-2009 The Board of Trustees of the
 *cr                        University of Illinois
 *cr                         All Rights Reserved
 *cr
 ***************************************************************************/

/***************************************************************************
 * RCS INFORMATION:
 *
 *      $RCSfile: mdfplugin.C,v $
 *      $Author: desrad_gullingj $       $Locker:  $             $State: Exp $
 *      $Revision: #2 $       $Date: 2013/03/04 $
 *
 ***************************************************************************/

#include "molfile_plugin.h"
#include "periodic_table.h"

#include <boost/foreach.hpp>
#include <boost/algorithm/string.hpp> /* for boost::trim */
#include <boost/iostreams/filtering_stream.hpp>
#include <boost/iostreams/filter/gzip.hpp>
#include <stdexcept>

#include <stdio.h>
#include <errno.h>
#include <string>
#include <vector>

#include <fstream>
#include <sstream>

#define MSYS_FAIL(args) do { \
    std::stringstream ss; \
    ss << args; \
    throw std::runtime_error(ss.str()); \
} while(0)


namespace {
    molfile_plugin_t plugin;

    /* FIXME: these are also implemented in atomsel.. */
    int stringToInt(std::string const& str){
        char* stop;
        int res = strtol( str.c_str(), &stop, 10 );
        if ( *stop != 0 ) MSYS_FAIL("Bad int Specification: '" << str << "'");
        return res;
    }
    
    double stringToDouble(std::string const& str){
        char* stop;
        double res = strtod( str.c_str(), &stop );
        if ( *stop != 0 ) MSYS_FAIL("Bad double Specification:\n" << str);
        return res;
    }

    class iterator {
        std::ifstream file;
        boost::iostreams::filtering_istream in;

    public:
        explicit iterator(std::string const& path)
        : file(path.c_str()), timesteps_done(false) {
            if (!file) {
                MSYS_FAIL("Failed opening SDF file for reading at " << path);
            }
            init(file);
        }

        void init(std::istream& input) {
            /* FIXME - copied from mae/mae.cxx */
            /* check for gzip magic number */
            if (input.get()==0x1f && input.get()==0x8b) {
                in.push(boost::iostreams::gzip_decompressor());
            }
            input.seekg(0);
            in.push(input);
        }

        std::vector<molfile_atom_t> atoms;
        std::vector<int> from, to;
        std::vector<float> order;
        std::vector<float> pos;
        bool next();

        bool timesteps_done;
    };
}

bool iterator::next() {
    if (in.eof()) return false;

    /* Header block contains exactly three lines.  */
    std::string h1, h2, h3;
    std::getline(in,h1);
    std::getline(in,h2);
    std::getline(in,h3);
    if (!in) {
        if (in.eof()) return false;
        MSYS_FAIL("Failed reading header block.");
    }

    /* parse counts line */
    std::string line;
    if (!std::getline(in,line)) MSYS_FAIL("Failed reading counts");
    int natoms = stringToInt(line.substr(0,3));
    int nbonds = stringToInt(line.substr(3,3));

    int bstart=atoms.size();

    /* Load Atoms */
    for (int i=0; i<natoms; i++) {
        if (!std::getline(in, line)) {
            MSYS_FAIL("Missing expected Atom record " << i+1);
        }

        /* Allow atom lines to have incomplete info (must have up to element) */
        if(line.size()<34){
            MSYS_FAIL("Malformed atom line:\n"<<line);
        }
    
        molfile_atom_t atom;
        memset(&atom,0,sizeof(atom));
        pos.push_back(stringToDouble(line.substr( 0,10)));
        pos.push_back(stringToDouble(line.substr(10,10)));
        pos.push_back(stringToDouble(line.substr(20,10)));
        std::string sym=line.substr(31,3);
        boost::trim(sym);
        strcpy(atom.name, sym.c_str());
        atom.atomicnumber = get_pte_idx(atom.name);

        if(line.size()>=39){
            int q=stringToInt(line.substr(36,3));
            /* Values of parsed charge field: 
               0 = uncharged or value other than these:
               1 = +3, 2 = +2, 3 = +1,
               4 = doublet radical, 
               5 = -1, 6 = -2, 7 = -3 
            */
            if(q<0 || q>7){
                MSYS_FAIL("charge specification for atom is out of range:\n" << line);
            }
            if(q==4){
                fprintf(stderr, "WARNING: Treating doublet radical charge specification as q=0\n");
            }
            /* Just set formal charge, not 'charge', for consistency with
             * the exporter, which only looks at formal charge.  */
            atom.charge = q==0 ? 0 : 4-q;
        }
        atoms.push_back(atom);

    } 

    /* Load Bonds */
    for (int i=0; i<nbonds; i++) {

        if (!std::getline(in, line)) {
            MSYS_FAIL("Missing expected Bond record " << i+1);
        }
        if(line.size()<9){
            MSYS_FAIL("Malformed bond line:\n"<<line);
        }

        int ai=stringToInt(line.substr(0,3));
        int aj=stringToInt(line.substr(3,3));
        int type=stringToInt(line.substr(6,3));

        if (ai<1 || aj<1 || ai>natoms || aj>natoms) {
            MSYS_FAIL("Invalid atom reference in Bond record:\n" << line);
        }
        if(type<1 || type>4){
            MSYS_FAIL("Invalid bond type in Bond record:\n" << line);
        }

        from.push_back(ai+bstart);
        to.push_back(aj+bstart);
        order.push_back(type);
    }
    /* properties, data and end of molecule delimeter scanning.
     * Incompletely parsed. */
    bool cleared_m_chg = false;
    while (std::getline(in, line)) {
        if (line.compare(0,3,"M  ")==0){
            if (line.compare(3,3,"CHG")==0){
                /* Atom Charge Info supersedes atom record lines */
                if (!cleared_m_chg) {
                    cleared_m_chg = true;
                    for (int i=0; i<natoms; i++) {
                        atoms[atoms.size()-1-i].charge=0;
                    }
                }
                std::istringstream ss(line.substr(6));
                int i, n;
                ss >> n;
                for (i=0; i<n; i++) {
                    int ai,fc;
                    ss >> ai >> fc;
                    if (!ss) MSYS_FAIL("Failed parsing CHG line " << line);
                    atoms[atoms.size()-natoms+ai-1].charge=fc;
                }

            } else if(line.compare(3,3,"END")==0){
                // End of molecule properties block
            }
        }else if(line.compare(0,3,"A  ")==0 || line.compare(0,3,"G  ")==0){
            std::getline(in, line);
        }else if(line.compare(0,3,"V  ")==0){
        }else if(line.compare(0,2,"> ")==0){
            /* If <xxx> is found on the line, use xxx as the key value */
            std::string key,val;
            size_t langle = line.find('<', 2);
            size_t rangle = line.find('>', langle+1);
            if (langle!=std::string::npos &&
                rangle!=std::string::npos) {
                key = line.substr(langle+1, rangle-langle-1);
            }
            while (std::getline(in, line)) {
                boost::trim(line);
                if (line.empty()) break;
                val=line;
            }
            //add_typed_keyval(key,val,mol->ct(0));
        }else if (line.compare(0,4,"$$$$")==0){
            // End of molecule
            break;
        }else{
            /* According to the spec, we shouldnt find any other blank lines,
               but we will be forgiving just in case */
            boost::trim(line);
            if(line != "")MSYS_FAIL("Unknown line in SDF file:\n"<<line);
        }
    }
    return true;
}

static void* open_sdf_read(const char* path, const char* type, int *natoms) {
    iterator* it = NULL;
    try {
        it = new iterator(path);
    }
    catch (std::exception& e) {
        delete it;
        fprintf(stderr, e.what());
        return NULL;
    }
    try {
        while (it->next());
    } catch (std::exception& e) {
        delete it;
        fprintf(stderr, e.what());
        return NULL;
    }
    *natoms = it->atoms.size();
    return it;
}

static int read_sdf_structure(void *v, int *optflags, molfile_atom_t *atoms) {
    *optflags = MOLFILE_CHARGE;
    iterator* it = (iterator*)v;
    std::copy(it->atoms.begin(), it->atoms.end(), atoms);
    return MOLFILE_SUCCESS;
}

static int read_sdf_bonds(void *v, int *nbonds, int **from_data, int **to_data, 
                          float **bondorderptr, int **bondtype, 
                          int *nbondtypes, char ***bondtypename) {

    iterator* it = (iterator*)v;
    *nbonds = it->from.size();
    *from_data = &it->from[0];
    *to_data = &it->to[0];
    *bondorderptr = &it->order[0];
    return MOLFILE_SUCCESS;
}

static int read_sdf_timestep(void *v, int natoms, molfile_timestep_t *ts) {
    iterator* it = (iterator*) v;
    if (it->timesteps_done) return MOLFILE_EOF;
    it->timesteps_done=true;
    std::copy(it->pos.begin(), it->pos.end(), ts->coords);
    return MOLFILE_SUCCESS;
}

static void close_sdf_read(void *v) {
    iterator* it = (iterator*)v;
    delete it;
}

// Plugin Initialization

VMDPLUGIN_API int VMDPLUGIN_init(void) { 
  memset(&plugin, 0, sizeof(molfile_plugin_t));
  plugin.abiversion = vmdplugin_ABIVERSION;
  plugin.type = MOLFILE_PLUGIN_TYPE;
  plugin.name = "sdf";
  plugin.prettyname = "SDF";
  plugin.author = "D. E. Shaw Research";
  plugin.majorv = 0;
  plugin.minorv = 1;
  plugin.is_reentrant = VMDPLUGIN_THREADSAFE;
  plugin.filename_extension = "sdf,sdf.gz";
  plugin.open_file_read = open_sdf_read;
  plugin.read_structure = read_sdf_structure;
  plugin.read_bonds = read_sdf_bonds;
  plugin.read_next_timestep = read_sdf_timestep;
  plugin.close_file_read = close_sdf_read;
  return VMDPLUGIN_SUCCESS;
}

VMDPLUGIN_API int VMDPLUGIN_register(void *v, vmdplugin_register_cb cb) {
  (*cb)(v, (vmdplugin_t *)&plugin);
  return VMDPLUGIN_SUCCESS;
}

VMDPLUGIN_API int VMDPLUGIN_fini(void) { return VMDPLUGIN_SUCCESS; }

