### No #! interpreter given here.
### Run this via $SCHRODINGER/run ev85392.py

from schrodinger import structure
import sys

args = sys.argv[1:]
for i, arg in enumerate(args):

    print "Reading file: '%s'" %arg

    num_struct = 0;
    for st in structure.StructureReader(arg, format="maestro"):
        num_struct += 1
        print "  Read structure #%d" %num_struct

    print "End of file: '%s'.  Found %d structures.\n" %(arg, num_struct)
