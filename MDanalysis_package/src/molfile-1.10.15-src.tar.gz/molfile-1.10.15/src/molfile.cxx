/* 
Copyright 2012-2014, D. E. Shaw Research.
All rights reserved.

Redistribution and use in source and binary forms, with or without
modification, are permitted provided that the following conditions are
met:

* Redistributions of source code must retain the above copyright
  notice, this list of conditions, and the following disclaimer.

* Redistributions in binary form must reproduce the above copyright
  notice, this list of conditions, and the following disclaimer in the
  documentation and/or other materials provided with the distribution.

* Neither the name of D. E. Shaw Research nor the names of its
  contributors may be used to endorse or promote products derived from
  this software without specific prior written permission.

THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
"AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR
A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT
OWNER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,
SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT
LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE,
DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY
THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
(INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE
OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
*/
#include "molfile.hxx"
#include "findframe.hxx"
#include "libmolfile_plugin.h"

#include <cstdlib>
#include <cmath>
#include <cstdio>
#include <cstring>

#include <map>
#include <stdexcept>
#include <string>

namespace ff = desres::molfile::findframe;

namespace {
    // mapping from plugin type to plugin instance
    std::map<std::string,molfile_plugin_t*>& plugindict() {
        static std::map<std::string,molfile_plugin_t*> dict;
        return dict;
    }
    // mapping from filename extension to plugin instance
    typedef std::multimap<std::string,molfile_plugin_t*> ExtensionDict;
    ExtensionDict& extensiondict() {
        static ExtensionDict dict;
        return dict;
    }
    bool molfile_registered = false;
    int register_cb(void *v, vmdplugin_t *p) {
        molfile_plugin_t *plugin = reinterpret_cast<molfile_plugin_t*>(p);
        plugindict()[plugin->name] = plugin;
        if (plugin->filename_extension) {
            char *buf = strdup(plugin->filename_extension);
            const char *token=strtok(buf, ",");
            if (token) do {
                extensiondict().insert(
                        ExtensionDict::value_type(std::string(token),plugin));
            } while ( (token = strtok(NULL, ",")) );
            free(buf);
        }
        return MOLFILE_SUCCESS;
    }
}

namespace desres { namespace molfile {


    const molfile_plugin_t *plugin_for_type(const char *type) {
        if (!molfile_registered) {
            molfile_registered=true;
            MOLFILE_INIT_ALL;
            MOLFILE_REGISTER_ALL(NULL, register_cb);
        }
        if (plugindict().count(type)>0) return plugindict()[type];
        return NULL;
    }
    
    
    const molfile_plugin_t *plugin_for_path(const char * path,
                                            const char * fallback ) {
        if (!molfile_registered) {
            molfile_registered=true;
            MOLFILE_INIT_ALL;
            MOLFILE_REGISTER_ALL(NULL, register_cb);
        }
        if (!path) return NULL;
        const char * ext = strrchr(path, '.');
        const molfile_plugin_t * plugin = NULL;
        if (ext) {
            ext += 1;
            if (extensiondict().count(ext)>0)
                plugin = extensiondict().find(ext)->second;
        }
        if (!plugin && fallback!=NULL && extensiondict().count(fallback)>0)
            plugin = extensiondict().find(fallback)->second;
        return plugin;
    }

    Frame::Frame(size_t natoms, bool with_velocities, bool double_precision) 
    : m_natoms(natoms) {
        memset(&ts, 0, sizeof(ts));
        if (double_precision) {
            ts.dcoords = new double[3*natoms];
            memset(ts.dcoords, 0, 3*natoms*sizeof(double));
            if (with_velocities) {
                ts.dvelocities = new double[3*natoms];
                memset(ts.dvelocities, 0, 3*natoms*sizeof(double));
            }
        } else {
            ts.coords = new float[3*natoms];
            memset(ts.coords, 0, 3*natoms*sizeof(float));
            if (with_velocities) {
                ts.velocities = new float[3*natoms];
                memset(ts.velocities, 0, 3*natoms*sizeof(float));
            }
        }
        ts.total_energy = HUGE_VAL;
        ts.kinetic_energy = HUGE_VAL;
        ts.potential_energy = HUGE_VAL;
        ts.extended_energy = HUGE_VAL;
        ts.temperature = HUGE_VAL;
        ts.pressure = HUGE_VAL;
    }
    Frame::~Frame() {
        delete [] ts.coords;
        delete [] ts.velocities;
        delete [] ts.dcoords;
        delete [] ts.dvelocities;
    }

    Reader::~Reader() {
        if (plugin->close_file_read) plugin->close_file_read(handle);
    }

    Reader::Reader(const molfile_plugin_t *p, const char * _path,
                   bool double_precision) 
    : plugin(p), path(_path), handle(NULL), m_nframes(-1), m_natoms(0), 
      m_optflags(0), m_has_velocities(false), m_double_precision(double_precision) {

            int natoms=0;
            handle = plugin->open_file_read(_path, plugin->name, &natoms);
            if (!handle) throw std::runtime_error("open_file_read failed");
            if (natoms<0) throw std::runtime_error("plugin could not determined #atoms");
            m_natoms = natoms;

            // count the number of frames
            bool supports_doubles = false;
            if (plugin->read_timestep_metadata) {
                molfile_timestep_metadata_t meta[1];
                memset(meta, 0, sizeof(meta));
                if (plugin->read_timestep_metadata(handle, meta)==MOLFILE_SUCCESS) {
                    m_nframes = meta->count;
                    m_has_velocities = meta->has_velocities;
                    supports_doubles = meta->supports_double_precision;
                }
            }
            /* plugin must explicitly declare its support for reading
             * of double precision positions and velocities */
            if (double_precision && !supports_doubles) {
                throw std::runtime_error(
                        std::string("plugin '") + p->name + "' does not support reading of double-precision positions"); 
            }

            // read structure information if available
            if (plugin->read_structure) {
                m_atoms.resize(natoms);
                if (plugin->read_structure(handle, &m_optflags, &m_atoms[0])
                        !=MOLFILE_SUCCESS) {
                    throw std::runtime_error("read_structure failed");
                }
                // read the bonds, if possible
                int *from=NULL, *to=NULL;
                float *order=NULL;
                int *bondtype=NULL;
                int nbondtypes;
                char **bondtypename;
                int nbonds=0;
                if (plugin->read_bonds && 
                        plugin->read_bonds(handle, &nbonds, &from, &to, &order,
                            &bondtype, &nbondtypes, &bondtypename) 
                        != MOLFILE_SUCCESS) { 
                    throw std::runtime_error("Failed reading bonds");
                }
                for (int i=0; i<nbonds; i++) {
                    ssize_t ai=from[i]-1;
                    ssize_t aj=to[i]-1;
                    if (ai<0 || aj<0 || ai>=natoms || aj>=natoms) {
                        throw std::runtime_error("Bond out of range");
                    }
                    m_bonds.push_back(bond_t(ai, aj, order ? order[i] : 1));
                }

                // read the glue, if possible
                if (plugin->read_fictitious_bonds &&
                    plugin->read_fictitious_bonds(
                        handle, &nbonds, &from, &to)!=MOLFILE_SUCCESS) {
                    throw std::runtime_error("Failed reading glue");
                }
                for (int i=0; i<nbonds; i++) {
                    ssize_t ai=from[i]-1;
                    ssize_t aj=to[i]-1;
                    if (ai<0 || aj<0 || ai>=natoms || aj>=natoms) {
                        throw std::runtime_error("Glue out of range");
                    }
                    m_glues.push_back(glue_t(ai, aj));
                }
            }
        }

    Reader* Reader::reopen() const {
        return new Reader(plugin, path.c_str(), m_double_precision);
    }

    ssize_t Reader::read_times(ssize_t start, ssize_t count, double * times) const {
        if (!plugin->read_times) return -1;
        return plugin->read_times(handle, start, count, times);
    }

    namespace {
        struct Oracle {
            const Reader& reader;
            Oracle(const Reader& _reader) : reader(_reader) {}
            double operator[](ssize_t i) const {
                double T;
                if (reader.read_times(i,1,&T)!=1) {
                    throw std::runtime_error("Error reading time");
                }
                return T;
            }
        };
    }

    ssize_t Reader::Reader::at_time_near(double T) const {
        return ff::at_time_near<Oracle>(nframes(), *this, T);
    }
    ssize_t Reader::at_time_gt(double T) const {
        return ff::at_time_gt<Oracle>(nframes(), *this, T);
    }
    ssize_t Reader::at_time_ge(double T) const {
        return ff::at_time_ge<Oracle>(nframes(), *this, T);
    }
    ssize_t Reader::at_time_lt(double T) const {
        return ff::at_time_lt<Oracle>(nframes(), *this, T);
    }
    ssize_t Reader::at_time_le(double T) const {
        return ff::at_time_le<Oracle>(nframes(), *this, T);
    }

    Frame *Reader::frame(ssize_t index) const {
        if (!plugin->read_timestep2) 
            throw std::runtime_error("frame() not implemented for this plugin");

        if (index < 0) {
            if (m_nframes<0) {
                throw std::runtime_error(
                        "Cannot use negative index when number of frames is not known");
            }
            index += m_nframes;
        }
        Frame *result = new Frame(natoms(), has_velocities(), double_precision());
        if (plugin->read_timestep2(handle, index, *result) !=MOLFILE_SUCCESS) {
            delete result;
            throw std::runtime_error("Reading frame failed");
        }
        return result;
    }

    Frame *Reader::next() const {
        if (!plugin->read_next_timestep) return NULL;
        Frame *result = new Frame(natoms(), has_velocities(), double_precision());
        if (plugin->read_next_timestep(handle, natoms(), *result)!=MOLFILE_SUCCESS) {
            delete result;
            result=NULL;
        }
        return result;
    }

    void Reader::skip() const {
        if (plugin->read_next_timestep) {
            plugin->read_next_timestep(handle, natoms(), NULL);
        }
    }

    Writer::Writer(const molfile_plugin_t *p, const char * path, ssize_t natoms)
        : plugin(p), handle(NULL), m_natoms(natoms) {
            handle = plugin->open_file_write(path, plugin->name, natoms);
            if (!handle) throw std::runtime_error("Failed opening file for writing");
        }

    void Writer::close() {
        if (handle) plugin->close_file_write(handle);
        handle = NULL;
    }

    Writer::~Writer() {
        close();
    }

    bool Writer::requires_atoms() const {
        return plugin->write_structure;
    }

    Writer& Writer::write_atoms(const std::vector<atom_t> &atoms,
                                const std::vector<bond_t> &bonds,
                                int optflags) {
        if (!handle) throw std::runtime_error("I/O on closed writer.");
        if (!requires_atoms()) return *this;
        
        std::vector<int> from, to;
        std::vector<float> order;
        if (plugin->write_bonds) {
            for (unsigned i=0; i<bonds.size(); i++) {
                from.push_back(bonds[i].from+1);
                to.push_back(bonds[i].to+1);
                order.push_back(bonds[i].order);
            }
            /* prevent illegal reference to element zero in the case 
             * of no bonds. */
            if (!bonds.size()) {
                from.resize(1);
                to.resize(1);
                order.resize(1);
            }
            if (plugin->write_bonds(handle, bonds.size(), 
                        &from[0], &to[0], &order[0], 
                        NULL, 0, NULL) != MOLFILE_SUCCESS) {
                throw std::runtime_error("Writing bonds failed");
            }
        }
        int rc;
        if (!atoms.size()) {
            /* provide dummy atoms */
            std::vector<atom_t> dummies(natoms());
            atom_t * ptr = natoms() ? &dummies[0] : NULL;
            memset(ptr, 0, natoms()*sizeof(*ptr));
            rc=plugin->write_structure(handle, 0, ptr);
        } else {
            rc=plugin->write_structure(handle, optflags, &atoms[0]);
        }
        if (rc != MOLFILE_SUCCESS) {
            throw std::runtime_error("Writing structure failed");
        }
        return *this;
    }

    bool Writer::writes_frames() const {
        return plugin->write_timestep;
    }

    Writer& Writer::write_frame(const Frame &frame) {
        if (!writes_frames())
            throw std::runtime_error("Plugin does not support writing frames");
        if ((ssize_t)frame.natoms() != natoms())
            throw std::runtime_error("Number of atoms in frame doesn't match file");
        if (!handle) throw std::runtime_error("I/O on closed writer.");
        if (plugin->write_timestep(handle, frame) != MOLFILE_SUCCESS)
            throw std::runtime_error("Writing frame failed");
        return *this;
    }

}}
