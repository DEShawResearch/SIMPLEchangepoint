#!/usr/bin/env desres-exec
#{
# desres-cleanenv $MOLFILE_SCRIPT_CLEANENV -- python $0 "$@"
#}

'''
frame2dms [ options ] input.dtr input.dms output.dms
Run with -h to get a list of options
'''

import molfile
from molfile import findframe
import os, shutil, sqlite3, sys

def frame2dms( F, db, verbose=False, zero_velocities=False ):

    def chatter(s):
        if (verbose):
            print s

    # check for matching number of atoms
    natoms = len(F.pos)
    count = db.execute('select count() from particle').fetchone()[0]
    if count!=natoms:
        raise ValueError, "#atoms in dms file (%d) != #atoms in trajectory (%d)" % (count, natoms)

    # update global cell
    db.execute('delete from global_cell')
    for i in range(3):
        db.execute('insert into global_cell (x,y,z) values (?,?,?)', 
                ( F.box[0,i], F.box[1,i], F.box[2,i] ) )

    # update positions
    pos=F.pos
    chatter("Updating positions...")
    for i in range(natoms):
        x,y,z=map(float, pos[i])
        db.execute('update particle set x=?, y=?, z=? where id=?', (x,y,z,i) )

    if zero_velocities:
        chatter("Setting velocities to zero")
        vel = pos-pos
    else:
        vel = F.vel
    if vel is None:
        chatter('No velocities in frame, not updating velocities')
    else:
        chatter('Updating velocities...')
        for i in range(natoms):
            x,y,z=map(float,vel[i])
            db.execute('update particle set vx=?, vy=?, vz=? where id=?', 
                    (x,y,z,i) )


def main():
    from optparse import OptionParser
    parser = OptionParser(usage=__doc__)
    parser.add_option("-v", "--verbose", action="store_true", default=True)
    parser.add_option('-Q', "--quiet", action="store_false", dest="verbose")
    parser.add_option('-t', "--time", default=None, type='float',
            help="Selected frame time")
    parser.add_option('-i', "--index", default=None, type='int',
            help="Selected frame index")
    parser.add_option('-f', "--clobber", action="store_true", default=False,
            help="Overwrite output file?")
    parser.add_option('--zero-velocities', action="store_true", default=False,
            help="Use zero velocities instead of reading from frame")

    opts, args = parser.parse_args()
    if opts.time is None and opts.index is None:
        parser.error("Specify either --time or --index")
    if opts.time is not None and opts.index is not None:
        parser.error("Specify either --time or --index, not both")
    if len(args)!=3:
        parser.error("Incorrect number of arguments")
    trjpath, ipath, opath = args
    verbose = opts.verbose

    # extract selected frame from trajectory
    if verbose:
        print "Opening trajectory %s" % trjpath
    T = molfile.dtr.read( trjpath )
    if verbose:
        print "Trajectory contains %d frames, %d atoms" % (T.nframes, T.natoms)
    if opts.time is not None:
        F = T.at_time_near(opts.time)
    else:
        F = T.frame(opts.index)
    if verbose:
        ind = findframe.at_time_near( T.times, F.time )
        print "selected frame %d with time %s" % (ind, F.time)

    # remove output file path if needed
    if os.path.exists(opath) or os.path.islink(opath):
        if opts.clobber:
            if verbose:
                print "Removing file %s" % opath
            os.remove(opath)
        else:
            print >> sys.stderr, "File '%s' already exists; move out of the way, or use -f" % opath
            exit(1)

    # copy original dms to tmp file
    tmppath = opath+".tmp.%d" % os.getpid()
    shutil.copyfile( ipath, tmppath )

    # copy frame data to tmp dms
    db = sqlite3.Connection( tmppath )
    frame2dms( F, db, verbose, opts.zero_velocities )
    
    if verbose:
        print "Saving results..."
    db.commit()
    db.close()

    # rename to opath
    if verbose:
        print "Writing to %s" % opath
    os.rename(tmppath, opath)
    if verbose:
        print "done."

if __name__ == '__main__': main()
