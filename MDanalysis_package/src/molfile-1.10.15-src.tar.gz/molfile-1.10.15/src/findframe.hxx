/* 
Copyright 2012-2014, D. E. Shaw Research.
All rights reserved.

Redistribution and use in source and binary forms, with or without
modification, are permitted provided that the following conditions are
met:

* Redistributions of source code must retain the above copyright
  notice, this list of conditions, and the following disclaimer.

* Redistributions in binary form must reproduce the above copyright
  notice, this list of conditions, and the following disclaimer in the
  documentation and/or other materials provided with the distribution.

* Neither the name of D. E. Shaw Research nor the names of its
  contributors may be used to endorse or promote products derived from
  this software without specific prior written permission.

THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
"AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR
A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT
OWNER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,
SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT
LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE,
DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY
THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
(INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE
OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
*/
#include <cmath>
#include <sys/types.h>

namespace desres { namespace molfile { namespace findframe {

    /* The Oracle in all these functions implements operator[] taking a
     * ssize_t in the half-open range [0,N) and returning a time. */

    template <typename Oracle>
    void lookup_time( ssize_t N, const Oracle& times, double T, 
                         ssize_t& left, ssize_t& right ) {

       ssize_t mid;

       // -----------------------------------------------
       // Time not found if we have no frames!
       // -----------------------------------------------
       left = 0;
       right = N-1;
       if (N <= 0) return;

       // -----------------------------------------------
       // Knuth's binary search
       // Notice that mid = (left+right)/2 suffers from
       // overflow problems, so the less intuitive
       // mid = left + ((right-left)/2)
       // is used instead.
       // -----------------------------------------------
       while(left <= right) {
           mid = left + ((right-left)/2);
           double mid_time = times[mid];
           if (T > mid_time) {
               left = mid + 1;
           } else if (T < mid_time) {
               right = mid - 1;
           } else {
               /* Exact match */
               left = right = mid;
               break;
           }
       }

       // -----------------------------------------------
       // CAUTION: at this point, the meanings of 
       // left and right are switched (i.e. left >= right,
       // see the while() loop above if you don't believe me!
       // -----------------------------------------------
       ssize_t swap = left;
       left = right;
       right = swap;
    }   

    template <typename Oracle>
    ssize_t at_time_near( ssize_t N, const Oracle& times, double T ) {
        ssize_t left, right;
        lookup_time(N,times,T,left,right);
        if (right<0) return -1;     /* no frames */
        if (left<0) return 0;       /* time less than first time */
        if (right==N) return left;  /* right greater than last time */
        return (fabs(T-times[right]) < fabs(T-times[left])) ? right : left;
    }
    
    template <typename Oracle>
    ssize_t at_time_le(   ssize_t N, const Oracle& times, double T ) {
        ssize_t left, right;
        lookup_time(N,times,T,left,right);
        if (right<0) return -1;
        if (left<0) return -1;
        if (right>N) return -1;
        if (times[left]>T) return -1;
        return left;
    }
    
    template <typename Oracle>
    ssize_t at_time_lt(   ssize_t N, const Oracle& times, double T ) {
        ssize_t left, right;
        lookup_time(N,times,T,left,right);
        if (right<0) return -1;
        if (left<=0) return -1;
        if (left==right) {
            if (times[left-1]>=T) return -1;
            return left-1;
        }
        if (times[left]>=T) return -1;
        return left;
    }
    
    template <typename Oracle>
    ssize_t at_time_ge(   ssize_t N, const Oracle& times, double T ) {
        ssize_t left, right;
        lookup_time(N,times,T,left,right);
        if (right<0) return -1;
        if (right>=N) return -1;
        if (times[right]<T) return -1;
        return right;
    }
    
    template <typename Oracle>
    ssize_t at_time_gt(   ssize_t N, const Oracle& times, double T ) {
        ssize_t left, right;
        lookup_time(N,times,T,left,right);
        if (right<0) return -1;
        if (right>=N) return -1;
        if (left==right) {
            if (right+1==N) {
                if (times[left]>T) return left; /* single frame case */
                return -1;
            }
            if (times[right+1]<=T) return -1;
            return right+1;
        }
        if (times[right]<=T) return -1;
        return right;
    }

}}}
