
'''
Structure and coordinate file manipulation library.

--------------------------
# Synopsis of common tasks
--------------------------

Reading a structure file:

  reader = molfile.mae.read('/path/to/foo.mae')

Iterating through the frames in a file:

  for frame in molfile.dtr.read('/path/to/foo.dtr').frames():
    function( frame.pos, frame.vel, frame.time, frame.box )

Random access to frames (only dtr files support this currently):

  f27 = molfile.dtr.read('/path/to/foo.dtr').frame(27) # 0-based index

Convert an mae file to a pdb file:

  input=molfile.mae.read('foo.mae')
  output=molfile.pdb.write('foo.pdb', atoms=input.atoms)
  output.frame(input.frames().next())
  output.close()

Write every 10th frame in a dtr to a trr:

  input=molfile.dtr.read('big.dtr')
  output=molfile.trr.write('out.trr, natoms=input.natoms)
  for i in range(0,input.nframes, 10):
    output.frame( input.frame(i) )
  output.close()


--------------------------
# The molfile data module
--------------------------
All data is read to and from molfile objects in terms of a small number of
classes defined within the module:

  Atom:  Represents fixed particle attributes; i.e. no position or
         velocity!  Atoms hold references to other atoms through their
         bonds member; use Atom.addbond and Atom.delbond to change the
         bond topology.

  Frame: Data from a single timestep.  Contains position, velocity,
         unit cell, and physical time.

--------------------------
# Plugin objects
--------------------------
For each supported file type, e.g., 'pdb', 'mae', trr', there is a Plugin
object with that name in the module.  A Plugin can be queried for its 
capabilities using its 'can_*' methods.  Nearly all plugins can read files,
but only some can write.  Use the Plugin.read method to create a Reader,
and Plugin.write to create a write.

Some plugins, e.g., psf, read only structure data (atoms), while others,
e.g., dtr, read only coordinate data (frames).  If you try to read atoms
from a dtr, or frames from a psf, you'll get an error.

--------------------------
# Reader objects
--------------------------
A Reader is a handle to an open file.  Use the atoms member to fetch the
atomic structure from the file, assuming it exists.  To access frames,
there are two methods.

  Reader.frames() -- returns a FrameIter object for iteration over frames.
  FrameIter has two methods: the usual next() method which returns a
  Frame, and skip(n=1), which advances the iterator by n frames without
  (necessarily) reading anything.  FrameIter is a very poor iterator:
  once a frame has been read or skipped, it can't be loaded again;
  you have use a brand new Reader.

  Reader.frame(n) -- returns the nth frame (0-based index).  Currently
  only the dtr plugin supports this method.

--------------------------
# Writer objects
--------------------------
Writers are initialized with a path and either an array of Atoms or an
atom count.  If the Writer supports structure writing, Atoms must be 
provided; if the Writer only writes frames, either one will do.

If the writer supports frame writing, Writer.frame(f) appends frame f
to the end of the file.  

Writer.close() will be invoked when the Writer goes out of scope, but
it's not a bad idea to invoke it explicitly.

'''

from _molfile import *
import os, sys
import threading
import Queue
import time

extensiondict=dict()

def register_plugin(plugin, d=extensiondict):
    ''' put plugin in the global namespace, and add to extensiondict '''
    globals()[plugin.name]=plugin
    for ext in plugin.filename_extensions.split(','):
        ext=ext.strip()
        if ext:
            d.setdefault(ext,[]).append(plugin)

_molfile.register_all(register_plugin)

def load_shared_library(path):
    register_shared_library(path, register_plugin)

def guess_filetype(filename, default=None, extensiondict=extensiondict):
    ''' return plugin name based on filename, or default if none found. '''
    dot=filename.rfind('.')
    if dot>0:
        key=filename[dot+1:].lower()
        val=extensiondict.get(key)
        if val:
            return val[-1]
    return default


class FrameIter(object):
    def __init__(self, reader): 
        if reader.nframes >= 0:
            self.reader = reader
            self.curframe = 0
            self.nframes = self.reader.nframes
        else:
            # number of frames is not known, so we have to use the
            # Reader.next() method which does not rewind.  Reload the
            # reader so that we can keep a private copy of our 
            # current frame.
            self.reader = reader.reopen()
            self.curframe = -1

    def __iter__(self): return self

    def next(self):
        if self.curframe < 0:
            # iterate the reader itself
            f=self.reader.next()
            if not f:
                raise StopIteration
            return f
        
        # using our own iterator state
        if self.curframe >= self.nframes:
            raise StopIteration
        f = self.reader.frame(self.curframe)
        self.curframe += 1
        return f

    def skip(self, count=1):
        r=self.reader
        if count<0: raise ValueError, "skip count must be nonnegative"
        while count:
            r.skip()
            count -= 1



def reader_frames(self): return FrameIter(self)
_molfile.Reader.frames = reader_frames
del reader_frames


