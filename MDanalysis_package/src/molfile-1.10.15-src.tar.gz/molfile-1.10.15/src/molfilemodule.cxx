/* 
Copyright 2012-2014, D. E. Shaw Research.
All rights reserved.

Redistribution and use in source and binary forms, with or without
modification, are permitted provided that the following conditions are
met:

* Redistributions of source code must retain the above copyright
  notice, this list of conditions, and the following disclaimer.

* Redistributions in binary form must reproduce the above copyright
  notice, this list of conditions, and the following disclaimer in the
  documentation and/or other materials provided with the distribution.

* Neither the name of D. E. Shaw Research nor the names of its
  contributors may be used to endorse or promote products derived from
  this software without specific prior written permission.

THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
"AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR
A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT
OWNER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,
SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT
LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE,
DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY
THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
(INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE
OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
*/
#include "molfilemodule.hxx"
#include "numpy/arrayobject.h"
#include <map>
#include <string>
#include <dlfcn.h>

#include <boost/python.hpp>

using namespace desres::molfile;
using namespace boost::python;

// all the numpy stuff has to live in this file!

PyObject **desres::molfile::object_array(int size, PyObject **returned_result) {
    npy_intp dims=size;
    PyObject *result = PyArray_SimpleNew(1, &dims, NPY_OBJECT);
    if (!result) return NULL;
    *returned_result = result;
    return reinterpret_cast<PyObject**>(PyArray_DATA(result));
}

PyObject *desres::molfile::backed_vector( 
        int nd, Py_ssize_t *dims, DataType type, void *data, PyObject *base ) {
    npy_intp mydims[NPY_MAXDIMS];
    for (int i=0; i<nd; i++) mydims[i] = dims[i];
    int mytype = type==INT ? PyArray_INT :
        type==FLOAT ? PyArray_FLOAT :
        type==DOUBLE ? PyArray_DOUBLE :
        0;
    if (!mytype) {
        PyErr_Format(PyExc_RuntimeError, "Unsupported type '%d'", type);
        return NULL;
    }
    PyObject *result;
    if (base) { 
        result = PyArray_SimpleNewFromData( nd, mydims, mytype, (char *)data);
        Py_INCREF( PyArray_BASE(result) = reinterpret_cast<PyObject*>(base) );
    } else {
        result = PyArray_SimpleNewFromData( nd, mydims, mytype, NULL);
        if (data) {
            memcpy( PyArray_DATA(result), data, PyArray_NBYTES(result) );
        }
    }
    return result;
}

void * desres::molfile::array_data( PyObject * arr ) {
    return PyArray_DATA(arr);
}

namespace {

    // create a Plugin object representing each molfile_plugin_t.
    int register_cb( void *v, vmdplugin_t *raw_plugin ) {
        object& func = *(object *)v;
        func(reinterpret_cast<molfile_plugin_t*>(raw_plugin));
        return MOLFILE_SUCCESS;
    }

    typedef int (*initfunc)(void);
    typedef int (*regfunc)(void *, vmdplugin_register_cb);
    typedef int (*finifunc)(void);

    // scan the .so file at the given path and load 
    void register_shared_library(const std::string& path, object& callback) {
        void * handle = dlopen(path.c_str(), RTLD_NOW | RTLD_LOCAL);
        if (!handle) throw std::runtime_error(dlerror());
        void * ifunc = dlsym(handle, "vmdplugin_init");
        if (ifunc && ((initfunc)(ifunc))()) {
            dlclose(handle);
            throw std::runtime_error("vmdplugin_init() failed");
        }
        void * rfunc = dlsym(handle, "vmdplugin_register");
        if (!rfunc) {
            dlclose(handle);
            throw std::runtime_error("No vmdplugin_register() found");
        }
        ((regfunc)rfunc)(&callback, register_cb);
    }

    /* return a list of all the plugins */
    void register_all(object& func) {
        MOLFILE_REGISTER_ALL(&func, register_cb); 
    }
}

BOOST_PYTHON_MODULE(_molfile) {

    import_array();
    if (PyErr_Occurred()) return;

    export_plugin();
    export_reader();
    export_frame();
    export_writer();
    export_dtrreader();

    // I could use a static to initialize these types on first access,
    // but then the type objects wouldn't be present in the module
    // until first use.  This would cause help(molfile) to be incomplete.
    if (initialize_atom()) return;

    static PyObject *pyAtom = reinterpret_cast<PyObject *>(&AtomType);
    Py_INCREF(pyAtom);
    scope().attr("Atom")=object(handle<>(pyAtom));

    MOLFILE_INIT_ALL;
    def("register_all", register_all);
    def("register_shared_library", register_shared_library);
}

