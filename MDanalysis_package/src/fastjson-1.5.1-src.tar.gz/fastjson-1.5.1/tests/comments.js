
/* a comment !  with # hash mark##*/
[32
# hash
, 42,# dude
"#hello#there"]


