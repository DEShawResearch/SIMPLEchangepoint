# Be lenient with floating point numbers
[
  0,
 -0,
  0., 
  .0, 
  1.,
  .1,
  -0., 
  -.0,
  -1.,
  -.1,
   00.,
  -00.,
  0.e3,
  .0e3,
  1.e3,
  .1e3,
  -0.e3,
  -.0e3,
  -1.e3,
  -.1e3,
   001.e3,
  -001.e3
]



