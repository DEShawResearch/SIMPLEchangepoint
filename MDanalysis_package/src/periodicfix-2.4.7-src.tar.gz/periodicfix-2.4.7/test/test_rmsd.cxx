/* 
Copyright 2012-2014, D. E. Shaw Research.
All rights reserved.

Redistribution and use in source and binary forms, with or without
modification, are permitted provided that the following conditions are
met:

* Redistributions of source code must retain the above copyright
  notice, this list of conditions, and the following disclaimer.

* Redistributions in binary form must reproduce the above copyright
  notice, this list of conditions, and the following disclaimer in the
  documentation and/or other materials provided with the distribution.

* Neither the name of D. E. Shaw Research nor the names of its
  contributors may be used to endorse or promote products derived from
  this software without specific prior written permission.

THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
"AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR
A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT
OWNER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,
SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT
LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE,
DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY
THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
(INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE
OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
*/
#include "rmsd.hxx"
#include "fit.hxx"
#include <cmath>
#include <cassert>
#include <cstring>
#include <cstdio>

using namespace desres::periodicfix;

namespace {
    /* make a rotation matrix */
    static void rotation_matrix( char axis, float degrees, double * mat) {
        double rad = degrees * M_PI/180;
        double costheta = cos(rad);
        double sintheta = sin(rad);
        for (int i=0; i<9; i++) mat[i]=0;
        int a,b,c;
        if (axis=='x')      { a=1; b=2; c=0; }
        else if (axis=='y') { a=2; b=0; c=1; }
        else if (axis=='z') { a=0; b=1; c=2; }
        else assert(false);
        mat[3*a+a] = costheta;
        mat[3*b+b] = costheta;
        mat[3*c+c] = 1;
        mat[3*a+b] =-sintheta;
        mat[3*b+a] = sintheta;
    }

    void print_matrix(const double * mat) {
        for (int i=0; i<3; i++) {
            for (int j=0; j<3; j++) {
                printf("%f ", mat[3*i+j]);
            }
            printf("\n");
        }
    }

    void apply_translation( int natoms, float * pos,
                            float cx, float cy, float cz ) {
        float * end = pos+3*natoms;
        for (; pos!=end; pos+=3) {
            pos[0] += cx;
            pos[1] += cy;
            pos[2] += cz;
        }
    }

    void apply_weird_rotation( int npos, float * pos ) {
        double mat[9];
        rotation_matrix( 'z', 90, mat ); apply_rotation( npos, pos, mat );
        rotation_matrix( 'x', 35, mat ); apply_rotation( npos, pos, mat );
        rotation_matrix( 'y', 17, mat ); apply_rotation( npos, pos, mat );
    }
}

#define assert_near(p1,p2) do { \
    for (int i=0; i<3; i++) { \
        double dx = (p1)[i] - (p2)[i]; \
        assert(fabs(dx)<1e-6); \
    } \
} while (0)

int main(void) {

    /* reference positions are the centers of the faces of a rectangular 
     * solid. */
    static const float xdim=1, ydim=3, zdim=7;
    static const int npos=6;
    static const float oldpos[3*npos] = {
        -xdim,      0,      0,
         xdim,      0,      0,
            0,  -ydim,      0,
            0,   ydim,      0,
            0,      0,  -zdim,
            0,      0,   zdim
    };

    /* generate new positions */
    float newpos[3*npos];
    double mat[9], R[9];

    /* check that simple rotations are reconstructed by compute_alignment */
    /* y-rotation */
    memcpy(newpos, oldpos, sizeof(newpos));
    rotation_matrix( 'y', 90, mat ); apply_rotation( npos, newpos, mat );
    compute_alignment( npos, oldpos, newpos, (float*)NULL, R );
    for (int i=0; i<3; i++) assert_near( mat+i, R+i );

    /* x-rotation */
    memcpy(newpos, oldpos, sizeof(newpos));
    rotation_matrix( 'x', 30, mat ); apply_rotation( npos, newpos, mat );
    compute_alignment( npos, oldpos, newpos, (float*)NULL, R );
    for (int i=0; i<3; i++) assert_near( mat+i, R+i );

    /* z-rotation */
    memcpy(newpos, oldpos, sizeof(newpos));
    rotation_matrix( 'z', 70, mat ); apply_rotation( npos, newpos, mat );
    compute_alignment( npos, oldpos, newpos, (float*)NULL, R );
    for (int i=0; i<3; i++) assert_near( mat+i, R+i );

    /* check that we recover the original positions */
    memcpy(newpos, oldpos, sizeof(newpos));
    apply_weird_rotation( npos, newpos );
    compute_alignment( npos, newpos, oldpos, (float*)NULL, R );
    apply_rotation( npos, newpos, R );
    for (int i=0; i<npos; i++) assert_near( oldpos+3*i, newpos+3*i );

    /* Same deal, only with the Fit class */
    memcpy(newpos, oldpos, sizeof(newpos));
    apply_weird_rotation( npos, newpos );
    Fit<float>(npos, oldpos, NULL).align(newpos);
    for (int i=0; i<npos; i++) assert_near( oldpos+3*i, newpos+3*i );

    printf("OK\n");
    return 0;
}
