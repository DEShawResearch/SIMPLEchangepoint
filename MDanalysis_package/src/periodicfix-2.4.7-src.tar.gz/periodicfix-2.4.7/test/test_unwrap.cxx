/* 
Copyright 2012-2014, D. E. Shaw Research.
All rights reserved.

Redistribution and use in source and binary forms, with or without
modification, are permitted provided that the following conditions are
met:

* Redistributions of source code must retain the above copyright
  notice, this list of conditions, and the following disclaimer.

* Redistributions in binary form must reproduce the above copyright
  notice, this list of conditions, and the following disclaimer in the
  documentation and/or other materials provided with the distribution.

* Neither the name of D. E. Shaw Research nor the names of its
  contributors may be used to endorse or promote products derived from
  this software without specific prior written permission.

THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
"AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR
A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT
OWNER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,
SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT
LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE,
DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY
THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
(INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE
OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
*/
#include "periodicfix.hxx"
#include "topology.hxx"
#include <stdlib.h>
#include <iostream>

namespace pf=desres::periodicfix;

namespace {

    struct State {
        float box; /* box length */
        float pos; /* particle position wrapped to [-0.5, 0.5) */
        State() {}
        State(float b, float p) : box(b), pos(p) {}
    };

    float wrap(float p) {
        while (p<-0.5) p+=1;
        while (p>=0.5) p-=1;
        return p;
    }

    /* generator of simulation states.  */
    class Sim {

        const float _avgbox;   /* average box length */
        const float _devbox;   /* box standard deviation */
        const float _devpos;   /* particle standard deviation */

    public:
        Sim( float avgbox, float devbox, float devpos ) 
        : _avgbox(avgbox), _devbox(devbox), _devpos(devpos) {}

        State update(State s) const {

            const float oldpos = s.pos;
            const float u1 = drand48();
            const float u2 = drand48();
            const float newbox = _devbox * (u1-0.5) + _avgbox;
            const float newpos = wrap(oldpos + (u2-0.5) * _devpos/newbox);
            return State(newbox, newpos);
        }
    };
}

std::ostream& operator<<(std::ostream& out, const State& s) {
    out << s.box << " " << s.pos;
    return out;
}

static void usage(const char * prog) {
    std::cerr << prog << " avgbox devbox devpos nsteps" << std::endl;
    exit(1);
}

int main( int argc, char *argv[]) {
    if (argc!=5) usage(argv[0]);
    float avgbox = atof(argv[1]);
    float devbox = atof(argv[2]);
    float devpos = atof(argv[3]);
    int i, n = atoi(argv[4]);
    Sim sim(avgbox, devbox, devpos);
    State oldstate(avgbox, 0);
    const pf::Topology topo(1);
    const pf::UnitCell refcell(avgbox, avgbox, avgbox );
    float oldx = oldstate.pos * oldstate.box;
    double shift[3] = {0,0,0};
    for (i=1; i<=n; i++) {
        State newstate = sim.update(oldstate);
        float newx = newstate.pos * newstate.box;
        float oldpos[3] = { oldx, 0,0 };
        float newpos[3] = { newx, 0,0 };
        topo.traverse_frags( pf::UnWrapper<float>(
                    1, 
                    newpos, oldpos, shift,
                    pf::UnitCell( newstate.box, 0,0 ),
                    pf::UnitCell( oldstate.box, 0,0 ),
                    refcell ));
        std::cout << i << " " << newstate << " " << shift[0]+newpos[0] << std::endl;
        oldstate = newstate;
        oldx = newpos[0];
    }
    return 0;
}


