import sys, os, molfile
libpath=os.path.join(os.path.dirname(__file__), '..', 'objs', 'Linux', 'x86_64', 'lib', 'python')
sys.path.insert(0, libpath)

import periodicfix as pf
import numpy as np
import cPickle
from time import time

import unittest

def make_topology(reader, glue=[]):
    ''' construct a periodicfic topology from bonds in atoms
    '''
    t=pf.Topology(reader.topology)
    for ai, aj in glue:
        t.add_bond(ai, aj)
    return t

def rotate(axis, degrees):
    rad=degrees * np.pi / 180.
    R=np.eye(3)
    c=np.cos(rad)
    s=np.sin(rad)
    if axis=='x':   
        a,b = 1,2
    elif axis=='y': 
        a,b = 2,0
    elif axis=='z': 
        a,b = 0,1
    R[a][a]= c
    R[b][b]= c
    R[a][b]=-s
    R[b][a]= s
    return R.transpose()

def make_rotation_matrix():
    # generate a rotation matrix
    R1=np.eye(3)
    R2=np.eye(3)
    R3=np.eye(3)
    R1=rotate('x', 20)
    R2=rotate('y', -30)
    R3=rotate('z', 40)
    R = np.dot(np.dot(R1,R2),R3).astype('f')
    return R

dmsfile=os.path.join('test/apoa1.dms')

class RmsAlignTestCase(unittest.TestCase):
    def setUp(self):
        glue=((6402, 8),)
        r=molfile.dms.read(dmsfile)
        self.atoms=r.atoms
        
        # construct topology and extract positions and unit cell
        self.topo = make_topology(r,glue)
        self.frame = r.frame(0)
        self.cell = self.frame.box

    def wrap_bonds(self):
        s=time()
        self.topo.wrap_bonds( self.frame.pos, self.cell )
        t=time()
        self.topo.check_bonds( self.frame.pos, self.cell )
        print "wrap_bonds: %f seconds" % (t-s)

    def wrap_frags(self):
        self.wrap_bonds()

        self.frame.moveby(40,40,0)
        s=time()
        self.topo.wrap_frags( self.frame.pos, self.cell )
        t=time()
        self.topo.check_frags( self.frame.pos, self.cell )
        print "wrap_frags: %f seconds" % (t-s)

    def testDump(self):
        d=self.topo.dump()
        t2=pf.Topology(d)
        d2=t2.dump()
        self.assertEqual(d,d2)

    def testPickle(self):
        d=self.topo.dump()
        s=cPickle.dumps(self.topo, cPickle.HIGHEST_PROTOCOL)
        t2=cPickle.loads(s)
        d2=t2.dump()
        self.assertEqual(d,d2)

    def testRawRmsd(self):
        self.wrap_frags()

        # transform a subset of the coordinates the coordinates
        frame=self.frame
        R=make_rotation_matrix()
        mask=np.arange(0,len(self.atoms), 7)
        pos=frame.pos.copy()
        pos[mask] = np.dot(frame.pos, R)[mask]
        wts=np.zeros(len(self.atoms), dtype='f')
        wts[mask]=3.14
        
        # check that the matrix which aligns old to new is the same as the
        # transformation matrix we used.
        s=time()
        myR = pf.compute_alignment( frame.pos, pos, wts )
        t=time()
        print "rms align:  %f seconds" % (t-s)

        self.assertFalse( np.any(np.abs(R-myR)>1e-7) )
        
        # apply the transformation to all the coordinates, as well as 
        # to the unit cell.
        frame.pos[:] = np.dot(frame.pos, R)
        frame.box[:] = np.dot(frame.box, R)
        
        # check that we can shift and wrap, and still have good frags.
        frame.moveby(40,10,37)
        self.topo.wrap_frags( frame.pos, frame.box )
        self.topo.check_frags( frame.pos, frame.box )

        #molfile.dms.write('raw.dms', atoms=self.atoms).frame(frame)

    def testFit(self):
        self.wrap_bonds()

        frame=self.frame
        R=make_rotation_matrix()
        pos=frame.pos.copy()
        pos[:] += np.array([10,20,-30])
        pos[:] = np.dot(pos, R)
        pos[:] -= np.array([30,10,-50])

        wts=np.zeros(len(pos), dtype='f')
        wts[np.arange(0,len(pos),7)] = 1
        fit=pf.Fit( self.frame.pos, weights=wts )
        s=time()
        fit.align( pos )
        t=time()
        #print "rms fit:    %f seconds" % (t-s)
        self.assertFalse( np.any(np.abs(pos-self.frame.pos)>1e-3) )


    def testVisitFrags(self):

        class MyVisitor(object):
            def __init__(self):
                self.natoms=0
            def __call__(self, frag):
                self.natoms += len(frag)

        v=MyVisitor()
        self.topo.visit_frags(v)
        self.assertEqual( v.natoms, len(self.atoms ) )

    def testVisitBonds(self):
        def visit(ai,aj): pass
        self.topo.visit_bonds(visit)

class WrapperTestCase(unittest.TestCase):
    def setUp(self):
        r=molfile.dms.read(dmsfile)
        self.topo = pf.Topology(r.topology)
        self.frame = r.frame(0)
        self.cell = self.frame.box
        self.topo.wrap_bonds( self.frame.pos, self.cell )
        self.wrapper = pf.FragmentWrapper(self.topo)

    def testPickle(self):
        w=self.wrapper
        s=cPickle.dumps(w, cPickle.HIGHEST_PROTOCOL)
        w2=cPickle.loads(s)
        self.wrapper = w2
        self.testAggregate()

    def testAggregate(self):
        w=self.wrapper
        glue=(6402, 8)
        n=w.aggregate(glue)
        self.assertEqual(n,2)
        w.join(self.cell, self.frame.pos)
        w.wrap(self.cell, self.frame.pos, None)

        self.topo.add_bond(6402,8)
        self.topo.check_frags(self.frame.pos, self.cell)


if __name__=="__main__":
    unittest.main()

