/* 
Copyright 2012-2014, D. E. Shaw Research.
All rights reserved.

Redistribution and use in source and binary forms, with or without
modification, are permitted provided that the following conditions are
met:

* Redistributions of source code must retain the above copyright
  notice, this list of conditions, and the following disclaimer.

* Redistributions in binary form must reproduce the above copyright
  notice, this list of conditions, and the following disclaimer in the
  documentation and/or other materials provided with the distribution.

* Neither the name of D. E. Shaw Research nor the names of its
  contributors may be used to endorse or promote products derived from
  this software without specific prior written permission.

THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
"AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR
A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT
OWNER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,
SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT
LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE,
DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY
THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
(INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE
OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
*/
#include "fragment.hxx"
#include <stdio.h>

using namespace desres::periodicfix;

int main() {
    /* define topology */
    Topology top(3);
    top.add_bond(0,2);

    {
        /* test Topology::clone() */
        std::vector<unsigned> iids(2);
        iids[0] = 0; iids[1] = 2;
        //for (unsigned i=0; i<iids.size(); i++) iids[i]=i;
        Topology t = top.clone(iids.begin(), iids.end());
        printf("cloned top has %d atoms\n", t.size());
        for (int i=0; i<t.size(); i++) {
            printf("  atom %d: %lu bonds\n", i, t.neighbors()[i].size());
        }
    }

    std::vector<float> pos(9);
    UnitCell cell(30,40,50);

    /* create wrapper */
    FragmentWrapper w(top);

    printf("initial fragments: %u\n", w.maxFragid());
    for (unsigned i=0; i<w.maxFragid(); i++) {
        printf("  fragment %u: %lu\n", i, w.fragment(i).size());
    }

    /* aggregate atoms */
    AtomidList ids(2);
    ids[0] = 0;
    ids[1] = 1;
    w.aggregate(ids);

    printf("after aggregate: %u\n", w.maxFragid());
    for (unsigned i=0; i<w.maxFragid(); i++) {
        printf("  fragment %u: %lu\n", i, w.fragment(i).size());
    }

    w.join(cell, &pos[0]);

    return 0;
}
