/* 
Copyright 2012-2014, D. E. Shaw Research.
All rights reserved.

Redistribution and use in source and binary forms, with or without
modification, are permitted provided that the following conditions are
met:

* Redistributions of source code must retain the above copyright
  notice, this list of conditions, and the following disclaimer.

* Redistributions in binary form must reproduce the above copyright
  notice, this list of conditions, and the following disclaimer in the
  documentation and/or other materials provided with the distribution.

* Neither the name of D. E. Shaw Research nor the names of its
  contributors may be used to endorse or promote products derived from
  this software without specific prior written permission.

THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
"AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR
A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT
OWNER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,
SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT
LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE,
DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY
THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
(INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE
OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
*/
#ifndef desres_periodicfix_unitcell_hxx
#define desres_periodicfix_unitcell_hxx

#include <algorithm>
#include <stdexcept>
#include <math.h>

namespace desres { namespace periodicfix {

    namespace details {

        template <class scalar>
        static void crossprod(scalar *c, const scalar *a, const scalar *b) {
            c[0] =  a[1]*b[2] - a[2]*b[1];
            c[1] =  a[2]*b[0] - a[0]*b[2];
            c[2] =  a[0]*b[1] - a[1]*b[0];
        }
        
        template <class scalar>
        static void vecscale(scalar *c, scalar x) {
            c[0] *= x;
            c[1] *= x;
            c[2] *= x;
        }

        template <typename T1, typename T2>
        inline double dotprod(const T1 *a, const T2 *b) {
            double result = a[0]*b[0];
            result += a[1]*b[1];
            result += a[2]*b[2];
            return result;
        }

        inline double ROUND(double x) {
            static const double BLACK_MAGIC = 6755399441055744.0;
            // need to write out to memory to force loss of precision
            volatile double temp = x + BLACK_MAGIC;
            return temp - BLACK_MAGIC;
        }
    }

    /* representation of the unit cell */
    class UnitCell {
        double a1[3], a2[3], a3[3];
        double b1[3], b2[3], b3[3];
        bool is_triclinic;
        bool is_diagonal;

        /* constructors can't call constructors */
        void init( double ax, double ay, double az,
                   double bx, double by, double bz,
                   double cx, double cy, double cz ) {

            using namespace details;

            a1[0] = ax;
            a1[1] = ay;
            a1[2] = az;
            a2[0] = bx;
            a2[1] = by;
            a2[2] = bz;
            a3[0] = cx;
            a3[1] = cy;
            a3[2] = cz;

            double n11, n22, n33;

            crossprod(b1, a2, a3); 
            n11 = dotprod(b1, a1);
            if (n11) n11 = 1./n11;
            vecscale(b1, n11);

            crossprod(b2, a3, a1); 
            n22 = dotprod(b2, a2);
            if (n22) n22 = 1./n22;
            vecscale(b2, n22);

            crossprod(b3, a1, a2); 
            n33 = dotprod(b3, a3);
            if (n33) n33 = 1./n33;
            vecscale(b3, n33);

            is_diagonal = a1[1]==0 && a1[2]==0 &&
                          a2[2]==0 && a2[0]==0 && 
                          a3[0]==0 && a3[1]==0;

            /* check for orthogonal cell vectors: must have ai . aj / |ai||aj| == 0 */
            n11 = dotprod(a1,a1); 
            if (n11) n11 = 1.0/sqrt(n11);
            n22 = dotprod(a2,a2);
            if (n22) n22 = 1.0/sqrt(n22);
            n33 = dotprod(a3,a3);
            if (n33) n33 = 1.0/sqrt(n33);

            double cos12 = fabs(dotprod(a1,a2)*n11*n22);
            double cos23 = fabs(dotprod(a2,a3)*n22*n33);
            double cos31 = fabs(dotprod(a3,a1)*n33*n11);
          
            static const double eps = 1e-13;
            is_triclinic = (cos12>eps || cos23>eps || cos31>eps);
        }

    public:
        /* construct a non-periodic cell */
        UnitCell() { 
            init(0,0,0, 0,0,0, 0,0,0); 
        }

        /* construct an orthorhombic cell that's periodic for the nonzero
         * lengths. */
        UnitCell( double a, double b, double c ) { 
            init(a,0,0, 0,b,0, 0,0,c);
        }

        /* construct a triclinic cell from a, b, c, alpha, beta, gamma */
        UnitCell( double A, double B, double C,
                  double alpha, double beta, double gamma ) {

            double cosBC = sin( ((90 - alpha ) / 180) * M_PI );
            double cosAC = sin( ((90 - beta  ) / 180) * M_PI );
            double cosAB = sin( ((90 - gamma ) / 180) * M_PI );
            double sinAB = cos( ((90 - gamma ) / 180) * M_PI );

            double ax = A;

            double bx = B * cosAB;
            double by = B * sinAB;

            double cx=0, cy=0, cz=0;

            // If sinAB is zero, then we can't determine C uniquely since it's 
            // defined in terms of the angle between A and B.
            if (sinAB > 0) {
                cx = cosAC;
                cy = (cosBC - cosAC * cosAB) / sinAB;
                cz = sqrtf(1.0 - cx*cx - cy*cy);
                cx *= C;
                cy *= C;
                cz *= C;
            }

            init(ax,0,0, bx,by,0, cx,cy,cz);
        }

        /* construct a triclinic cell that's periodic for the nonzero
         * lengths */
        UnitCell( double ax, double ay, double az,
                  double bx, double by, double bz,
                  double cx, double cy, double cz ) {
            init(ax,ay,az, bx,by,bz, cx,cy,cz);
        }

        /* construct from a sequence of 9 elements, corresponding to 
         * ax, ay, az, bx, by, bz, cx, cy, cz */
        template <typename T>
        UnitCell(T begin, T end) {
            if (end-begin!=9) {
                throw std::runtime_error(
                        "UnitCell(begin,end) requires 9 elements");
            }
            double d[9];
            std::copy(begin,end,d);
            init( d[0], d[1], d[2], 
                  d[3], d[4], d[5], 
                  d[6], d[7], d[8] );
        }

        bool triclinic() const { return is_triclinic; }
        bool diagonal() const { return is_diagonal; }

        /* cell lengths */
        double a() const {
            return diagonal() ? a1[0] : sqrt(details::dotprod(a1,a1));
        }
        double b() const {
            return diagonal() ? a2[1] : sqrt(details::dotprod(a2,a2));
        }
        double c() const {
            return diagonal() ? a3[2] : sqrt(details::dotprod(a3,a3));
        }

        /* construct from row-major matrix with lattice vectors as rows */
        template <typename T>
        explicit UnitCell( const T m[9] ) {
            init( m[0], m[1], m[2],
                  m[3], m[4], m[5],
                  m[6], m[7], m[8] );
        }

        /* get a row-major matrix representation, with lattice vectors
         * as the rows. */
        template <typename Float>
        void as_matrix( Float m[9] ) const {
            std::copy( a1,a1+3,m+0 );
            std::copy( a2,a2+3,m+3 );
            std::copy( a3,a3+3,m+6 );
        }

        /* compute the shift required to place the given point inside 
         * the unit cell */
        template <typename Float>
        void wrap_point( const Float * pos,
                               Float * delta ) const {
           if (!pos || !delta) return;
           using namespace details;
           Float delta_x=0, delta_y=0, delta_z=0;
           Float n1 = ROUND(dotprod(b1, pos));
           Float n2 = ROUND(dotprod(b2, pos));
           Float n3 = ROUND(dotprod(b3, pos));
           /* FIXME: We shouldn't have to use the slow search method when
            * the cell is not diagonal, only when it is triclinic, but
            * for reasons as yet unexplained this routine fails to work
            * on rotated cells. */
           if (n1!=0 || n2!=0 || n3!=0 || !is_diagonal) {
               Float rx = n1*a1[0] + n2*a2[0] + n3*a3[0];
               Float ry = n1*a1[1] + n2*a2[1] + n3*a3[1];
               Float rz = n1*a1[2] + n2*a2[2] + n3*a3[2];

               if (!is_diagonal) {
                   Float c[3] = { pos[0]-rx, pos[1]-ry, pos[2]-rz };
                   Float dist = dotprod(c,c);
                   /* try out all nearby shift vectors */
                   for ( int i1=-1; i1<=1; ++i1 ) {
                       for ( int i2 =-1; i2<=1; ++i2 ) {
                           for ( int i3 =-1; i3<=1; ++i3 ) {
                               Float sx = i1*a1[0] + i2*a2[0] + i3*a3[0];
                               Float sy = i1*a1[1] + i2*a2[1] + i3*a3[1];
                               Float sz = i1*a1[2] + i2*a2[2] + i3*a3[2];
                               
                               Float dx = c[0] + sx;
                               Float dy = c[1] + sy;
                               Float dz = c[2] + sz;

                               // pick the one that's closest to the origin
                               Float newdist = dx*dx + dy*dy + dz*dz;
                               if ( newdist < dist ) {
                                   dist = newdist;
                                   delta_x = sx;
                                   delta_y = sy;
                                   delta_z = sz;
                               }
                           }
                       }
                   }
               }
               delta_x -= rx;
               delta_y -= ry;
               delta_z -= rz;
          }
           delta[0] = delta_x;
           delta[1] = delta_y;
           delta[2] = delta_z;
        }       

        /* compute the shift required to make the given vector have 
         * no projection larger than 1/2 along any basis vector */
        template <typename Float>
        void wrap_vector( const Float * vec,
                                Float * delta ) const {
            if (!vec || !delta) return;
            using namespace details;
            Float c1 = -ROUND(dotprod( vec, b1 ));
            Float c2 = -ROUND(dotprod( vec, b2 ));
            Float c3 = -ROUND(dotprod( vec, b3 ));
            Float dx = c1*a1[0] + c2*a2[0] + c3*a3[0];
            Float dy = c1*a1[1] + c2*a2[1] + c3*a3[1];
            Float dz = c1*a1[2] + c2*a2[2] + c3*a3[2];

            delta[0] = dx;
            delta[1] = dy;
            delta[2] = dz;
        }

    };

}} /* namespace */

#endif

