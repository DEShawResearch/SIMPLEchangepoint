/* 
Copyright 2012-2014, D. E. Shaw Research.
All rights reserved.

Redistribution and use in source and binary forms, with or without
modification, are permitted provided that the following conditions are
met:

* Redistributions of source code must retain the above copyright
  notice, this list of conditions, and the following disclaimer.

* Redistributions in binary form must reproduce the above copyright
  notice, this list of conditions, and the following disclaimer in the
  documentation and/or other materials provided with the distribution.

* Neither the name of D. E. Shaw Research nor the names of its
  contributors may be used to endorse or promote products derived from
  this software without specific prior written permission.

THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
"AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR
A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT
OWNER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,
SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT
LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE,
DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY
THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
(INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE
OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
*/
#ifndef desres_periodicfix_svd_hxx
#define desres_periodicfix_svd_hxx

#include <math.h>
#include <string>
#include <cstring>

namespace desres { namespace periodicfix {

    namespace details {
        inline double dot_column(const double *A, int p, int q) {
            double x = A[3*0+p] * A[3*0+q];
            x       += A[3*1+p] * A[3*1+q];
            x       += A[3*2+p] * A[3*2+q];
            return x;
        }
    }

    inline bool svd_3x3(double *A, double *w, double *V) {

        static const int MAXITER=500;
        static const double TOL=1e-13;
        double ortho = 0;

        // set V to identity
        memset(V,0,9*sizeof(double));
        V[0] = V[4] = V[8] = 1;
      
        for (int iter=0; iter<MAXITER; ++iter) {
          bool done=true;
      
          for (int i=0; i<3; i++) {
            // orthogonalize columns p and q
            int p=i;
            int q=(p+1) % 3;
            int r=(p+2) % 3;
            if (p==2) { p=0; q=2; r=1; }
      
            // compute dot products
            double App=details::dot_column(A, p, p);
            double Aqq=details::dot_column(A, q, q);
            double Apq=details::dot_column(A, p, q);
      
            // sort as we go, putting largest singular first
            bool sorted = App >= Aqq; // FIXME: coerce 64-bit precision first?
      
            // check for convergence: cosine between columns < tolerance
            ortho = Apq*Apq / (App * Aqq);
            if (sorted && !(ortho >= TOL*TOL)) continue; // robust against NaN
            done = false;
      
            double c,s;
            if (!sorted) {
              // swap columns
              c=0;
              s=1;
      
            } else {
              // compute Jacobi rotation
              // reference: de Rijk 1989
              double Q = App-Aqq;
              double root = sqrt(Q*Q + 4*Apq*Apq);
              if (Q<0) root = -root;
              double t = 2*Apq / (Q+root);
              c = 1/sqrt(1+t*t);
              s = c*t;
            }

#define a(i,j) ( A[3*(i) + (j)] )
#define v(i,j) ( V[3*(i) + (j)] )
      
            // apply transformation ((c,-s),(s,c)) to m
            double x = a(p,p);
            double y = a(p,q);
            a(p,p) = c*x + s*y;
            a(p,q) = c*y - s*x;
            x = a(q,p);
            y = a(q,q);
            a(q,p) = c*x + s*y;
            a(q,q) = c*y - s*x;
            x = a(r,p);
            y = a(r,q);
            a(r,p) = c*x + s*y;
            a(r,q) = c*y - s*x;
      
            // apply transformation to V
            x = v(p,p);
            y = v(p,q);
            v(p,p) = c*x + s*y;
            v(p,q) = c*y - s*x;
            x = v(q,p);
            y = v(q,q);
            v(q,p) = c*x + s*y;
            v(q,q) = c*y - s*x;
            x = v(r,p);
            y = v(r,q);
            v(r,p) = c*x + s*y;
            v(r,q) = c*y - s*x;
          }
          if (done) {
      
            // at this point A holds AV = UW.  Extract the singular values
            // from the norms of the column vectors of U.
            for (int i=0; i<3; i++) {
              double s = sqrt(details::dot_column(A, i,i));
              w[i] = s;
              if (s != 0) s = 1/s;
              for (int k=0; k<3; k++) a(k,i) *= s;
            }
            //assert(w[0] >= w[1]);
            //assert(w[1] >= w[2]);
            return true;
          }
        }
        return false;

#undef a
#undef v

    }
}}

#endif
