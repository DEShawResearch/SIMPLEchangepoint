/* 
Copyright 2012-2014, D. E. Shaw Research.
All rights reserved.

Redistribution and use in source and binary forms, with or without
modification, are permitted provided that the following conditions are
met:

* Redistributions of source code must retain the above copyright
  notice, this list of conditions, and the following disclaimer.

* Redistributions in binary form must reproduce the above copyright
  notice, this list of conditions, and the following disclaimer in the
  documentation and/or other materials provided with the distribution.

* Neither the name of D. E. Shaw Research nor the names of its
  contributors may be used to endorse or promote products derived from
  this software without specific prior written permission.

THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
"AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR
A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT
OWNER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,
SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT
LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE,
DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY
THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
(INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE
OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
*/
#ifndef desres_periodicfix_rmsd_hxx
#define desres_periodicfix_rmsd_hxx

#include "svd.hxx"
#include <cstdlib>
#include <stdexcept>

namespace desres { namespace periodicfix {

    namespace details {
        // 3x3 matrix transpose
        inline void trans_3x3(double * a_tr, const double * a) {
          for(int i=0; i<3; ++i) 
            for(int j=0; j<3; ++j) 
              a_tr[3*i + j] = a[3*j + i];
        }

        // 3x3 matrix-matrix multiply
        inline void matmult_3x3(double* c, const double* a, const double* b) {
          for(int i=0; i<3; ++i) {
            for(int j=0; j<3; ++j) {
              c[3*i + j] = 0;
              for(int k=0; k<3; ++k) 
                c[3*i + j] += a[3*i + k] * b[3*k + j];
            }
          }
        }
    }

    /* from Desmond */
#define DET_3x3( m11, m12, m13,                                    \
                 m21, m22, m23,                                    \
                 m31, m32, m33 )                                   \
   ( ( (m11)*(m22)*(m33) + (m12)*(m23)*(m31) + (m13)*(m21)*(m32) ) \
   - ( (m11)*(m23)*(m32) + (m12)*(m21)*(m33) + (m13)*(m22)*(m31) ) )

    /* remove the center from the given array of positions. */
    template <typename Float>
    void remove_center( int N,                  /* number of positions */
                        Float * pos,            /* Nx3 positions */
                        const Float * wts,      /* optional N weights */
                        Float * center ) {      /* optional returned center */

        double cx=0, cy=0, cz=0, tw=0;
        Float * p = pos;
        for (int i=0; i<N; i++) {
            double w = wts ? wts[i] : 1;
            cx += w * p[0];
            cy += w * p[1];
            cz += w * p[2];
            tw += w;
            p += 3;
        }
        if (tw==0) {
            throw std::runtime_error("remove_center: weights sum to 0");
        } else {
            double inv_tw = 1.0/tw;
            Float sx = cx * inv_tw;
            Float sy = cy * inv_tw;
            Float sz = cz * inv_tw;
            p = pos;
            for (int i=0; i<N; i++) {
                p[0] -= sx;
                p[1] -= sy;
                p[2] -= sz;
                p += 3;
            }
            if (center) {
                center[0] = sx;
                center[1] = sy;
                center[2] = sz;
            }
        }
    }

    /* compute the alignment matrix by the method of Kabsch (1976, 1978).
     * Returned matrix is in row-major format, such that the matrix-vector
     * product R x_pos = x_ref; i.e. mat superposes pos onto ref.  ref 
     * and pos are assumed to be already * centered on the origin. */
    template <typename Float>
    void compute_alignment( 
                        int N,                  /* number of positions     */
                        const Float * pos,      /* Nx3 structure positions */
                        const Float * ref,      /* Nx3 reference positions */
                        const Float * wts,      /* if non-NULL, N weights  */
                        double      * mat) {    /* returned matrix         */

        double U[9], S[3], V[9], V_tr[9];
        double W[9] = {0, 0, 0, 0, 0, 0, 0, 0, 0};

        for (int i=0; i<N; i++) {
            double w = wts ? wts[i] : 1;
            W[3*0 + 0] += w * ref[0] * pos[0];
            W[3*0 + 1] += w * ref[0] * pos[1];
            W[3*0 + 2] += w * ref[0] * pos[2];
            W[3*1 + 0] += w * ref[1] * pos[0];
            W[3*1 + 1] += w * ref[1] * pos[1];
            W[3*1 + 2] += w * ref[1] * pos[2];
            W[3*2 + 0] += w * ref[2] * pos[0];
            W[3*2 + 1] += w * ref[2] * pos[1];
            W[3*2 + 2] += w * ref[2] * pos[2];
            pos += 3;
            ref += 3;
        }


        svd_3x3(W, S, V); 
        details::trans_3x3(V_tr, V);

        const double det_W = DET_3x3(W[0], W[1], W[2],
                                     W[3], W[4], W[5],
                                     W[6], W[7], W[8]);

        const double det_V_tr = DET_3x3(V_tr[0], V_tr[1], V_tr[2],
                                        V_tr[3], V_tr[4], V_tr[5],
                                        V_tr[6], V_tr[7], V_tr[8]);

        if(det_W * det_V_tr < 0) {
          W[3*0+2] *= -1;
          W[3*1+2] *= -1;
          W[3*2+2] *= -1;
        }

        details::matmult_3x3(U, W, V_tr);
        
        for (int i=0; i<9; i++) mat[i] = U[i];
    }

    /* calculates the inner product of two structures.
     * Output: A - inner product matrix, and E0
     * WARNING: structures must be centered!
     */
    template <typename Float>
    double compute_inner_product(
            int N,
            const Float * pos,
            const Float * ref,
            const Float * wts,
            double* A_3x3 ) {

        double G1=0, G2=0;
        double a0=0, a1=0, a2=0, a3=0, a4=0, a5=0, a6=0, a7=0, a8=0;
        for (int i=0; i<N; i++) {
            Float w = wts ? wts[i] : 1;

            double x1 = w * pos[0];
            double y1 = w * pos[1];
            double z1 = w * pos[2];
            G1 += x1*pos[0] + y1*pos[1] + z1*pos[2];

            double x2 = ref[0];
            double y2 = ref[1];
            double z2 = ref[2];
            G2 += w * (x2*x2 + y2*y2 + z2*z2);

            pos += 3;
            ref += 3;

            a0 += x1*x2;
            a1 += x1*y2;
            a2 += x1*z2;

            a3 += y1*x2;
            a4 += y1*y2;
            a5 += y1*z2;

            a6 += z1*x2;
            a7 += z1*y2;
            a8 += z1*z2;
        }
        if (A_3x3) {
            A_3x3[0]=a0;
            A_3x3[1]=a1;
            A_3x3[2]=a2;
            A_3x3[3]=a3;
            A_3x3[4]=a4;
            A_3x3[5]=a5;
            A_3x3[6]=a6;
            A_3x3[7]=a7;
            A_3x3[8]=a8;
        }
        return (G1+G2) * 0.5;
    }

    /* apply the rotation for matrix mat to the given coordinates */
    template <typename Float, typename MFloat>
    void apply_rotation( int N, Float * pos, const MFloat * mat ) {
        Float * end = pos+3*N;
#define M(i,j) (mat[3*i+j])
        for (; pos!=end; pos+=3) {
            const Float x = pos[0];
            const Float y = pos[1];
            const Float z = pos[2];
            pos[0] = M(0,0)*x + M(0,1)*y + M(0,2)*z;
            pos[1] = M(1,0)*x + M(1,1)*y + M(1,2)*z;
            pos[2] = M(2,0)*x + M(2,1)*y + M(2,2)*z;
        }
#undef M
    }

}}

#endif
