/* 
Copyright 2012-2014, D. E. Shaw Research.
All rights reserved.

Redistribution and use in source and binary forms, with or without
modification, are permitted provided that the following conditions are
met:

* Redistributions of source code must retain the above copyright
  notice, this list of conditions, and the following disclaimer.

* Redistributions in binary form must reproduce the above copyright
  notice, this list of conditions, and the following disclaimer in the
  documentation and/or other materials provided with the distribution.

* Neither the name of D. E. Shaw Research nor the names of its
  contributors may be used to endorse or promote products derived from
  this software without specific prior written permission.

THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
"AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR
A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT
OWNER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,
SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT
LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE,
DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY
THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
(INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE
OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
*/
#ifndef desres_periodicfix_fit_hxx
#define desres_periodicfix_fit_hxx

#include "rmsd.hxx"
#include <vector>
#include <cmath>
#include <cstddef>
#include <stdexcept>

namespace desres { namespace periodicfix {
    namespace details {

        template <typename Float>
        void compute_center( int natoms, Float * pos, const Float * weights,
                             Float * center ) {
            if (!natoms) {
                throw std::runtime_error("compute_center: no positions");
            }
            double cx=0, cy=0, cz=0, wt=0;
            for (int i=0; i<natoms; i++) {
                double w = weights ? weights[i] : 1;
                cx += w * pos[0];
                cy += w * pos[1];
                cz += w * pos[2];
                pos += 3;
                wt += w;
            }
            if (!wt) {
                throw std::runtime_error("compute_center: weights sum to 0");
            }
            wt = 1.0/wt;
            center[0] = cx * wt;
            center[1] = cy * wt;
            center[2] = cz * wt;
        }
    
        template <typename Float>
        void apply_translation( int natoms, Float * pos,
                                Float cx, Float cy, Float cz ) {
            Float * end = pos+3*natoms;
            for (; pos!=end; pos+=3) {
                pos[0] += cx;
                pos[1] += cy;
                pos[2] += cz;
            }
        }
    }
                         

    /* Instances of this class perform weighted RMS alignment, with optional
     * centering and rewrapping. */
    template <typename Float>
    class Fit {
        
        std::vector<Float> refpos;
        Float              center[3];
        Float*             weights;

        mutable std::vector<Float> tmppos;

    public:
        /* constructor: supply reference positions as Nx3 array (copied).
         *
         * Weights will be used to compute centers and 
         * rms alignment.  Copied if non-NULL.
         */
        Fit( size_t natoms,                     /* number of atoms N */
             const Float * target,              /* Nx3 reference positions */
             const Float * opt_weights=NULL,    /* N weights */
             const Float * opt_center=NULL ) {  /* center on this */

            using namespace details;

            weights=NULL;

           /* cache reference positions */
           refpos.resize(3*natoms);
           std::copy( target, target+3*natoms, refpos.begin() );

           /* cache weights */
           if (opt_weights) {
               weights = new float[natoms];
               std::copy( opt_weights, opt_weights+natoms, weights );
           }

           /* compute and remove weighted center from reference positions */
           compute_center( natoms, &refpos[0], weights, center );
           apply_translation( natoms, &refpos[0], 
                   -center[0], -center[1], -center[2] );
           if (opt_center) {
               std::copy( opt_center, opt_center+3, center );
           }
        }       

        ~Fit() { delete [] weights; }

        size_t size() const { return refpos.size()/3; }

        /* return the (weighted) center of the target positions in the 
         * supplied buffer. */
        void get_center( Float buf[3] ) const {
            std::copy( center, center+3, buf );
        }

        /* Align pos with refpos.  Rotate cell and velocity if provided.
         * If movepos is provided, use pos for the alignment, but apply
         * the alignment to movepos instead of pos.  */
        void align( 
                Float * pos,                            /* Nx3 positions */
                double * opt_cell=NULL,                 /* unit cell */
                Float * opt_vel=NULL,                   /* velocities */
                Float * opt_move=NULL ) const { /* move this intead of pos */

            using namespace details;
            Float t1[3];
            double mat[9];
            size_t natoms = size();
        
            if (!opt_move) opt_move = pos;
            /* remove weighted center from given positions */
            compute_center( natoms, pos, weights, t1);
            apply_translation(natoms, pos, -t1[0], -t1[1], -t1[2]);
        
            /* compute alignment matrix to take pos back to refpos */
            compute_alignment( natoms, pos, &refpos[0], weights, mat );
            //printf("mat: %f %f %f %f %f %f %f %f %f\n",
                    //mat[0], mat[1], mat[2],
                    //mat[3], mat[4], mat[5],
                    //mat[6], mat[7], mat[8] );
        
            /* apply that alignment matrix */
            apply_rotation( natoms, opt_move, mat );
            if (opt_cell) {
                apply_rotation( 3, opt_cell, mat );
            }
            if (opt_vel) {
                apply_rotation( natoms, opt_vel, mat );
            }
        
            /* bring back to center */
            apply_translation( natoms, opt_move, center[0], center[1], center[2] );
        }

        /* Shift the supplied positions to the weighted center */
        void remove_center(Float * pos) const {
            Float t[3];
            using namespace details;

            size_t natoms = size();

            compute_center( natoms, pos, weights, t );
            apply_translation( natoms, pos, -t[0], -t[1], -t[2] );
        }

        /* compute weighted rmsd */
        double rmsd(Float * pos) const {

            unsigned i,n = size();
            if (!n) return 0;
            const Float* ref= &refpos[0];
            double R=0, W=0;
            for (i=0; i<n; i++) {
                double w  = weights ? weights[i] : 1;
                double dx = center[0] + ref[0] - pos[0];
                double dy = center[1] + ref[1] - pos[1];
                double dz = center[2] + ref[2] - pos[2];
                double r2 = dx*dx + dy*dy + dz*dz;
                R += w * r2;
                W += w;
                pos += 3;
                ref += 3;

            }
            if (W==0) return 0;
            return sqrt(R/W);
        }
    };

}}

#endif
