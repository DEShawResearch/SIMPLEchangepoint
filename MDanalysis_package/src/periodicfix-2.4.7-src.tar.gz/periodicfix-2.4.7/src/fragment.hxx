/* 
Copyright 2012-2014, D. E. Shaw Research.
All rights reserved.

Redistribution and use in source and binary forms, with or without
modification, are permitted provided that the following conditions are
met:

* Redistributions of source code must retain the above copyright
  notice, this list of conditions, and the following disclaimer.

* Redistributions in binary form must reproduce the above copyright
  notice, this list of conditions, and the following disclaimer in the
  documentation and/or other materials provided with the distribution.

* Neither the name of D. E. Shaw Research nor the names of its
  contributors may be used to endorse or promote products derived from
  this software without specific prior written permission.

THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
"AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR
A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT
OWNER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,
SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT
LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE,
DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY
THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
(INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE
OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
*/
#ifndef desres_periodicfix_fragment_hxx
#define desres_periodicfix_fragment_hxx

#include <vector>
#include <math.h>
#include <stdio.h>
#include <stdexcept>
#include <algorithm>
#include <boost/foreach.hpp>

#include "unitcell.hxx"
#include "topology.hxx"

namespace desres { namespace periodicfix {

    typedef std::vector<unsigned> AtomidList;
    typedef std::vector<std::pair<unsigned,unsigned> > RangeList;

    class FragmentWrapper {

        /* atoms grouped by fragment */
        AtomidList  _atomids;

        /* start, end of of each fragment */
        RangeList   _ranges;

        /* fragments which are to be kept together */
        struct Aggregate {
            /* atoms grouped by fragment */
            AtomidList  atoms;

            /* start, end of each fragment */
            RangeList   frags;

            /* number of atoms used to calculate center of each fragment */
            std::vector<unsigned> sizes;

            inline void join(UnitCell const& cell, float * pos) const;

            template <typename Writer>
            void dump(Writer& a) const {
                unsigned natoms = atoms.size();
                unsigned nfrags = frags.size();
                unsigned nsizes = sizes.size();
                a(&natoms, sizeof(natoms));
                a(&nfrags, sizeof(nfrags));
                a(&nsizes, sizeof(nsizes));
                if (natoms) a(&atoms[0], natoms*sizeof(atoms[0]));
                if (nfrags) a(&frags[0], nfrags*sizeof(frags[0]));
                if (nsizes) a(&sizes[0], nsizes*sizeof(sizes[0]));
            }

            template <typename Reader>
            void load(Reader& a) {
                unsigned natoms, nfrags, nsizes;
                a(&natoms, sizeof(natoms));
                a(&nfrags, sizeof(nfrags));
                a(&nsizes, sizeof(nsizes));
                atoms.resize(natoms);
                frags.resize(nfrags);
                sizes.resize(nsizes);
                if (natoms) a(&atoms[0], natoms*sizeof(atoms[0]));
                if (nfrags) a(&frags[0], nfrags*sizeof(frags[0]));
                if (nsizes) a(&sizes[0], nsizes*sizeof(sizes[0]));
            }
        };

        typedef std::vector<Aggregate> AggregateList;
        AggregateList _aggregates;

    public:
        /* Default constructor for use with load() */
        FragmentWrapper() {}

        /* initialize from topology */
        inline explicit FragmentWrapper(Topology const& top); 

        /* maximum fragid; some fragments may be empty after calls to
         * aggregate(), but initially all fragments will contain at least
         * one atom. */
        unsigned maxFragid() const { return _ranges.size(); }

        /* maximum atom id */
        unsigned maxAtomid() const { return _atomids.size(); }

        /* Atoms in the given fragment */
        AtomidList fragment(unsigned fragid) const {
            std::pair<unsigned,unsigned> r = _ranges.at(fragid);
            AtomidList::const_iterator begin = _atomids.begin()+r.first;
            AtomidList::const_iterator end   = _atomids.begin()+r.second;
            return AtomidList(begin,end);
        }

        /* specify that the given set of atoms are to be kept together
         * during wrapping.  All atoms in the same fragment as the
         * atoms in the aggregate will be given the same fragid.  Return the 
         * number of non-empty fragments in the aggregate.
         *
         * Because std::binary_search will be used to determine if
         * a particular atom is in the given set, the list of atoms 
         * must be unique and in sorted order! */
        inline unsigned aggregate(AtomidList const& atoms);

        /* Return the atoms which are in the same fragment as the
         * input set; note that aggregate() changes this result
         * as atoms are reassigned to new fragments.  atoms must be
         * sorted and unique. */
        inline AtomidList sameFragmentAs(AtomidList const& atoms) const;

        /* Return a new wrapper for the specified set of atom ids.  For
         * each fragment intersected by the given atoms, all aggregated
         * atoms (i.e. atoms that were part of a single call to aggregate())
         * that are part of that fragment must be included in the set.
         */
        inline FragmentWrapper clone(AtomidList const& atoms) const;

        /* join all aggregates */
        void join(UnitCell const& cell, float * pos) const {
            for (unsigned i=0; i<_aggregates.size(); i++) {
                _aggregates[i].join(cell,pos);
            }
        }

        /* wrap all fragments */
        inline void wrap(UnitCell   const& cell,
                  float           * pos,
                  const float     * center=NULL) const;

        /* serialization to Writer::operator()(const void* buf, size_t sz) */
        template <typename Writer>
        void dump(Writer& a) const {
            unsigned natoms=_atomids.size();
            unsigned nfrags=_ranges.size();
            unsigned naggrs=_aggregates.size();
            a(&natoms, sizeof(natoms));
            a(&nfrags, sizeof(nfrags));
            a(&naggrs, sizeof(naggrs));
            if (natoms) a(&_atomids[0], natoms*sizeof(_atomids[0]));
            if (nfrags) a(&_ranges[0], nfrags*sizeof(_ranges[0]));
            for (unsigned i=0; i<naggrs; i++) _aggregates[i].dump(a);
        }

        /* deserialization to Reader::operator()(void* buf, size_t sz) */
        template <typename Reader>
        void load(Reader& a) {
            unsigned natoms, nfrags, naggrs;
            a(&natoms, sizeof(natoms));
            a(&nfrags, sizeof(nfrags));
            a(&naggrs, sizeof(naggrs));
            _atomids.resize(natoms);
            _ranges.resize(nfrags);
            _aggregates.resize(naggrs);
            if (natoms) a(&_atomids[0], natoms*sizeof(_atomids[0]));
            if (nfrags) a(&_ranges[0], nfrags*sizeof(_ranges[0]));
            for (unsigned i=0; i<naggrs; i++) _aggregates[i].load(a);
        }

        struct StreamWriter {
            std::ostream& _str;
            explicit StreamWriter(std::ostream& str) : _str(str) {}
            void operator()(const void* buf, size_t sz) {
                _str.write((const char *)buf, sz);
            }
        };
        struct StreamReader {
            std::istream& _str;
            explicit StreamReader(std::istream& str) : _str(str) {}
            void operator()(void* buf, size_t sz) {
                _str.read((char *)buf, sz);
            }
        };

    };

}} /* namespace desres::periodicfix */

inline
std::ostream& operator<<(std::ostream& o, 
                         desres::periodicfix::FragmentWrapper const& w) {
    desres::periodicfix::FragmentWrapper::StreamWriter s(o);
    w.dump(s);
    return o;
}

inline
std::istream& operator>>(std::istream& o, 
                         desres::periodicfix::FragmentWrapper      & w) {
    desres::periodicfix::FragmentWrapper::StreamReader s(o);
    w.load(s);
    return o;
}

#include "fragment_inl.hxx"

#endif


