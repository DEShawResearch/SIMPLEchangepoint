/* 
Copyright 2012-2014, D. E. Shaw Research.
All rights reserved.

Redistribution and use in source and binary forms, with or without
modification, are permitted provided that the following conditions are
met:

* Redistributions of source code must retain the above copyright
  notice, this list of conditions, and the following disclaimer.

* Redistributions in binary form must reproduce the above copyright
  notice, this list of conditions, and the following disclaimer in the
  documentation and/or other materials provided with the distribution.

* Neither the name of D. E. Shaw Research nor the names of its
  contributors may be used to endorse or promote products derived from
  this software without specific prior written permission.

THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
"AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR
A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT
OWNER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,
SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT
LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE,
DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY
THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
(INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE
OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
*/
#include <boost/python.hpp>
#include <boost/foreach.hpp>
#include <numpy/ndarrayobject.h>

#include "periodicfix.hxx"
#include "topology.hxx"
#include "rmsd.hxx"
#include "fit.hxx"
#include "fragment.hxx"
#include "contacts.hxx"
#include "hbond.hxx"

using namespace boost::python;
namespace pf = desres::periodicfix;

namespace {

    /* make_cell in its various forms converts from a numpy array to a 
     * UnitCell object.  It was found that exposing the UnitCell type
     * directly made one write ugly Python code that did nothing but
     * cast a numpy array to a UnitCell.  Better to just accept the
     * numpy array directly and do conversions here, in the wrapper
     * layer.  */
    template <typename T> 
    pf::UnitCell make_cell(const void * v, int ndim, int nrows, int ncols) {
        const T * d = reinterpret_cast<const T *>(v);
        if (ncols==1) {
            if (nrows==3) {
                return pf::UnitCell( d[0],d[1],d[2] );

            } else if (nrows==6) {
                return pf::UnitCell( d[0],d[1],d[2],
                                     d[3],d[4],d[5] );
            }
        } else if (nrows==3 && ncols==3) {
                return pf::UnitCell( d[0],d[1],d[2],
                                     d[3],d[4],d[5],
                                     d[6],d[7],d[8] );
        }
        throw std::runtime_error("cannot form unit cell from given NumPy array");
        return pf::UnitCell();
    }

    pf::UnitCell make_cell( object& arrobj ) {
        if (!PyArray_Check(arrobj.ptr())) {
            throw std::runtime_error("NumPy array expected");
        }
        PyObject * arr = arrobj.ptr();
        int ndim = PyArray_NDIM(arr);
        int nrows = PyArray_DIM(arr,0);
        int ncols = ndim > 1 ? PyArray_DIM(arr,1) : 1;
        if (ndim>2) {
            throw std::runtime_error("Expected 1d or 2d NumPy array");
        }
        const void * data = PyArray_DATA(arr);
        switch (PyArray_TYPE(arr)) {
            case NPY_FLOAT:  return make_cell<float>(data,ndim,nrows,ncols);
            case NPY_DOUBLE: return make_cell<double>(data,ndim,nrows,ncols);
            case NPY_INT:    return make_cell<int>(data,ndim,nrows,ncols);
            case NPY_LONG:   return make_cell<long>(data,ndim,nrows,ncols);
            default: 
                throw std::runtime_error("expected float, double, int or long as dtype");
        }
        assert(false);
        return pf::UnitCell(); /* never gets here */
    }


    int array_length( object& o ) {
        if (!PyArray_Check(o.ptr())) {
            throw std::runtime_error("NumPy array expected");
        }
        PyArrayObject * arr = reinterpret_cast<PyArrayObject *>(o.ptr());
        return PyArray_DIM(arr,0);
    }

    /* convert o to a Nxm numpy float array, or throw an exception on
     * failure. */
    float * parse_array( object& o, int N, int m, const char * msg="NumPy array expected" ) {

        /* require Nx3 numpy array, where N=topo.size() */
        if (!PyArray_Check(o.ptr())) {
            throw std::runtime_error(msg);
        }
        PyArrayObject * arr = reinterpret_cast<PyArrayObject *>(o.ptr());
        if (PyArray_DIM(arr,0)!=N) {
            throw std::runtime_error("NumPy array has incorrect length");
        }
        if (m>1 && (PyArray_NDIM(arr)!=2 || PyArray_DIM(arr,1)!=3)) {
            throw std::runtime_error("NumPy array has incorrect number of columns");
        }
        /* require contiguous array */
        if (!PyArray_ISCONTIGUOUS(arr)) {
            throw std::runtime_error("Require a contiguous NumPy array");
        }
        /* it's got to be float! */
        if (PyArray_TYPE(arr)!=NPY_FLOAT) {
            throw std::runtime_error("Require NumPy dtype=float32");
        }
        return reinterpret_cast<float *>(PyArray_DATA(arr));
    }

    double * parse_dbl_array( object& o, int N, int m, const char * msg="NumPy array expected" ) {

        /* require Nx3 numpy array, where N=topo.size() */
        if (!PyArray_Check(o.ptr())) {
            throw std::runtime_error(msg);
        }
        PyArrayObject * arr = reinterpret_cast<PyArrayObject *>(o.ptr());
        if (PyArray_DIM(arr,0)!=N) {
            throw std::runtime_error("NumPy array has incorrect length");
        }
        if (m>1 && (PyArray_NDIM(arr)!=2 || PyArray_DIM(arr,1)!=3)) {
            throw std::runtime_error("NumPy array has incorrect number of columns");
        }
        /* require contiguous array */
        if (!PyArray_ISCONTIGUOUS(arr)) {
            throw std::runtime_error("Require a contiguous NumPy array");
        }
        /* it's got to be double! */
        if (PyArray_TYPE(arr)!=NPY_FLOAT64) {
            throw std::runtime_error("Require NumPy dtype=float64");
        }
        return reinterpret_cast<double *>(PyArray_DATA(arr));
    }

    void wrap_bonds( const pf::Topology& topo,
                     object& o ,
                     object& cell ) {

        int n=topo.size();
        topo.traverse_bonds( pf::Wrapper<float>( n, parse_array(o,n,3), 
                    make_cell(cell) ) );
    }

    void check_bonds( const pf::Topology& topo,
                     object& o,
                      object& cell  ) {

        int n=topo.size();
        topo.traverse_bonds( pf::WrapChecker<float>( n, parse_array(o,n,3), 
                    make_cell(cell) ) );
    }

    void wrap_frags( const pf::Topology& topo,
                     object& o,
                     object& cell,
                     object& c) {

        int n=topo.size();
        float * centerptr = NULL;
        object none;
        if (c.ptr()!=none.ptr()) {
            centerptr = parse_array(c,3,1);
        }
        topo.traverse_frags( 
                pf::Wrapper<float>( 
                    n, 
                    parse_array(o,n,3), 
                    make_cell(cell),
                    centerptr ));
    }

    void unwrap_frags( const pf::Topology& topo,
                       object& frame,
                       object& prev,
                       object& shifts,
                       object& cell,
                       object& prev_cell,
                       object& ref_cell ) {

        int n=topo.size();
        topo.traverse_frags( 
                pf::UnWrapper<float>( 
                    n, 
                    parse_array(frame,n,3), 
                    parse_array(prev,n,3), 
                    parse_dbl_array(shifts,n,3),
                    make_cell(cell),
                    make_cell(prev_cell),
                    make_cell(ref_cell)));
    }

    struct TopologyVisitor {
        object& obj;

        explicit TopologyVisitor( object& _obj ) : obj(_obj) {}
        
        void visit_bond(int i, int j) const {
            PyObject * ai = PyInt_FromLong(i);
            PyObject * aj = PyInt_FromLong(j);
            PyObject * result = PyObject_CallFunctionObjArgs(
                    obj.ptr(), ai, aj, NULL );
            Py_DECREF(ai);
            Py_DECREF(aj);
            if (!result) throw error_already_set();
            Py_DECREF(result);
        }

        template <typename T>
        void visit_fragment( const T& begin, const T& end ) const {
            unsigned i=0, n = end-begin;
            PyObject * tuple = PyTuple_New(n);
            for (T t=begin; t!=end; ++t, ++i) {
                PyTuple_SET_ITEM( tuple, i, PyInt_FromLong( *t ));
            }
            PyObject * result = PyObject_CallFunctionObjArgs( 
                    obj.ptr(), tuple, NULL );
            Py_DECREF(tuple);
            if (!result) throw error_already_set();
            Py_DECREF(result);
        }
    };

    void visit_bonds( const pf::Topology& topo,
                      object& o ) {
        topo.traverse_bonds( TopologyVisitor( o ));
    }

    void visit_frags( const pf::Topology& topo,
                      object& o ) {
        topo.traverse_frags( TopologyVisitor( o ));
    }

    void check_frags( const pf::Topology& topo,
                      object& o,
                      object& cell ) {

        int n=topo.size();
        topo.traverse_frags( pf::WrapChecker<float>( n, parse_array(o,n,3),
                    make_cell(cell) ) );
    }

    object rms_align( object& refobj, object& posobj, object& wtsobj ) {
        double mat[9];
        int n = array_length(refobj);
        const float * ref = parse_array( refobj, n, 3 );
        const float * pos = parse_array( posobj, n, 3 );
        const float * wts = NULL;
        if (wtsobj.ptr() != Py_None) {
            wts = parse_array( wtsobj, n, 1 );
        }
        pf::compute_alignment( n, ref, pos, wts, mat );

        npy_intp dims[2] = {3,3};
        PyObject * result = PyArray_SimpleNew( 2, dims, NPY_FLOAT );
        float * ptr = reinterpret_cast<float *>(PyArray_DATA(result));
        /* since we deal with Nx3 numpy arrays, it's most convenient
         * to return R.transpose(), so that we can apply the rotation
         * with dot(coords, R).  */
        for (int i=0; i<3; i++) for (int j=0; j<3; j++) ptr[3*i+j]=mat[3*j+i];

        return object(handle<>(result));
    }

    object convert_cell( double a, double b, double c,
                         double alpha, double beta, double gamma ) {
        npy_intp dims[2] = {3,3};
        PyObject * result = PyArray_SimpleNew( 2, dims, NPY_FLOAT );
        float * ptr = reinterpret_cast<float *>(PyArray_DATA(result));
        pf::UnitCell( a,b,c, alpha, beta, gamma ).as_matrix(ptr);
        return object(handle<>(result));
    }
    
    pf::Fit<float> * make_fit( object& targetobj, 
                        object& weightobj,
                        object& centerobj ) {
        object none;
        int n = array_length(targetobj);
        float * target = parse_array(targetobj, n, 3, "parsing target");
        float * weight = NULL;
        if (weightobj.ptr()!=none.ptr()) {
            weight = parse_array(weightobj, n, 1, "parsing weights");
        }
        float * center = NULL;
        if (centerobj.ptr()!=none.ptr()) {
            center = parse_array(centerobj, 3, 1, "parsing center");
        }
        return new pf::Fit<float>(n, target, weight, center);
    }

    object fit_get_center( const pf::Fit<float>& self ) {
        npy_intp dims[1] = {3};
        PyObject * result = PyArray_SimpleNew( 1, dims, NPY_FLOAT );
        float * ptr = reinterpret_cast<float *>(PyArray_DATA(result));
        self.get_center( ptr );
        return object(handle<>(result));
    }

    void fit_align( const pf::Fit<float>& self, object& posobj, object& cellobj,
                   object& velobj, object& moveposobj ) {

        object none;
        int n = array_length(posobj);
        float * pos = parse_array(posobj, n, 3, "parsing pos");

        /* parse cell, accepting either float or double */
        double * cell = NULL;
        float * fltcell = NULL;
        double tmpcell[9];
        if (cellobj.ptr()!=none.ptr()) {
            if (!PyArray_Check(cellobj.ptr())) {
                throw std::runtime_error("exected NumPy array");
            }
            if (PyArray_TYPE(cellobj.ptr())==NPY_FLOAT) {
                fltcell = parse_array(cellobj, 3, 3, "parsing cell");
                for (int i=0; i<9; i++) tmpcell[i]=fltcell[i];
                cell = tmpcell;
            } else {
                cell = parse_dbl_array(cellobj, 3, 3, "parsing cell");
            }
        }
        float * vel = NULL;
        if (velobj.ptr()!=none.ptr()) {
            vel = parse_array(velobj, n, 3);
        }
        float * movepos = NULL;
        if (moveposobj.ptr()!=none.ptr()) {
            movepos = parse_array(moveposobj, n, 3);
        }
        self.align(pos, &cell[0], vel, movepos);
        if (fltcell!=NULL) {
            for (int i=0; i<9; i++) fltcell[i] = tmpcell[i];
        }
    }


    double fit_rmsd( const pf::Fit<float>& self, object& posobj) {
        int n = array_length(posobj);
        float * pos = parse_array(posobj, n, 3, "parsing pos");
        return self.rmsd(pos);
    }

    void fit_remove_center(const pf::Fit<float>& self, object& posobj) {
        int n = array_length(posobj);
        float * pos = parse_array(posobj, n, 3, "parsing pos");
        self.remove_center(pos);
    }

    static const char make_topo_doc[] = 
        "__init__(sequence) -> construct from list of bondlists.\n"
        "   elements in sequence should be lists of gids, one for each\n"
        "   bond in the corresponding atom.";

    pf::Topology * make_topo_from_bondlist(object& seq) {
        PyObject * obj = seq.ptr();

        /* allow construction from integer, giving empty Topology */
        int n = PyInt_AsLong(obj);
        if (!PyErr_Occurred()) return new pf::Topology(n);
        PyErr_Clear();

        if (!PySequence_Check(obj)) {
            throw std::runtime_error("expected a sequence");
        }
        n = PyObject_Size(obj);
        pf::Topology * topo = new pf::Topology(n);
        for (int i=0; i<n; i++) {
            PyObject * sublist = PySequence_GetItem(obj,i);
            if (!sublist || !PySequence_Check(sublist)) {
                if (sublist) {
                    Py_DECREF(sublist);
                }
                delete topo;
                throw std::runtime_error("sequence elements must be sequences");
            }
            int nn = PyObject_Size(sublist);
            for (int j=0; j<nn; j++) {
                PyObject * item = PySequence_GetItem(sublist,j);
                int gid=0;
                PyErr_Clear();
                if (item) {
                    gid = PyInt_AsLong(item);
                    Py_DECREF(item);
                }
                if (PyErr_Occurred()) {
                    Py_DECREF(sublist);
                    throw std::runtime_error("subsequence elements must be integer");
                }
                topo->add_bond(i,gid);
            }
            Py_DECREF(sublist);
        }
        return topo;
    }

    list dump(pf::Topology const& top) {
        list result;
        pf::Topology::AtomList neighbors = top.neighbors();
        for (int i=0; i<top.size(); i++) {
            pf::Topology::BondList const& bonds = neighbors[i];
            list sub;
            BOOST_FOREACH(int j, bonds) {
                if (i>j) continue;
                sub.append(object(j));
            }
            result.append(sub);
        }
        return result;
    }

    int frag_aggregate(pf::FragmentWrapper& f, object L) {
        pf::AtomidList atoms(len(L));
        for (int i=0; i<len(L); i++) {
            atoms[i] = extract<unsigned>(L[i]);
        }
        std::sort(atoms.begin(), atoms.end());
        atoms.resize(std::unique(atoms.begin(), atoms.end())-atoms.begin());
        return int(f.aggregate(atoms));
    }
    
    list frag_same_frag_as(pf::FragmentWrapper const& f, object L) {
        pf::AtomidList atoms(len(L));
        for (int i=0; i<len(L); i++) {
            atoms[i] = extract<unsigned>(L[i]);
        }
        atoms = f.sameFragmentAs(atoms);
        list R;
        for (unsigned i=0; i<atoms.size(); i++) R.append(object(atoms[i]));
        return R;
    }

    pf::FragmentWrapper frag_clone(pf::FragmentWrapper const& f, object L) {
        pf::AtomidList atoms(len(L));
        for (int i=0; i<len(L); i++) {
            atoms[i] = extract<unsigned>(L[i]);
        }
        return f.clone(atoms);
    }

    void frag_join(pf::FragmentWrapper const& f,
                   object cellobj,
                   object posobj) {

        f.join(make_cell(cellobj), parse_array(posobj, f.maxAtomid(), 3));
    }

    void frag_wrap(pf::FragmentWrapper const& f,
                   object cellobj,
                   object posobj,
                   object centerobj) {

        float * centerptr = NULL;
        object none;
        if (centerobj.ptr()!=none.ptr()) {
            centerptr = parse_array(centerobj,3,1);
        }
        f.wrap(make_cell(cellobj), 
               parse_array(posobj, f.maxAtomid(), 3),
               centerptr);
    }

    std::string frag_dump(pf::FragmentWrapper const& f) {
        std::stringstream ss;
        ss << f;
        return ss.str();
    }
    void frag_load(pf::FragmentWrapper& f, std::string const& s) {
        std::stringstream ss(s);
        ss >> f;
    }

    void destructor(PyObject* obj) { if (obj) Py_DECREF(obj); }

    struct ContactsOutput {
        std::vector<uint32_t> pairs;
        pf::Topology const& top;
        const bool self;
        ContactsOutput(pf::Topology const& t, bool _self) 
        : top(t), self(_self) {}

        bool exclude(uint32_t a, uint32_t b) const {
            if (self && a>=b) return true;
            if (top.size()) {
                pf::Topology::BondList const& bonds = top.neighbors().at(a);
                if (std::find(bonds.begin(), bonds.end(), b)!=bonds.end()) {
                    return true;
                } 
            }
            return false;
        }
        void operator()(uint32_t a, uint32_t b, float d2) {
            pairs.push_back(a);
            pairs.push_back(b);
        }
    };

    PyObject* wrap_find_contacts(float cutoff,
                                 PyObject* Pobj,
                                 PyObject* Aobj,
                                 PyObject* Bobj,
                                 pf::Topology const& top) {

        PyObject *Aarr=NULL, *Barr = NULL, *Parr = NULL;

        /* parse A */
        Aarr = PyArray_FromAny(
                Aobj, 
                PyArray_DescrFromType(NPY_UINT32),
                1,1,
                NPY_C_CONTIGUOUS | NPY_ALIGNED,
                NULL);
        if (!Aarr) throw_error_already_set();
        boost::shared_ptr<PyObject> _a(Aarr, destructor);

        /* parse B */
        if (Bobj==Py_None) {
            Barr = Aarr;
            Py_INCREF(Barr);
        } else {
            Barr = PyArray_FromAny(
                Bobj, 
                PyArray_DescrFromType(NPY_UINT32),
                1,1,
                NPY_C_CONTIGUOUS | NPY_ALIGNED,
                NULL);
            if (!Barr) throw_error_already_set();
        }
        boost::shared_ptr<PyObject> _b(Barr, destructor);

        /* parse P */
        Parr = PyArray_FromAny(
                Pobj, 
                PyArray_DescrFromType(NPY_FLOAT32),
                2,2,
                NPY_C_CONTIGUOUS | NPY_ALIGNED | NPY_FORCECAST,
                NULL);
        if (!Parr) throw_error_already_set();
        boost::shared_ptr<PyObject> _p(Parr, destructor);
        if (PyArray_DIM(Parr,1)!=3) {
            PyErr_Format(PyExc_ValueError,
                    "Supplied %ld-d positions, expected 3d", 
                    PyArray_DIM(Parr,1)); 
            throw_error_already_set();
        }
        const float* pos = (const float *)PyArray_DATA(Parr);
        const uint32_t* a = (const uint32_t*)PyArray_DATA(Aarr);
        const uint32_t* b = (const uint32_t*)PyArray_DATA(Barr);
        const uint32_t n = PyArray_DIM(Parr,0);
        const uint32_t nA = PyArray_DIM(Aarr,0);
        const uint32_t nB = PyArray_DIM(Barr,0);
        for (uint32_t i=0; i<nA; i++) {
            if (a[i]<0 || a[i]>=n) {
                PyErr_Format(PyExc_ValueError, "A[%u]=%u is out of range",
                        i,a[i]);
                throw_error_already_set();
            }
        }
        for (uint32_t i=0; i<nB; i++) {
            if (b[i]<0 || b[i]>=n) {
                PyErr_Format(PyExc_ValueError, "B[%u]=%u is out of range",
                        i,b[i]);
                throw_error_already_set();
            }
        }

        ContactsOutput output(top, Aarr==Barr);

        pf::find_contacts(cutoff, pos, a,a+nA, b,b+nB, output);

        npy_intp dims[2];
        dims[0] = output.pairs.size()/2;
        dims[1] = 2;
        PyObject* arr = PyArray_SimpleNew(2,dims,NPY_UINT32);
        memcpy(PyArray_DATA(arr), &output.pairs[0], output.pairs.size()*sizeof(uint32_t));
        return arr;
    }

    typedef boost::shared_ptr<PyObject> PyObjectPtr;
    static void py_destructor(PyObject* obj) {
        Py_DECREF(obj);
    }

    PyObjectPtr get_vec3d(PyObject* obj) {
        if (obj==Py_None) return PyObjectPtr();
        PyObject* arr = PyArray_FromAny(
                obj,
                PyArray_DescrFromType(NPY_FLOAT64),
                1,1,
                NPY_C_CONTIGUOUS,
                NULL);
        if (!arr) throw_error_already_set();
        PyObjectPtr ptr(arr, py_destructor);
        if (PyArray_DIM(arr,0)!=3) {
            PyErr_Format(PyExc_ValueError, 
                    "Expected 3 elements in vector, got %ld",
                    PyArray_DIM(arr,0));
            throw_error_already_set();
        }
        return ptr;
    }

    pf::HydrogenBond *init_hbond(
            PyObject* dobj,
            PyObject* aobj,
            PyObject* hobj,
            PyObject* cobj,
            PyObject* caobj) {

        PyObjectPtr darr = get_vec3d(dobj);
        PyObjectPtr aarr = get_vec3d(aobj);
        PyObjectPtr harr = get_vec3d(hobj);
        PyObjectPtr carr = get_vec3d(cobj);
        PyObjectPtr caarr = get_vec3d(caobj);
        return new pf::HydrogenBond(
                darr ? (const double *)PyArray_DATA(darr.get()) : NULL,
                aarr ? (const double *)PyArray_DATA(aarr.get()) : NULL,
                harr ? (const double *)PyArray_DATA(harr.get()) : NULL,
                carr ? (const double *)PyArray_DATA(carr.get()) : NULL,
                caarr? (const double *)PyArray_DATA(caarr.get()): NULL);
    }
}

BOOST_PYTHON_MODULE(_periodicfix) {

    import_array();

    class_<pf::Topology>("Topology", no_init)
        .def("__init__", make_constructor(make_topo_from_bondlist))
        .def("add_bond", &pf::Topology::add_bond)
        .def("size", &pf::Topology::size)
        .def("dump", dump)
        .def("wrap_bonds", wrap_bonds,
            (arg("self"),
             arg("pos"),
             arg("cell")))
        .def("wrap_frags", wrap_frags,
            (arg("self"),
             arg("pos"),
             arg("cell"),
             arg("center")=object()))
        .def("unwrap_frags", unwrap_frags,
            (arg("self"),
             arg("pos"),
             arg("prev"),
             arg("cell"),
             arg("prev_cell")=object(),
             arg("ref_cell")=object()))
        .def("visit_bonds", visit_bonds,
            (arg("self"),
             arg("visitor")))
        .def("check_bonds", check_bonds)
        .def("visit_frags", visit_frags,
            (arg("self"),
             arg("visitor")))
        .def("check_bonds", check_bonds)
        .def("check_frags", check_frags)
        .enable_pickling()
        ;

    class_<pf::Fit<float> >("Fit", no_init)
        .def("__init__", 
                make_constructor( 
                    make_fit,
                    default_call_policies(),
                    (arg_("target"), 
                     arg_("weights")=object(),
                     arg_("center")=object())))
        .add_property("center", fit_get_center)
        .def("align", fit_align,
                (arg("self"),
                 arg("pos"), 
                 arg("cell")=object(),
                 arg("vel")=object(),
                 arg("movepos")=object()))
        .def("rmsd", fit_rmsd,
                (arg("self"),
                 arg("pos")))
        .def("remove_center", fit_remove_center,
                (arg("self"),
                 arg("pos")))
        ;

    def("convert_cell", convert_cell,
            (arg("a"),
             arg("b"),
             arg("c"),
             arg("alpha")=90,
             arg("beta")=90,
             arg("gamma")=90),
            "convert unit cell dimensions and/or angles to 3x3 cell");

    def("compute_alignment", rms_align);

    def("find_contacts", wrap_find_contacts,
            (arg("cutoff"),
             arg("pos"),
             arg("A"),
             arg("B")=object(),
             arg("topology")=pf::Topology()),
            "find ids of atoms in A within cutoff of atoms in B, excluding those found in the topology.  If B is None, finds self-contacts.");

    class_<pf::FragmentWrapper>("FragmentWrapper", init<pf::Topology>())
        .def(init<>())
        .def("aggregate", frag_aggregate)
        .def("sameFragmentAs", frag_same_frag_as)
        .def("clone", frag_clone)
        .def("join", frag_join)
        .def("wrap", frag_wrap)
        .def("dump", frag_dump)
        .def("load", frag_load)
        .enable_pickling()
        ;

    class_<pf::HydrogenBond>("HydrogenBond", init<>())
        .def("__init__", make_constructor(
                      init_hbond
                    , default_call_policies()
                    , (arg("d"), 
                       arg("a"), 
                       arg("h")=object(), 
                       arg("c")=object(),
                       arg("ca")=object())))
        .def("energy",      &pf::HydrogenBond::energy,
                "Stride hbond energy function")
        .def_readwrite("r", &pf::HydrogenBond::r, 
                "donor-acceptor distance")
        .def_readwrite("p", &pf::HydrogenBond::p, 
                "donor-hydrogen-acceptor angle in radians")
        .def_readwrite("ti",&pf::HydrogenBond::ti,
                "out-of-plane deviation of H from lone-pair plane")
        .def_readwrite("to",&pf::HydrogenBond::to,
                "within-plane deviation of H from lone-pair bisector")
        ;

}

