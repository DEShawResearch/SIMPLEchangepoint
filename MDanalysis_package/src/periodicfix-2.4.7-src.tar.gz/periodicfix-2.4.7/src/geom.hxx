/* 
Copyright 2012-2014, D. E. Shaw Research.
All rights reserved.

Redistribution and use in source and binary forms, with or without
modification, are permitted provided that the following conditions are
met:

* Redistributions of source code must retain the above copyright
  notice, this list of conditions, and the following disclaimer.

* Redistributions in binary form must reproduce the above copyright
  notice, this list of conditions, and the following disclaimer in the
  documentation and/or other materials provided with the distribution.

* Neither the name of D. E. Shaw Research nor the names of its
  contributors may be used to endorse or promote products derived from
  this software without specific prior written permission.

THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
"AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR
A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT
OWNER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,
SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT
LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE,
DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY
THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
(INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE
OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
*/
#ifndef desres_periodicfix_geom_hxx
#define desres_periodicfix_geom_hxx

#include <cmath>

namespace desres { namespace periodicfix { namespace geom {

    template <typename Float> 
    Float calc_dot_prod(const Float* a, const Float* b) {
        Float d=0;
        for (int i=0; i<3; i++) d += a[i]*b[i];
        return d;
    }

    template <typename Float>
    Float calc_distance(const Float* a, const Float* b) {
        Float d=0;
        for (int i=0; i<3; i++) {
            Float delta = a[i]-b[i];
            d += delta * delta;
        }
        return std::sqrt(d);
    }

    template <typename Float>
    void calc_cross_prod(const Float* a, const Float* b, Float* c) {
        Float cx =  a[1]*b[2] - b[1]*a[2];
        Float cy = -a[0]*b[2] + b[0]*a[2];
        Float cz =  a[0]*b[1] - b[0]*a[1];
        c[0] = cx;
        c[1] = cy;
        c[2] = cz;
    }
    
    template <typename Float>
    Float normalize(Float* a) {
        Float norm = std::sqrt(calc_dot_prod(a,a));
        if (norm>0) {
            Float sf = Float(1)/norm;
            for (int i=0; i<3; i++) a[i] *= sf;
        }
        return norm;
    }
    
    template <typename Float> 
    Float calc_vec_angle(const Float* r1, const Float* r2) {
        Float r3[3];

        calc_cross_prod(r1,r2,r3);
        Float psin = std::sqrt(calc_dot_prod(r3,r3));
        Float pcos = calc_dot_prod( r1, r2 );
        return std::atan2(psin,pcos);
    }
    
    template <typename Float>
    Float calc_angle( const Float* a, const Float* b, const Float* c) {
        Float r1[3], r2[3];
        for (int i=0; i<3; i++) {
            r1[i]=a[i]-b[i];
            r2[i]=c[i]-b[i];
        }
        return calc_vec_angle( r1, r2 );
    }
    
    template <typename Float>
    Float calc_dihedral( const Float* A, const Float* B, 
                         const Float* C, const Float* D ) {
        Float r1[3], r2[3], r3[3];
        Float n1[3], n2[3];
        Float psin, pcos;
        for (int i=0; i<3; i++) {
            r1[i]=B[i]-A[i];
            r2[i]=C[i]-B[i];
            r3[i]=D[i]-C[i];
        }
        calc_cross_prod( r1, r2, n1 );
        calc_cross_prod( r2, r3, n2 );
        psin = calc_dot_prod( n1, r3 ) * std::sqrt(calc_dot_prod( r2, r2 ));
        pcos = calc_dot_prod( n1, n2 );
        return std::atan2(psin,pcos);
    }

    /* project p onto the plane formed by c1, c2, c3 */
    template <typename Float>
    void calc_projection(const Float* c1, const Float* c2,
                         const Float* c3, const Float* p,
                         Float* proj) {

        /* compute a normal */
        Float r1[3], r3[3], p1[3];
        for (int i=0; i<3; i++) {
            r1[i] = c1[i] - c2[i];
            r3[i] = c3[i] - c2[i];
            p1[i] = c1[i] -  p[i];
        }

        calc_cross_prod(r1,r3,proj);
        normalize(proj);

        Float s = calc_dot_prod(proj, p1);
        for (int i=0; i<3; i++) {
            proj[i] = proj[i] * s + p[i];
        }
    }
    
}}}

#endif

