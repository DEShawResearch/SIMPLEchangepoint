/* 
Copyright 2012-2014, D. E. Shaw Research.
All rights reserved.

Redistribution and use in source and binary forms, with or without
modification, are permitted provided that the following conditions are
met:

* Redistributions of source code must retain the above copyright
  notice, this list of conditions, and the following disclaimer.

* Redistributions in binary form must reproduce the above copyright
  notice, this list of conditions, and the following disclaimer in the
  documentation and/or other materials provided with the distribution.

* Neither the name of D. E. Shaw Research nor the names of its
  contributors may be used to endorse or promote products derived from
  this software without specific prior written permission.

THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
"AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR
A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT
OWNER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,
SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT
LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE,
DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY
THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
(INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE
OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
*/
#ifndef desres_periodicfix_contacts_hxx
#define desres_periodicfix_contacts_hxx

#include <stdint.h>
#include <math.h>
#include <string.h>
#include <stdlib.h>
#include <stdio.h>

namespace desres { namespace periodicfix {

    /* TODO: move this stuff into a details header and namespace */
    typedef uint32_t Id;

    struct voxel_t {
        static const int STACK_SIZE = 4;
        int nbrs[27];
        int n_nbrs;
        Id stack[STACK_SIZE];
        Id * points;
        int num;
        int max;
    
        voxel_t() : n_nbrs(0), points(stack), num(0), max(STACK_SIZE) {}
        ~voxel_t() {
            if (points!=stack) free(points);
        }
    
        void add(Id p) {
            if (num==max) {
                max *= 1.33;
                if (points==stack) {
                    points = (Id *)malloc(max*sizeof(Id));
                    memcpy(points, stack, num*sizeof(Id));
                } else {
                    points = (Id *)realloc(points, max*sizeof(Id));
                }
            }
            points[num++] = p;
        }
    };

    template <typename Iter, typename Float>
    void find_bbox(Iter begin, Iter end, const Float* pos, 
                   Float *min, Float *max) {
        if (begin==end) return;
        memcpy(min, pos+3*(*begin), 3*sizeof(Float));
        memcpy(max, pos+3*(*begin), 3*sizeof(Float));
    
        Float xmin,ymin,zmin;
        Float xmax,ymax,zmax;
        xmin=min[0];
        ymin=min[1];
        zmin=min[2];
        xmax=min[0];
        ymax=min[1];
        zmax=min[2];
        for (++begin; begin!=end; ++begin) {
            const Float* p = pos+3*(*begin);
            const Float x=p[0];
            const Float y=p[1];
            const Float z=p[2];
    
            if (x<xmin) xmin=x;
            if (x>xmax) xmax=x;
    
            if (y<ymin) ymin=y;
            if (y>ymax) ymax=y;
    
            if (z<zmin) zmin=z;
            if (z>zmax) zmax=z;
        }
        min[0]=xmin;
        min[1]=ymin;
        min[2]=zmin;
        max[0]=xmax;
        max[1]=ymax;
        max[2]=zmax;
    }

    template <typename Voxel>
    void find_voxel_full_shell_neighbors(Voxel *mesh, int nx, int ny, int nz) {
        int i, zi, yi, xi, ti, si, ri;
        for (zi=0; zi<nz; zi++) {
            for (yi=0; yi<ny; yi++) {
                for (xi=0; xi<nx; xi++) {
                    int n=0;
                    int nbrs[27];
                    int self = xi + nx*(yi + ny*zi);
                    for (ti=zi-1; ti<=zi+1; ti++) {
                        if (ti<0 || ti>=nz) continue;
                        for (si=yi-1; si<=yi+1; si++) {
                            if (si<0 || si>=ny) continue;
                            for (ri=xi-1; ri<=xi+1; ri++) {
                                if (ri<0 || ri>=nx) continue;
                                int index = ri + nx*(si + ny*ti);
                                /* skip empty voxels */
                                if (mesh[index].num) nbrs[n++] = index;
                            }
                        }
                    }
                    mesh[self].n_nbrs=n;
                    for (i=0; i<n; i++) mesh[self].nbrs[i] = nbrs[i];
                }
            }
        }
    }

    /* output is a functor implementing operator()(Id a, Id b)
     * and bool exclude(Id a, Id b)
     */
    template <typename Float, typename Iter, typename Output>
    void find_contacts(Float rad, const Float* pos,
                       Iter beginA, Iter endA,
                       Iter beginB, Iter endB,
                       Output& output) {
        
        /* sanity checks */
        if (rad<=0 || beginA==endA || beginB==endB || !pos) return;

        /* find bounding box of subselection */
        Float min[3], max[3];
        find_bbox(beginB, endB, pos, min, max);

        /* extend bounding box by selection radius */
        for (int i=0; i<3; i++) {
            min[i] -= rad;
            max[i] += rad;
        }

        /* create and initialize voxel mesh */
        const Float r2 = rad*rad;
        const Float ir = 1.0/rad;

        Float xmin=min[0];
        Float ymin=min[1];
        Float zmin=min[2];
        Float xsize=max[0]-xmin;
        Float ysize=max[1]-ymin;
        Float zsize=max[2]-zmin;

        int nx = (int)(xsize/rad)+1;
        int ny = (int)(ysize/rad)+1;
        int nz = (int)(zsize/rad)+1;
        int nvoxel = nx*ny*nz;
        voxel_t* mesh = new voxel_t[nvoxel];

        /* map B atoms to voxels */
        for (; beginB!=endB; ++beginB) {
            const Id atm = *beginB;
            const Float* p = pos+3*atm;
            int xi = (p[0]-xmin)*ir;
            int yi = (p[1]-ymin)*ir;
            int zi = (p[2]-zmin)*ir;
            int index = xi + nx*(yi + ny*zi);
            mesh[index].add(atm);
        }

        find_voxel_full_shell_neighbors(&mesh[0], nx, ny, nz);

        /* loop over atoms in A */
        for (; beginA!=endA; ++beginA) {
            const Id atm = *beginA;
            const Float* p = pos+3*atm;
            const Float x=p[0];
            const Float y=p[1];
            const Float z=p[2];
            int xi = (x-xmin)*ir;
            int yi = (y-ymin)*ir;
            int zi = (z-zmin)*ir;
            if (xi<0 || xi>=nx ||
                yi<0 || yi>=ny ||
                zi<0 || zi>=nz) {
                continue;
            }
            const int index = xi + nx*(yi + ny*zi);
            const voxel_t& v = mesh[index];
            const int n_nbrs = v.n_nbrs;
            const int* nbrs = v.nbrs;
            for (int j=0; j<n_nbrs; j++) {
                const voxel_t& nbr = mesh[nbrs[j]];
                const int natoms = nbr.num;
                for (int k=0; k<natoms; k++) {
                    const Id pk = nbr.points[k];
                    if (output.exclude(atm, pk)) continue;
                    const Float* p = pos+3*pk;
                    Float dx=x-p[0];
                    Float dy=y-p[1];
                    Float dz=z-p[2];
                    Float d2 = dx*dx + dy*dy + dz*dz;
                    if (d2 <= r2) {
                        output(atm, pk, d2);
                    }
                }
            }
        }
        delete [] mesh;
    }
}}

#endif
