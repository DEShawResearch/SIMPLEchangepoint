#!/usr/bin/env python2.7

import periodicfix as pf
import numpy as np
import molfile
import math

class Visitor():
    def __init__(self, pos, sf):
        '''construct with Nx3 position array, and scale factor'''
        self.pos=pos
        self.sf=sf

    def __call__(self, inds):
        '''shift the atoms in inds so that their center is scaled by sf'''
        inds=np.array(inds)
        c=self.pos[inds].mean(0)
        c *= self.sf
        self.pos[inds] += c

def scale_volume(topo, frame, sf):
    f = math.pow(sf,1./3.)
    for i in range(3): frame.box[i,i] *= f

    v=Visitor(frame.pos, f)
    topo.visit_frags(v)

def compute_density( atoms, box ):
    '''return density in g/mL'''
    M = sum((a.mass for a in atoms))
    V = np.linalg.det(box)

    # convert amu to grams
    g_amu = 1.66053886e-24
    # convert A^3 to mL
    mL_A3 = 1e-24

    return M/V * (g_amu/mL_A3)

def main(target, input, output):
    r=molfile.mae.read(input)
    w=molfile.mae.write(output, r.atoms)
    frame = r.frames().next()
    topo=pf.Topology(r.topology)

    current = compute_density(r.atoms, frame.box)
    print "old density:", current
    ratio = current/target
    print "scaling by", ratio
    scale_volume( topo, frame, ratio)
    current = compute_density(r.atoms, frame.box)
    print "new density:", current
    w.frame(frame)
    w.close()

if __name__=="__main__":
    import sys
    input = sys.argv[1]
    target = float(sys.argv[2])
    output = sys.argv[3]

    main(target, input, output)

