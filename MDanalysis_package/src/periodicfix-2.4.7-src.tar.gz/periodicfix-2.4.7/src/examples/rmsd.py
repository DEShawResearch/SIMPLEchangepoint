
'''
compute backbone rmsd using vmd
'''

import sys
import vmd
import molecule, vmdnumpy
from atomsel import atomsel

id=molecule.load('dms', 'bace.dms')
molecule.read(id,'dcd', 'bace.dcd', waitfor=-1)

ref=atomsel('backbone', frame=0)
sel=atomsel('backbone')
all=atomsel()

for i in range(1,molecule.numframes(id)):
    sel.frame=i
    all.frame=i
    oldrms=sel.rmsd(ref)
    all.move(sel.fit(ref))
    newrms=sel.rmsd(ref)
    print "frame %4d oldrms %.8f newrms %.8f" % (i,oldrms, newrms)


# now use periodfix to do the alignment.  Use VMD's atom selection to 
# define weights using the backbone atoms
import molfile
import numpy as NP
import periodicfix as PF

dms=molfile.dms.read('bace.dms')
dcd=molfile.dcd.read('bace.dcd')

wts=NP.zeros(dms.natoms, dtype='float32')
bb=ref.get('index')
wts[bb]=1

fit=PF.Fit(dms.frame(0).pos, wts)
topo=PF.Topology(dms.topology)

w1=molfile.dcd.write('align.dcd', dms.atoms)
w2=molfile.dcd.write('align-wrap.dcd', dms.atoms)

print " ---- "
for i, f in enumerate(molfile.dcd.read('bace.dcd').frames()):
    oldrms=fit.rmsd(f.pos)
    topo.wrap_bonds(f.pos, f.box)
    fit.align(f.pos, f.box)
    newrms=fit.rmsd(f.pos)
    # notice that we pass fit.center to wrap frags; if we didn't do this,
    # wrap_frags might shift the position of the aligned atoms, which we
    # don't want to happen.
    topo.wrap_frags(f.pos, f.box, fit.center)
    newrms2=fit.rmsd(f.pos)
    assert newrms==newrms2

    print "frame %4d oldrms %.8f newrms %.8f" % (i,oldrms, newrms)

    w2.frame(f)


