#!/usr/bin/env desres-exec
#{
# exec desres-cleanenv \
# -m Python/2.7.1-06A/bin \
# -m numpy/1.5.1-29A/lib-python \
# -m msys/1.5.7/lib-python \
# -m periodicfix/2.3.14/lib-python \
# -m molfile/1.9.2/lib-python \
# -m vmd/1.9.0-42/all \
# -- python $0 "$@"
#}

import msys
import periodicfix as pf
import sys
import numpy

import os
os.environ['VMD_QUIET_STARTUP']='1'

path, selA, selB, cutoff = sys.argv[1:]
cutoff=float(cutoff)
mol=msys.Load(path)
top=pf.Topology(mol.topology)
A=numpy.array([a.id for a in mol.select(selA)], dtype=numpy.uint32)
if selB==selA:
    B=None
    print "self contacts among %s (%d)" % (selA,len(A))
else:
    B=numpy.array([a.id for a in mol.select(selB)], dtype=numpy.uint32)
    print "contacts between %s (%d) and %s (%d)" % (selA,len(A), selB, len(B))
pos=mol.positions
pairs=pf.find_contacts(cutoff, pos, A, B, top)
print "found %d pairs" % len(pairs)
if B is None:
    pairs = [sorted(x) for x in pairs]
else:
    pairs = [list(x) for x in pairs]
pairs.sort()
#print pairs

import vmd
print vmd
import molecule
from atomsel import atomsel
molecule.load('dms', path)
A=atomsel(selA)
B=atomsel(selB)
c=zip(*A.contacts(B, cutoff))
if selA==selB:
    c=[sorted(x) for x in c]
else:
    c=[list(x) for x in c]
c.sort()
print "vmd: %d pairs" % len(c)
#print c
assert pairs==c
print "OK"
