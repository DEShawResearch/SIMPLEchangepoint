
'''
compute backbone rmsd using vmd
'''

import sys
import vmd
import molecule, vmdnumpy
from atomsel import atomsel

id=molecule.load('dms', 'bace.dms')

ref=atomsel(sys.argv[1])
print "alignment on %d atoms" % len(ref)

# now use periodfix to do the alignment.  Use VMD's atom selection to 
# define weights using the backbone atoms
import molfile
import numpy as NP
import periodicfix as PF

dms=molfile.dms.read('bace.dms')
bb=ref.get('index')

# load the first few frames
r=molfile.dcd.read('bace.dcd')
frames=[]
for f in r.frames():
    frames.append(f.pos[bb])
n=len(frames)

rms=[]

from time import time
for i in xrange(1):
    fit=PF.Fit(frames[i])
    s=time()
    for j in xrange(i+1,n):
        pos=frames[j]
        fit.align(pos)
        rms.append(fit.rmsd(pos))

t=time()
print "ms:", 1000*(t-s)

r=molfile.dcd.read('bace.dcd')
frames=[]
for f in r.frames():
    frames.append(f.pos[bb])
n=len(frames)
rms2=[]

R=NP.eye(3, dtype='f')
#R=None
for i in xrange(1):
    fit=PF.Fit(frames[i])
    s=time()
    for j in xrange(i+1,n):
        pos=frames[j]
        fit.remove_center(pos)
        rms2.append(fit.aligned_rmsd(pos, precentered=True))
        #rms2.append(fit.aligned_rmsd(pos, rotation=R))
        #print R

t=time()
print "ms:", 1000*(t-s)

print "max difference:", max((a-b) for a,b in zip(rms, rms2))
