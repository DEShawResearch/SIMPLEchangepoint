/* 
Copyright 2012-2014, D. E. Shaw Research.
All rights reserved.

Redistribution and use in source and binary forms, with or without
modification, are permitted provided that the following conditions are
met:

* Redistributions of source code must retain the above copyright
  notice, this list of conditions, and the following disclaimer.

* Redistributions in binary form must reproduce the above copyright
  notice, this list of conditions, and the following disclaimer in the
  documentation and/or other materials provided with the distribution.

* Neither the name of D. E. Shaw Research nor the names of its
  contributors may be used to endorse or promote products derived from
  this software without specific prior written permission.

THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
"AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR
A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT
OWNER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,
SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT
LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE,
DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY
THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
(INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE
OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
*/

namespace desres { namespace periodicfix {

namespace details {
    /* return vector of length x giving number of increments 
     * to shift each coordinate in order to minimize the square distance
     * between them */
    static
    std::vector<int> find_optimal_shifts(std::vector<float> x) {
        const int n=x.size();
        std::vector<int> s(n);
        if (n<2) return s;
    
        /* bring all points to [-1/2, 1/2). */
        for (int i=0; i<n; i++) {
            while (x[i] < -0.5f) { x[i] += 1; s[i] += 1; }
            while (x[i] >= 0.5f) { x[i] -= 1; s[i] -= 1; }
        }
        /* We have v(1) = 1/2 sum(xi-xj)^2 = N * sum(xi^2) - sum(xi)^2, 
         * and v(k) = 1/2 sum(xi - xj + (i<k) - (j<k))^2.  The leftmost 
         * point should be the one corresponding to the smallest element 
         * in v.  We can compute v in linear time using a recurrence 
         * relation.  Total complexity O(n log n) for the sort.
         * Credit to R. Lippert for the algorithm. */
        std::vector<float> _x(x);
        std::vector<double> v(n);
        std::sort(_x.begin(), _x.end());
        double sum=0, sum2=0;
        for (int i=0; i<n; i++) {
            const float t=_x[i];
            sum += t;
            sum2 += t*t;
        }
        v[0] = n * sum2 - sum*sum;
        for (int i=0; i<n-1; i++) {
            v[i+1] = v[i] + n-1 - 2*(sum+i-n*_x[i]);
        }
        int k = std::min_element(v.begin(), v.end())-v.begin();
        const float left = _x[k];
        for (int i=0; i<n; i++) {
            if (x[i]<left) s[i] += 1;
        }
        return s;
    }

    struct AtomidVisitor {
        AtomidList& atomids;
        RangeList&  ranges;
        
        AtomidVisitor(AtomidList& a, RangeList& r) 
        : atomids(a), ranges(r) {
            atomids.clear();
            ranges.clear();
        }

        template <typename T>
        void visit_fragment(T const& begin, T const& end) const {
            unsigned first = atomids.size();
            for (T it=begin; it!=end; ++it) {
                atomids.push_back(*it);
            }
            unsigned last = atomids.size();
            ranges.push_back(std::make_pair(first,last));
        }
    };

    template <typename T>
    static void find_center(T const& begin, T const& end, 
                            const float* coords,
                            float* center) {
        int n = end-begin;
        float invn = n<1 ? 0 : 1.0/n;
        double c[3]={0,0,0};
        int i=0;
        for (T iter=begin; iter!=end; ++iter, ++i) {
            const float * pos = coords + 3*(*iter);
            c[0] += pos[0];
            c[1] += pos[1];
            c[2] += pos[2];
        }
        for (int i=0; i<3; i++) center[i] = c[i] * invn;
    }

}

FragmentWrapper::FragmentWrapper(Topology const& top) {
    details::AtomidVisitor v(_atomids, _ranges);
    top.traverse_frags(v);
}

unsigned
FragmentWrapper::aggregate(AtomidList const& atomids) {

    /* construct a new aggregate */
    Aggregate agg;

    /* Compute which fragments are affected by the aggregation */
    std::vector<unsigned> clique;
    for (unsigned i=0; i<_ranges.size(); i++) {
        unsigned begin = _ranges[i].first;
        unsigned end   = _ranges[i].second;
        if (begin==end) continue;
        unsigned first = agg.atoms.size();

        /* keep track of atoms which are part of the fragment but not used
         * in centering.  We'll put those at the end.  */
        std::vector<unsigned> tmp;
        tmp.reserve(end-begin);

        /* add atoms from this fragment to the aggregate if they overlap,
         * and to tmp if they don't. */
        for (unsigned j=begin; j!=end; j++) {
            unsigned atm = _atomids[j];
            if (std::binary_search(atomids.begin(), atomids.end(), atm)) {
                agg.atoms.push_back(atm);
            }  else {
                tmp.push_back(atm);
            }
        }
        /* if agg.atoms grew, we found some overlap */
        unsigned size = agg.atoms.size()-first;
        if (!size) continue;
        /* stash the number of atoms used for centering */
        agg.sizes.push_back(size);
        /* append the non-centering atoms which are part of the fragment */
        agg.atoms.insert(agg.atoms.end(), tmp.begin(), tmp.end());
        /* keep track the of the size of the whole fragment */
        agg.frags.push_back(std::make_pair(first, agg.atoms.size()));
        /* note which fragments were used by the aggregate */
        clique.push_back(i);
    }

    /* if we didn't get more than two non-empty fragments, nothing to do. */
    unsigned nfrags = agg.frags.size();
    if (nfrags<2) return nfrags;
    _aggregates.push_back(agg);

    /* move the atoms from fragments 1, 2, ... into fragment 0 of the clique.
     * easiest to just copy into a new array rather than do surgery on the
     * existing array and have to worry about the order of the atom ranges */
    AtomidList newatoms(_atomids.size());
    unsigned start=0;
    unsigned size=0;
    for (unsigned i=0; i<_ranges.size(); i++) {
        if (i==clique[0]) {
            /* copy all atoms in clique to this clique */
            size=0;
            for (unsigned j=0; j<clique.size(); j++) {
                AtomidList::const_iterator begin, end;
                begin = _atomids.begin()+_ranges[clique[j]].first;
                end   = _atomids.begin()+_ranges[clique[j]].second;
                std::copy(begin, end, newatoms.begin()+start+size);
                size += end-begin;
            }

        } else if (std::find(clique.begin()+1, clique.end(), i)!=clique.end()) {
            /* set the range to empty */
            size = 0;

        } else {
            /* copy range not in clique */
            AtomidList::const_iterator begin, end;
            begin = _atomids.begin()+_ranges[i].first;
            end   = _atomids.begin()+_ranges[i].second;
            size  = end-begin;
            std::copy(begin, end, newatoms.begin()+start);
        }
        _ranges[i].first  = start;
        _ranges[i].second = start+size;
        start += size;
    }
    _atomids = newatoms;
    return nfrags;
}

AtomidList 
FragmentWrapper::sameFragmentAs(AtomidList const& atoms) const {
    AtomidList ids;
    for (unsigned i=0; i<_ranges.size(); i++) {
        AtomidList::const_iterator begin = _atomids.begin()+_ranges[i].first;
        AtomidList::const_iterator end   = _atomids.begin()+_ranges[i].second;
        for (AtomidList::const_iterator it=begin; it!=end; ++it) {
            if (std::binary_search(atoms.begin(), atoms.end(), *it)) {
                ids.insert(ids.end(), begin, end);
                break;
            }
        }
    }
    std::sort(ids.begin(), ids.end());
    return ids;
}

FragmentWrapper FragmentWrapper::clone(AtomidList const& atoms) const {
    FragmentWrapper w;

    /* construct mapping from current system to new system, checking
     * for valid input along the way */
    static const unsigned BadId(-1);
    AtomidList map(_atomids.size(), BadId);
    for (unsigned i=0; i<atoms.size(); i++) {
        if (i && atoms[i]<=atoms[i-1]) {
            throw std::runtime_error("FragmentWrapper::clone(): atoms must be sorted and distinct");
        }
        map.at(atoms[i])=i;
    }

    /* clone the aggregates that have at least one mapped fragment */
    BOOST_FOREACH(Aggregate const& agg, _aggregates) {
        Aggregate newagg;
        for (unsigned i=0; i<agg.frags.size(); i++) {
            /* determine if any atoms of this fragment intersect the input 
             * set, and how many of those are from the centering selection. */
            unsigned first = newagg.atoms.size();
            unsigned mapped_centers=0;
            unsigned begin = agg.frags[i].first;
            unsigned end   = agg.frags[i].second;
            unsigned ntot  = end-begin;
            unsigned ncent = agg.sizes[i];
            for (unsigned j=0; j<ncent; j++) {
                unsigned src = agg.atoms[j+begin];
                unsigned dst = map.at(src);
                if (dst!=BadId) {
                    newagg.atoms.push_back(dst);
                    ++mapped_centers;
                }
            }
            /* map the rest of the atoms */
            for (unsigned j=ncent; j<ntot; j++) {
                unsigned src = agg.atoms[j+begin];
                unsigned dst = map.at(src);
                if (dst!=BadId) {
                    newagg.atoms.push_back(dst);
                }
            }
            unsigned last = newagg.atoms.size();
            if (first==last) continue; // nothing mapped
            if (mapped_centers!=ncent) {
                throw std::runtime_error("FragmentWrapper::clone - input set does not include all of the joined atoms in an fragment that it intersects");
            }
            newagg.frags.push_back(std::make_pair(first,last));
            newagg.sizes.push_back(ncent);
        }
        if (newagg.frags.size()>1) {
            w._aggregates.push_back(newagg);
        }
    }

    /* clone the non-empty fragments */
    for (unsigned i=0; i<_ranges.size(); i++) {
        AtomidList::const_iterator it  = _atomids.begin()+_ranges[i].first;
        AtomidList::const_iterator end = _atomids.begin()+_ranges[i].second;
        if (it==end) continue;
        unsigned first = w._atomids.size();
        for (; it!=end; ++it) {
            unsigned src = *it;
            unsigned dst = map.at(src);
            if (dst!=BadId) {
                w._atomids.push_back(dst);
            }
        }
        unsigned last = w._atomids.size();
        if (first!=last) w._ranges.push_back(std::make_pair(first,last));
    }
    return w;
}

void 
FragmentWrapper::Aggregate::join(UnitCell const& cell,
                                 float * pos) const {

    const unsigned n = frags.size();

    /* compute the center of of each fragment */
    std::vector<float> centers(3*n);
    for (unsigned i=0; i<n; i++) {
        details::find_center(atoms.begin()+frags[i].first,
                             atoms.begin()+frags[i].first+sizes[i],
                             pos, &centers[3*i]);
    }
    if (cell.triclinic()) {
        throw std::runtime_error("join not implemented for triclinic");
    } else {
        /* optimize a, b, c shift independently */
        float box[9];
        cell.as_matrix(box);
        for (int dir=0; dir<3; dir++) {
            /* obtain unit cell vector */
            const float* vec = box+3*dir;
            double len2 = details::dotprod(vec,vec);
            if (len2==0) continue;
            /* compute projection of centers along this vector */
            std::vector<float> x(n);
            for (unsigned i=0; i<n; i++) {
                x[i] = details::dotprod(&centers[3*i], vec) / len2;
            }
            std::vector<int> s = details::find_optimal_shifts(x);

            /* apply the shifts to the fragments */
            for (unsigned i=0; i<n; i++) {
                unsigned begin = frags[i].first;
                unsigned end   = frags[i].second;
                for (unsigned j=begin; j!=end; j++) {
                    int id = atoms.at(j);
                    pos[3*id  ] += vec[0]*s[i];
                    pos[3*id+1] += vec[1]*s[i];
                    pos[3*id+2] += vec[2]*s[i];
                }
            }
        }
    }
}

void 
FragmentWrapper::wrap( UnitCell const& cell,
                       float         * pos,
                       const float   * center) const {

    for (unsigned i=0; i<_ranges.size(); i++) {
        AtomidList::const_iterator it  = _atomids.begin()+_ranges[i].first;
        AtomidList::const_iterator end = _atomids.begin()+_ranges[i].second;
        if (it==end) continue;
        float c[3];
        details::find_center(it, end, pos, c);
        if (center) for (int j=0; j<3; j++) c[j] -= center[j];
        cell.wrap_point( c,c );
        for (; it!=end; ++it) {
            float * xyz = pos + 3*(*it);
            xyz[0] += c[0];
            xyz[1] += c[1];
            xyz[2] += c[2];
        }
    }
}

}}

