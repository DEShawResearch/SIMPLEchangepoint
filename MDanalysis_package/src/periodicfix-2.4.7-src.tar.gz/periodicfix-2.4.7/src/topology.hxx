/* 
Copyright 2012-2014, D. E. Shaw Research.
All rights reserved.

Redistribution and use in source and binary forms, with or without
modification, are permitted provided that the following conditions are
met:

* Redistributions of source code must retain the above copyright
  notice, this list of conditions, and the following disclaimer.

* Redistributions in binary form must reproduce the above copyright
  notice, this list of conditions, and the following disclaimer in the
  documentation and/or other materials provided with the distribution.

* Neither the name of D. E. Shaw Research nor the names of its
  contributors may be used to endorse or promote products derived from
  this software without specific prior written permission.

THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
"AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR
A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT
OWNER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,
SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT
LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE,
DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY
THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
(INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE
OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
*/
#ifndef desres_periodicfix_topology_hxx
#define desres_periodicfix_topology_hxx

#include <vector>
#include <stack>
#include <algorithm>
#include <sstream>
#include <stdexcept>

namespace desres { namespace periodicfix {

    class Topology {
    public:
        typedef std::vector<int> BondList;
        typedef std::vector<BondList> AtomList;

    private:
        /* adjacency list */
        AtomList atoms;

    public:
        /* default constructor for use with load() */
        Topology() {}

        /* initialize with number of atoms */
        explicit Topology( int natoms ) : atoms(natoms) {}

        /* the underlying redundant neighbor list */
        AtomList const& neighbors() const { return atoms; }

        /* number of atoms in the topology */
        int size() const { return atoms.size(); }

        /* add a bond between atoms.  std::runtime_error will be thrown
         * unless ai!=aj, ai>=0, aj>=0, ai<natoms, and aj<natoms.  
         * Returns true if the bond already existed, false if not.
         * In either case, the bond is added.  */
        bool add_bond( int ai, int aj ) {
            if (ai==aj || ai<0 || aj<0 || ai>=size() || aj>=size()) {
                std::stringstream ss;
                ss << "Invalid bond (" << ai << ") -- (" << aj 
                   << ") for topology with " << size() << " atoms.";
                throw std::runtime_error(ss.str());
            }
            BondList& bi = atoms[ai];
            BondList& bj = atoms[aj];
            if (std::find(bi.begin(), bi.end(), aj)!=bi.end()) return true;
            bi.push_back(aj);
            bj.push_back(ai);
            return false;
        }

        /* Return a new Topology remapped to a subset of the original
         * set of atoms.  The iterators begin,end should bound a set of
         * atoms which are distinct and sorted. */
        template <typename Iter>
        Topology clone(Iter begin, Iter end) const {
            Topology top(end-begin);
            int i,n = size();
            for (i=0; i<n; i++) {
                Iter it = std::lower_bound(begin,end,i);
                if (it==end) continue;
                int j = it-begin;
                unsigned k,m = atoms[i].size();
                for (k=0; k<m; k++) {
                    Iter it = std::lower_bound(begin,end,atoms[i][k]);
                    if (it==end) continue;
                    top.atoms[j].push_back(it-begin);
                }
            }
            return top;
        }


        /* serialization to Writer::operator()(const void* buf, size_t sz) */
        template <typename Writer>
        void dump(Writer& a) const {
            unsigned natoms=atoms.size();
            a(&natoms, sizeof(natoms));
            for (unsigned i=0; i<natoms; i++) {
                unsigned nbonds=atoms[i].size();
                a(&nbonds, sizeof(nbonds));
                if (nbonds) a(&atoms[i][0], nbonds * sizeof(atoms[i][0])); 
            }
        }

        /* deserialization to Reader::operator()(void* buf, size_t sz) */
        template <typename Reader>
        void load(Reader& a) {
            unsigned natoms=0;
            a(&natoms, sizeof(natoms));
            atoms.resize(natoms);
            for (unsigned i=0; i<natoms; i++) {
                unsigned nbonds=0;
                a(&nbonds, sizeof(nbonds));
                atoms[i].resize(nbonds);
                if (nbonds) a(&atoms[i][0], nbonds * sizeof(atoms[i][0]));
            }
        }

        /* visit all bonds in topologically sorted order.  */
        template <typename Visitor>
        void traverse_bonds( const Visitor& v ) const {
            int i,n = size();
            std::stack<BondList::value_type> S;
            std::vector<bool> flags(n);

            for (i=0; i<n; i++) {
                S.push(i);
                while (S.size()) {
                    int ind=S.top();
                    S.pop();
                    if (flags[ind]) continue;
                    const BondList& bonds = atoms[ind];
                    BondList::const_iterator j;
                    for (j=bonds.begin(); j!=bonds.end(); ++j) {
                        if (!flags[*j]) {
                            v.visit_bond( ind, *j );
                        }
                        S.push(*j);
                    }
                    flags[ind]=1;
                }
            }
        }
        /* visit all fragments */
        template <typename Visitor>
        void traverse_frags( const Visitor& v ) const {
            int i,n = size();
            std::stack<BondList::value_type> S;
            std::vector<bool> flags(n);

            for (i=0; i<n; i++) {
                S.push(i);
                std::vector<int> atomlist;
                while (S.size()) {
                    int ind=S.top();
                    S.pop();
                    if (flags[ind]) continue;
                    atomlist.push_back(ind);
                    const BondList& bonds = atoms[ind];
                    BondList::const_iterator j;
                    for (j=bonds.begin(); j!=bonds.end(); ++j) {
                        S.push(*j);
                    }
                    flags[ind]=1;
                }
                if (atomlist.size()) {
                    v.visit_fragment(atomlist.begin(), atomlist.end());
                }
            }
        }
    };

}} /* namespace */

#endif
