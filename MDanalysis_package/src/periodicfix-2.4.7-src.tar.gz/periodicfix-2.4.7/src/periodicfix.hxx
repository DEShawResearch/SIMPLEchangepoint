/* 
Copyright 2012-2014, D. E. Shaw Research.
All rights reserved.

Redistribution and use in source and binary forms, with or without
modification, are permitted provided that the following conditions are
met:

* Redistributions of source code must retain the above copyright
  notice, this list of conditions, and the following disclaimer.

* Redistributions in binary form must reproduce the above copyright
  notice, this list of conditions, and the following disclaimer in the
  documentation and/or other materials provided with the distribution.

* Neither the name of D. E. Shaw Research nor the names of its
  contributors may be used to endorse or promote products derived from
  this software without specific prior written permission.

THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
"AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR
A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT
OWNER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,
SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT
LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE,
DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY
THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
(INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE
OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
*/
#ifndef desres_periodicfix_periodicfix_hxx
#define desres_periodicfix_periodicfix_hxx

#include "unitcell.hxx"
#include <stdexcept>
#include <sstream>
#include <cstdio>

namespace desres { namespace periodicfix {

    template <typename Float>
    class Wrapper {
        const int n;
        Float * coords;
        const UnitCell& cell;
        const Float * center;

    public:
        Wrapper( int _n, Float * _coords, const UnitCell& _cell,
                 const Float * _center = NULL )
        : n(_n), coords(_coords), cell(_cell), center(_center) {}

        /* implement the interface expected by Topology::traverse */
        void visit_bond( int ai, int aj ) const {
            const Float * ref = coords + 3*ai;
            Float *       pos = coords + 3*aj;
            Float delta[3] = {pos[0]-ref[0], pos[1]-ref[1], pos[2]-ref[2]};
            cell.wrap_vector(delta,delta);
            pos[0] += delta[0];
            pos[1] += delta[1];
            pos[2] += delta[2];
        }
        template <typename T>
        void visit_fragment( const T& begin, const T& end ) const {
            int n = end-begin;
            Float invn = 1.0/n;
            T iter;
            Float c[3]={0,0,0};
            for (iter=begin; iter!=end; ++iter) {
                const Float * pos = coords + 3*(*iter);
                c[0] += pos[0];
                c[1] += pos[1];
                c[2] += pos[2];
            }
            c[0] *= invn; c[1] *= invn; c[2] *= invn;
            if (center) for (int i=0; i<3; i++) c[i] -= center[i];
            cell.wrap_point( c,c );
            for (iter=begin; iter!=end; ++iter) {
                Float * pos = coords + 3*(*iter);
                pos[0] += c[0];
                pos[1] += c[1];
                pos[2] += c[2];
            }
        }
    };

    // attempt to undo periodic wrapping of a trajectory.
    // Caveat emptor: don't compute pair correlations or other 
    // structural quantities after applying this operation!
    template <typename Float>
    class UnWrapper {
        const int n;
        const Float * coords;
        const Float * prev;
        double * shifts;
        double fx, fy, fz; // scale factors for current frame
        double px, py, pz; // scale factors for previous frame
        const UnitCell& refcell;

    public:
        UnWrapper( int _n, 
                   const Float * _coords,     /* current frame */
                   const Float * _prev,       /* previous frame */
                   double * _shifts,
                   const UnitCell& cell,      /* current unit cell */
                   const UnitCell& prevcell,  /* previous unit cell */
                   const UnitCell& _refcell ) /* cell used for wrapping */
        : n(_n), coords(_coords), prev(_prev), shifts(_shifts), 
            refcell(_refcell) {

            /* we don't even try to handle triclinics */
            if (cell.triclinic() || 
                prevcell.triclinic() || 
                refcell.triclinic()) {
                throw std::runtime_error("Unwrap not implemented for triclinic cells");
            }

            /* compute scale factors relative to reference cell */
            double a=refcell.a();
            double b=refcell.b();
            double c=refcell.c();
            fx=cell.a() ? a/cell.a() : 0;
            fy=cell.b() ? b/cell.b() : 0;
            fz=cell.c() ? c/cell.c() : 0;
            px=prevcell.a() ? a/prevcell.a() : 0;
            py=prevcell.b() ? b/prevcell.b() : 0;
            pz=prevcell.c() ? c/prevcell.c() : 0;
        }

        template <typename T>
        void visit_fragment( const T& begin, const T& end ) const {
            int n = end-begin;
            Float invn = 1.0/n;
            T iter;
            /* compute center of molecule */
            double c[3]={0,0,0};
            double d[3]={0,0,0};
            for (iter=begin; iter!=end; ++iter) {
                const Float * pos = coords + 3*(*iter);
                c[0] += pos[0];
                c[1] += pos[1];
                c[2] += pos[2];
                pos = prev + 3*(*iter);
                d[0] += pos[0];
                d[1] += pos[1];
                d[2] += pos[2];
            }
            /* scale center to bring it into the reference cell */
            c[0] *= invn*fx; c[1] *= invn*fy; c[2] *= invn*fz;
            d[0] *= invn*px; d[1] *= invn*py; d[2] *= invn*pz;

            /* compute minimum image */
            Float s[3]={0,0,0};
            for (int i=0; i<3; i++) s[i] += c[i]-d[i];
            refcell.wrap_point( s,s );

            /* apply shift to the molecule */
            for (iter=begin; iter!=end; ++iter) {
                double * pos = shifts + 3*(*iter);
                pos[0] += s[0];
                pos[1] += s[1];
                pos[2] += s[2];
            }
        }
    };


    template <typename Float>
    class WrapChecker {
        const int n;
        Float * coords;
        const UnitCell& cell;

    public:
        struct UnwrappedBondException : std::runtime_error {
            UnwrappedBondException(const std::string& s) 
            : std::runtime_error(s.c_str()) {}
        };
        struct UnwrappedFragmentException : std::runtime_error {
            UnwrappedFragmentException(const std::string& s) 
            : std::runtime_error(s.c_str()) {}
        };
            
        WrapChecker( int _n, Float * _coords, const UnitCell& _cell )
        : n(_n), coords(_coords), cell(_cell) {}

        /* implement the interface expected by Topology::traverse */
        void visit_bond( int ai, int aj ) const {
            const Float * ref = coords + 3*ai;
            Float *       pos = coords + 3*aj;
            Float delta[3] = {pos[0]-ref[0], pos[1]-ref[1], pos[2]-ref[2]};
            cell.wrap_vector(delta, delta);
            if (delta[0] || delta[1] || delta[2]) {
                std::stringstream ss;
                ss << "Unwrapped bond: " << ai << " - " << aj << std::endl;
                throw UnwrappedBondException(ss.str());
            }
        }
        template <typename T>
        void visit_fragment( const T& begin, const T& end ) const {
            int n = end-begin;
            Float invn = 1.0/n;
            T iter;
            Float c[3]={0,0,0};
            for (iter=begin; iter!=end; ++iter) {
                const Float * pos = coords + 3*(*iter);
                c[0] += pos[0];
                c[1] += pos[1];
                c[2] += pos[2];
            }
            c[0] *= invn; c[1] *= invn; c[2] *= invn;
            cell.wrap_point( c,c );
            if (c[0] || c[1] || c[2]) {
                std::stringstream ss;
                ss << "Unwrapped fragment containing atom " << *begin 
                   << std::endl;
                throw UnwrappedFragmentException(ss.str());
            }
        }
    };

}} /* namespaces */

#endif
