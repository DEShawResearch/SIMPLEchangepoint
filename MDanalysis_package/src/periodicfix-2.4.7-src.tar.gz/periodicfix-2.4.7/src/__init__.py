''' 
Adjust atom coordinates for structures with periodic boundary conditions.

The periodicfix module provides methods for adjusting atom coordinates
so that bonds between atoms do not cross periodic boundaries, and so
that connected sets of atoms are as close as possible to the origin of
the global cell.  It also provides an RMS alignment facility, since RMS
alignment of structures in a periodic box requires special considerations
not likely to be found in general RMS alignment package.

** Synopsis

import periodicfix as PF
import numpy as NP

# Load a dms file
r = molfile.dms.read('input.dms')

# Use the coordinates for atoms 1-300 in the dms file as a reference frame 
# for fitting.  We do this by providing weights that are nonzero only for
# the selected atoms.
wts=NP.zeros(r.natoms, dtype=NP.float32)
wts[:300]=1
fit = PF.Fit(r.frame[0].pos, weights=wts)

# create Topology from the reader
topo = PF.Topology(r.topology)

# Add glue to keep molecules together
topo.add_bond(32,52)

# For each frame in a molfile frame:
for frame in molfile.dtr.read('input.dtr').frames():

    # Fix the bonds and apply glue
    topo.wrap_bonds( frame.pos, frame.box )

    # Align the frame to the reference
    fit.align( frame.pos, frame.box, frame.vel )

    # Rewrap - note that the rotated periodic cell is used and we wrap about
    # the center of the reference structure
    topo.wrap_frags( frame.pos, frame.box, fit.center )

    # compute the weighted rmsd
    print "time %8.3f rmsd %8.3f" % (frame.time, fit.rmsd(frame.pos))

# Suppose you don't care about periodic wrapping, and you just want the
# RMSD for the aligned structures as fast as possible.  Here's the recipe:

# fit on the first 300 atoms - could also use an atom selection.  Slicing
# the positions is faster than using weights.
ref=PF.Fit(r.frame[0].pos[:300]

for frame in molfile.dtr.read('input.dtr').frames():
    rmsd = ref.aligned_rmsd(frame.pos[:300])


** Module components:

Topology:
    Constructor: takes number of atoms, or a sequence of 0-based
    adjacencies.

    add_bond( a1, a2 ): add a bond between atom indices a1 and a2.

    size(): number of atoms in the topology.

    wrap_bonds(pos, cell): adjust positions in pos such that no bond
      is longer than half a box dimension.  pos must be an Nx3 Numpy
      float32, cell must be a 3x3 Numpy float32 with shift vectors in
      the _rows_.

    wrap_frags(pos, cell, center=None): adjust positions in pos such
      that each molecule (connected set of atoms) is as close as possible
      to the center, which defaults to the origin.  pos must be an Nx3
      Numpy float32, cell must be a 3x3 Numpy float32 with shift vectors
      in the _rows_.

    visit_bonds(visitor): for each bond (ai, aj), calls visitor(ai,aj).

    visit_frags(visitor): for each fragment (connected set of atoms),
      calls visitor(t) where t is a tuple containing the indexes of the atoms
      in the fragment.

Fit:
    Constructor: takes target positions, and optional weights and center.
      positions must be Nx3 Numpy float32, and will be copied.  Weights,
      if given, must be Nx1 Numpy float32 and is also copied; default
      is to use identical weights for all atoms.  center, if given,
      is the shift to apply to coordinates after aligning them to the
      centered target coordinates; default is the weighted center of
      the target coordinates.

    center: center of aligned coordinates.

    align(pos, cell=None, vel=None, movepos=None): Aligns pos
    to target.  If cell is provided, it is _rotated_ by the rotation
    applied to bring pos onto target.   If vel is provided, it must be
    a Nx3 Numpy float32 array; it will likewise be transformed by the
    computed rotation.  If movepos is supplied, it must be an Nx3 Numpy
    float32 array; the transformation required to superpose pos onto
    target will instead be applied to movepos.

    rmsd(pos): returns weighted rmsd to reference structure.


convert_cell(a,b,c,alpha=90,beta=90,gamma=90):
    returns a 3x3 Numpy float32 array computed from the given cell lengths
    and angles.  alpha is the angle between vectors b and c, beta the
    angle between vectors c and a, and gamma the angle between a and b.

compute_alignment(ref, pos, wts):
    Computes the rotation matrix required to superpose pos onto ref with
    given weights.  ref and pos are assumed to already be centered on
    the origin.

'''

from _periodicfix import *
Topology.__getinitargs__ = lambda self: (self.dump(),)

FragmentWrapper.__getstate__ = lambda self: (self.dump(),)
FragmentWrapper.__setstate__ = lambda self, state: self.load(state[0])

