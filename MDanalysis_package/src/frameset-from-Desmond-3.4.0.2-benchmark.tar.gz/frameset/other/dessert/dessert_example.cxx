/* 
Copyright 2012-2014, D. E. Shaw Research.
All rights reserved.

Redistribution and use in source and binary forms, with or without
modification, are permitted provided that the following conditions are
met:

* Redistributions of source code must retain the above copyright
  notice, this list of conditions, and the following disclaimer.

* Redistributions in binary form must reproduce the above copyright
  notice, this list of conditions, and the following disclaimer in the
  documentation and/or other materials provided with the distribution.

* Neither the name of D. E. Shaw Research nor the names of its
  contributors may be used to endorse or promote products derived from
  this software without specific prior written permission.

THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
"AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR
A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT
OWNER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,
SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT
LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE,
DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY
THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
(INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE
OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
*/

#include "dessert/dessert.hpp"
#include "badbehavior.hpp"

#include <cstdio>
#include <iostream>
#include <csignal>
#include <cstdlib>

using namespace std;
using namespace desres;

int main() {
  printf("Welcome to the test program.  Please choose your fate:\n");
  // Just because you can write your own handlers doesn't mean
  // you should.  If you really want to, crib as much code as you
  // can from dessert_terminate_with_output_sighandler.
  signal(SIGINT, dessert_terminate_with_output_sighandler);
  signal(SIGSEGV, dessert_terminate_with_output_sighandler);
  for(;;) {
    printf("0) normal exit\n"
           "1) throw an exception in c++ and don't catch it\n"
           "2) throw an exception in c (and catch it)\n"
           "3) throw an exception in c++ (and catch it)\n"
           "4) infinite loop\n"
           "5) throw from a shared library\n"
           "6) segfault in a shared library\n"
           );
    int opt=0;
    scanf("%d",&opt);
    if (!opt) exit(0);
    if (opt==1) {
      throw_cpp_exception(); // and don't catch
    }
    try {
      switch(opt) {
      case 6: solib_segv(); break;
      case 5: solib_cpp_exception(); break;
      case 4: infinite_loop(); break;
      case 2: throw_c_exception(); break;
      case 3: throw_cpp_exception(); break;
      default: ;
      }
    }
    catch (dessert &e) {
      cerr << "e.what(): " << e.what() << endl;
      cerr << "e.what(false): " << e.what(false) << endl;
    }
  }
}
