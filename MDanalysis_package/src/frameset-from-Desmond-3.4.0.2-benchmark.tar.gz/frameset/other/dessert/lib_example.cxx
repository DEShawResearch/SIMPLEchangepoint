/* 
Copyright 2012-2014, D. E. Shaw Research.
All rights reserved.

Redistribution and use in source and binary forms, with or without
modification, are permitted provided that the following conditions are
met:

* Redistributions of source code must retain the above copyright
  notice, this list of conditions, and the following disclaimer.

* Redistributions in binary form must reproduce the above copyright
  notice, this list of conditions, and the following disclaimer in the
  documentation and/or other materials provided with the distribution.

* Neither the name of D. E. Shaw Research nor the names of its
  contributors may be used to endorse or promote products derived from
  this software without specific prior written permission.

THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
"AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR
A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT
OWNER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,
SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT
LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE,
DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY
THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
(INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE
OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
*/

#include "dessert/dessert.hpp"
#include <csignal>
#include <cstdio>
using namespace desres;

#ifdef DESRES_OS_Windows
#define snprintf _snprintf
#endif

extern "C" void cfunc();

void solib_c_exception(int n=10) {
  try {
    if (n<0)   cfunc();
    solib_c_exception(n-1);
  } catch (dessert &e) {
    // Sigh.  In actual code, you'd use stringprintf or
    // maybe staticprintf:
    //e.rethrow(stringprintf("n=%d", n));
    // But in this *particular* library, because we are trying
    // so hard not to bring any extra libraries into the prereq
    // list, we do something much more half-assed:
    char msg[128];
    snprintf(msg, sizeof(msg), "n=%d", n);
    e.rethrow(msg);
  }
}

void solib_cpp_exception(int n=10) {
  try {
    if (n<0){
      throw dessert("c++ thrower:  cpp exception", DESSERT_LOC);
    }
    solib_cpp_exception(n-1);
  } catch (dessert &e) {
    // See comment above...
    char msg[128];
    snprintf(msg, sizeof(msg), "n=%d", n);
    e.rethrow(msg);
  }
}

// Without this, the compiler is too smart and figures out that it
// doesn't have to create any stack frames for the recursive
// invocation of solib_segv.  By dereferencing it, it is also a
// convenient way to generate a bona fide, protection-violating segv.
// raise(SIGSEGV) ought to have the same effect, but we're operating
// well outside the envelope of standard-specified, well-documented
// behavior here.
int *kill_tail_recursion = 0;

void solib_segv(int n=10){
  if( n<0 ){
    printf("you should never see this.  We should segfault first: %d\n",
           *kill_tail_recursion);
    return;
  }
  solib_segv(n-1);
  ++kill_tail_recursion;
}
