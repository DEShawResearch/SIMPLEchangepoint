/* 
Copyright 2012-2014, D. E. Shaw Research.
All rights reserved.

Redistribution and use in source and binary forms, with or without
modification, are permitted provided that the following conditions are
met:

* Redistributions of source code must retain the above copyright
  notice, this list of conditions, and the following disclaimer.

* Redistributions in binary form must reproduce the above copyright
  notice, this list of conditions, and the following disclaimer in the
  documentation and/or other materials provided with the distribution.

* Neither the name of D. E. Shaw Research nor the names of its
  contributors may be used to endorse or promote products derived from
  this software without specific prior written permission.

THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
"AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR
A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT
OWNER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,
SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT
LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE,
DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY
THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
(INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE
OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
*/

#include "dessert.hpp"
#include "bt.h"
#include <sstream>
#include <cstdio>
#include <cstring>
#include <csignal>
#include <cerrno>
#include <cstdlib>
#include <exception>
#include <typeinfo>
#ifdef DESRES_OS_Windows
#include <io.h>
#define HAS_NO_SIGNALS
#else
#include <unistd.h>
#endif

#if defined(DESRES_NO_THREADS)
// pass
#elif defined(DESRES_BOOST_THREADS)
#include <boost/thread/mutex.hpp>
#else
#include <pthread.h>
#endif

#include <fcntl.h>

#ifdef __GLIBC__
#include <execinfo.h>
#endif
#if _GLIBCXX_HOSTED
#include <cxxabi.h>
#endif

using namespace std;
using namespace desres;

// Handlers for C++ termination and signals that write a backtrace
// using the dessert machinery.

// It is incredibly easy to let signal handling turn into an endless
// series of patches and hacks.  The "What ifs" are endless and
// fascinating in a sick kind of way ("what if abort doesn't work
// because the MPI library has subverted it?"  "What if the stack is
// corrupt and I can't return to my caller?")

// DON'T BE SUCKED IN.  BEFORE ADDING MORE COMPLEXITY TO THIS CODE,
// ASK YOURSELF WHETHER IT WOULD BE EASIER AND MORE INFORMATIVE TO
// JUST SAY:
//
//  #define THROW_FAILURE(s) abort()
//
// in Failure.hxx.  

// I.e., Get a core dump and use a debugger to figure out what's going
// on.  This code already handles the simple cases.  If something
// confuses, confounds, subverts or transcends it, you're probably not
// going to figure out what's happening without a core file, and you
// probably want it sooner (at the point the problem was detected)
// rather than later (after some number of signal handlers have been
// invoked, elf-reading libraries have pored over your executable, etc.)

// N.B.  All signal names are specified by POSIX.  If they don't "port",
// some day, we'll add #ifdefs as needed.

namespace {
  struct default_formatter : desres::dessert::formatter {
    ostringstream oss;

    void begin() { oss.str(""); }

    void exception_class(const std::string &ec) {
      oss << "Exception: " << ec << "\nContext:\n";
    }

    virtual void add_context(const std::string &what,
                             const std::string &file,
                             unsigned lineno,
                             const std::string &func) {
      oss << what;
      if( lineno != 0 || !func.empty() || !file.empty() )
        oss << " @" << file << ":" <<  lineno << " in " << func;
      oss << "\n";
    }
    void begin_backtrace() {
      oss << "Backtrace:\n";
    }
    virtual void add_backtrace(const char *srcfile,
                               unsigned lineno,
                               const char *func,
                               const char *objfile,
                               unsigned offset,
                               const char *symb,
                               void * frame) {
      oss << srcfile << ":" << lineno << " " << func
          << "+" << offset << " objfile:" << objfile
          << " [" << frame << "]\n";
      // The consensus (John, Chuck, Ross) on Jun 14 2007 was not to print
      // the unmangled symbol by default.  Here it is in case we change our mind.
      //oss << srcfile << ":" << lineno << " " << dem << "+" << offset << " objfile:" << objfile << " [" << frame << "] " << symb << "\n";
    }

    std::string end() { return oss.str(); }
  };
}

namespace desres{

void dessert::cxx_terminate_handler(){
  // Don't get into a loop.
  // NOTE - If a second thread
  // calls cxx_terminate_handler, it thinks its being
  // called recursively.  It turns around and calls
  // terminate_with_output, which is partially protected by
  // a mutex.  See the comment in terminate_with_output.
  static int recursive;

  if(dessert::abort_in_constructor)
    dessert_abandon_all_hope(0);

  switch(recursive++){
  case 0:
    break;
  case 1:
    dessert::terminate_with_output(dessert("\nC++ TERMINATION HANDLER called recursively"), -1, true); // with core dump and glibc backtrace
    return;
  default:
    dessert_abandon_all_hope(0);
    return;
  }
  
  // With the __GNUC__ runtime, if we get here because of an uncaught
  // exception, throw; will rethrow it for us, allowing us to catch and
  // examine it.  As far as I can tell, this behavior is not
  // guaranteed by the standard.  Other systems may not think that
  // there's a current outstanding exception, and hence may call
  // terminate() (recursively!) as a result of this throw.  We
  // catch that above.
  string msg;
  try{ throw; }
  catch(desres::dessert &d){
    // We've already got a dessert with a backtrace.
    // Print it and terminate
    desres::dessert::terminate_with_output(d, -1, true);
  }catch(std::exception &e){
    // We're looking at some other kind of exception.
    // Let's manufacture a message, which  we'll put
    // in a dessert, which will give us a backtrace
    // to where we are now.
    string ename = dessert::demangle(typeid(e).name());
    // Avoid the temptation to use stringprintf.
    // see the comment in dessert_terminate_with_output_sighandler.
    msg = "\nIn C++ termination handler due to uncaught exception of type " 
        + ename +
        "\nwhat: " + e.what();
  }catch(...){
    // We have no idea what we're looking at, but
    // it's not a std::exception.  Say so and move
    // on...
    msg = "\nIn C++ termination handler due to uncaught exception of unknown type (not matching std::exception)";
  }
  // A core dump can be helpful if we get into the termination handler,
  // so set exstatus to -1.
  desres::dessert::terminate_with_output(dessert(msg), -1, true);
}

// public static data members of dessert:
bool dessert::abort_in_constructor=false;
#ifdef __GLIBC__
bool dessert::glibc_backtrace_never=false;
#endif

std::string& dessert::output_filename(){
    // This is no longer necessary.  It was briefly the case
    // that static destructors were being called multiple
    // times, so this code was put in place to intentionally
    // leak a single std::string which was never deleted.
    static std::string *answer = new std::string();
    return *answer;
}

dessert::formatter&   dessert::output_formatter(dessert::formatter *f) {
  static formatter *answer = new default_formatter();
  if (f) answer = f;
  return *answer;
}

// C-callable functions:  util_handler_setup, set_dessert_name()
void
dessert::install_handlers()
{
#ifdef HAS_NO_SIGNALS
#else
  struct sigaction sa;
  sa.sa_handler = dessert_terminate_with_output_sighandler;
  sigfillset(&sa.sa_mask);      // all signals will be blocked
                                // while the handler runs
  sigdelset(&sa.sa_mask, SIGALRM); // except for SIGALRM
  sa.sa_flags = 0;

  sigaction(SIGQUIT, &sa, 0);
  sigaction(SIGILL, &sa, 0);
  sigaction(SIGABRT, &sa, 0);
  sigaction(SIGFPE, &sa, 0);
  sigaction(SIGSEGV, &sa, 0);
  sigaction(SIGBUS, &sa, 0);
  set_terminate(cxx_terminate_handler);
#endif
}

/* write to fd without going through stdio, or risking a call
   to malloc.  strlen should be safe(?), even with a corrupted heap.  */
#define WRT(fd, S) ::write(fd, S, strlen(S))
  
// With threading and signals, we can get multiple "simultaneous"
// invocations of terminate_with_output.  Protecting the
// whole thing with a mutex is an attempt to keep the output from
// becoming too garbled.  As always, with NFS, YMMV.  *You* think you
// closed the file and flushed its contents -- but does the remote
// kernel?
#if defined(DESRES_NO_THREADS)
// pass
#elif defined(DESRES_BOOST_THREADS)
static boost::mutex mutex;
#else
static pthread_mutex_t mutex = PTHREAD_MUTEX_INITIALIZER;
#endif

void 
dessert::abandon_all_hope_on_unexpected_signal(int timeout){
#ifdef HAS_NO_SIGNALS
#else
  // Sigaction vs. signal:
  // The man page for signal(3) on our CentOS system says:
  //    If one on a glibc2  system  defines  a  feature  test  macro  such  as
  //    _XOPEN_SOURCE  or  uses  a  separate sysv_signal function, one obtains
  //    classical behaviour. This is not recommended.
  //
  // Sigh.  Desmond, and much else at DESRES is compiled with _XOPEN_SOURCE,
  // so we are required to use the modern sigaction instead of the older
  // (and simpler) signal.
  struct sigaction sa;
  // If anything bad happens now, invoke the abandon_all_hope
  sa.sa_handler = dessert_abandon_all_hope;
  sa.sa_flags = 0;
  // If we do get into abandon_all_hope, we don't want to be
  // interrupted again.
  sigfillset(&sa.sa_mask);
  if( timeout > 0 ){
      sigdelset(&sa.sa_mask, SIGALRM);
  }
  sigaction(SIGALRM, &sa, 0);
  if( timeout > 0 ){
      // if we're in a signal handler now, make sure that SIGALRM
      // is unblocked.
      sigset_t unblock;
      sigemptyset(&unblock);
      sigaddset(&unblock, SIGALRM);
      sigprocmask(SIG_UNBLOCK, &unblock, 0);
      // set the alarm.
      alarm(timeout);
  }
  sigaction(SIGQUIT, &sa, 0);
  sigaction(SIGILL, &sa, 0);
  sigaction(SIGABRT, &sa, 0);
  sigaction(SIGFPE, &sa, 0);
  sigaction(SIGSEGV, &sa, 0);
  sigaction(SIGBUS, &sa, 0);
#endif
}

void
dessert::terminate_with_output(const std::exception& e, 
                               int exstatus,
                               bool glibc_backtrace_also,
                               void (*exit_callback)(int))
{
  int fd = -1;
  // DANGER - it's not hard to get malloc into a state where if you
  // call it again from inside the signal handler it just hangs.
  // (calling free twice with glibc/2.3.4-2.13 on Centos seems to do
  // it).  Other scenarios in which open, close or write may hang are
  // easy enough to imagine.  Basically, once we're handling signals
  // and/or internal errors, there's no guarantee that we can do
  // anything without spinning off into a hang.
  //
  // So as a safety net, set an alarm for enough time to dump our
  // backtrace and exit "cleanly".  If something goes wrong, there's a
  // good chance the alarm will kick us over into a core dump.
  //
  dessert::abandon_all_hope_on_unexpected_signal(60);

  // d is non-NULL if this is a bona fide desres::dessert.
  // Otherwise, it's a std::exception.
  const desres::dessert *d = dynamic_cast<const desres::dessert*>(&e);

#if defined(DESRES_NO_THREADS)
  // pass
#elif defined(DESRES_BOOST_THREADS)
  mutex.lock();
#else
  pthread_mutex_lock(&mutex);
#endif
  const char *why = "unknown";
  if(!output_filename().empty()){
    fd = open(output_filename().c_str(), O_WRONLY|O_CREAT|O_APPEND, 0644);
    if(fd<0)
      why = strerror(errno);
  }else{
    why = "output_filename is empty";
  }
  if(fd < 0){
    fd = fileno(stderr);
    WRT(fileno(stderr), "*** UNABLE TO OPEN dessert file: ");
    if(!output_filename().empty()){
      WRT(fileno(stderr), output_filename().c_str());
    }
    WRT(fileno(stderr), " Reason: ");
    WRT(fileno(stderr), why);
    WRT(fileno(stderr), " ***\n"
        "RECORD EXCEPTION in: /dev/stderr\n");
  }else{
    WRT(fileno(stderr), "RECORD EXCEPTION in: ");
    WRT(fileno(stderr), output_filename().c_str());
    WRT(fileno(stderr), "\n");
  }

  // With threading, we can get a bunch of these in one file.
  // It's helpful to delimit the top and bottom of each one.
  WRT(fd, "<record_dessert_in_standard_place>\n");
  // glibc_backtrace_also provides an option to dump as much as we can
  // of the backtrace without using malloc.  It is intended for use in
  // signal handlers that may be called with a corrupted heap and that
  // can't rely on *anything*.  Call it first in case the fancier
  // stuff hangs.
#ifdef __GLIBC__
  if(glibc_backtrace_also && !glibc_backtrace_never && d){
    // FIXME - call backtrace() ourselves if e is not a dessert.
    WRT(fd, "::: glibc backtrace_symbols :::\n");
    backtrace_symbols_fd(d->stkframes, d->nstkframes, fd);
  }
#endif

  if(d){
    // Write the short form of what() to stderr.
    WRT(fileno(stderr), "::: DESSERT (short form) :::\n");
    WRT(fileno(stderr), d->what(false));

    // Write the long form of what() to fd.
    WRT(fd, "::: DESSERT (long form) :::\n");
    WRT(fd, d->what());
  }else{
    // do we really want to call demangle?  It calls malloc and
    // a string ctor.
    std::string dename = demangle(typeid(e).name());
    WRT(fileno(stderr), "::: "); WRT(fileno(stderr), dename.c_str()); WRT(fileno(stderr), ":::\n");
    WRT(fileno(stderr), e.what());
    WRT(fd, "::: "); WRT(fd, dename.c_str()); WRT(fd, ":::\n");
    WRT(fd, e.what());
  }
    
  WRT(fd, "</record_dessert_in_standard_place>\n");
  if(fd != fileno(stderr))
    close(fd);
  // Is this the right point at which to release the lock?  We're done
  // with output, which is good.  But what happens if some other
  // thread enters the top of the critical section and starts fiddling
  // with sigaction while we're trying to terminate?  I haven't done
  // the necessary deep thinking about how threads, sigaction sleep,
  // alarm, exit and abort interact is required to understand what's
  // really going to happen.
#if defined(DESRES_NO_THREADS)
  // pass
#elif defined(DESRES_BOOST_THREADS)
  mutex.unlock();
#else
  pthread_mutex_unlock(&mutex);
#endif

  // In a MIMD world, the first few threads through here might call
  // abort, which may cause A LOT of data to get written out to NFS.
  // That, in turn will get in the way of other processes and threads
  // that might be trying to finish up their own
  // 'terminate_with_output'.  Ultimately, what *seems* to happen is
  // that mpirun sees that somebody died on a signal and starts the
  // cleanup process before everybody gets a chance to record their
  // backtraces.  This sleep is an *attempt* to give everyone a chance
  // to write backtraces before mpirun swoops in to shut everything
  // down.  It's all a house of cards...
  //
  // If we're not going to abort, do we need the sleep?  Hard to
  // say.  It probably doesn't have to be for quite as long.

#ifdef HAS_NO_SIGNALS
  WRT(fileno(stderr), "Calling abort from desres::dessert::terminate_with_output\n");
#else
  alarm(0);                     // disengage time bomb
  struct sigaction sa;
  sa.sa_handler = SIG_DFL;
  sa.sa_flags = 0;
  sigfillset(&sa.sa_mask);
  sigaction(SIGALRM, &sa, 0); // just in case sleep interacts with SIGALRM
  sleep( (exstatus<0)? 10 : 1 );
  // Re-engage the time bomb.
  sa.sa_handler = dessert_abandon_all_hope;
  sigaction(SIGALRM, &sa, 0);
  alarm(10);

  if( exit_callback ){
    WRT(fileno(stderr), "Calling user-specified exit_callback() from  desres::dessert::terminate_with_output\n");
    (*exit_callback)(exstatus);
    // exit_callback shouldn't return, but if it does, we fall through
    // to the abort code, and if it hangs, SIGALRM takes us to
    // dessert_abandon_all_hope
  }else if(exstatus >= 0){
    WRT(fileno(stderr), "Calling exit() from desres::dessert::terminate_with_output\n");
    exit(exstatus);
    // exit shouldn't return, but if it does, we fall through to the
    // abort code, and if it hangs, SIGALRM takes us to
    // dessert_abandon_all_hope
  }      

  WRT(fileno(stderr), "Calling abort from desres::dessert::terminate_with_output\n");
  sa.sa_handler = SIG_DFL;
  sigaction(SIGABRT, &sa, 0);
  // Make sure SIGABRT isn't blocked.
  sigdelset(&sa.sa_mask, SIGABRT);
  sigprocmask(SIG_SETMASK, &sa.sa_mask, 0);
#endif

  abort();
}

} // namespace desres
