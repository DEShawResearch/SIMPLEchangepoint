/* 
Copyright 2012-2014, D. E. Shaw Research.
All rights reserved.

Redistribution and use in source and binary forms, with or without
modification, are permitted provided that the following conditions are
met:

* Redistributions of source code must retain the above copyright
  notice, this list of conditions, and the following disclaimer.

* Redistributions in binary form must reproduce the above copyright
  notice, this list of conditions, and the following disclaimer in the
  documentation and/or other materials provided with the distribution.

* Neither the name of D. E. Shaw Research nor the names of its
  contributors may be used to endorse or promote products derived from
  this software without specific prior written permission.

THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
"AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR
A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT
OWNER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,
SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT
LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE,
DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY
THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
(INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE
OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
*/

#ifndef DESRES_DESSERT_DESSERT_hpp
#define DESRES_DESSERT_DESSERT_hpp

/*
  DOCUMENTATION_BEGIN

  dessert provides a unified framework of exception handling and
  backtrace generation.  It provides more features than the old backtrace
  library, but uses more resources (heap and stack space) and makes
  greater demands on the compilation and runtime infrastructure (C++
  exceptions, RTTI, std::strings, std::lists, and various
  constructors, as well as libbfd are all used).

  dessert is a subclass of std::exception in the desres namespace.
  Its constructor records a stack backtrace taken at the point the
  constructor was called as well as optional contextual information
  supplied as arguments.  The member function append() provides a
  mechanism for code that catches the exception to add context
  information to it.
 
  dessert's what() method composes all the accumulated information
  into a rather long NUL-terminated-byte string (NTBS) that should be
  very helpful for debugging.

  __throwing___

  In the simplest case, you'd create and throw a dessert with:

  throw dessert("some message");


  The dessert constructor looks like:

    dessert(const std::string&);
    dessert(const std::string&, const char* file, int lineno, const char* func);

  The current __FILE__, __LINE__ and __func__ info can be succinctly
  inserted with the macro DESSERT_LOC, so if you want your dessert's
  context to have information about the exact point from which the
  constructor was called, say:

  throw dessert("some message", DESSERT_LOC)

  Notice that dessert doesn't provide varargs/printf-like semantics
  itself.  You are encouraged to use stringprintf from
  printfutils/printfutils.hpp or other tools from the C++ arsenal to
  assemble your 'what' string, e.g.,

  throw dessert(stringprintf("Uh oh.  n(%d) > m(%d)", n, m), DESSERT_LOC);

  _catching and handling_

  You don't have to *ever* catch a dessert.  In many cases this
  produces perfectly useful behavior.  Generally, an uncaught
  exception will invoke the C++ runtime's termination handler which
  will abort your program.  Sometimes (with gcc runtimes newer than
  3.3) you'll also get the result of the uncaught exception's what()
  member on stderr, which, for a dessert, will contain a stack
  backtrace and context information (see below).  If you don't need
  any more than that then don't catch a dessert.

  If all you want to do in your catch block is "print" the dessert's
  what() to a file of your choosing and then exit, then consider using
  dessert::terminate_with_output, which works very hard to do exactly
  that (it's not easy to do it reliably in the face of signals, heap
  corruption, etc).  Here's the boilerplate code:

    int main(int argc, char **argv) try{
      desres::dessert::output_filename() = ...;
      desres::dessert::install_handlers(); // optional
      ...
    }catch(desres::dessert &d){ 
      desres::dessert::terminate_with_output(d);
    }

  Note that if your code uses threads of any kind, the C++ try/catch
  mechanism does not work across thread invocations.  Thus, you should
  never allow a throw to go uncaught at a thread entry point. If you
  don't already have a try/catch around your thread entry points, you
  should create one.  The example above of a try/catch around main is
  probably a good place to start.  Note that dessert's output_filename
  is *not* thread-local.  The desserts from all threads will go to the
  same file.  The dessert library tries to use pthread mutexes to keep
  this file from becoming garbled, but if you want the desserts from
  different threads to go to different files, you'll have to call
  dessert::output_filename() with a thread-specific name in the catch
  block.

  The above example uses these static members:

   static void dessert::install_handlers();  // see below
   static std::string& dessert::output_filename();
   static void dessert::terminate_with_output(
     std::exception &e, 
     int exstatus = 1,
     bool glibc_backtrace_also = false,
     void (*exit_callback)(int) = 0
     );
 
  install_handlers() is described below.

  terminate_with_output places e.what() in the file previously named
  by the string assigned to output_filename().  In addition, if e is a
  bona fide desres::dessert, the short form of the e.what(false)
  output is also written to stderr.  Note, output_filename() returns a
  string ref that can be used as an lvalue.  Treat it just as if it
  were a static data member.  WARNING: The file is always opened in
  append mode.  If you run your program several times in the same
  directory it may append to the same dessert file each time.  In such
  cases, you *should* arrange that each run gets its own unique
  dessert file, but if you don't dessert won't gratuitously write over
  info from previous jobs.  Similar considerations apply to MPI and
  threaded programs.  You *should* arrange that all processes in an
  MPI program get unique output_filenames, but if you don't each
  process' data will be appended to the common file.  Note though,
  that NFS has a badly broken notion of what it means to append to a
  file.  Don't count on it.

  If output_filename() is empty, or if the file cannot be opened,
  terminate_with_output writes e.what() to stderr.

  After writing info about the exception, terminate_with_dessert
  terminates the program.  Extraordinary efforts are made to guarantee
  that terminate_with_output is always fatal to the caller.  It
  contains a self-destruct mechanism that kills the process with
  extreme prejudice if more than a few seconds elapse while
  terminate_with_output does its work.  This is meant as a safety net
  for any hangs associated with libraries, memory allocation, I/O,
  atexit handlers, interactions with mpirun, etc.  
 
  If exit_callback is non-NULL, it is called with its argument set
  to the value of exstatus.  

  Otherwise, if exit_callback is NULL and exstatus is greater than or
  equal to 0, then exit is called with exstatus as its argument.

  Finally, if exstatus is negative, or if the call to *exit_callback()
  or (less likely) exit() returns, abort is called.

    terminate_with_output(e, 0) // calls exit(0)
    terminate_with_output(e, 1) // calls exit(1)
    terminate_with_output(e, -1) // calls abort()
    terminate_with_output(e, -2, gbt_also, &myexit) // calls myexit(-2)

  The exit_callback hook may be useful in MPI implementations where
  simply calling abort or exit on one process doesn't terminate the
  whole MPI_COMM_WORLD.  In such cases, it might be helpful to write a
  little function that calls MPI_Abort and to pass it as the
  exit_callback argument to terminate_with_output.

  Note that a core dump from a catch block around main is pretty
  useless so calling terminate_with_output with exstatus=-1 there is
  unproductive.  OTOH, core dumps from signal handlers and termination
  handlers can be very informative.  If you write your own handlers,
  consider calling terminate_with_output with exstatus=-1.  To
  accomodate the idiosyncracies of mpirun launchers, a 10 second delay
  is introduced between writing the dessert file and calling abort.
  This delay is not counted by the self-destruct timer.
 
  glibc_backtrace_also controls whether a limited glibc backtrace is
  written before attempting to produce a source-level backtrace.  If
  the heap is trashed (as often happens with "malloc bugs"), you'll
  frequently see *only* the glibc backtrace because the code that
  generates the full backtrace spirals off to oblivion trying to
  malloc enough space to process the elf binaries.  In fact, seeing
  only the glibc backtrace is symptomatic of a "malloc bug" completely
  unrelated to dessert library or the code that threw the dessert.
 
  _catching_and_rethrowing_

  dessert is catchable, of course, but it additionally has an append
  facility for adding more context information that might be known to
  the catcher but not the thrower.  You should only use the
  catch/append/rethrow features of dessert if you actually have
  something useful to add.  E.g., if you know the name of the file
  that couldn't be opened, or the purpose of the object that couldn't
  be allocated, it might be helpful to add that to the error report
  with a catch/append/rethrow.  Most of the time, you just want to let
  the errors "fly overhead" and not bother with catching and
  rethrowing.  To append some context to a dessert, use:

    d.append(std::string& what);
    d.append(std::string& what, const char *file, int lineno, const char *func);

  Usually, you want to append some context and then rethrow.  The
  rethrow methods (same signature as append) will do that for you.
  Thus, a catch block might look like

    catch (dessert &d) {
      d.rethrow("diagnostic info available at this point in the program", DESSERT_LOC);
    }

  Note that rethrow uses the no-operand form of the C++ throw
  expression, so it is a fatal error (it calls terminate()) if it is
  called outside a catch block.

  __throwing from C__

  dessert.hpp is safe to include in a C source file.
  The error-reporting features of dessert are accessible from C
  source files.  You don't have to write in C++ to throw a dessert.
  In C, you can say:

    dessert_throw(msg, DESSERT_LOC);
    dessert_throw_desres_dessert(msg, DESSERT_NOLOC);
    dessert_throw(msg, file, line, func);

  where message is a NUL-terminated string.  Note that the .o file
  will have to be linked with C++ to resolve the exception handling
  infrastructure.  Consider using staticprintf from
  desradutils/printfCutils.h to assemble the message string.

  In addition, C programs can use :
   extern "C" const char * dessert_output_filename(const char *);
  to inspect and/or modify the output_filename.  If the argument is
  non-NULL, it is copied to the internal output_filename() reference.
  The (possibly new) value of output_filenamen is returned.

  The function:
   extern "C" dessert_install_handlers();
  may be called from C in lieu of the static class member function
  install_handlers().

  __ what() __

  There are two forms of dessert::what():

   const char *what(bool do_backtrace) const throws();
   const char *what() const throws();

  If the argument is false, the NTBS produced by what contains only
  the original context and any appended info.  The stack backtrace is
  not produced.  The no-argument form is equivalent to what(true).

  The NTBS returned by what(true) looks like:

  Exception: desres::dessert
  Context:
  <what> @<srcfile>:<lineno> <functionname>
  ...
  Backtrace:
  <srcfile>:<lineno> <demangled_symbol>+<offset> objfile:<objfile> [<addr>]
  ...

  The demangled_symbol, srcfile and objectfile may be "??" and lineno
  might be -1 if, for some reason, the program can't find the relevant
  information.  You should always get an addr, so you can try addr2line
  or other tools.

  In the Context list, the @<srcfile>:<lineno> <function> info is only
  printed if the source information was passed to the constructor or
  dessert::append.

  Note that with optimization turned on, many functions don't have
  stack frames and hence are not visible in the backtrace.  Also note
  that C++ symbols are generally "mangled", often beyond recognition.
  The mangled symbol is what you'd find by doing, say, nm or objdump
  on the object file.  The demangled symbol is much closer to what you
  would expect to find in your program's source code.

  __signal and termination handlers__

  Getting tracebacks from signal handlers and the C++ runtime
  termination handler can be very helpful.  It's also very tricky to
  get right.  Throwing from a signal handler is "likely to lead to
  disaster" according to Usenet gurus.  A better strategy is
  something like:

  void handler(int signum){
      desres::dessert d(stringprintf("In signal handler(signum=%d)", signum));
      // Do something with d;
      // reraise signum or exit or longjump or ...
  }

  For your convenience, 

    extern "C" void dessert_terminate_with_output_sighandler(int)

  is just such a handler.  It calls terminate_with output to report
  the stack trace.  

  In standard C++, a "termination handler" is called in a variety of
  dire situations.  Among them (and most relevant for users of dessert)
  is a completely uncaught exception.  Standard C++ allows you to
  specify your own "termination handler" to replace the one supplied
  by the runtime.  Writing such a handler so that it prints out as
  much as it can about the state of the stack, the characteristics
  of the uncaught exception that precipitated it, etc., is another
  tricky exercise.  dessert provides a static function intended for
  use as a termination handler:

    void dessert::cxx_terminate_handler();

  You can use it by saying something like:

    set_terminate(dessert::cxx_terminate_handler);

  For even greater convenience:

    void dessert::install_handlers()
  or
    extern "C" void dessert_install_handlers()

  will install dessert::terminate_with_output_sighandler for the most
  common "unexpected" signals (QUIT, ILL, ABRT, FPE, SEGV and BUS) and
  dessert::cxx_terminate_handler in place of the C++ terminate()
  function.  Notice that neither TERM nor INT are among the
  "unexpected" signals.  If you want a dessert from them, add it
  yourself with, e.g.,

    signal(SIGTERM, dessert_terminate_with_output_sighandler);
 
  When terminate_with_output encounters internal problems it
  calls:

    extern "C" void dessert::abandon_all_hope(int ignored)

  which does everything in its power to terminate immediately with a
  core dump.  Client code may call it directly or install it as a
  signal handler for extreme circumstances.

  Finally, you can arrange that any of the 'unexpected signals', or
  the passage of 'timeout' seconds will invoke the abandon_all_hope
  handler by calling:

    dessert::abandon_all_hope_on_unexpected_signal(int timeout);

  or, from C:

    dessert_abandon_all_hope_on_unexpected_signal(int timeout);

  If timeout is greater than zero, an alarm is set to trigger the abandonment
  of hope after timeout seconds, otherwise no alarm is set and
  SIGALRM is blocked.

  __ catching std::exception vs. dessert __

  Notice that the argument to terminate_with_output is a
  std::exception.  You *may* choose to:

       catch{std::exception &e){ terminate_with_output(e); }
 
  but if you do, you'll only get a backtrace from the point of the
  catch.  OTOH, if you leave the non-dessert std::exceptions
  unhandled, the runtime will ultimately call the standard C++
  terminate() function.  If you've installed
  dessert::cxx_terminate_handler to handle termination, you should get
  a backtrace from where the original exception was thrown.  That's
  usually more informative.  N.B.  The state of the stack when
  terminate is called for an unhandled exception is "implementation
  defined" (Std 15.5.2 pagraph 2).  For gcc3 and gcc4, the
  implementation seems to define it to be the unwound stack.  Other
  runtimes may behave differently.


  __ rolling your own output __

  Somewhere in your program (main, perhaps, or at the entry point to
  your threads) you'll want to catch a dessert and actually do
  something with it.  Maybe you want to print some or all of the
  information to stderr.  Maybe you want to send something to syslog.
  Maybe you want to pop up a dialog box and force the user to
  acknowledge the problem.  Maybe you want to format an SMS message to
  the on-call staff's beeper.  How you report the information in a
  dessert to the outside world is *completely* up to you.  Nothing in
  the dessert library requires you to print anything to stderr, open
  any files or access any other external channel.

  Remember that dealing with the intricacies of threads, MPI, signals
  and termination handlers in the context of a possibly corrupted
  stack and/or heap is not to be undertaken lightly.

  The data members of a dessert are public for exactly this reason.
  Instead of calling d.what() or terminate_with_output(d), you can
  pick out specific information from the dessert data member:

     std::list<dessert::Context> contexts;

  Each element of the list came from either the contsrutctor or a call
  to append. dessert::Context has public data members which you can
  display however you like:

     struct dessert::Context{
        std::string what;
        std::string file;
        int lineno;
        std::string func;
     }

  If the append or constructor was called without location
  information, file and func will be empty and lineno will be 0.

  You can examine the stack backtrace:

     void *stkframes[];
     int nstkframes;

  There's are also nicely wrapped C++ static member functions to make
  demangling a little easier:
     std::string dessert::demangle(const char *);
     std::string dessert::demangle(const std::string&);

  And you can call dessert_bt_lookup and/or dessert_bt_demangle (see
  dessert/bt.h) to turn those stkframe pointers into symbols, source
  files, etc.  which you can display in the format of your choosing.

  __subclassing__

  dessert may be subclassed.  You might do this if you want to add
  more information to certain types of errors.  E.g., you might want
  to carry an errno along with errors arising from failed system
  calls.  Or you might feel inspired by <stdexcept> and want to use
  the type-sensitivity of catch() to distinguish between different
  kinds of errors, e.g., to handle Ark::exceptions and
  Desmond::Failures differently.

  If you derive a class from dessert, you may override dessert's
  what() members to change the way the exception is formatted, and you
  can add whatever information you wish to the class itself.

  When you derive from dessert, it's usually best *NOT* to inline the
  constructor of your derived class.  Even it is completely trivial,
  write the constructor in its own .cpp file, not inlined in the .hpp
  file.  Your stack backtraces will make a lot more sense.  I.e.,
  write:

  In MyDessert.hpp:
    class MyDessert : public dessert{
      public:
        explicit MyDessert();
        ...
    };

  In MyDessert.cpp:
    MyDessert::MyDessert() : dessert() {}

  If you want your derived class to be throwable from C, create a
  macro/function pair analogous to throw_desres_dessert.

  __ abort_in_constructor __

  Dessert relies on some fairly complex infrastructure including
  constructors for lists and strings and the ability to open object
  files and parse symbol tables and debug info.  If things are really
  bad, e.g., the stack or text segments are corrupted or you're out of
  heap space it's probably hopeless to throw a dessert.  In that case,
  your best bet is probably to do an immediate abort().  You can tell
  dessert to do this by setting the static data member:

     bool dessert::abort_in_constructor

  If true, any attempt to create a dessert object will result in an
  immediate call to abort.  You can then use a post-mortem debugger to
  figure out what went wrong.

  DOCUMENTATION_END
*/

#ifdef __cplusplus

#include <string>
#include <list>
#include <exception>

namespace desres {
  class dessert : public std::exception {
    // mutable because they are changed by
    // what() which is a const method.
    mutable std::string whatstring;
    mutable std::string what_nobt;
  public:
    struct Context{
      std::string what;
      std::string file;
      unsigned    line;
      std::string func;
      Context(const std::string& what_) : what(what_), file(), line(), func(){}
      Context(const std::string& what_, const char *file_, int line_, const char* func_) :
        what(what_), file(file_), line(line_), func(func_){}
    };

    static const int MAX_stkframes=128;
    void *stkframes[MAX_stkframes];
    int  nstkframes;
    std::list<Context>  contexts;

    // The const and virtual specifications follow the same
    // pattern as std::exception.  While it wouldn't strictly be an
    // error to change them, it would surely be confusing.  Note that
    // according to 18.6.1 [lib.exception], the pointer returned by
    // std::exception::what() "remains valid until the exception
    // object from which it is obtained is destroyed, or a non-const
    // function of the exception object is called."  Dessert makes the
    // same promise.
    // 
    // Notice that unlike std::exception and other "internal"
    // exceptions, but like std::runtime_error and other "library"
    // exceptions, dessert's constructors and operator= (implicit)
    // do not have an empty throw() guarantee.  See:
    //    http://www.gotw.ca/gotw/066.htm
    // for why.
    dessert();
    virtual ~dessert() throw(){}

    struct formatter;

    virtual const char *what(bool do_backtrace) const throw();
    virtual const char *what() const throw() { return what(true); }

    // These are specific to dessert
    dessert(const std::string& s);
    dessert(const Context& c);
    dessert(const std::string& s, const char *file, int line, const char *func);
    void append(const std::string& s) throw();
    void append(const Context& c) throw();
    void append(const std::string& s, const char *file, int line, const char *func) throw();

    void rethrow(const std::string& s);
    void rethrow(const Context& c);
    void rethrow(const std::string& s, const char *file, int line, const char *func);

    static void terminate_with_output(const std::exception& e, int exstatus = 1, bool glibc_backtrace_also = false, void (*exit_callback)(int) = 0);
    static void cxx_terminate_handler();
    static void install_handlers();
    static void abandon_all_hope_on_unexpected_signal(int timeout);

    // A demangler that burns a little stack space but relieves you from
    // worrying about who owns the return value.
    static std::string demangle(const char *);
    static std::string demangle(const std::string& s){ return demangle(s.c_str()); }

    // public static data members.  The application may assign these.
    static std::string& output_filename();
    // assign to this by passing in a new pointer
    static formatter&   output_formatter(formatter* f=NULL);
#ifdef __GLIBC__
    static bool glibc_backtrace_never;
#endif
    static bool abort_in_constructor;

#if DEBUG_MULTIPLE_DESTRUCTORS
    // For reproducing the multiple-destructor-bug.  Chatty's
    // ctor and dtor write to stderr whenever they're invoked.
    struct Chatty{
      Chatty();
      ~Chatty();
    };
    static Chatty shouldBeConstructedAndDestroyedOnce;
#endif

  };

  struct dessert::formatter {
    virtual ~formatter() {}
    virtual void begin() {}
    virtual void exception_class(const std::string & /*classname*/) {}
    virtual void begin_context() {}
    virtual void add_context(const std::string & /* what   */,
                             const std::string & /* file   */,
                             unsigned            /* lineno */,
                             const std::string & /* func   */) {}
    virtual void end_context() {}
    virtual void begin_backtrace() {}
    virtual void add_backtrace(const char * /* srcfile */,
                               unsigned     /* lineno  */,
                               const char * /* func    */,
                               const char * /* objfile */,
                               unsigned     /* offset  */,
                               const char * /* symb    */,
                               void *       /* frame   */) {}
    virtual void end_backtrace() {}
    virtual std::string end()=0;
  };
}
#endif /* __cplusplus */

/* A convenience macro to pass file, line and function info to
   dessert's constructor and/or append member function.  */
#ifdef _MSC_VER
#define DESSERT_LOC __FILE__, __LINE__, __FUNCSIG__
#elif defined(_GNUC_)
#define DESSERT_LOC __FILE__, __LINE__, __PRETTY_FUNCTION__
#else
#define DESSERT_LOC __FILE__, __LINE__, "(unknown)"
#endif

/* If you don't want location information, in C++, you can leave the
   arguments off entirely from the dessert constructor or append
   member.  In C (or C++, if you wish) you can use DESSERT_NOLOC, e.g.,
     throw_desres_dessert("Locationless dessert from C", DESSERT_NOLOC);
*/
#define DESSERT_NOLOC "", 0, ""

#ifdef __cplusplus
extern "C" {
#endif
extern void dessert_throw(const char *what, const char *file, int line, const char *func);
extern const char * dessert_output_filename(const char *s);
extern void dessert_install_handlers();
extern void dessert_abandon_all_hope(int ignored);
extern void dessert_terminate_with_output_sighandler(int signum);
extern void dessert_abandon_all_hope_on_unexpected_signal(int timeout);
#ifdef __cplusplus
}
#endif

#endif
