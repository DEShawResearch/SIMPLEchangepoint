/* 
Copyright 2012-2014, D. E. Shaw Research.
All rights reserved.

Redistribution and use in source and binary forms, with or without
modification, are permitted provided that the following conditions are
met:

* Redistributions of source code must retain the above copyright
  notice, this list of conditions, and the following disclaimer.

* Redistributions in binary form must reproduce the above copyright
  notice, this list of conditions, and the following disclaimer in the
  documentation and/or other materials provided with the distribution.

* Neither the name of D. E. Shaw Research nor the names of its
  contributors may be used to endorse or promote products derived from
  this software without specific prior written permission.

THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
"AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR
A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT
OWNER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,
SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT
LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE,
DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY
THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
(INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE
OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
*/

#include "dessert.hpp"
#include "bt.h"
#include <csignal>
#include <cstdlib>
#include <cstdio>
#include <cstring>
#include <typeinfo>
#if defined(DESRES_OS_Windows) || defined(DESRES_OS_MINGW_GCC4)
#include <io.h>
#define snprintf _snprintf
#define HAS_NO_SIGNALS
#else
#include <unistd.h>
#endif

using namespace std;

#define PANIC_WRT(s) write(2, s, sizeof(s))

namespace desres {
//
// A very interesting discussion of the implications of an empty
// throw specification on a constructor is here:
//    http://www.gotw.ca/gotw/066.htm
// Here's the punch-line:
// <snip>
// Now that we've done all the hard work, this one's easy: For a
// constructor to have an empty throw-specification, all base and
// member subobjects must be known to never throw (whether they
// have throw-specs that say so or not).
//
// An empty throw-specification on a constructor declares to the
// world that construction cannot fail. If for whatever reason it
// can indeed fail, then the empty throw-spec isn't appropriate,
// that's all.
// </snip>
//
// Since dessert has string and list members whose constructors
// could throw (bad_alloc, conceivably) dessert's constructors can't
// guarantee an empty throw().  Nevertheless, it is *extremely*
// unlikely that dessert's constructors will throw.  It can only
// happen if the default constructor for a string or list throws.
dessert::dessert(){
    if(abort_in_constructor)
        dessert_abandon_all_hope(0);
    nstkframes = dessert_backtrace(stkframes, MAX_stkframes);
}

dessert::dessert(const std::string& s){
    if(abort_in_constructor)
        dessert_abandon_all_hope(0);
    nstkframes = dessert_backtrace(stkframes, MAX_stkframes);
    append(s);
}

dessert::dessert(const Context& c){
    if(abort_in_constructor)
        dessert_abandon_all_hope(0);
    nstkframes = dessert_backtrace(stkframes, MAX_stkframes);
    append(c);
}

dessert::dessert(const std::string& s, const char *file, int line, const char *func){
    if(abort_in_constructor)
        dessert_abandon_all_hope(0);
    nstkframes = dessert_backtrace(stkframes, MAX_stkframes);
    append(s, file, line, func);
}

// Even though this static is assigned a value in the header,
// you must *STILL* include this declaration in the source
// FIXME: I'm not sure that this is true
#ifndef DESRES_OS_Windows
const int dessert::MAX_stkframes;
#endif

const char *
dessert::what(bool do_backtrace) const throw() try{
    // do_backtrace is a hack.  Don't let it get any more
    // complicated.  If more complex logic is needed, find
    // another approach.
    if(do_backtrace){
        if(!whatstring.empty())
            return whatstring.c_str();
    }else{
        if(!what_nobt.empty()){
            return what_nobt.c_str();
        }
    }

    formatter &F(output_formatter());
    F.begin();

    const char *classname = (const char *)dessert_demangle(typeid(*this).name());

    F.exception_class((classname? classname : "<unknown>"));
    free((void*)classname);

    F.begin_context();
    for(list<Context>::const_iterator p = contexts.begin();
        p != contexts.end(); ++p){
        F.add_context(p->what,p->file,p->line,demangle(p->func));
    }
    F.end_context();

    if( do_backtrace && nstkframes ){
        F.begin_backtrace();
        for(int i=0; i<nstkframes; ++i){
            const char *srcfile;
            const char *symb;
            const char *objfile;
            const char *dem;
            unsigned lineno;
            unsigned offset;
            dessert_bt_lookup((void const*)stkframes[i], &objfile, &symb, &offset, &srcfile, &lineno, &dem);
            // if symb is NULL, lookup couldn't figure out a nearby symbol.
            if(symb == NULL)
                symb = strdup("??");
            // If dem is NULL, the demangler couldn't demangle the symbol.  This
            // happens when the symbol is NULL, but it also happens when the
            // symbol is a perfectly nice unmangled string.  So:
            if(dem == NULL)
                dem = strdup(symb);

            F.add_backtrace(srcfile,lineno,dem,objfile,offset,symb,stkframes[i]);

            free((void*)objfile);
            free((void*)srcfile);
            free((void*)symb);
            free((void*)dem);
        }
        F.end_backtrace();
    }
    
    if(do_backtrace){
        whatstring = F.end();
        return whatstring.c_str();
    }else{
        what_nobt = F.end();
        return what_nobt.c_str();
    }
}catch(...){
    return 
        "exception thrown by the implementation of dessert::what() itself.\n"
        "We have *no* idea what's wrong.";
}

void dessert::append(const std::string& s) throw() {
    append(Context(s, DESSERT_NOLOC));
}

void dessert::append(const std::string& s, const char *file, int line, const char* func) throw() {
    append(Context(s, file, line, func));
}

void dessert::append(const Context& c) throw() {
    // Yes.  something in here might throw a bad_alloc or some other
    // internal error.  If that happens, we're better off just letting
    // unexpected() fall through to terminate(), which, if we're lucky,
    // will tell us something or abort.
    whatstring.erase();
    what_nobt.erase();
    contexts.push_back(c);
}

void dessert::rethrow(const std::string& s){
    append(s);
    throw;
}

void dessert::rethrow(const std::string& s, const char *file, int line, const char* func) {
    append(s, file, line, func);
    throw;
}

void dessert::rethrow(const Context& c) {
    append(c);
    throw;
}

std::string
dessert::demangle(const char *name){
    char *p = dessert_demangle(name);
    std::string answer;
    if(p==NULL)
        answer=name;
    else{
        answer=p;
        free(p);
    }
    return answer;
}

#if DEBUG_MULTIPLE_DESTRUCTORS
dessert::Chatty::Chatty(){
    desres::dessert d(staticprintf("Chatty() this=%p", this));
    write(2, d.what(), strlen(d.what()));
}
dessert::Chatty::~Chatty(){
    desres::dessert d(staticprintf("~Chatty() this=%p", this));
    write(2, d.what(), strlen(d.what()));
}
dessert::Chatty shouldBeConstructedAndDestroyedOnce;
#endif
} // namespace desres

void
dessert_throw(const char *what, const char *file, int line, const char *func){
    throw desres::dessert(what, file, line, func);
}

const char *dessert_output_filename(const char *s){
    if(s)
        desres::dessert::output_filename() = s;
    return desres::dessert::output_filename().c_str();
}

void dessert_install_handlers(){
    desres::dessert::install_handlers();
}

void dessert_abandon_all_hope_install_handlers(){
    desres::dessert::install_handlers();
}

void dessert_abandon_all_hope(int signum){
    // ENOUGH.  We only get here if an earlier signal handler
    // hung.  There's *NOTHING LEFT TO DO* except to try to
    // dump core so somebody can figure out what's up.
    // This function is usually called from signal handler,
    // but it can be called directly from 'normal' code.
    static char farewell_generic[] = 
        "\n*** dessert::abnormal termination ***\n"
        "We got here because something blew up *inside* one of\n"
        "the dessert handlers.  This is often the result of stack\n"
        "or heap (i.e., malloc) corruption.  The information in the\n"
        "backtrace and/or core dump tells you where the program is now.\n"
        "The problem may be somewhere else entirely.\n";
    static char farewell_sigalrm[] = 
        "\n*** dessert::abnormal termination ***\n"
        "We got here because of a SIGALRM.  The most common way for\n"
        "that to happen is if the normal process of catching and\n"
        "printing a dessert took much longer than it should have, which\n"
        "in turn is usually the result of a corrupted stack or heap.\n"
        "The information in the backtrace and/or core dump tells you\n"
        "where the program is now.  The problem may be somewhere else\n"
        "entirely.\n";

    // DANGER - the SIGALRM *might* have gone off because we were
    // hung on I/O.  Writing could hang.  OTOH, getting a message
    // out that reminds people not to put too much faith in the
    // backtrace is pretty useful.
#ifdef HAS_NO_SIGNALS
    write(2, farewell_generic, sizeof(farewell_generic)-1);
#else
    if( signum != SIGALRM )
        write(2, farewell_generic, sizeof(farewell_generic)-1);
    else
        write(2, farewell_sigalrm, sizeof(farewell_sigalrm)-1);
        
    // Re-establish a default handler for SIGABRT.
    struct sigaction sa;
    sa.sa_handler = SIG_DFL;
    sigemptyset(&sa.sa_mask);
    sa.sa_flags = 0;
    sigaction(SIGABRT, &sa, 0);
    // N.B. We could just call abort, but what if the signal is
    // blocked?  Well, it *should* get through right after we return
    // from the signal handler running with blocked signals, which
    // *might* be this one...  BUT the whole point here is that
    // *things are really REALLY bad*.  We don't want to return and
    // let somebody else take care of the mess.  We want the process
    // to finish now.  So let's make sure that SIGABRT is unblocked.
    // If SIGABRT happens to be pending, so be it -- the pending
    // signal will deliver the coup de grace and we won't get to the
    // abort on the following line.  It's possible that this is
    // overdesign and introduces some other undesirable problem.  Time
    // will tell...
    sigaddset(&sa.sa_mask, SIGABRT);
    sigprocmask(SIG_UNBLOCK, &sa.sa_mask, 0);
#endif
    abort();
}    

void dessert_terminate_with_output_sighandler(int signum){
  // Let's not even waste time constructing a dessert if it's just going
  // to dump core:
  if(desres::dessert::abort_in_constructor)
    dessert_abandon_all_hope(0);

  // We *tried* to block signals before getting in here
  // by using sigaction to set up the signal handler.
  // But can you really block SEGV or BUS?  And what's supposed
  // to happen afterwards if one gets raised while it's
  // blocked.  Let's arrange that even if a signal gets
  // through, it causes us to abort immediately.
  desres::dessert::abandon_all_hope_on_unexpected_signal(10);

  // stringprintf would certainly be more elegant and "safer", but the
  // dessert library is *so* fundamental and the version-compatibility
  // capabilities of the current garden (June 2008) are so deficient,
  // that in this special case, it seems worth avoiding the library
  // call and thereby avoiding the dependence on a particular version
  // of the printfutils library.
  char msg[64];               // more than enough for the one and only
                              // call below.
  snprintf(msg, sizeof(msg), "\nCAUGHT UNEXPECTED SIGNAL %d", signum);
  desres::dessert::terminate_with_output(desres::dessert(msg), -1, true);
}

