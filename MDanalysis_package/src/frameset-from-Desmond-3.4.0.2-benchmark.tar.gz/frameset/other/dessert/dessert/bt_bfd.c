/* Copyright D. E. Shaw Research, 2004-2012. */

#define _GNU_SOURCE
#include "bt.h"
#include <dlfcn.h>
#include <execinfo.h>
#include <bfd.h>
#include <sys/types.h>
#include <unistd.h>
#include <sys/stat.h>
#include <string.h>
#include <strings.h>
#include <sys/param.h>
#include <stdio.h>
#include <stdlib.h>
#include <pthread.h>

int dessert_backtrace(void *stkframes[], int MAX_stkframes){
    return backtrace(stkframes, MAX_stkframes);
}

/*
   three types are defined in bfd.h
     bfd          - describes the binary structure of the executable
     asection     - a piece of bfd describing a section of an executable
     A bfd contains sections in the form of a link list:
        bfd *b;
        b->sections is of type asection and is the head of the list
        asection *s;
        s->next is of type asection and is the next elt in the list or NULL
     flagword bfd_get_section_flags(bfd *,asection *)
        returns the flags for this section.  One should only look for
        addresses of functions in sections where flags & SEC_ALLOC !=0

     bfd_vma bfd_get_section_vma (bfd *,section *s)
        returns the start address of section s

     bfd_vma_size_type bfd_get_section_size (bfd *,section *s)
        returns the size of the non-reloc portion of the section.
        function addresses in a section occur somehwere between
           vma<= ... <vma+size

     bfd_vma      - an int type which can hold a program address (unclear if
                    signed or not)
     bfd_size_type - an unsigned type of the same size as bfd_vma

     bfd_vma bfd_scan_vma( const char *, const char **, unsigned)
     works just like strtol only it parses the number into a program address.

     flagword bfd_get_file_flags(bfd *b)
     returns flags associated with b.  Assumes b is opened.
     The macro HAS_SYMS tests if we actually have symbolic information
     in the file.  It would be a bad plan to try to read in symbol info
     if b doesn't have syms.

     int bfd_find_nearest_line (bfd*, asection*, void* s, bfd_vma off,
                                const char **file,const char **func,
                                unsigned *line)
     returns the "line" information for address X where
        X = start address of p + off
     swings the file and func pointers to some internal char*'s
     and sets line[0] to the line number in the program source.
     s is this mysterious table of minisymbols returned by a function
     below (it is not modified by the call).
     returns non-zero if successfully did the lookup.
      
     bfd *bfd_openr (const char *exefile, void *x)
     'opens' the exefile and returns associated bfd structure.
     The exact function of x is unknown but it can be NULL;
     Returns 0 if there is a problem.

     ??? bfd_close(bfd *)
     closes a bfd.  I don't know what it returns.

     void bfd_init()
     this must be called before any bfd things are done ever.
     It is completely unclear whether there is a corresponding
     bfd_halt() function of if this function is idempotent.

     const char * bfd_errmsg( ??? )
     returns a string stranslation of an error code
     ???  bfd_get_error()
     returns the most recent error code (errors are signaled by
     return values and stuff like that, so don't test this against
     0 or anything).

     int bfd_check_format(bfd *b, ???)
     (from Info pages)
A format is a BFD concept of high level file contents type. The formats
supported by BFD are:
   * `bfd_object'
   The BFD may contain data, symbols, relocations and debug info.
   * `bfd_archive'
   The BFD contains other BFDs and an optional index.
   * `bfd_core'
   The BFD contains the result of an executable core dump.

   The function returns `TRUE' on success, otherwise `FALSE' with one
of the following error codes:
   * `bfd_error_invalid_operation' - if `format' is not one of
     `bfd_object', `bfd_archive' or `bfd_core'.
   * `bfd_error_system_call' - if an error occured during a read - even
     some file mismatches can cause bfd_error_system_calls.
   * `file_not_recognised' - none of the backends recognised the file
     format.
   * `bfd_error_file_ambiguously_recognized' - more than one backend
     recognised the file format.

     char **matching;
     int bfd_check_format_matches(bfd *b, ???, char ***m)
     requires b to be opened and already check_format-ed.
     I don't know what the second argument is but the macro 'bfd_object'
     will work. m is some sort of pointer to internal stuff which is
     being set as a side effect, but has no relevance or use for us
     (not clear what the function does with it).  Polarity is the
     opposite of bfd_check_format!!!!  Yuck!

     long bfd_read_minisymbols(bfd *b, int st, void **s, unsigned *x)
     obtains symbol information from b.  requires that b has been
     check_format_matches-ed before use.  s isn't really a void* but
     is some sort of memory buffer which is malloc-ed and needs to be
     freed once all use of s has finished.  x is the address of an
     unsigned in to which is written the total size of the symbols.
       set st to 0 if this is a staticly linked exe
       set st to 1 if dynamically linked exe
     The return value is the total count of symbols in the exe, if all
     goes well.  It is negative is something disasterous happened.  It
     is 0 if st=0 and the exe really isn't static.  It is not ridiculous
     to try this function with st=0, see if it returns 0, and try again
     with st=1 if so.
*/

/* shut things down.  close/free and nullify that which is not */
static void shutdown_bfd(bfd **_BFD,void **_SYMT) {
  /** release all BFD and SYMT resources **/
  if (*_BFD) bfd_close(*_BFD);
  *_BFD = NULL;
  if (*_SYMT) free(*_SYMT);
  *_SYMT = NULL;
}

static unsigned size_of_symbols;
static int number_of_symbols;

/* We have a C++ FindBin library.  There are two reasons not to use it:
  1 - this is a C program.  But why?
  2 - versionitis.
  This code is lifted from there.
  Always return a malloc'ed buffer.  The caller is responsible for freeing.
*/
static char *FindBin(const char *argv0){
    size_t len0 = strlen(argv0);
    const char *PATH = getenv("PATH");
    /* If the name has slashes, just dup it.  Don't look it up in PATH. */
    if( strchr(argv0, '/') != 0 )
        return strdup(argv0);
    if(PATH==NULL)
        return strdup(argv0);
    const char *p;
    const char *colon;
    for(p=PATH; *p; p=colon+1){
        struct stat sb;
        colon = strchr(p, ':');
        if(!colon)
            colon = p + strlen(p);
        /* What if PATH has a leading colon, a trailing
        // colon or a double-colon?  Then dir is empty.
        // Is that a no-op?  Does it mean "."?  Let's
        // make it a no-op.
        */
        if(colon == p)
            continue;
        /* Working with strings in C is dangerous!  It's neither
           cleaner nor safer with strcat and strncpy.*/
        char *exe = malloc( (colon-p) + 1 + len0 + 1 );
        memcpy(exe, p, colon-p); 
        exe[colon-p]='/';
        memcpy(exe+(colon-p)+1, argv0, len0+1);

        /* Is exe a bona fide executable  */
        if( stat(exe, &sb) == 0 ){
            if( (sb.st_mode & S_IFREG) ){
                /* Can *I* execute it.  We could compare group and
                // user ids', or we could just call access.  N.B.
                // access may return false-positives for euid root
                // over NFS.
                */
                if( access(exe, X_OK)==0 )
                    return exe;
            }
        }
        free((void*)exe);
    }
    return strdup(argv0);
}

static void startup_bfd(const char *objfile, bfd **_BFD,void **_SYMT) {
  const unsigned int Statically_link_exe=0;
  const unsigned int Dynamically_link_exe=1;
  static int initialized = 0;

  if(_BFD==NULL || _SYMT==NULL)
      return;

  if( !initialized ){
    /* Reentrancy issues? */
    initialized = 1;
    bfd_init();
  }
  *_BFD = bfd_openr(objfile,NULL);
  *_SYMT = NULL;
  if (*_BFD == NULL) return;

  if (bfd_check_format(*_BFD,bfd_object)==FALSE) {
    shutdown_bfd(_BFD,_SYMT);
    return;
  }

  if (!(bfd_get_file_flags(*_BFD) & HAS_SYMS)) {
    shutdown_bfd(_BFD,_SYMT);
    return;
  }

  /* First try it as a staticly linked exe, then as a dynamic */
  number_of_symbols = bfd_read_minisymbols(*_BFD,Statically_link_exe,
                           _SYMT,&size_of_symbols);
  if (number_of_symbols==0) {
    number_of_symbols = bfd_read_minisymbols(*_BFD,Dynamically_link_exe,
                             _SYMT,&size_of_symbols);
  }
  if (number_of_symbols<0) {
    shutdown_bfd(_BFD,_SYMT);
    return;
  }
}

/* Some mysterious crashes point to the possibility that
   the bfd stuff isn't thread-safe.  Since it's hard to know
   for sure, it's better to be safe than sorry.  Wrap
   the entire dessert_bt_lookup inside a critical-section
*/
static pthread_mutex_t mutex = PTHREAD_MUTEX_INITIALIZER;

/* Look up addr in the current process (which might or might not
   be dynamically loaded.  The caller can assume that any "returned"
   char* was obtained with strdup (or equivalently, malloc).  It's
   up to the caller to free them when done. */
int dessert_bt_lookup(const void *addr,
               const char **objfilep,
               const char **symbp,
               unsigned    *offsetp,
               const char **srcfilep,
               unsigned    *linenop,
               const char **demangled_symbp
               ){
  bfd *bfd;
  void *symt;
  int ret;
  Dl_info dli;
  void *dlibase;
  const char *srcfile = 0;
  const char *symb = 0;
  *demangled_symbp = 0;
  asection* mysection = NULL;
  bfd_vma begin = 0;
  bfd_vma end = 0;
  asection* section;
  bfd_vma offset;
  int shared_lib = 0;
  
  pthread_mutex_lock(&mutex);
  /*
  // We can get objfile and symbol information from dladdr, which is
  // provided by glibc.  To get sourcefile and line number
  // information, we need bfd.  But to use bfd, we need to know the
  // objfile, so the first thing to do is to call dladdr.  BUT - if
  // we're staticly linked, dladdr fails.  In that case, we can still
  // use bfd on /proc/self/exe.

  // FIXME - also note that the dli_fbase may be a relative path,
  // relative to the cwd at the time the program started.  If we've
  // chdir'ed since then, we're hosed (unless we remembered where we
  // were when we started).  If the binary has changed (been unlinked
  // or overwritten) since we started, we're really hosed, but in that
  // case, really now, what did you expect?
  */
  /* Indirect evicence (i.e., a segfault) suggests that libbfd hangs
     on to its char* filename argument (i.e., obfile), so we have
     to hang onto it as well until we've shut down. */
  if(dladdr(addr, &dli)){
      *objfilep = FindBin(dli.dli_fname);
      dlibase = dli.dli_fbase;
      *offsetp = (char *)addr - (char*)dli.dli_saddr;
  }else{
      *objfilep = strdup("/proc/self/exe");
      dlibase = 0;
      *offsetp = 0;
  }
  startup_bfd(*objfilep, &bfd, &symt);
  if(bfd == 0 || symt==0){
      ret = 0;
      goto outahere;
  }
  shared_lib = bfd_get_file_flags(bfd) & DYNAMIC;
  /* FIXME - we've got the symbol and we've got offset-begin.  We'd
     like to know the address of the symbol so we can report something
     like:
       0x400325=main+19
  */

  /*
  // CONFUSING!  
  //  Sometimes we can 'find' our addresses by subtracting
  //  dli_fbase, and sometimes not.  Why?  I have no idea.
  //          
  //  Even stranger -- objdump reports 0x400000 based
  //  addresses for the executable, but it reports
  //  0x0 based addresses for libc.so.6, but when
  //  we examine it with bfd, we get the wacky 0x3ebe0000
  //  addresses.
  // 
  //  Bottom-line There's plenty I don't understand about bfd.
  //
  //  Another curiosity:  when looking up some symbols (notably, the
  //  constructor for dessert::dessert), bfd reports that the symbol
  //  is the unmangled string "dessert".  Usually, it gives the mangled
  //  C++ name, but not in this case.  Why?  Who knows?  Maybe it
  //  has something to do with it being a constructor, and hence
  //  found in a different "section"?  In any case, the demangler
  //  fails, just as it does for all unmangled names, but the unmangled
  //  and unadorned name is indicative
  //  enough, so I'm not going to worry about it for now.
  */
  for(section=bfd->sections; section && !mysection; section=section->next) {
    flagword section_flags = bfd_get_section_flags(bfd,section);
    if (!(section_flags & SEC_ALLOC)) continue;

    begin = bfd_get_section_vma(bfd,section);
    end = begin + bfd_get_section_size(section);
    bfd_vma addrminusbase = (const char *)addr-(const char *)dlibase;
    bfd_vma addrminuszero = (const char *)addr - (const char *)0;
    if ( shared_lib && addrminusbase >= begin && addrminusbase < end ) {
      mysection = section;
      offset = addrminusbase;
      break;
    }
    if ( addrminuszero >= begin && addrminuszero < end ) {
      mysection = section;
      offset = addrminuszero;
      break;
    }
  }
  if (!mysection){
    bfd_set_error(bfd_error_invalid_error_code);
    ret = 0;
    goto outahere;
  }

  /** DO LOOKUP **/
  ret = bfd_find_nearest_line(bfd,mysection,(struct bfd_symbol**)symt,offset-begin,
                              &srcfile,&symb,linenop);

  if(!ret){
      srcfile = 0;
      symb = 0;
      *linenop = 0;
      goto outahere;
  }
  
  if(symb){
      *demangled_symbp = dessert_demangle(symb);
  }

 outahere:
  if(!srcfile) srcfile = "??";
  if(!symb)    symb    = "??";
      
  *symbp = strdup(symb);
  *srcfilep = strdup(srcfile);
      
  shutdown_bfd(&bfd, &symt);
  pthread_mutex_unlock(&mutex);
  return ret;
}
               
