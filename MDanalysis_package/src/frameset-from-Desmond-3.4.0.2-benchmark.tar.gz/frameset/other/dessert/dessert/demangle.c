/* Copyright D. E. Shaw Research, 2004-2012. */

#include <string.h>
#include "bt.h"

/*
// With g++, we can just say
// #include <cxxabi.h>
// But with, gcc, we don't have that directory in our search path.
// In fact, cxxabi.h is in <c++/__VERSION__/cxxabi.h>, but
// __VERSION__ is a pp-symbol whose value is a quoted string,
// e.g., "4.2.1".  I see no way to remove the quotes and
// hand it off to the #include machinery.
// Const string concatenation didn't work, which is a shame...
// i.e., #include "c++/" __VERSION__ "/cxxabi.h"
// We could put some hackery in the Makefile and/or desres-install-helper
// to -D CXXABIDOTH="c++/4.1.1/cxxabi.h" on the command-line.
// Or we can just write out the one declaration we're
// interested in...
*/

#ifdef __cplusplus
extern "C" 
#endif
char*
__cxa_demangle(const char* __mangled_name, char* __output_buffer,
		 size_t* __length, int* __status);

char *dessert_demangle(const char *name){

  if (!name) return 0;
#ifdef __GNUC__
  int status;
  return __cxa_demangle(name,NULL,NULL,&status);
#else
  return strdup(name);
#endif
}



