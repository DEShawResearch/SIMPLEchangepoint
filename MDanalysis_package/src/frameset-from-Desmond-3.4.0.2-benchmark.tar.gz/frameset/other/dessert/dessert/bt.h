/* Copyright D. E. Shaw Research, 2004-2012. */

#ifndef _dessert_bt_dot_h
#define _dessert_bt_dot_h

/* 
   DOCUMENTATION_BEGIN

   dessert/bt.h - abstracted utilities for working with stack
   backtraces in C and C++.  Unlike the rest of the dessert
   library, the implementation of these functions is *entirely*
   C, so you can include bt.h in C programs that are linked
   with a C compiler.  C++ linkage is not required.

   The functions in this header are thin wrappers around capabilities
   provided by the glibc, libbfd and gcc's libstdc++ libraries on
   Linux.  It is likely that similar functionality exists on other
   platforms, and it is at least plausible that this abstraction layer
   can be retargeted if and when ports are required to other
   platforms.  At the very least, it is straightforward to define
   "no-op" versions of these functions on any platform.

   int dessert_backtrace(void *stkframes[], int MAX_stkframes) - 
    call the backtrace() function in glibc, or do something
    functionally equivalent.  Populate the array of stkframes with
    pointers to addresses that carry some information about the
    program's stack.  Return the number of populated stkframes, not
    greater than MAX_stkframes.

   char *dessert_demangle(const char *name) - 
    return a pointer to the 'demangled' version of name.  The value
    returned was obtained by malloc.  The caller is responsible for
    freeing it.  May return NULL if confused or unable to demangle the
    name

   int dessert_bt_lookup(const void *addr,
                         const char **objfile,
                         const char **symbol, unsigned *offset,
                         const char **srcfile, unsigned *lineno,
                         const char **demangled)
    Look up addr in the current process (which might or might not be
    dynamically loaded) and report the object file from which the
    address was loaded, the nearest symbol, the offset of addr from
    that symbol, the source file and line number and the demangled
    symbol name.  The caller can assume that any "returned" char* was
    obtained with strdup (or equivalently, malloc).  If a result is
    unavailable, "??" is returned instead.  The caller is
    responsible for calling free.  
  DOCUMENTATION_END
*/

#ifdef __cplusplus
extern "C"{
#endif
extern int dessert_backtrace(void *stkframes[], int MAX_stkframes);

extern char *dessert_demangle (const char *name);

extern int dessert_bt_lookup(void const *addr,
                      char const **objfile,
                      char const **symbol,
                      unsigned    *offset,
                      char const **srcfile,
                      unsigned    *lineno,
                      char const **demangled
                      );

#ifdef __cplusplus
}
#endif

#endif
