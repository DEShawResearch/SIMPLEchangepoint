/* Copyright D. E. Shaw Research, 2004-2012. */

#include "bt.h"
#include <string.h>
#include <stdio.h>
#include <stdlib.h>

#if defined(USE_BACKTRACE)

#include <execinfo.h>

int dessert_backtrace(void *stkframes[], int MAX_stkframes){
    return backtrace(stkframes, MAX_stkframes);
}

int dessert_bt_lookup(const void *addr,
               const char **objfilep,
               const char **symbp,
               unsigned    *offsetp,
               const char **srcfilep,
               unsigned    *linenop,
               const char **demangled_symbp
               ){

    const char * first_paren = NULL;
    const char * last_paren = NULL;
    const char * first_bracket = NULL;
    const char * last_bracket = NULL;
    const char * sym = NULL;
    char ** symbols;
    
    /* we're expecting something of the form:

    /u/nyc/gullingj/dpr/Linux/x86_64/dessert/2.0.27/Release/lib/libdessert.so(_ZN6desres7dessertC1ERKSsPKciS4_+0x94) [0x7f2732fb9744]

    I'll assume () and [] make good delimiters...
    */
    symbols = backtrace_symbols( (void * const *)&addr, 1 );
    if (symbols && (sym=symbols[0])) {
        first_paren = strchr(sym, '(');
        last_paren = first_paren ? strchr(first_paren, ')') : NULL;
        first_bracket = last_paren ? strchr(last_paren, '[') : NULL;
        last_bracket = first_bracket ? strchr(first_bracket, ']') : NULL;
    }

    /* extract objfilep */
    if (sym && first_paren) {
        char * p = strdup(sym);
        p[first_paren-sym] = '\0';
        *objfilep = p;
    } else {
        *objfilep = strdup("<unknown executable>");
    }

    /* extract symbp */
    if (first_paren && last_paren) {
        char * delim, * p = strdup(first_paren+1);
        p[last_paren-first_paren-1] = '\0';
        *symbp = p;

        /* get the demangled part */
        p = strdup(first_paren+1);
        delim = strchr(p, '+');
        if (delim) {
            *delim = '\0';
            *demangled_symbp = dessert_demangle(p);
        } else {
            *symbp = strdup("<unknown symbol>");
            *demangled_symbp = strdup("???");
        } 
        free(p);

    } else {
        *symbp = strdup("<unknown symbol>");
        *demangled_symbp = strdup("???");
    }

    /* put the hex address in srcfilep */
    if (first_bracket && last_bracket) {
        char * p = strdup(first_bracket+1);
        p[last_bracket-first_bracket-1] = '\0';
        *srcfilep = p;
    } else {
        *srcfilep = strdup("<unknown source file>");
    }

    /* no other information */
    *offsetp = 0;
    *linenop = 0;

    free(symbols);
    return 0;
}

#else /* if defined(USE_BACKTRACE) */

int dessert_backtrace(void *stkframes[], int MAX_stkframes){
    return 0;
}

int dessert_bt_lookup(const void *addr,
               const char **objfilep,
               const char **symbp,
               unsigned    *offsetp,
               const char **srcfilep,
               unsigned    *linenop,
               const char **demangled_symbp
               ){
    *objfilep = strdup("XX");
    *symbp = strdup("XX");
    *offsetp = 0;
    *srcfilep = strdup("XX");
    *linenop = 0;
    *demangled_symbp = strdup("XX");

    return 0;
}

#endif

