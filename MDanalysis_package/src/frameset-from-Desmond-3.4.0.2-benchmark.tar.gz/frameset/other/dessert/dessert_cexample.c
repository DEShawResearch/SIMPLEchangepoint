/* Copyright D. E. Shaw Research, 2004-2012. */

#include <dessert/dessert.hpp>
#include <stdio.h>
#include <stdlib.h>

void cfunc() {
  fprintf(stderr,"throwing a C 'exception'\n");
  dessert_throw("a c function throws", DESSERT_LOC);
  fprintf(stderr, "NOT IMPLEMENTED YET\n");
  exit(1);
}
