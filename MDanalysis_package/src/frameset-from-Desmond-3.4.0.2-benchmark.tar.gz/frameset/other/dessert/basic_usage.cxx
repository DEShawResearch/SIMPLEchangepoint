/* 
Copyright 2012-2014, D. E. Shaw Research.
All rights reserved.

Redistribution and use in source and binary forms, with or without
modification, are permitted provided that the following conditions are
met:

* Redistributions of source code must retain the above copyright
  notice, this list of conditions, and the following disclaimer.

* Redistributions in binary form must reproduce the above copyright
  notice, this list of conditions, and the following disclaimer in the
  documentation and/or other materials provided with the distribution.

* Neither the name of D. E. Shaw Research nor the names of its
  contributors may be used to endorse or promote products derived from
  this software without specific prior written permission.

THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
"AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR
A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT
OWNER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,
SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT
LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE,
DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY
THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
(INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE
OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
*/

#include "dessert/dessert.hpp"
#include "badbehavior.hpp"
#include <iostream>
#include <cstdio>
#include <cstdlib>
#include <cstring>

// This is a very simple example of basic usage.
using namespace desres;

void Usage(const char *av0){
    printf("Usage: %s [normal|throwcpp|throwc|loop|throwcpp.so|segv]\n", av0);
    exit(1);
}

void myexit(int ex){
    printf("myexit(%d)\n", ex);
    if(ex > 0){
        exit(ex);
    }else{
        abort();
    }
}

int main(int argc, char **argv) try {
    dessert::output_filename() = "basic_usage.dessertout";
    dessert::install_handlers();

    //
    // Your code goes here.  It might throw a dessert,
    // or a std::exception or segfault
    //

    // For illustrative purposes, we let
    // argv select from a variety of unhappy termination
    // options.  You wouldn't do this in real code.
    if( argc != 2 ){
        Usage(argv[0]);
    }
    dessert::output_filename() = std::string("basic_usage.") + argv[1] + ".dessertout";
    if(!strcmp(argv[1], "normal")){
        exit(0);
    }else if(!strcmp(argv[1], "throwcpp")){
        throw_cpp_exception();
    }else if(!strcmp(argv[1], "throwc")){
        throw_c_exception();
    }else if(!strcmp(argv[1], "loop")){
        printf("Hit ctrl-C to exit quietly, Ctrl-\\ to get a dessert\n");
        infinite_loop();
    }else if(!strcmp(argv[1], "throwcpp.so")){
        solib_cpp_exception();
    }else if(!strcmp(argv[1], "segv")){
        solib_segv();
    }else{
        Usage(argv[0]);
    }

    return 0;
}catch(dessert& d){
    dessert::terminate_with_output(d, 1, false, &myexit);
}
