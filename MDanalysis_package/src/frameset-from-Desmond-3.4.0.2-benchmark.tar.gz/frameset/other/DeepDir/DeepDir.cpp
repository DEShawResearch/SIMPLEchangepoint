/* 
Copyright 2012-2014, D. E. Shaw Research.
All rights reserved.

Redistribution and use in source and binary forms, with or without
modification, are permitted provided that the following conditions are
met:

* Redistributions of source code must retain the above copyright
  notice, this list of conditions, and the following disclaimer.

* Redistributions in binary form must reproduce the above copyright
  notice, this list of conditions, and the following disclaimer in the
  documentation and/or other materials provided with the distribution.

* Neither the name of D. E. Shaw Research nor the names of its
  contributors may be used to endorse or promote products derived from
  this software without specific prior written permission.

THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
"AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR
A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT
OWNER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,
SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT
LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE,
DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY
THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
(INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE
OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
*/

#include "DeepDir/DeepDir.hpp"
#include <sys/types.h>
#include <sys/stat.h>
#include <stdint.h>
#include <fcntl.h>
#include <cerrno>
#include <cstdio>
#include <ios>
#include <fstream>
#include <string>
#include <stdexcept>
#include <boost/crc.hpp>
#include <boost/filesystem.hpp>

#ifdef DESRES_OS_Windows
#include <io.h>
#endif

using namespace std;
namespace bfs = boost::filesystem;

// boost/crc.hpp typedefs something called crc_32_type.  It differs by
// having an initial remainder of 0xffffffff and reflecting both
// inputs and outputs.  The documentation implies that crc_32_type is
// the checksum used in PKZip, AUTODIN II, Ethernet and FDDI.  It is
// not (apparently) the crc32 used by the unix utility cksum.
// /usr/bin/cksum's has an initial value 0, reflects neither input nor
// output, and incorporates (just before output), the non-zero octets of
// the number of bytes processed, least-significant-octet first.

typedef boost::crc_optimal<32, 0x04C11DB7, 0x0, 0xFFFFFFFF, false, false>
crc_cksum_type;

static int32_t cksum(const string &s){
    crc_cksum_type cksum;
    int length = s.length();
    cksum.process_bytes(s.data(), length);
    for(; length; length >>= 8){
        cksum.process_byte(length & 0xff);
    }
    return cksum.checksum();
}
    
// FIXME - Why not just use boost/filesystem for all our filesystem
// needs (especially mkdir).  Unfortunately, it doesn't have link,
// so it's not that useful.  It does hava a nifty exception type that
// encapsulates "who", "path1" "path2" and an errno-like error code
// that would probably be better than DDException.

static void mklink(const std::string &dirpath, const StorageSet *s, int i){
    throw DDException("mklink not implemented", 0);
}

inline std::string addslash(const std::string& s){
    return (s.rbegin()[0] == '/') ? s : s + "/";
}

void DDmkdir(const std::string &dirpath, const StorageSet *s, mode_t mode, int ndir1, int ndir2){
    std::string dpslash(addslash(dirpath));

    bfs::create_directory(dpslash);
    bfs::create_directory(dpslash + "not_hashed");

    FILE *fp = fopen((dpslash + "not_hashed/.ddparams").c_str(), "w");
    if(fp == NULL)
	throw DDException("fopen( .ddparams, \"w\" )", errno);
    if( fprintf(fp, "%d %d\n", ndir1, ndir2) < 0 ){
        fclose(fp);
	throw DDException("fprintf(.ddparams ...)", errno);
    }
    if( fclose(fp) )
	throw DDException("fclose(.ddparams)", errno);

    for(int i=0; i<ndir1; ++i){
	char sub[6];
	sprintf(sub, "%03x/", i);
	std::string dirsub = dpslash + sub;
	bfs::create_directory(dirsub);
	for(int j=0; j<ndir2; ++j){
	    char subsub[6];
	    sprintf(subsub, "%03x", j);
	    std::string dirsubsub = dirsub + subsub;
	    bfs::create_directory(dirsubsub);
	}
    }
}

bool DDisaDeepDir(const std::string& path){
    // Alternatively, we could go through a bunch of
    // stats, looking for directories and files called
    // .ddparams.  If we did that we could probably
    // return some kind of diagnaostic through errno,
    // e.g., ENOTDIR or EINVAL or something.  It just
    // doesn't seem worth the trouble.
    try{
        int ndir1, ndir2;
        DDgetparams(path, &ndir1, &ndir2);
    }catch(DDException&){
        return false;
    }
    return true;
}

std::string DDreldir(const std::string& fname, int ndir1, int ndir2){
    if( fname.find('/', 0) != string::npos )
        throw DDException("DDreldir fname contains /", 0);

    uint32_t hash = cksum(fname);

    // uint32_t u1 = ndir1;
    // uint32_t u2 = ndir2;
    uint32_t d1, d2;
    char answer[DD_RELPATH_MAXLEN];
    if(ndir1 > 0){
	d1 = hash%ndir1;
	if(ndir2 > 0){
	    d2 = (hash/ndir1)%ndir2;
	    sprintf(answer, "%03x/%03x/", d1, d2);
	}else{
	    sprintf(answer, "%03x/", d1);
	}
    }else{
	sprintf(answer, "./");
    }
    return std::string(answer);
}

void DDgetparams(const std::string& dirpath, int *ndir1, int *ndir2){
    std::string dirslash(addslash(dirpath));
    // New convention - .ddparams is in not_hashed/.
    FILE *fp = fopen((dirslash + "not_hashed/.ddparams").c_str(), "r");
    // Allow the old convention of placing .ddparams in the top-level.
    if( fp == NULL && errno == ENOENT )
        fp = fopen((dirslash + ".ddparams").c_str(), "r");
    if(fp == NULL)
	throw DDException("fopen( .ddparams, \"r\" )", errno);
    if( fscanf(fp, "%d%d", ndir1, ndir2) != 2 )
	throw DDException("fscanf(.ddparams ...) != 2", errno);
    if( fclose(fp) )
	throw DDException("fclose(.ddparams)", errno);
}

std::string DDfullpath(const std::string &dirpath, 
                       const std::string &fname, int ndir1, int ndir2){
    std::string dpslash(addslash(dirpath));
    return dpslash + DDreldir(fname, ndir1, ndir2) + fname;
}

FILE *DDfopen(const string &dirpath, const string &fname, 
              int ndir1, int ndir2, 
              const char *mode){
    // Exceptions??  Return NULL?
    return fopen(DDfullpath(dirpath, fname, ndir1, ndir2).c_str(), mode);
}

int DDopen(const string &dirpath, const string &fname, 
           int ndir1, int ndir2,
           int flags, mode_t mode){
    // Exceptions??  Return -1 and set errno?
    return open(DDfullpath(dirpath, fname, ndir1, ndir2).c_str(), flags, mode);
}

DDstream::DDstream(const std::string &dirpath, const std::string &fname, 
                   std::ios_base::openmode mode, int ndir1, int ndir2){
    open(DDfullpath(dirpath, fname, ndir1, ndir2).c_str(), mode);;
}

extern "C"{
int DDopen(const char *dirpath, const char *fname,
           int ndir1, int ndir2,
           int flags, mode_t mode){
    int ret;
    try{
        ret = DDopen(std::string(dirpath), std::string(fname),
                     ndir1, ndir2, flags, mode);
    }catch(...){
        // Use C++ if you want to know *why* it failed.
        return -1;
    }
    return ret;
}

FILE* DDfopen(const char *dirpath, const char *fname,
              int ndir1, int ndir2,
              const char *mode){
    FILE *ret;
    try{
        ret = DDfopen(std::string(dirpath), std::string(fname),
                      ndir1, ndir2, mode);
    }catch(...){
        // Use C++ if you want to know *why* it failed.
        return 0;
    }
    return ret;
}
}
