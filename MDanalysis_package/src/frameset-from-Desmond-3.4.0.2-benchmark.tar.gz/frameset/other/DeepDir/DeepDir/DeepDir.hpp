/* 
Copyright 2012-2014, D. E. Shaw Research.
All rights reserved.

Redistribution and use in source and binary forms, with or without
modification, are permitted provided that the following conditions are
met:

* Redistributions of source code must retain the above copyright
  notice, this list of conditions, and the following disclaimer.

* Redistributions in binary form must reproduce the above copyright
  notice, this list of conditions, and the following disclaimer in the
  documentation and/or other materials provided with the distribution.

* Neither the name of D. E. Shaw Research nor the names of its
  contributors may be used to endorse or promote products derived from
  this software without specific prior written permission.

THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
"AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR
A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT
OWNER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,
SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT
LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE,
DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY
THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
(INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE
OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
*/

#ifndef _DeepDirDotHpp_
#define _DeepDirDotHpp_

// This is a C++-only header file.  Most of the functions take or
// return strings.  Exceptions are used.  Etc.  None of this is
// essential to DeepDir, but it's a lot more succinct to return a
// std::string in C++ than to pass pointer-to-data and
// pointer-to-length arguments and all the other nonsense that's
// necessary to make a C API "safe" against buffer overflows.  When
// the C++ api settles down, we'll devise a set of C-callable
// interfaces.

/*
  DOCUMENTATION_BEGIN

  DeepDir - a minimal set of functions to help us manage
  "directories" with millions of files.

void DDmkdir(const std::string& dirpath, const StorageSet *s, 
                    mode_t mode, int ndir1, int ndir2);

  does mkdir(path, mode) and mkdir(path/not_hashed, mode), and then
  writes ndir1 and ndir2 into a file called not_hashed/.ddparams, as
  decimal integers.  In the new directory, creates ndir1
  subdirectories and within each of them creates ndir2 subdirectories.
  All directories will be named by simple hex digits, e.g., 0ac/01c.
  If ndir2 is 0, then no level-2 directories are created and the
  hierarchy is only one deep.  If ndir1 is 0, no subdirectories are
  created (regardless of ndir2).  ndir1 and ndir2 must be less than or
  equal to DD_NDIR_MAX (4096), so that directory names all fit in
  three hex digits.

  The directory not_hashed/ is intended for user-content that the user
  chooses not to store and retrieve via the DeepDir hashing mechanism.
  The user may populate dirpath/not_hashed with arbitrary content,
  with the exception that not_hashed/.ddparams is reserved for use by
  the library.

  On network storage, ndir1*ndir2 mkdirs can take up to ndir1*ndir2*(a
  few milliseconds).  Each directory can comfortably handle several
  thousand files.  Applications can choose ndir1 and ndir2 to trade
  off expandability for startup time.  Roughly:

     ndir1  ndir2   #files   DDmkdir time
     4096   4096   10^10(?)      hours
     256    256    10^8        minutes
     256    0      10^6   fraction of a second
     0      0      10^3        microseconds

  Other values are possible, but multiples of 16 make for nice,
  orderly, succinct directory names.

  The StorageSet argument is currently ignored.  Plans to have it
  refer to a collection of symlinks never came to anything.

  Creating a directory with permisions that do not include read and
  'execute' by owner, e.g., at least 0300, is possible but not
  recommended.
  
bool DDisaDeepDir(const std::string& path);  Returns true if path
  "looks like" a deepdir.  Specifically, it returns true if
  DDgetparams returns without throwing an exception.

void DDgetparams(const std::string& path, int *ndir1, int *ndir2); Opens the
  file path/not_hashed/.ddparams or, if there is no path/not_hashed
  directory, open path/.ddparams instead.  Parse the contents to
  obtain the values in ndir1 and ndir2.  It is an error if path is not
  a directory.  If there is no .ddparams, a DDException is thrown, but
  note that ndir1=ndir2=0 are acceptable arguments to the other DD
  functions, so it is reasonable to catch and ignore this exception.
  and to set ndir1 = ndir2 = 0, which allows one to use the DD API on
  "plain old directories".  The only limitation on "plain old directories"
  is that they may not contain user-generated files or directories with
  the specific name "not_hashed".

std::string DDreldir(const std::string &fname, int ndir1, int ndir2);
  Returns a string corresponding to the intermediate "relative directory"
  part of the path at which fname should be stored/found.  The string is
  obtained by doing a crc32 checksum (exactly the same one as the
  POSIX cksum utility), and taking the remainder with respect
  to ndir1 and ndir2.  The results are then written into a string
  using a format if neither ndir1 nor ndir2 is 0:
     sprintf(result, "%03x/%03x/", cksum%ndir1, (cksum/ndir1)%ndir2)
  If ndir2 is 0, the format is:
     sprintf(result, "%03x/", cksum%ndir1)
  If ndir1 is 0, the format is:
     sprintf(result, "./")

The remaining functions may be thought of as "derived from" the
primitive functions above.

std::string DDfullpath(const std::string &dirpath, 
                              const std::string &fname, int ndir1, int ndir2);
  Returns the concatenation: dirpath + DDreldir(fname, ndir1, ndir2) + fname
  I.e., the full path to the location at which the named file should
  be stored in the DeepDir.

The following functions encapsulate the most common ways to access
files in DeepDirs.  They return a FILE*, a file descriptor or a
DDfstream (essentially an fstream with an alternate constructor).
Reading and writing of files, as well as other filesystem supported
activities (close, stat, seek, locking, mmap, etc.) is entirely up to
the caller.

FILE *DDfopen(const char *dirpath, 
              const char *fname, int ndir1, int ndir2, const char *mode);

  returns fopen(DDfullpath(dirpath, fname, ndir1, ndir2), mode)

extern "C"{
int   DDopen(const char *dirpath, const char *fname, 
		    int ndir1, int ndir2,
                    int flags, mode_t mode);
}
  returns open(DDfullpath(dirpath, fname, ndir1, ndir2), flags, mode)
  i.e., opens the file, returning  a file descriptor.  Note DDopen
  departs from the convention of using std::string for names so that
  it can be used directly from C programs.

DDstream::DDstream(const std::string &dirpath, const std::string &fname, 
             std::ios_base::openmode, int ndir1, int ndir2);
  The fstream class in the C++ stream library is not assignable.
  In order to "return" an open fstream, we have to supply a
  constructor for a new class derived from fstream.  DDstream
  is that class, and this is its constructor.

DDresize(const std::string &dirpath, int n1, int n2) Reorganize and
  repopulate dirpath so that it has n1 primary subdirectories and n2
  secondary subdirectories and a not_hashed/ subdirectory.  It is
  permissible for n1==n2==0, in which case, the result is 'flat', with
  no subdirectories.  If an error occurs, a DDException is thrown
  immediately, potentially (probably!) leaving the directory in an
  inconsistent state.  User files, i.e., other than .ddparams and
  those created specifically to facilitate the resize) are never
  unlinked, they're only renamed, so even in the event of an error, no
  data should be lost, but some care may be required to to reconstruct
  a bona fide DeepDir.  Look for files and directories in
  dirpath/not_hashed/ddtmpXXXXXXX in the event of an error.

  DOCUMENTATION_END
*/


#include <stdio.h>

#include <fstream>
#include <ios>
#include <stdexcept>
#include <sys/types.h>

#define DD_MAXNDIR (16*16*16)  /* 3 hex digits */
#define DD_RELPATH_MAXLEN (9) /* %03x/%03x/\0 */

struct StorageSet;  // Until we have a real StorageSet.h

extern void DDmkdir(const std::string& dirpath, const StorageSet *s, 
                    mode_t mode, int ndir1, int ndir2);
extern bool DDisaDeepDir(const std::string& dirpath);
extern std::string DDreldir(const std::string &fname, int ndir1, int ndir2);
extern void DDgetparams(const std::string &dirpath, int *ndir1, int *ndir2);


/* Convenience functions.  If the arguments ndir1 and ndir2
 * are 0, then ignore them and read them with DDgetparams.
 * N.B.  What about a *real* ndir1=ndir2=0 directory??
 */
extern std::string DDfullpath(const std::string &dirpath, 
                              const std::string &fname, int ndir1, int ndir2);
extern FILE *DDfopen(const std::string &dirpath, const std::string &fname, 
                     int ndir1, int ndir2,
                     const char *mode);
extern int   DDopen(const std::string &dirpath, const std::string &fname, 
                    int ndir1, int ndir2,
                    int flags, mode_t mode);
extern void DDresize(const std::string& root, int n1, int n2);

extern "C"{
    extern FILE *DDfopen(const char *dirpath, const char *fname, 
                         int ndir1, int ndir2,
                         const char *mode);
    extern int   DDopen(const char *dirpath, const char *fname, 
                        int ndir1, int ndir2,
                        int flags, mode_t mode);
}

struct DDstream : public std::fstream {
    DDstream(const std::string &dirpath, const std::string &fname, 
             std::ios_base::openmode, int ndir1, int ndir2);
};

// Until we have a unified exception mechanism:
// Should we bother to format errno into the output of what()
// See: http://www.boost.org/more/error_handling.html
//      http://www.boost.org/libs/filesystem/doc/exception.htm
// Even more ambitious: http://www.revergestudios.com/boost-exception/boost-exception.htm
class DDException : public std::runtime_error{
 public:
    int eno;
    DDException(const std::string &text, int _eno=0) : std::runtime_error(text), eno(_eno){}
};


#endif /* _DeepDirDotHpp_ */
