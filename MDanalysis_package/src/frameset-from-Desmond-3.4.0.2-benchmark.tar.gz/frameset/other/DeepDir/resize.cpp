/* 
Copyright 2012-2014, D. E. Shaw Research.
All rights reserved.

Redistribution and use in source and binary forms, with or without
modification, are permitted provided that the following conditions are
met:

* Redistributions of source code must retain the above copyright
  notice, this list of conditions, and the following disclaimer.

* Redistributions in binary form must reproduce the above copyright
  notice, this list of conditions, and the following disclaimer in the
  documentation and/or other materials provided with the distribution.

* Neither the name of D. E. Shaw Research nor the names of its
  contributors may be used to endorse or promote products derived from
  this software without specific prior written permission.

THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
"AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR
A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT
OWNER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,
SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT
LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE,
DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY
THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
(INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE
OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
*/

#include "DeepDir/DeepDir.hpp"
#include <cstdio>
#include <string>
#include <cstdlib>
#include <cerrno>
#include <dirent.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <unistd.h>
#include <string.h>

#if 0
#include <diag/diag.h>
DIAG_DEFINE_STDFILEKEY;
#else
#define DIAG(x)
#endif

using namespace std;

namespace{
    // repot_contents() - take the contents of dir and rename it into
    // the path/n1/n2 deepdir.
    void repot_contents(const string& from, const string& to, int n1, int n2, const char *skip){
        DIR *dirp = opendir(from.c_str());
        if(dirp == 0)
            throw DDException("opendir " + from, errno);
        string toslash = to + "/";
        string fromslash = from + "/";
        errno = 0;
        struct dirent *dp;
        DIAG("repot_contents " << from << " " << to << " " << n1 << " " << n2 << " " << skip << "\n");
        while( dp = readdir(dirp) ){
            if( strcmp(dp->d_name, ".") == 0 ||
                strcmp(dp->d_name, "..") == 0 )
                continue;
            if( skip && strcmp(skip, dp->d_name)==0 ){
                DIAG("skipping " << dp->d_name << "\n");
                continue;
            }
            string tofile = toslash + DDreldir(dp->d_name, n1, n2) + dp->d_name;
            string fromfile = fromslash + dp->d_name;
            DIAG("rename " << fromfile << " " << tofile << "\n");
            if( rename(fromfile.c_str(), tofile.c_str()) < 0 )
                throw DDException("rename " + fromfile + " " + tofile, errno);
        }
        if(errno)
            throw DDException("readdir", errno);
    }

    void rmdir(const string& s){
        DIAG("rmdir " << s << "\n");
        if( ::rmdir(s.c_str()) < 0 )
            throw DDException("rmdir " + s, errno);
    }

    // glibc complains that 'the use of tempnam is dangerous.  Better
    // to use mkstemp'.  Umm.  Right.  But I'm creating a directory.
    // So I have to do mkstemp, then close and unlink, and then mkdir to
    // avoid this nagging?  Sigh...
    std::string tempnam_nonag(const char *dir, const char *pfx){
        // 8 for /, terminal NUL and 6 X's.
        char *space = (char *)malloc(strlen(dir) + strlen(pfx) + 8);
        if( space == 0 )
            throw DDException("malloc");
        sprintf(space, "%s/%sXXXXXX", dir, pfx);
        int fd;
        if( (fd = mkstemp(space)) < 0 ){
            free(space);
            throw DDException("mkstemp " + std::string(space), errno);
        }
        std::string ret(space);
        free(space);
        if( close(fd) < 0 )
            throw DDException("close fd from mkstemp", errno);
        if( unlink(ret.c_str()) < 0 )
            throw DDException("unlink " + ret, errno);
        return ret;
    }
}

// DDresize - resize a deepdir "in place".  Strategy: create a
// temporary dd.  Copy everything into it, then rename its contents
// back into the original root.
void DDresize(const std::string& root, int n1, int n2){
    int oldn1, oldn2;
    try{
        DDgetparams(root, &oldn1, &oldn2);
    }catch(DDException &e){
        // Don't worry about missing .ddparams.  Just assume
        // it's a flat directory.
        oldn1 = oldn2 = 0;
    }

    if( (oldn1 != 0) && (n1 == 0) ){
        // We're creating a flat directory out of a non-flat
        // directory.  Take care that 'not_hashed' is not
        // present in the non-flat directory.  If it is,
        // bail out before we damage anything.
        string not_hashed = root + "/" + DDreldir("not_hashed", oldn1, oldn2) + "not_hashed";
        if( access(not_hashed.c_str(), F_OK) == 0 )
            throw DDException("existing file 'not_hashed' not permissible in a flat (n1==n2==0) DeepDir");
    }
    struct stat sb;
    if( stat(root.c_str(), &sb) < 0 )
        throw DDException("stat " + root, errno);
    mode_t newmode = sb.st_mode;
    // Bail out before we damage anything if the directory isn't writable.
    if( access(root.c_str(), W_OK|X_OK) < 0 )
        throw DDException("resize requires wx permissions on the directory");

    // If there isn't already a not_hashed, then create one.
    string not_hashed = root + "/not_hashed";
    if( stat(not_hashed.c_str(), &sb) < 0 ){
        if( errno == ENOENT ){
            if( mkdir(not_hashed.c_str(), newmode) < 0 )
                throw DDException("mkdir " + not_hashed, errno);
            if( stat(not_hashed.c_str(), &sb) < 0 )
                throw DDException("stat " + not_hashed, errno);
        }else{
            throw DDException("stat " + not_hashed, errno);
        }
    }
    if( !S_ISDIR(sb.st_mode) )
        throw DDException(root + "/not_hashed exists but is not a directory");
            
    string tmpdirname = tempnam_nonag((root + "/not_hashed").c_str(), "ddtmp");
    DDmkdir(tmpdirname, 0, newmode, n1, n2);
    
    // unlink not_hashed/.ddparams.  If it doesn't already exist, don't
    // sweat it.
    if( unlink((root + "/not_hashed/.ddparams").c_str()) < 0 ){
        if( errno != ENOENT)
            throw DDException("unlink " + root + "/not_hashed/.ddparams", errno);
    }
    if( unlink((root + "/.ddparams").c_str()) < 0 ){
        if( errno != ENOENT)
            throw DDException("unlink " + root + "/not_hashed/.ddparams", errno);
    }

    // copy everything to tmpdir, giving it the new deepdir structure
    if(oldn1 == 0){
        repot_contents(root, tmpdirname, n1, n2, "not_hashed");
    }else{
        for(int i=0; i<oldn1; ++i){
            char sub[6];
            sprintf(sub, "/%03x", i);
            string dirsub = root + sub;
            if( oldn2 == 0 ){
                repot_contents(dirsub, tmpdirname, n1, n2, NULL);
            }else{
                 for(int j=0; j<oldn2; ++j){
                    char subsub[6];
                    sprintf(subsub, "/%03x", j);
                    string dirsubsub = dirsub + subsub;
                    repot_contents(dirsubsub, tmpdirname, n1, n2, NULL);
                    rmdir(dirsubsub);
                }
            }
            rmdir(dirsub);
        }
    }    
    // copy everything back from the tmpdir to the root.
    // With n1=n2=0, we just do a flat copy, which is exactly
    // what we want.
    repot_contents(tmpdirname, root, 0, 0, "not_hashed");
    if( rename( (tmpdirname + "/not_hashed/.ddparams").c_str(), (root + "/not_hashed/.ddparams").c_str()) < 0 )
        throw DDException("rename " + tmpdirname + "/not_hashed/.ddparams" + root + "/not_hashed/.ddparams", errno);
    rmdir(tmpdirname + "/not_hashed");
    rmdir(tmpdirname);
}

