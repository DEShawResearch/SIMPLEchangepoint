/* 
Copyright 2012-2014, D. E. Shaw Research.
All rights reserved.

Redistribution and use in source and binary forms, with or without
modification, are permitted provided that the following conditions are
met:

* Redistributions of source code must retain the above copyright
  notice, this list of conditions, and the following disclaimer.

* Redistributions in binary form must reproduce the above copyright
  notice, this list of conditions, and the following disclaimer in the
  documentation and/or other materials provided with the distribution.

* Neither the name of D. E. Shaw Research nor the names of its
  contributors may be used to endorse or promote products derived from
  this software without specific prior written permission.

THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
"AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR
A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT
OWNER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,
SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT
LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE,
DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY
THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
(INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE
OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
*/

#include "FrameSet/FrameSet.hxx"
#include "FrameSet/Frame.hxx"
#include "FrameSet/FrameSetExceptions.hxx"
#include "UnitTestCommon.hxx"

#include <iostream>
#include <exception>
#include <string>
#include <cassert>
#include <cstdio>

#include <sys/types.h>
#include <sys/stat.h>

#ifdef DESRES_OS_Windows
#include <direct.h>
#define mkdir(a,b) _mkdir(a)
#endif

int main(void) {
  struct stat statbuf;
  const std::string name("foo.dir");
  const std::string name2("bar.dir");

  try {

    // -----------------------------------------------
    // Should just remove the link if the "directory"
    // is a link (and leave the target alone).
    // -----------------------------------------------
    {
      ::mkdir("the_real_directory.dir",0777);
      ::mkdir("the_real_directory.dir/subdir",0777);
      ::unlink("the_link_directory.dir");
      if (::symlink("the_real_directory.dir",
                    "the_link_directory.dir") < 0) {
        perror("symlink");
      }
      struct stat statbuf;
      assert(lstat("the_real_directory.dir",&statbuf) == 0);
      assert(S_ISDIR(statbuf.st_mode));
      assert(lstat("the_real_directory.dir/subdir",&statbuf) == 0);
      assert(S_ISDIR(statbuf.st_mode));
      assert(lstat("the_link_directory.dir",&statbuf) == 0);
      assert(S_ISLNK(statbuf.st_mode));

      frameset::FrameSet::recursivelyRemove("the_link_directory.dir");
      assert(lstat("the_real_directory.dir",&statbuf) == 0);
      assert(S_ISDIR(statbuf.st_mode));
      assert(lstat("the_real_directory.dir/subdir",&statbuf) == 0);
      assert(S_ISDIR(statbuf.st_mode));
      assert(lstat("the_link_directory.dir",&statbuf) < 0);

      frameset::FrameSet::recursivelyRemove("the_real_directory.dir");
      assert(lstat("the_real_directory.dir",&statbuf) < 0);
      assert(lstat("the_real_directory.dir/subdir",&statbuf) < 0);
      assert(lstat("the_link_directory.dir",&statbuf) < 0);
    }

    // -----------------------------------------------
    // Open for write removes the directory if it
    // exists when you use w! (fails if it exists with w)
    // -----------------------------------------------
    {
      frameset::FrameSet frameset(name,"w!");
      assert(frameset.size() == 0);

      // -----------------------------------------------
      // Recover the starting filename.
      // The name must map to a full pathname
      // -----------------------------------------------
      const std::string& dirname = frameset.name();
#ifdef DESRES_OS_Windows
      assert(dirname.size() > 1 && dirname[1] == ':');
#else
      assert(dirname.size() > 0 && dirname[0] == '/');
#endif

      // -----------------------------------------------
      // Map a flat name into a hierarchical name.
      // That name must start with the full directory
      // path in this basic model.
      // -----------------------------------------------
      std::string foo = frameset.hierarchicalName("foo");
      assert(foo.size() > dirname.size());
      assert(foo.substr(0,dirname.size()) == dirname);

      // -----------------------------------------------
      // Map a frame number to a heirarchical name
      // -----------------------------------------------
      std::string framefile = frameset.framefile(3);
      assert(framefile.size() > dirname.size());
      assert(framefile.substr(0,dirname.size()) == dirname);
    }

    // -----------------------------------------------
    // Some sort of file by that name should exist
    // (does not have to be a directory, could be
    // a top level index file or something).
    // -----------------------------------------------
    if (::stat(name.c_str(),&statbuf) < 0) {
      throw frameset::IoErrnoException("stat " + name,DESSERT_LOC);
    }

    // -----------------------------------------------
    // We can open it for reading or appending
    // -----------------------------------------------
    frameset::FrameSet reading(name,"r");
    frameset::FrameSet reading2(name);
    frameset::FrameSet appending(name,"a");

    // -----------------------------------------------
    // We can open for append even if it doesn't exist.
    // -----------------------------------------------
    frameset::FrameSet::recursivelyRemove(name2);
    frameset::FrameSet appending2(name2,"a");
    if (::stat(name2.c_str(),&statbuf) < 0) {
      throw frameset::IoErrnoException("stat " + name,DESSERT_LOC);
    }

    // -----------------------------------------------
    // Can build a blank frameset, but its not very
    // interesting.
    // -----------------------------------------------
    frameset::FrameSet blank;

    // -----------------------------------------------
    // Cannot get the directory name from a blank.
    // -----------------------------------------------
    MUST_THROW(frameset::FrameSetException,{
        blank.name();
      });

    // -----------------------------------------------
    // Cannot map a hierarchical name from a blank.
    // -----------------------------------------------
    MUST_THROW(frameset::FrameSetException,{
      blank.hierarchicalName("foo");
      });

    // -----------------------------------------------
    // Cannot get a framefile from a blank.
    // -----------------------------------------------
    MUST_THROW(frameset::FrameSetException,{
      blank.framefile(0);
      });

    // -----------------------------------------------
    // The mode must be "r", "w", or "a"
    // -----------------------------------------------
    MUST_THROW(frameset::FrameSetException,{
      frameset::FrameSet naughty("goo.dir","z");
      });

    // -----------------------------------------------
    // Some coverage bits
    // -----------------------------------------------
    assert(frameset::Frame::lobytes(static_cast<uint32_t>(12345)) == 12345);
    assert(frameset::Frame::hibytes(static_cast<uint32_t>(12345)) == 0);

    frameset::Frame coverage_frame;
    const frameset::Frame& const_coverage_frame = coverage_frame;
    frameset::FrameSet::FramePtr more_data_frame(new frameset::Frame);

    coverage_frame.set_value("SOMETHING",3);
    coverage_frame.set_value("SOMETHING_TO_DELETE",3);
    coverage_frame.del("SOMETHING_TO_DELETE");

    coverage_frame.knowsType("int32_t");

    coverage_frame.sameEndianism();

    coverage_frame.type("SOMETHING");

    coverage_frame.count("SOMETHING");

    coverage_frame.elementsize("SOMETHING");

    std::set<std::string> types;
    const_coverage_frame.types(types);

    coverage_frame.set_default_frame(more_data_frame);
    coverage_frame.get_default_frame();
    const_coverage_frame.get_default_frame();

    try {
      coverage_frame.count("not an attribute");
    } catch (...) {}
    try {
      coverage_frame.count("not an attribute",false);
    } catch (...) {}

    try {
      throw frameset::NotImplementedException(__FILE__,__LINE__,"f");
    } catch (...) {}

    try {
      throw frameset::ErrnoException("/some/where");
    } catch (const frameset::ErrnoException& e) {
      e.error();
    }

    try {
      throw frameset::IoErrnoException("message");
    } catch (...) {}

    try {
      throw frameset::DereferenceError("message");
    } catch (...) {}


  } catch (std::exception& e) {
    std::cerr << e.what() << std::endl;
    return 1;
  }

  // -----------------------------------------------
  // Clean up on success
  // -----------------------------------------------
  frameset::FrameSet::recursivelyRemove(name);
  frameset::FrameSet::recursivelyRemove(name2);


  return 0;
}


