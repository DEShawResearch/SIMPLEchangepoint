/* 
Copyright 2012-2014, D. E. Shaw Research.
All rights reserved.

Redistribution and use in source and binary forms, with or without
modification, are permitted provided that the following conditions are
met:

* Redistributions of source code must retain the above copyright
  notice, this list of conditions, and the following disclaimer.

* Redistributions in binary form must reproduce the above copyright
  notice, this list of conditions, and the following disclaimer in the
  documentation and/or other materials provided with the distribution.

* Neither the name of D. E. Shaw Research nor the names of its
  contributors may be used to endorse or promote products derived from
  this software without specific prior written permission.

THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
"AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR
A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT
OWNER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,
SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT
LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE,
DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY
THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
(INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE
OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
*/

// NOTE:  Cannot use ::ntohl or htonl since under optimization
// they are turned into efficient macros

#include "FrameSet/Frame.hxx"

#ifdef DESRES_OS_Windows
#include <Windows.h>
#define __LITTLE_ENDIAN 1234
#else
#include <netinet/in.h> // For ntohl
#endif

#include <cstring>

namespace frameset {

  /*!
   * See RFC 1146 for Fletcher's Checksum (http://tools.ietf.org/html/rfc1146)
   */
  uint32_t fletcher( uint16_t *data, size_t len ) {
    uint32_t sum1 = 0xffff, sum2 = 0xffff;
 
    while (len) {
      unsigned tlen = len > 360 ? 360 : len;
      len -= tlen;
      do {
        sum1 += *data++;
        sum2 += sum1;
      } while (--tlen);
      sum1 = (sum1 & 0xffff) + (sum1 >> 16);
      sum2 = (sum2 & 0xffff) + (sum2 >> 16);
    }
    /* Second reduction step to reduce sums to 16 bits */
    sum1 = (sum1 & 0xffff) + (sum1 >> 16);
    sum2 = (sum2 & 0xffff) + (sum2 >> 16);
    return sum2 << 16 | sum1;
  }

  /*!
   * Align an integer to a boundary.  I should likely convert this
   * to an inline function and use masking with border assumed
   * to be a power of two (or make it simply a mask).
   */
  uint64_t Frame::alignInteger(const uint64_t& x,unsigned border) {
    return x + (border - x%border)%border;
  }


  /*!
   * Extracts the low 32 bits of a 32 bit integer (just those bits)
   * We include this routine because when we are cracking size_t
   * values on a 32-bit architecture, we still need to crack out
   * the low and high bits (though high bits are always zero in
   * this case).
   */
  uint32_t Frame::lobytes(const uint32_t& x) {
    return x;
  }

  /*!
   * Extract the high 32 bits of a 32 bit integer (always 0)
   */
  uint32_t Frame::hibytes(const uint32_t& x) {
    return 0;
  }

  /*!
   * Extracts the low 32 bits of a 64 bit integer by masking.
   */
  uint32_t Frame::lobytes(const uint64_t& x) {
    uint32_t mask = 0xffffffff;
    return x & mask;
  }

  /*!
   * Extract the high 32 bits of a 64 bit integer by shifting.
   */
  uint32_t Frame::hibytes(const uint64_t& x) {
    return x >> 32;
  }

  /*!
   * Extract the low 32 bits of a 64 bit float as an integer.
   */
  uint32_t Frame::lobytes(const double& x) {
    union {
      uint64_t ival;
      double   dval;
    } u;
    u.dval = x;
    return lobytes(u.ival);
  }

  /*!
   * Extract the high 32 bits of a 64 bit float as an integer.
   */
  uint32_t Frame::hibytes(const double& x) {
    union {
      uint64_t ival;
      double   dval;
    } u;
    u.dval = x;
    return hibytes(u.ival);
  }

  /*!
   * Reassemble a 64 bit integer from 32 bit components.
   */
  uint64_t Frame::assemble64(uint32_t lo, uint32_t hi) {
    uint64_t hi64 = hi;
    return (hi64 << 32) | lo;
  }

  /*!
   * Reassemble a 64 bit double from 32 bit components.
   */
  double Frame::assembleDouble(uint32_t lo, uint32_t hi) {
    union {
      uint64_t ival;
      double   dval;
    } u;
    u.ival = assemble64(lo,hi);
    return u.dval;
  }
  
  /*!
   * Required virtual destructor.
   */
  FrameInfo::~FrameInfo() {
  }

  // No reachable path to this routine...
  ///*!
  // * This routine factors out the meta data lookup that shows
  // * up in several methods below.  This enables us to carefully
  // * check that an attribute exists and throw an AttributeError
  // * as needed.
  // */
  //FrameInfo::meta_t& Frame::lookup_meta(const std::string& label, bool chase) {
  //  meta_map_t& meta_map = meta();
  //  meta_map_t::iterator meta_p = meta_map.find(label);
  //  if (meta_p != meta_map.end()) return meta_p->second;
  //  else if( chase && m_more_data ) return m_more_data->lookup_meta(label, chase);
  //  else throw AttributeError(label);
  //}
   
  /*!
   * This routine factors out the meta data lookup that shows
   * up in several methods below.  This enables us to carefully
   * check that an attribute exists and throw an AttributeError
   * as needed.
   */
  const FrameInfo::meta_t& Frame::lookup_meta(const std::string& label, bool chase) const {
    const meta_map_t& meta_map = meta();
    meta_map_t::const_iterator meta_p = meta_map.find(label);
    if (meta_p != meta_map.end()) return meta_p->second;
    else if( chase && m_more_data ) return m_more_data->lookup_meta(label, chase);
    else throw AttributeError(label);
  }

  /*!
   * Accessor function that guards the frame's meta information.
   * It is virtual, so derived classes (like ReaderFrame) can
   * force information to be loaded only when needed.  A more
   * clever scheme would let us read in only the bytes we needed
   * when they are needed.
   */
  FrameInfo::meta_map_t& FrameInfo::meta() {
    return m_meta;
  }

  /*!
   * Accessor function guarding meta data.
   */
  const FrameInfo::meta_map_t& FrameInfo::meta() const  {
    return m_meta;
  }

  /*!
   * Accessor function guarding data blobs associated with
   * frame elements.
   */
  FrameInfo::data_map_t& FrameInfo::data() {
    return m_data;
  }

  /*!
   * Accessor function guarding data blobs associated with
   * frame elements.
   */
  const FrameInfo::data_map_t& FrameInfo::data() const {
    return m_data;
  }

  /*!
   * Accessor function guarding the type names associated with
   * frame elements.  The list is in typecode order (i.e. the
   * 0'th element is the name of typecode 0, the 1st element
   * is the name of typecode 1, etc...).
   */
  FrameInfo::typecode_imap_t& FrameInfo::typecodes() {
    return m_typecodes;
  }

  /*!
   * Accessor function guarding the type names associated with
   * frame elements.
   */
  const FrameInfo::typecode_imap_t& FrameInfo::typecodes() const {
    return m_typecodes;
  }

  /*!
   * The magic number spells 'DESM' when placed in network
   * byte order at the head of a file.
   */
  const uint32_t Frame::s_magic = 0x4445534d;

  /*!
   * Current version is 0.0.1-0
   */
  const uint32_t Frame::s_version = 0x00000100;

  /*!
   * 4 byte alignment check.
   */
  const uint32_t Frame::s_irosetta = 0x12345678;

  /*!
   * 4 byte float for format and alignment check.
   */
  const float Frame::s_frosetta = 1234.5;

  /*!
   * 8 byte float for format and alignment check.
   */
  const double Frame::s_drosetta = 1234.5e6;

  /*!
   * Avoid the current non-portability of 8 byte integer
   * constants by assembling lrosetta from a low and
   * high half.
   */
  const uint32_t Frame::s_lrosetta_lo = 0x89abcdef;

  /*!
   * Other half of lrosetta.
   */
  const uint32_t Frame::s_lrosetta_hi = 0x01234567;

  /*!
   * For better alignment reading multiple frames in a file.
   */
  const uint32_t Frame::s_blocksize = 4096;

  /*!
   * For better alignment internal to frames we align to
   * a doubleword boundary.
   */
  const uint32_t Frame::s_alignsize = 8;

  /*!
   * An empty frame.
   */
  Frame::Frame() {
  }

  /*!
   * Add a pointer to a frame with 'more' data
   */
  void Frame::set_default_frame(boost::shared_ptr<Frame> more){
    m_more_data = more;
  }

  /*! 
   * Get the pointer to a frame with 'more' data
   */
  boost::shared_ptr<Frame> Frame::get_default_frame(){
    return m_more_data;
  }

  /*! 
   * Get the pointer to a frame with 'more' data
   */
  const boost::shared_ptr<Frame> Frame::get_default_frame() const{
    return m_more_data;
  }

  /*!
   * Clean up the frame.  This will release the hold the frame
   * has on any data blobs that are shared with external data.
   */
  Frame::~Frame() {
  }

  /*!
   * Associate some typed data with a label.  This entails
   * creating a meta-data entry with type and size information
   * and stashing it into the meta_map and pushing the
   * data into the data_map.
   */
  void Frame::set(std::string label, const BaseBlob& blob) {
    meta_map_t& meta_map = meta();
    data_map_t& data_map = data();

    meta_t meta_entry = {
      typecodes().insert(blob.type()),
      blob.elementsize(),
      blob.count()
    };
    meta_map[label] = meta_entry;
    data_map[label] = blob;
  }
    
  /*!
   * Return the data associated with a particular label.
   * We throw an AttributeError if the label is not
   * present.  The data is returned as a generic blob
   * that will autoshape itself to a typed blob on
   * assignment or copy (throwing a TypeSafetyException
   * if the target is the wrong type).
   */
  BaseBlob Frame::get(std::string label, bool chase) {
    data_map_t& data_map = data();
    data_map_t::iterator p = data_map.find(label);
    if (p != data_map.end()) return p->second;
    else if (chase && m_more_data) return m_more_data->get(label, chase);
    else throw AttributeError(label);
  }

  /*!
   * Return the data associated with a particular label.
   * We throw an AttributeError if the label is not
   * present.  The data is returned as a generic blob
   * that will autoshape itself to a typed blob on
   * assignment or copy (throwing a TypeSafetyException
   * if the target is the wrong type).
   */
  const BaseBlob Frame::get(std::string label, bool chase) const {
    const data_map_t& data_map = data();
    data_map_t::const_iterator p = data_map.find(label);
    if (p != data_map.end()) return p->second;
    else if (chase && m_more_data) return m_more_data->get(label, chase);
    else throw AttributeError(label);
  }
    
  /*!
   * Remove a field from the meta_map and data_map.  The
   * type data is not cleansed so that if this was the
   * last instance of a particular type, that type name
   * remains in the typetable.  Removing the type would
   * entail re-typecoding all the fields since the code
   * number is the offset of the label in the typecode
   * list.
   */
  void Frame::del(std::string label) {
    data_map_t& data_map = data();
    data_map_t::iterator p = data_map.find(label);
    if (p == data_map.end()) throw AttributeError(label);

    meta_map_t& meta_map = meta();
    meta_map_t::iterator p2 = meta_map.find(label);
    if (p2 == meta_map.end()) throw AttributeError(label);

    data_map.erase(p);
    meta_map.erase(p2);
  }

  /*!
   * Returns true if the named field exists in this frame
   * and false otherwise.
   */
  bool Frame::has(std::string title, bool chase) const {
    const meta_map_t& meta_map = meta();
    return ( meta_map.find(title) != meta_map.end() ||
             (chase && m_more_data && m_more_data->has(title, chase)) );
  }

  /*!
   * Returns true if the type named is known by this frame.
   * Note that if all fields of a particular type are
   * deleted, the frame still "knows" the type even if
   * there are no such actual fields!
   */
  bool Frame::knowsType(std::string type, bool chase) const {
    return typecodes().count(type) 
      || (chase && m_more_data && m_more_data->knowsType(type, chase));
  }

  /*!
   * Insert the types known by this frame into result
   */
  void Frame::types(std::set<std::string> &result, bool chase) const {
    result.insert(typecodes().begin(), typecodes().end());
    if(chase && m_more_data)
      m_more_data->types(result, chase);
  }

  /*!
   * Insert the Frame's labels into result.
   */
  void Frame::labels(std::set<std::string> &result, bool chase) const {
    const meta_map_t& meta_map = meta();
    for(meta_map_t::const_iterator p = meta_map.begin();
        p != meta_map.end(); ++p) {
      result.insert(p->first);
    }
    if(chase && m_more_data)
      m_more_data->labels(result, chase);
  }

  /*!
   * The endianism related to this frame.  Here in the base
   * Frame, this is simply the machine endianism.  When we
   * read frames in from disk, the endianism may be different.
   */
  uint32_t Frame::endianism() const {
    return machineEndianism();
  }

  /*!
   * The byte order associated with this machine.  We use
   * 1234 for little endian, 4321 for big endian, and
   * 3412 for the unlikely PDB endianism.
   */
  uint32_t Frame::machineEndianism() {
#if __BYTE_ORDER == __LITTLE_ENDIAN
    uint32_t byteorder = 1234;
#else
#if __BYTE_ORDER == __BIG_ENDIAN
    uint32_t byteorder = 4321;
#else
#ifdef PDB_ENDIAN
#if __BYTE_ORDER == __PDB_ENDIAN
    uint32_t byteorder = 3412;
#endif
#endif
#endif
#endif
    // If we get a compile error here, then __BYTE_ORDER
    // has an unexpected value.
    return byteorder;
  }

  /*!
   * Compares the frame endianism against the machine's endianism.
   */
  bool Frame::sameEndianism() const {
    return (endianism() == machineEndianism());
  }

  /*!
   * The type associated with the named field.  If the field
   * doesn't exist, then an AttributeError is thrown.
   */
  std::string Frame::type(std::string label, bool chase) const {
    // grrr! I'd like to use lookup_meta, but I cannot because I need
    // to apply the local typecodes() map to the result.
    const meta_map_t& meta_map = meta();
    meta_map_t::const_iterator meta_p = meta_map.find(label);
    if (meta_p != meta_map.end()) return typecodes()[meta_p->second.type];
    else if( chase && m_more_data ) return m_more_data->type(label, chase);
    else throw AttributeError(label);
  }

  /*!
   * Grabs the field count from the meta data for a field.
   */
  uint64_t Frame::count(std::string label, bool chase) const {
    const meta_t& meta = lookup_meta(label, chase);
    return meta.count;
  }

  /*!
   * Grabs the elementsize from the meta data for a field.
   */
  uint32_t Frame::elementsize(std::string label, bool chase) const {
    const meta_t& meta = lookup_meta(label, chase);
    return meta.elementsize;
  }

  /*!
   * Computes number of bytes needed to store a field from its
   * meta data.
   */
  uint64_t Frame::nbytes(std::string label, bool chase) const {
    const meta_t& meta = lookup_meta(label, chase);
    return meta.elementsize*meta.count;
  }


  /*!
   * Size of header block
   */
  uint64_t Frame::compute_header_size() const {
    uint64_t header_size = sizeof(header_t);
    header_size = alignInteger(header_size,s_alignsize);
    return header_size;
  }

  /*!
   * Size of all the names, null terminated + null at end.
   */
  uint64_t Frame::compute_typename_size() const {
    const typecode_imap_t& typecode_list = typecodes();
    
    uint64_t typename_size = 0;
    for(typecode_imap_t::const_iterator p = typecode_list.begin();
        p != typecode_list.end(); ++p) {
      typename_size += (*p).size() + 1; // 1 for the null
    }
    typename_size++; // Add the super terminating null
    typename_size = alignInteger(typename_size,s_alignsize);
    return typename_size;
  }

  /*!
   * Size of all meta data when stored to disk.  Note that
   * we round up the reported size to the alignment
   * boundary.
   */
  uint64_t Frame::compute_meta_size() const {
    const meta_map_t& meta_map = meta();
    uint64_t meta_size =  meta_map.size()*sizeof(metadisk_t);
    meta_size = alignInteger(meta_size,s_alignsize);
    return meta_size;
  }

  /*!
   * Labels are stored:
   *
   *    xxx0yyy0zz00
   *
   * so count the total string length, plus a separating
   * null, plus a terminating null.
   */
  uint64_t Frame::compute_label_size() const {
    const meta_map_t& meta_map = meta();
    uint64_t label_size = 0;

    for(meta_map_t::const_iterator p = meta_map.begin();
        p != meta_map.end(); ++p) {
      label_size += (*p).first.size() + 1; // 1 for the null
    }

    // -----------------------------------------------
    // Add a final terminating null
    // -----------------------------------------------
    label_size++;
    label_size = alignInteger(label_size,s_alignsize);
    return label_size;
  }

  /*!
   * Each scalar field is rounded to the nearest multiple of
   * 8 so that we can be sure that items fall on double word
   * boundaries.  We are separating the scalars and empty
   * fields out so that they will cluster at the front of
   * the data on disk to make reading faster for mmap'd data
   * or to reduct the amount of reading needed for just
   * scalar quantities.  Note that each field is padded
   * to the alignment boundary.  This means that all
   * fields start on the alignment boundary.  This will
   * simplify matters if we are trying to read a field
   * directly from mmap'd data on a machine where alignment
   * matter for either performance or for correctness.
   */
  uint64_t Frame::compute_scalar_size() const {
    const data_map_t& data_map = data();
    uint64_t scalar_size = 0;

    for(data_map_t::const_iterator p = data_map.begin();
        p != data_map.end(); ++p) {
      const BaseBlob& blob = (*p).second;
      if (blob.count() <= 1) scalar_size += alignInteger(blob.nbytes(),s_alignsize);
    }

    return scalar_size;
  }

  /*!
   * Compute the number of bytes needed to hold all the fields.
   * As with scalar fields, each field is padded to an alignment
   * boundary.
   */
  uint64_t Frame::compute_field_size() const {
    const data_map_t& data_map = data();
    uint64_t field_size = 0;

    for(data_map_t::const_iterator p = data_map.begin();
        p != data_map.end(); ++p) {
      const BaseBlob& blob = (*p).second;
      if (blob.count() > 1) field_size += alignInteger(blob.nbytes(),s_alignsize);
    }

    return field_size;
  }

  /*!
   * I'm not computing the CRC at the moment, but the frame
   * still reserves space for it.
   */
  uint64_t Frame::compute_crc_size() const {
    uint64_t crc_size = sizeof(uint32_t);

    return crc_size;
  }

  /*!
   * Individual fields are padded to a word alignment, but the
   * whole block is padded to a pagesize alignment.  This will
   * allow us to put multiple frames into a file if it ever
   * comes to it.
   */
  uint64_t Frame::compute_padding_size(uint64_t padding_offset) const {
    uint64_t padded_size = alignInteger(padding_offset,s_blocksize);
    uint64_t padding_size = padded_size - padding_offset;
    return padding_size;
  }

  /*!
   * Compute subblock sizes and offsets, returning the number
   * of bytes that will fully contain the serialization of the
   * frame.
   */
  uint64_t Frame::compute_blocksizes(uint64_t& size_header_block,
                                     uint64_t& offset_header_block,
                                     uint64_t& size_typename_block,
                                     uint64_t& offset_typename_block,
                                     uint64_t& size_meta_block,
                                     uint64_t& offset_meta_block,
                                     uint64_t& size_label_block,
                                     uint64_t& offset_label_block,
                                     uint64_t& size_scalar_block,
                                     uint64_t& offset_scalar_block,
                                     uint64_t& size_field_block,
                                     uint64_t& offset_field_block,
                                     uint64_t& size_crc_block,
                                     uint64_t& offset_crc_block,
                                     uint64_t& size_padding_block,
                                     uint64_t& offset_padding_block) const {

    // -----------------------------------------------
    // Compute sizes and offsets
    // -----------------------------------------------
    offset_header_block = 0;
    size_header_block = compute_header_size();

    offset_meta_block = offset_header_block + size_header_block;
    size_meta_block = compute_meta_size();

    offset_typename_block = offset_meta_block + size_meta_block;
    size_typename_block = compute_typename_size();

    offset_label_block = offset_typename_block + size_typename_block;
    size_label_block = compute_label_size();

    offset_scalar_block = offset_label_block + size_label_block;
    size_scalar_block = compute_scalar_size();

    offset_field_block = offset_scalar_block + size_scalar_block;
    size_field_block = compute_field_size();

    offset_crc_block = offset_field_block + size_field_block;
    size_crc_block = compute_crc_size();

    offset_padding_block = offset_crc_block + size_crc_block;
    size_padding_block = compute_padding_size(offset_padding_block);

    uint64_t framesize = offset_padding_block + size_padding_block;

    return framesize;
  }

  /*!
   * Compute the size of the full serialized frame.
   */
  uint64_t Frame::framesize() const {
    uint64_t size_header_block;
    uint64_t offset_header_block;
    uint64_t size_typename_block;
    uint64_t offset_typename_block;
    uint64_t size_meta_block;
    uint64_t offset_meta_block;
    uint64_t size_label_block;
    uint64_t offset_label_block;
    uint64_t size_scalar_block;
    uint64_t offset_scalar_block;
    uint64_t size_field_block;
    uint64_t offset_field_block;
    uint64_t size_crc_block;
    uint64_t offset_crc_block;
    uint64_t size_padding_block;
    uint64_t offset_padding_block;

    return compute_blocksizes(size_header_block,
                              offset_header_block,
                              size_typename_block,
                              offset_typename_block,
                              size_meta_block,
                              offset_meta_block,
                              size_label_block,
                              offset_label_block,
                              size_scalar_block,
                              offset_scalar_block,
                              size_field_block,
                              offset_field_block,
                              size_crc_block,
                              offset_crc_block,
                              size_padding_block,
                              offset_padding_block);
  }

  /*!
   * Generate the bytes that form the disk representation of this
   * frame.
   */
  boost::shared_array<char> Frame::bytes() const {
    
    boost::shared_array<char> result(new char[framesize()]);
    serialize(result.get());
    return result;
  }

  /*!
   * 
   */
  void Frame::serialize(void* target) const {
    const meta_map_t& meta_map = meta();
    const data_map_t& data_map = data();
    const typecode_imap_t& typecode_list = typecodes();

    // -----------------------------------------------
    // Construct the long long rosetta from its 32 bit
    // parts
    // -----------------------------------------------
    uint64_t lrosetta = assemble64(s_lrosetta_lo,s_lrosetta_hi);

    // -----------------------------------------------
    // Compute sizes and offsets
    // -----------------------------------------------
    uint64_t size_header_block;
    uint64_t offset_header_block;
    uint64_t size_typename_block;
    uint64_t offset_typename_block;
    uint64_t size_meta_block;
    uint64_t offset_meta_block;
    uint64_t size_label_block;
    uint64_t offset_label_block;
    uint64_t size_scalar_block;
    uint64_t offset_scalar_block;
    uint64_t size_field_block;
    uint64_t offset_field_block;
    uint64_t size_crc_block;
    uint64_t offset_crc_block;
    uint64_t size_padding_block;
    uint64_t offset_padding_block;

    uint64_t framesize =
      compute_blocksizes(size_header_block,
                         offset_header_block,
                         size_typename_block,
                         offset_typename_block,
                         size_meta_block,
                         offset_meta_block,
                         size_label_block,
                         offset_label_block,
                         size_scalar_block,
                         offset_scalar_block,
                         size_field_block,
                         offset_field_block,
                         size_crc_block,
                         offset_crc_block,
                         size_padding_block,
                         offset_padding_block);



    // -----------------------------------------------
    // File layout
    //
    //   header_t   header;
    //   metadisk_t diskmeta[nlabels];
    //   char*      typenames [0 separated and 0 terminated];
    //   char*      labels [0 separated and 0 terminated];
    //   char       scalars[size_scalar_block];
    //   char       fields[size_field_block];
    //   uint32_t   crc;
    //   char       padding[size_padding_block];
    // -----------------------------------------------
    char* base = reinterpret_cast<char*>(target);
    header_t*   header    = reinterpret_cast<header_t*>(base+offset_header_block);
    metadisk_t* diskmeta  = reinterpret_cast<metadisk_t*>(base+offset_meta_block);
    char*       typenames = reinterpret_cast<char*>(base+offset_typename_block);
    char*       labels    = reinterpret_cast<char*>(base+offset_label_block);
    char*       scalars   = reinterpret_cast<char*>(base+offset_scalar_block);
    char*       fields    = reinterpret_cast<char*>(base+offset_field_block);
    uint32_t*   crc       = reinterpret_cast<uint32_t*>(base+offset_crc_block);
    //char*       padding   = reinterpret_cast<char*>(base+offset_padding_block);

    // -----------------------------------------------
    // Zero out the whole data storage block for consistent
    // data files (binary diff's)
    // -----------------------------------------------
    ::memset(base,0,framesize);

    // -----------------------------------------------
    // Construct the header
    // -----------------------------------------------
    header->required.magic = htonl(s_magic);
    header->required.version = htonl(s_version);
    header->required.framesize_lo = htonl(lobytes(framesize));
    header->required.framesize_hi = htonl(hibytes(framesize));

    header->size_header_block = htonl(size_header_block);
    header->unused0 = 0;
    header->irosetta = s_irosetta;
    header->frosetta = s_frosetta;

    header->drosetta_lo = lobytes(s_drosetta);
    header->drosetta_hi = hibytes(s_drosetta);
    header->lrosetta_lo = lobytes(lrosetta);
    header->lrosetta_hi = hibytes(lrosetta);

    header->endianism = htonl(endianism());
    header->nlabels = htonl(meta_map.size());
    header->size_meta_block = htonl(size_meta_block);
    header->size_typename_block = htonl(size_typename_block);

    header->size_label_block = htonl(size_label_block);
    header->size_scalar_block = htonl(size_scalar_block);
    header->size_field_block_lo = htonl(lobytes(size_field_block));
    header->size_field_block_hi = htonl(hibytes(size_field_block));

    header->size_crc_block = htonl(size_crc_block);
    header->size_padding_block = htonl(size_padding_block);
    header->unused1 = 0;
    header->unused2 = 0;

    // -----------------------------------------------
    // Construct the diskmeta and labels and pack into
    // the fields.  We traverse the meta-data to insure
    // that fields are emitted in the same order in
    // all 4 sections (meta, labels, scalars, fields)
    //
    // Note that we round the size of each field to the
    // alignment size so that we can guarantee readers
    // of that alignment.  This can save us copying
    // the data another time just to satisfy alignment
    // constraints.
    // -----------------------------------------------
    for(meta_map_t::const_iterator p = meta_map.begin();
        p != meta_map.end(); ++p) {
      const std::string& label = (*p).first;
      const meta_t& meta = (*p).second;

      data_map_t::const_iterator blob_p = data_map.find(label);
      assert(blob_p != data_map.end());
      const BaseBlob& blob = (*blob_p).second;

      uint64_t nbytes = meta.count*meta.elementsize;

      diskmeta->type = htonl(meta.type);
      diskmeta->elementsize = htonl(meta.elementsize);
      diskmeta->count_lo = htonl(lobytes(meta.count));
      diskmeta->count_hi = htonl(hibytes(meta.count));
      diskmeta++;

      labels = std::copy(label.begin(),label.end(),labels);
      *labels++ = 0;  // Add a null terminator

      if (meta.count <= 1) {
        std::copy(blob.firstbyte(),blob.endbytes(),scalars);
        scalars += alignInteger(nbytes,s_alignsize);
      } else {
        std::copy(blob.firstbyte(),blob.endbytes(),fields);
        fields += alignInteger(nbytes,s_alignsize);
      }
    }
    *labels++ = 0;  // Add a final null terminator

    // -----------------------------------------------
    // Construct the typenames
    // -----------------------------------------------
    for(typecode_imap_t::const_iterator p = typecode_list.begin();
        p != typecode_list.end(); ++p) {
      const std::string& label = *p;
      typenames = std::copy(label.begin(),label.end(),typenames);
      *typenames++ = 0; // Add an entry null terminator
    }
    *typenames++ = 0; // Add a final null terminator

    // -----------------------------------------------
    // Construct the crc
    // -----------------------------------------------
    *crc = fletcher(reinterpret_cast<uint16_t*>(base),offset_crc_block/2);

    // -----------------------------------------------
    // Construct the padding
    // -----------------------------------------------
    //::memset(padding,0,size_padding_block);
  }

}
