/* 
Copyright 2012-2014, D. E. Shaw Research.
All rights reserved.

Redistribution and use in source and binary forms, with or without
modification, are permitted provided that the following conditions are
met:

* Redistributions of source code must retain the above copyright
  notice, this list of conditions, and the following disclaimer.

* Redistributions in binary form must reproduce the above copyright
  notice, this list of conditions, and the following disclaimer in the
  documentation and/or other materials provided with the distribution.

* Neither the name of D. E. Shaw Research nor the names of its
  contributors may be used to endorse or promote products derived from
  this software without specific prior written permission.

THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
"AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR
A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT
OWNER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,
SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT
LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE,
DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY
THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
(INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE
OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
*/

#include "FrameSet/Frame.hxx"
#include "FrameSet/FrameSetReader.hxx"
#include "FrameSet/StackFrameSet.hxx"
#include "FrameSet/OverlayFrameSet.hxx"
#include "dump_utils.hxx"

#include <iostream>
#include <vector>
#include <set>

#include <boost/filesystem.hpp>
namespace bfs = boost::filesystem;

#include <sys/types.h>
#include <sys/stat.h>
#include <float.h>

#include <cstdio>
#include <cstring>

using std::cout;
using std::cerr;
using std::endl;
using frameset::Frame;
using frameset::FrameSetReader;
using frameset::StackFrameSet;

static void dump_frameset(const FrameSetReader& reader,
                          const std::set<std::string>& match,
                          const std::set<std::string>& match_not,
                          size_t max,
                          ssize_t begin,
                          ssize_t end,
                          bool hexfloat,
                          bool json) {




  unsigned size = reader.size();

  // -----------------------------------------------
  // For every frame....
  // -----------------------------------------------
  size_t first = (begin < 0)?(size+begin):(begin);
  if (first > size) first = size;
  size_t last  = (end <= 0)?(size+end):(end);
  if (last > size) last = size;



  if (json) {
      cout << "[" << endl;
  } else {
    cout << "{" << endl;
    cout << "  size=" << (last-first) << endl;
  }

  for(unsigned i=first; i<last; ++i) {
    FrameSetReader::FramePtr frame = reader[i];
    double time = reader.time(i);
    int p = cout.precision(numeric_limits0x<double>::max_digits10);

    if (json)  {
      dump_json_frame(time,*frame,match,match_not,hexfloat);
      if (i != last-1) cout << ',';
      cout << endl;
   } else {
      cout << "  time=" << time << " {" << endl;
      cout.precision(p);
      dump_frame(*frame,match,match_not,max,hexfloat);
      cout << "  }" << endl;
    }
  }

  if (json) {
    cout << "]" << endl;
  } else {
    cout << "}" << endl;
  }
}

int main(int argc, char** argv) {
  ssize_t begin = 0;
  ssize_t end = 0;
  size_t max = 0;
  bool hexfloat = false;
  bool json = false;
  std::vector<std::string> framesets;
  std::set<std::string> match;
  std::set<std::string> match_not;

  // -----------------------------------------------
  // Argument processing...
  // -----------------------------------------------
  for(int argno=1; argno<argc; ++argno) {
    std::string arg = argv[argno];
    if (arg.compare(0,8,"--begin=") == 0) {
      std::istringstream input(arg.substr(8));
      input >> begin;
    } else if (arg.compare(0,6,"--end=") == 0) {
      std::istringstream input(arg.substr(6));
      input >> end;
    } else if (arg == "--json") {
      json = true;
    } else if (arg.compare(0,6,"--max=") == 0) {
      std::istringstream input(arg.substr(6));
      input >> max;
    } else if (arg.compare(0,8,"--match=") == 0) {
      if (match_not.size() != 0) {
        cerr << "Cannot use match and matchnot together" << endl;
        return 1;
      }
      match.insert(arg.substr(8));
    } else if (arg.compare(0,11,"--matchnot=") == 0) {
      if (match.size() != 0) {
        cerr << "Cannot use match and matchnot together" << endl;
        return 1;
      }
      match_not.insert(arg.substr(11));
    } else if (arg == "--hexfloat") {
      hexfloat = true;
    } else if (arg == "--help") {
      cerr << "fsdump [--begin=n] [--end=n] [--match=xxx] [--matchnot=xxx] [--max=n]"
        "framesetdir framesetdir..." << endl;

      cerr << endl;
      cerr << "--begin and --end use python-style relative offsets," << endl;
      cerr << "so --begin=-3 will output the last 3 frames" << endl;
      cerr << "Use --match=xxx --match=yyy to pull out selected fields" << endl;
      cerr << "Use --matchnot=exclude to discard unwanted fields" << endl;
      cerr << "Use --max to set a ceiling on the number of elements displayed" << endl;
      cerr << "Use --hexfloat to dump floats in hex format" << endl;
      cerr << "Use --json to dump in json compatible format (--max ignored)" << endl;
      return 1;
    } else {
      framesets.push_back(arg);
    }
  }

  try {

    // We may have an array of framesets
    if (json && framesets.size() > 1 ) cout << "[" << endl;


    // -----------------------------------------------
    // For every frameset file...
    // -----------------------------------------------
    for(std::vector<std::string>::iterator p = framesets.begin();
        p != framesets.end(); ++p) {

      // Make sure it exists and give a better error if not
      if (!frameset::exists(*p)) { perror(p->c_str()); return 1; }

      // -----------------------------------------------
      // This is either a frameset directory or a
      // directory of "stacked" framesets.  We can tell
      // the difference by probing for the timekeys
      // file.
      //
      // Or (DESRES#575), it is an .stk file
      // -----------------------------------------------
      if (!frameset::is_directory(*p)) {
        FILE* fp = fopen((*p).c_str(),"r");

        if (!fp) { perror((*p).c_str()); return 1; }

        // Read the first line... if blank, no frameset to display
        char line[4096];
        if (!fgets(line,sizeof(line),fp)) { perror((*p).c_str()); continue; }
        

        // Strip \n off the end and open the main reader
        line[strlen(line)-1] = 0;
        frameset::OverlayFrameSet reader(line);

        // Overlay subsequent parts
        while (fgets(line,sizeof(line),fp)) {
          line[strlen(line)-1] = 0;
          try {
            reader.overlay(line);
          } catch (...) {fclose(fp); throw;}
        }

        dump_frameset(reader,match,match_not,max,begin,end,hexfloat,json);

      } else if (FrameSetReader::isaFrameSetDirectory(*p)) {
        FrameSetReader reader(*p);
        dump_frameset(reader,match,match_not,max,begin,end,hexfloat,json);
      } else {
	std::vector<std::string> pathv;
        for ( bfs::directory_iterator d(*p); d != bfs::directory_iterator(); ++d) pathv.push_back(d->path().filename().string());
	std::sort(pathv.begin(), pathv.end());
	for ( unsigned int i = 0; i < pathv.size(); ++i ) {
	  if ( !FrameSetReader::isaFrameSetDirectory(pathv[i]) ) continue;
	  // Base reader
	  StackFrameSet reader(pathv[i]);
	  // stacked readers
	  for(unsigned int j=i+1; j<pathv.size(); ++j) {
	    if (!FrameSetReader::isaFrameSetDirectory(pathv[j])) continue;
	    boost::shared_ptr<FrameSetReader> more
	      (new FrameSetReader(pathv[j]));
	    reader.overlay(more);
	  }
	  dump_frameset(reader,match,match_not,max,begin,end,hexfloat,json);
	  break;	
          }
        }
      }

    if (json && framesets.size() > 1 ) cout << "]" << endl;

  } catch (std::exception& e) {
    cerr << e.what() << endl;
    return 1;
  }

  return 0;
}
      
