/* 
Copyright 2012-2014, D. E. Shaw Research.
All rights reserved.

Redistribution and use in source and binary forms, with or without
modification, are permitted provided that the following conditions are
met:

* Redistributions of source code must retain the above copyright
  notice, this list of conditions, and the following disclaimer.

* Redistributions in binary form must reproduce the above copyright
  notice, this list of conditions, and the following disclaimer in the
  documentation and/or other materials provided with the distribution.

* Neither the name of D. E. Shaw Research nor the names of its
  contributors may be used to endorse or promote products derived from
  this software without specific prior written permission.

THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
"AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR
A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT
OWNER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,
SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT
LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE,
DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY
THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
(INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE
OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
*/

#include "FrameSet/FrameSetExceptions.hxx"
#include <errno.h>
#include <cstring>

namespace frameset {

  FrameSetException::FrameSetException(const std::string& msg)
    : dessert(msg)
  {
  }

  FrameSetException::FrameSetException(const std::string& msg, const char* file, int lineno, const char* func)
    : dessert(msg,file,lineno,func)
  {
  }

  FrameSetException::~FrameSetException() throw () {
  }

  /*!
   * Creates an exception object with a not implemented warning
   * message.  This constructor requires file and line number
   * information.
   */
  NotImplementedException::NotImplementedException(const char* file, size_t line, const char* func)
    : FrameSetException("not implemented",file,line,func)
  {
  }

  /*!
   * Required virtual destructor.
   */
  NotImplementedException::~NotImplementedException() throw() {
  }


  /*!
   * Grab the strerror message and append it to the user's
   * message.
   */
  ErrnoException::ErrnoException(const std::string& msg)
    : FrameSetException(msg+": "+::strerror(errno)),
      m_errno(errno)
  {
  }

  /*!
   * Creates an exception object with associated message.
   * The message is formatted as file:line: message so
   * that error line parsers can do something useful.
   */
  ErrnoException::ErrnoException(const std::string& msg, const char* file, size_t line,const char* func)
    : FrameSetException(msg+": "+::strerror(errno),file,line,func),
      m_errno(errno)
  {
  }

  /*!
   * Required virtual destructor.
   */
  ErrnoException::~ErrnoException() throw() {
  }

  /*!
   * Returns the errno that instigated the I/O exception.
   */
  int ErrnoException::error() const {
    // NOTE: Cannot name this function errno since that
    // name is a MACRO
    return m_errno;
  }



  /*!
   * Specialization that indicates that the exception
   * was caused by an I/O call.
   */
  IoException::IoException(const std::string& msg)
    : FrameSetException(msg)
  {
  }

  /*!
   * Creates an exception object with associated message.
   * The message is formatted as file:line: message so
   * that error line parsers can do something useful.
   */
  IoException::IoException(const std::string& msg, const char* file, size_t line, const char* func) 
    : FrameSetException(msg,file,line,func)
  {
  }

  /*!
   * Required virtual destructor.
   */
  IoException::~IoException() throw() {
  }

  /*!
   * Specialization that associates an errno with
   */
  IoErrnoException::IoErrnoException(const std::string& msg)
    : IoException(msg+": "+::strerror(errno))
  {
  }

  /*!
   * Creates an exception object with associated message.
   * The message is formatted as file:line: message so
   * that error line parsers can do something useful.
   */
  IoErrnoException::IoErrnoException(const std::string& msg, const char* file, size_t line,const char* func) 
    : IoException(msg+": "+::strerror(errno),file,line,func)
  {
  }

  /*!
   * Required virtual destructor.
   */
  IoErrnoException::~IoErrnoException() throw() {
  }

  /*!
   * A special exception associated with failing to
   * find a named attribute.
   */
  AttributeError::AttributeError(const std::string& attr) 
    : FrameSetException("attribute error - " + attr),
      m_attr(attr)
  {
  }

  /*!
   * Creates an exception object with associated message.
   * The message is formatted as file:line: message so
   * that error line parsers can do something useful.
   */
  AttributeError::AttributeError(const std::string& attr, const char* file, size_t line, const char* func) 
    : FrameSetException("attribute error - " + attr,file,line,func),
      m_attr(attr)
  {
  }

  /*!
   * Required virtual destructor.
   */
  AttributeError::~AttributeError() throw() {
  }

  /*!
   * Returns the attribute request that instigated the
   * exception.
   */
  std::string AttributeError::attribute() const {
    return m_attr;
  }

  /*!
   * Create an exception that signals that TypeSafety
   * was being compromised.
   */
  TypeSafetyError::TypeSafetyError(const std::string& msg)
    : FrameSetException(msg)
  {
  }

  /*!
   * Creates an exception object with associated message.
   * The message is formatted as file:line: message so
   * that error line parsers can do something useful.
   */
  TypeSafetyError::TypeSafetyError(const std::string& msg, const char* file, size_t line, const char* func)
    : FrameSetException(msg,file,line,func)
  {
  }

  /*!
   * Required virtual destructor.
   */
  TypeSafetyError::~TypeSafetyError() throw() {
  }

  /*!
   * Create an exception that indicates that some kind
   * of bounds condition was compromised.
   */
  BoundsError::BoundsError(const std::string& msg)
    : FrameSetException(msg)
  {
  }

  /*!
   * Required virtual destructor.
   */
  BoundsError::~BoundsError() throw()
  {
  }

  /*!
   * Create an exception that indicates that a
   * dereference request was out of bounds.
   */
  DereferenceError::DereferenceError(const std::string& msg)
    : BoundsError(msg)
  {
  }

  /*!
   * Required virtual destructor.
   */
  DereferenceError::~DereferenceError() throw()
  {
  }

  /*!
   * Create an exception indicating that an indexed
   * access was out of some well defined bounds.
   */
  RangeError::RangeError(uint64_t idx, uint64_t max)
    : m_idx(idx), m_max(max)
  {
    std::ostringstream stream;
    stream << "Index " << idx << " greater-eq than " << max;
    append(stream.str());
  }

  /*!
   * Creates an exception object with associated message.
   * The message is formatted as file:line: message so
   * that error line parsers can do something useful.
   */
  RangeError::RangeError(uint64_t idx, uint64_t max, const char* file, size_t line, const char* func) 
    : m_idx(idx), m_max(max)
  {
    std::ostringstream stream;
    stream << file << ':' << line << ": "
           << "Index " << idx << " greater-eq than " << max;
    append(stream.str(),file,line,func);
  }

  /*!
   * Required virtual destructor.
   */
  RangeError::~RangeError() throw () {
  }

  /*!
   * Return the offending index that was out of range.
   */
  uint64_t RangeError::badIndex() const {
    return m_idx;
  }

  /*!
   * Return the maximum index that would have been in
   * range.
   */
  uint64_t RangeError::maxIndex() const {
    return m_max;
  }

  /*!
   * An auxilary function that checks that an index
   * is inside the requested bounds. If it is not,
   * an appropriate RangeError exception is generated
   * and thrown.
   */
  void RangeError::check(uint64_t idx, uint64_t max) {
    if (idx >= max) throw RangeError(idx,max);
  }

  /*!
   * An auxilary range check function that includes
   * traceback information.
   */
  void RangeError::check(uint64_t idx, uint64_t max, const char* file, size_t line, const char* func) {
    if (idx >= max) throw RangeError(idx,max,file,line,func);
  }
}

