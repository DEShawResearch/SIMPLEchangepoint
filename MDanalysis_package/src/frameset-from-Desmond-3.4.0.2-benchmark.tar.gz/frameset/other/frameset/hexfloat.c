/* Copyright D. E. Shaw Research, 2004-2012. */

#include "dump_utils.hxx"
#include <stdio.h>

/**************************************************************************/
/* GLOBAL **************          hexdump          ************************/
/**************************************************************************/
/* We do this in C so we can get the -std=c99 switch which give us %a     */
/**************************************************************************/
const char* hexdump(char buffer[32],double x) {
  sprintf(buffer,"%a",x);
  return buffer;
}
