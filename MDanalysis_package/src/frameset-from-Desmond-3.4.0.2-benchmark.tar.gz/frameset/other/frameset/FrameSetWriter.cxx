/* 
Copyright 2012-2014, D. E. Shaw Research.
All rights reserved.

Redistribution and use in source and binary forms, with or without
modification, are permitted provided that the following conditions are
met:

* Redistributions of source code must retain the above copyright
  notice, this list of conditions, and the following disclaimer.

* Redistributions in binary form must reproduce the above copyright
  notice, this list of conditions, and the following disclaimer in the
  documentation and/or other materials provided with the distribution.

* Neither the name of D. E. Shaw Research nor the names of its
  contributors may be used to endorse or promote products derived from
  this software without specific prior written permission.

THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
"AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR
A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT
OWNER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,
SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT
LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE,
DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY
THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
(INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE
OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
*/

// NOTE:  Cannot use ::ntohl or ::htonl since under optimization
// they are turned into efficient macros

#include "FrameSet/FrameSetWriter.hxx"
#include "FrameSet/FrameSetExceptions.hxx"

// TODO: remove
#include <iostream>
using std::cout;
using std::endl;

#include <fcntl.h>

#ifdef DESRES_OS_Windows
#include <Windows.h>
#define fsync _commit
#define ftruncate _chsize
#else
#include <unistd.h>
#include <netinet/in.h>
#define O_BINARY 0
#endif

#include <sys/types.h>
#include <sys/stat.h>

#ifndef WIN32
// This is for ::mmap, ::munmap
#include <sys/mman.h>
#define DO_NOT_USE_MMAP
#endif

// -----------------------------------------------
// Mmap is buggy on 4.6.9 and below kernels...
// So, we're skipping it for now.  TODO: Add
// a detector in desres-install-helper that checks
//  the kernel version using uname -r
// -----------------------------------------------
#ifndef DO_NOT_USE_MMAP
#define DO_NOT_USE_MMAP
#endif

namespace frameset {

  /*!
   * An unopened writer (will fail on write because keyfile is unopened).
   */
  FrameSetWriter::FrameSetWriter()
    : FrameSet(),
      m_keyfile_fd(-1),
      m_framefile_fd(-1),
      m_chemical_time(0.0)
  {
  }

  /*!
   * Opening for write or append.  In append mode, we leave the
   * existing directory alone.
   */
  FrameSetWriter::FrameSetWriter(std::string dirname,std::string mode,
                                 int ndir1,int ndir2,size_t frames_per_file,
                                 bool sync)
    : FrameSet(dirname,mode,ndir1,ndir2,frames_per_file),
      m_keyfile_fd(-1),
      m_framefile_fd(-1),
      m_chemical_time(0.0),
      m_sync(sync)
  {
    // -----------------------------------------------
    // Writers can only be "w" or "a"
    // -----------------------------------------------
    if (mode == "r") {
      throw FrameSetException("invalid mode for writing",DESSERT_LOC);
    }

    // -----------------------------------------------
    // We maintain a keyfile that associates frame numbers
    // with times (and specifies offsets if we have
    // multiple frames in a file).  It starts with a
    // prologue holding our magic number, the number of
    // frames in a file, and the size of our key_record_t.
    //
    // In write mode, we simply create it.  In append
    // mode, we read the existing one.
    // -----------------------------------------------
    std::string keyfile_path = keyfile();
    m_keyfile_fd = ::open(keyfile_path.c_str(),O_RDWR|O_APPEND|O_CREAT|O_BINARY,0666);
    if (m_keyfile_fd.file() < 0) throw IoException(keyfile_path,DESSERT_LOC);

    // Read in the entry (if none, we just write the default)
    key_prologue_t prologue;
    if (nointr_read(m_keyfile_fd.file(),&prologue,sizeof(prologue)) <
        (ssize_t)sizeof(prologue)) {
      prologue.magic = htonl(s_magic_timekey);
      prologue.frames_per_file = htonl(m_frames_per_file);
      prologue.key_record_size = htonl(sizeof(key_record_t));
      if (::lseek(m_keyfile_fd.file(),0,SEEK_SET) < 0) {
        throw IoException(keyfile_path,DESSERT_LOC); /* GCOV-IGNORE */
      }
      if (nointr_write(m_keyfile_fd.file(),&prologue,sizeof(prologue)) < 0) {
        throw IoException(keyfile_path,DESSERT_LOC); /* GCOV-IGNORE */
      }
    }
    if (ntohl(prologue.key_record_size) != sizeof(key_record_t)) {
      throw FrameSetException("key format has changed",DESSERT_LOC); /* GCOV-IGNORE */
    }


    // -----------------------------------------------
    // We calculate the number of frames from the key
    // file size.  Subtract off the prologue, divide
    // by the size of a record (truncating any partially
    // written records).  We also seek to the correct
    // writing location for the next record so that
    // key writes simply occur.
    // -----------------------------------------------
    off_t end_of_keys = ::lseek(m_keyfile_fd.file(),0,SEEK_END);
    if (end_of_keys < 0) IoException(keyfile_path,DESSERT_LOC);
    m_nframes = (end_of_keys-sizeof(prologue))/sizeof(key_record_t);
    if (m_nframes > 0) {
      // -----------------------------------------------
      // When appending, we must grab the last entry to
      // get the last chemical time right...
      // -----------------------------------------------
      if (::lseek(m_keyfile_fd.file(),sizeof(prologue)+(m_nframes-1)*sizeof(key_record_t),SEEK_SET) < 0) {
        throw IoException(keyfile_path,DESSERT_LOC);  /* GCOV-IGNORE */
      }
      key_record_t entry;
      ssize_t n = nointr_read(m_keyfile_fd.file(),&entry,sizeof(entry));
      if ( n  != sizeof(entry) ) {
        throw IoErrnoException("keytimes");  /* GCOV-IGNORE */
      }
      m_chemical_time = Frame::assembleDouble(ntohl(entry.time_lo),
                                              ntohl(entry.time_hi));
    }
    if (::lseek(m_keyfile_fd.file(),sizeof(prologue)+m_nframes*sizeof(key_record_t),SEEK_SET) < 0) {
      throw IoException(keyfile_path,DESSERT_LOC);  /* GCOV-IGNORE */
    }

  }

  /*!
   * Push a frame out onto the file system.
   */
  void FrameSetWriter::push_back(const Frame& frame, double time) {
      write_frame(&frame, NULL, 0, time);
  }

  void FrameSetWriter::push_back(const void *buf, size_t len, double time) {
      write_frame(NULL, buf, len, time);
  }

  /*!
   * Write the frame to the filesystem. If frame is NULL, buf contains frame data
   */
  void FrameSetWriter::write_frame(const Frame *frame, const void *buf, size_t len, double time)
  {

    // -----------------------------------------------
    // Some basic sanity checking
    // -----------------------------------------------
    if ( m_nframes > 0 && time <= m_chemical_time ) {
      std::stringstream error;
      error << "Frame times must strictly increase.  Time is "
        << m_chemical_time << " whilst trying " << time;
      throw FrameSetException(error.str(),DESSERT_LOC);
    }

    if (!frame && !buf) {
      throw FrameSetException("No frame data in frame or buffer!", DESSERT_LOC);
    }

    // -----------------------------------------------
    // We may need to open the file descriptor for the
    // new frame bundle.  This happens every
    // m_frames_per_file frames....
    // -----------------------------------------------
    std::string filepath = framefile(m_nframes);
    if (m_framefile_fd.file() < 0) {
      m_framefile_fd = ::open(filepath.c_str(),O_WRONLY|O_CREAT|O_BINARY,0666);
      if (m_framefile_fd.file() < 0) {
        throw IoErrnoException(filepath,DESSERT_LOC); /* GCOV-IGNORE */
      }
      m_framefile_offset = 0;
    }

    // -----------------------------------------------
    // Need to know how big the frame will be
    // -----------------------------------------------
    uint64_t framesize = frame ? frame->framesize() : len;

    // -----------------------------------------------
    // Either write out the bytes or serialize into
    // mmap'd space.
    // -----------------------------------------------
#ifdef DO_NOT_USE_MMAP
    if (frame) {
        boost::shared_array<char> bytes = frame->bytes();
        if (nointr_write(m_framefile_fd.file(),bytes.get(),framesize) < 0) {
            throw IoErrnoException(filepath,DESSERT_LOC); /* GCOV-IGNORE */
        }
    }
    else {
        if (nointr_write(m_framefile_fd.file(),buf,framesize) < 0) {
            throw IoErrnoException(filepath,DESSERT_LOC); /* GCOV-IGNORE */
        }
    }
    // Sync data to disk
    if (m_sync && nointr_fsync(m_framefile_fd.file()) != 0) {
        throw IoErrnoException(filepath, DESSERT_LOC); /* GCOV-IGNORE */
    }
#else
    // -----------------------------------------------
    // mmap is unhappy to map in more bytes than
    // currently exist in the file, so we just seek
    // to the end and write a byte.  This sets the
    // apparent size of the file to the correct size
    // and now mmap will be happy (otherwise you get
    // a mysterious SIGBUS because the file appears
    // truncated).
    // -----------------------------------------------
    if (::lseek(m_framefile_fd.file(),m_framefile_offset+framesize-1,SEEK_SET) == -1) {
      throw IoErrnoException(DESSERT_LOC,filepath);
    }
    if (nointr_write(m_framefile_fd.file(),"\0",1) != 1) {
      throw IoErrnoException(filepath);
    }

    // -----------------------------------------------
    // We memory map the file into our local space
    // and serialize into it.  Take care to catch
    // exceptions so that we can unmap the file.  The
    // file is closed by the catch(...) below.
    // -----------------------------------------------
    void* target = ::mmap(0,framesize,PROT_READ|PROT_WRITE,MAP_SHARED,fd.file(),offset);
    if (target == MAP_FAILED) throw IoErrnoException(filepath);
    if (frame) {
        try {
            frame.serialize(target);
        } catch (...) {
            ::munmap(target,frame.framesize());
            throw;
        }
    }
    else {
        memcpy(target, buf, framesize);
    }
    if (::munmap(target,framesize) != 0) {
      throw IoErrnoException(filepath);
    }
#endif

    // -----------------------------------------------
    // Now write the keyfile entry
    // -----------------------------------------------
    key_record_t timekey;
    timekey.time_lo = htonl(Frame::lobytes(time));
    timekey.time_hi = htonl(Frame::hibytes(time));
    timekey.offset_lo = htonl(Frame::lobytes(m_framefile_offset));
    timekey.offset_hi = htonl(Frame::hibytes(m_framefile_offset));
    timekey.framesize_lo = htonl(Frame::lobytes(framesize));
    timekey.framesize_hi = htonl(Frame::hibytes(framesize));
    if (nointr_write(m_keyfile_fd.file(),&timekey,sizeof(timekey)) < 0) {
      throw IoErrnoException(keyfile(),DESSERT_LOC); /* GCOV-IGNORE */
    }
    if (m_sync && nointr_fsync(m_keyfile_fd.file()) != 0) {
      throw IoErrnoException(keyfile(),DESSERT_LOC); /* GCOV-IGNORE */
    }

    // -----------------------------------------------
    // This commits the frame and we increment our
    // frame count and set our time.
    // -----------------------------------------------
    m_framefile_offset += framesize;
    m_chemical_time = time;
    m_nframes++;

    // -----------------------------------------------
    // Close the file when it becomes full so that
    // we will append into the next file
    // -----------------------------------------------
    if (m_nframes % m_frames_per_file == 0) {
      m_framefile_offset = 0;
      m_framefile_fd = -1; // Autoclosing takes care of ::close()
    }

  }

  /*!
   * On close, we have to close the timekey file if it
   * is open (likely unless the c'tor threw an exception).
   */
  FrameSetWriter::~FrameSetWriter() {
  }

  /*!
   * Force the keyfile out to disk
   */
  void FrameSetWriter::flush_keyfile() {
    nointr_fsync(m_keyfile_fd.file());
  }

  void FrameSetWriter::flush_framefile() {
    int fd = m_framefile_fd.file();
    if (fd>0 && nointr_fsync(fd)<0) {
      throw IoErrnoException(m_directory,DESSERT_LOC);
    }
  }

  /*!
   * The chemical time of the last successful write.  If
   * no frames were written, it returns 0.0.  The times
   * that are push_back'd into the set must be strictly
   * increasing, but may, in fact, start at a negative
   * time.
   */
  double FrameSetWriter::time() const {
    return m_chemical_time;
  }

  /*!
   * Resize the keyfile entries and the frame count and
   * the current time.  The idea is that if you rewind
   * to the last frame *before* the rewind time, then
   * a push_back(f,that time) would now be legal.
   */
  void FrameSetWriter::rewind(double rewind_before_time) {
    // Adjust and truncate the keyfile.  We don't have the cool search
    // functions that we have in ReaderFrame, so we just brute force
    // it for now (FIXME)
    off_t offset = ::lseek(m_keyfile_fd.file(),sizeof(key_prologue_t),SEEK_SET);
    off_t good_frame_offset = 0;
    double current_time = 0.0;
    size_t frames = 0;
    while(1) {
      key_record_t entry;
      ssize_t n = nointr_read(m_keyfile_fd.file(),&entry,sizeof(entry));
      if ( n != sizeof(entry) ) break;

      double time = Frame::assembleDouble(ntohl(entry.time_lo),
                                          ntohl(entry.time_hi));

      good_frame_offset = Frame::assemble64(ntohl(entry.offset_lo),
                                            ntohl(entry.offset_hi));


      if (time >= rewind_before_time) break;

      // We move the framecount, time, and offset to accommidate
      frames++;
      current_time = time;
      offset += sizeof(entry);
    }

    // Truncate the file and reset the time and framecount
    ::ftruncate(m_keyfile_fd.file(),offset);
    m_nframes = frames;
    m_chemical_time = current_time;

    // We may have to reopen and truncate the current frame file
    if (m_frames_per_file != 1) {
      m_framefile_fd = -1;  // Close old frame file
      if ( m_nframes%m_frames_per_file != 0) {

        // Open the previous frame file and set the offset
        std::string filepath = framefile(m_nframes);
        if (m_framefile_fd.file() < 0) {
          m_framefile_fd = ::open(filepath.c_str(),O_WRONLY|O_BINARY,0666);
          if (m_framefile_fd.file() < 0) {
            throw IoErrnoException(filepath,DESSERT_LOC); /* GCOV-IGNORE */
          }
          m_framefile_offset = good_frame_offset;
        }


      }
    }
  }
}
