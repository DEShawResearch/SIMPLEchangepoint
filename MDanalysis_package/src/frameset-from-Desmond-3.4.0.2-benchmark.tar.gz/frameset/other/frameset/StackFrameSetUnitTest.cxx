/* 
Copyright 2012-2014, D. E. Shaw Research.
All rights reserved.

Redistribution and use in source and binary forms, with or without
modification, are permitted provided that the following conditions are
met:

* Redistributions of source code must retain the above copyright
  notice, this list of conditions, and the following disclaimer.

* Redistributions in binary form must reproduce the above copyright
  notice, this list of conditions, and the following disclaimer in the
  documentation and/or other materials provided with the distribution.

* Neither the name of D. E. Shaw Research nor the names of its
  contributors may be used to endorse or promote products derived from
  this software without specific prior written permission.

THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
"AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR
A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT
OWNER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,
SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT
LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE,
DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY
THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
(INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE
OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
*/

#include "FrameSet/FrameSetWriter.hxx"
#include "FrameSet/StackFrameSet.hxx"
#include "UnitTestCommon.hxx"

#include <iostream>

#include <sys/stat.h>
#include <sys/types.h>

#ifdef DESRES_OS_Windows
#include <direct.h>
#define mkdir(a,b) _mkdir((a))
#endif

void write_frameset(int i, std::string dir) {
  frameset::FrameSetWriter writer(dir);
  frameset::Frame F;

  // Explore what happens with a field on only the base
  // frame!
  if (i == 0 ) F.set_values("TITLE","hello world!",12);

  uint32_t step;
  step = 110 + i;
  F.set_value("STEP",step);
  writer.push_back(F,0.0);

  step = 220 + i;
  F.set_value("STEP",step);
  writer.push_back(F,0.1);
}

int main(void) {
  try {
    // -----------------------------------------------
    // Make a few simple framesets
    // -----------------------------------------------
    frameset::FrameSet::recursivelyRemove("collection.dir");
    ::mkdir("collection.dir",0777);
    write_frameset(0,"collection.dir/part0");
    write_frameset(1,"collection.dir/part1");
    write_frameset(2,"collection.dir/part2");

    // -----------------------------------------------
    // Stack multiple framesets together
    // -----------------------------------------------
    {
      boost::shared_ptr<frameset::FrameSetReader>
        frameset(frameset::StackFrameSet::fromcollection("collection.dir",
                                                         "part"));

      // -----------------------------------------------
      // It should have 2 frames in it
      // -----------------------------------------------
      assert(frameset->size() == 2);

      // -----------------------------------------------
      // Get a frame and look at the stacked contents
      // -----------------------------------------------
      frameset::FrameSetReader::FramePtr frame = frameset->at(0);
      frameset::Blob<uint32_t> steps = frame->get("STEP");
      assert(steps.count() == 3); // One for each subframe
      assert(steps[0] == 110);
      assert(steps[1] == 111);
      assert(steps[2] == 112);

      frameset::Blob<char> blobtitle = frame->get("TITLE");
      std::string title(blobtitle.data().get(),blobtitle.count());
      assert(title == "hello world!");

      frame = frameset->at(1);
      steps = frame->get("STEP");
      assert(steps.count() == 3); // One for each subframe
      assert(steps[0] == 220);
      assert(steps[1] == 221);
      assert(steps[2] == 222);

    }

    frameset::FrameSet::recursivelyRemove("collection.dir");

  } catch (std::exception& e) {
    std::cerr << e.what() << std::endl;
    return 1;
  }
  return 0;
}
