/* 
Copyright 2012-2014, D. E. Shaw Research.
All rights reserved.

Redistribution and use in source and binary forms, with or without
modification, are permitted provided that the following conditions are
met:

* Redistributions of source code must retain the above copyright
  notice, this list of conditions, and the following disclaimer.

* Redistributions in binary form must reproduce the above copyright
  notice, this list of conditions, and the following disclaimer in the
  documentation and/or other materials provided with the distribution.

* Neither the name of D. E. Shaw Research nor the names of its
  contributors may be used to endorse or promote products derived from
  this software without specific prior written permission.

THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
"AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR
A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT
OWNER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,
SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT
LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE,
DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY
THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
(INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE
OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
*/

#include <FrameSet/FrameSetReader.hxx>

#include <string>
#include <vector>
#include <iostream>
#include <fstream>
#include <stdio.h>
#include <stdlib.h>
#include <sys/types.h>
#include <sys/stat.h>
#ifdef DESRES_OS_Windows
#else
#include <unistd.h>
#endif

static const char* usage =
  "frameset_lint_and_copy [--renumber-from-time=0.0] [--deltat=1.0] [--ignore-times] [--frames-per-file=128] [--output=FILE.{atr,dtr,dcd}] input ...\n"
  "\n"
  "  --renumber-from-time=TIME           Set a new start time\n"
  "  --deltat=TIME                       Set a new delta t if renumbering the times\n"
  "  --ignore-times                      Ignore frameset overlaps, useful for renumbering\n"
  "  --frames-per-file=N                 Number of frames per file in a frameset or dcd output (default 128)\n"
  "  --output=FILE                       Optional output file.  If not present, just check the frames\n"
  "\n"
  ;

static void validate_frame(const frameset::Frame& F,double chemical_time,double push_time) {
  frameset::Blob<double> T = F.get("CHEMICALTIME");
  printf("time is %g, frame time is %g,push time is %g\n",T[0],chemical_time,push_time);
}

static bool parseopt(const std::string& match,const std::string& option,std::string& arg) {
  arg = "";
  size_t match_n = match.size();

  // if the option does starts with match, we fail
  if ( option.substr(0,match_n) != match) return false;

  // if no further characters, we have a (no arg) match
  if ( option.size() == match_n) return true;

  // Else must have an ==
  if ( option[match_n] != '=' ) return false;

  // Set arg to the rest of the string
  arg = option.substr(match_n+1);
  return true;
}

static bool parsearg(const std::string& match,const std::string& option,std::string& arg) {
  return parseopt(match,option,arg) && arg.size() > 0;
}
  


int main(int argc, char** argv) {
  std::string output;
  std::string string_fpf = "128";
  std::string string_renumber_from_time = "0.0";
  std::string string_deltat = "1.0";

  bool verify_only = true;
  bool ignore_times = false;
  bool dcd_output = false;
  bool dtr_output = false;
  bool stk_output = false;
  bool renumber_times = false;

  // ------------------------------------------------------------------------
  // Pick off the options (if any)
  // ------------------------------------------------------------------------
  std::string value;
  for(int i=1;i<argc;++i) {
    std::string arg(argv[i]);

    if (parseopt("--ignore-times",arg,value)) {
      argv[i] = NULL;
      renumber_times = true;
      ignore_times = true;
    } else if (parsearg("--output",arg,value)) {

      argv[i] = NULL;
      output = value;

      verify_only = false;
      std::cout << output.substr(output.size()-4) << std::endl;
      if (output.substr(output.size()-4) == ".dcd") { dcd_output = true; }
      else if (output.substr(output.size()-4) == ".dtr") { dtr_output = true; }
      else if (output.substr(output.size()-4) == ".atr") { dtr_output = true; }
      else {
        fputs(usage,stderr);
        fprintf(stderr,"Output must be dcd, dtr, or atr\n");
        return 1;
      }

    } else if (parsearg("--frames-per-file",arg,value)) {
      argv[i] = NULL;
      string_fpf = value;
    } else if (parsearg("--renumber-from-time",arg,value)) {
      renumber_times = true;
      argv[i] = NULL;
      string_renumber_from_time = value;
    } else if (parsearg("--deltat",arg,value)) {
      renumber_times = true;
      argv[i] = NULL;
      string_deltat = value;
    } else if (arg.substr(0,1) == "-") {
        fputs(usage,stderr);
        fprintf(stderr,"Unknown option %s\n",argv[i]);
        return 1;
      }
  }

  std::cout << "output: " << output << std::endl;
  std::cout << "fpf: " << string_fpf << std::endl;
  std::cout << "renumber_from_time: " << string_renumber_from_time << std::endl;
  std::cout << "deltat: " << string_deltat << std::endl;
  std::cout << "verify_only: " << verify_only << std::endl;
  std::cout << "ignore_times: " << ignore_times << std::endl;
  std::cout << "dcd_output: " << dcd_output << std::endl;

  std::cout << "\n";

  // ------------------------------------------------------------------------
  // Convert from strings
  // ------------------------------------------------------------------------
  double renumber_from_time = strtod(string_renumber_from_time.c_str(),NULL);
  double deltat = strtod(string_deltat.c_str(),NULL);
  long fpf = strtod(string_fpf.c_str(),NULL);

  // ------------------------------------------------------------------------
  // Output cannot exist
  // ------------------------------------------------------------------------
  struct stat status;
  if (output.size() && stat(output.c_str(),&status) == 0) {
    fputs(usage,stderr);
    fprintf(stderr,"Cravenly refusing to overwrite %s\n",output.c_str());
    return 1;
  }

  // ------------------------------------------------------------------------
  // Look at each input argument.  If it is an .stk (regular file), then we
  // process each of it's internal elements.  If it is a directory, we presume
  // that it is a frameset.
  // ------------------------------------------------------------------------
  std::vector<std::string> inputs;
  for(int i=1;i<argc;++i) {
    if (argv[i] == NULL) continue; // Was an --option
    std::string arg = argv[i];

    struct stat status;
    if (stat(arg.c_str(),&status) < 0) {
      fputs(usage,stderr);
      fprintf(stderr,"No such input file %s\n",arg.c_str());
      return 1;
    }

    if (status.st_mode & S_IFDIR) {
      inputs.push_back(arg);
    } else {
      std::ifstream stk(arg.c_str());
      if (!stk.is_open()) {
        fputs(usage,stderr);
        fprintf(stderr,"Could not open STK %s\n",arg.c_str());
        return 1;
      }
      std::string line;
      while (stk.good() ) {
        getline(stk,line);
        if (line.size() == 0) continue; // Handles empty line at the end.

        struct stat status;
        if (stat(line.c_str(),&status) < 0) {
          fputs(usage,stderr);
          fprintf(stderr,"No such sub-file %s in STK file  %s\n",line.c_str(),arg.c_str());
          return 1;
        }
        inputs.push_back(line);
      }
      stk.close();
    }
  }

  // ------------------------------------------------------------------------
  // Get a vector of framesets... we're only going to look at them one-at-a-
  // time anyway.  This means that we'll open a lot of timekey files so it
  // will naturally be kind of slow.  We could multi-thread this part at a
  // later date and slam the filesystem.
  // ------------------------------------------------------------------------
  std::vector<frameset::FrameSetReader*> readers;
  for(std::vector<std::string>::iterator p=inputs.begin(),en=inputs.end(); p != en; ++p) {
    frameset::FrameSetReader* reader = NULL;
    try {
      reader = new frameset::FrameSetReader(*p);
      readers.push_back(reader);
    } catch (const std::exception& e) {
      fputs(usage,stderr);
      fprintf(stderr,"Could not open %s as a FrameSet\n",(*p).c_str());
      fputs(e.what(),stderr);
      return 1;
    }

  }

  // ------------------------------------------------------------------------
  // Look at the start times for each
  // ------------------------------------------------------------------------
  std::vector<double> start_times;
  
  // Handle degenerate case of empty first frameset (or all empty!)
  double default_start = -1.0;
  size_t nreaders = inputs.size();
  if (!nreaders) {
      fputs(usage,stderr);
      fprintf(stderr,"Nothing to read\n");
      return 1;
  }


  for(size_t i=0; i < nreaders; ++i) {
    frameset::FrameSetReader* reader = readers[i];
    size_t n = reader->size();
    if (n != 0) { default_start = reader->time(0); break; }
  }

  printf("First start time is %g\n",default_start);

  double end_time = default_start;
  for(size_t i=0; i < nreaders; ++i) {
    frameset::FrameSetReader* reader = readers[i];
    size_t n = reader->size();
    if (n) {
      double start = reader->time(0);
      start_times.push_back(start);
      default_start = start;
      end_time = reader->time(n-1);
    } else {
      start_times.push_back(default_start);
    }
  }

  // Add the last end time plus something to the start_times vector to simplify the time checks below
  start_times.push_back(end_time+1);
  for(size_t i=0; i <= nreaders; ++i) std::cerr << start_times[i] << std::endl;
  printf("last end time is %g\n",end_time);

  // ------------------------------------------------------------------------
  // We have to adjust the start time for each to account for overlap
  // ------------------------------------------------------------------------
  for(ssize_t i=nreaders; i > 0; --i) {
    if (start_times[i] < start_times[i-1]) {
      start_times[i-1] = start_times[i];
    }
  }


  // ------------------------------------------------------------------------
  // OK, now to copy over the frames (renumbering as we go if so desired)
  // ------------------------------------------------------------------------
  double T = renumber_from_time;
  for(size_t i=0; i < nreaders; ++i) {
    frameset::FrameSetReader* reader = readers[i];

    // If we ignore times, grab all frames (since we will be renumbering anyway)
    if (ignore_times) {
      for(frameset::FrameSetReader::iterator p=reader->begin(); p != reader->end(); ++p) {
        validate_frame(*p,p.time(),renumber_from_time);
        renumber_from_time += deltat;
      }
    } else {
      std::cerr << start_times[i] << " to " << start_times[i+1] << std::endl;
      ssize_t begin = reader->search_ge(start_times[i]);
      ssize_t end   = reader->search_lt(start_times[i+1]);
      std::cerr << "  -> " << begin << " to " << end << std::endl;
      for(ssize_t i=begin; i<=end; ++i) {
        validate_frame(*(*reader)[i],reader->time(i),renumber_from_time);
        renumber_from_time += deltat;
      }
    }
  }

  return 0;
}
