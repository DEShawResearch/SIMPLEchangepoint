#!/usr/bin/env desres-exec
#{
# desres-cleanenv $FRAMESET_SCRIPT_CLEANENV \
# -- python $0 "$@"
#}
# Copyright D. E. Shaw Research, 2004-2012.

import struct

HEADER_FORMAT = "!III"
ENTRY_FORMAT = '!IIIIII'

##################################################################
#                      FUNCTION ASSEMBLE64                       #
##################################################################
def assemble64(lo,hi):
    return long(hi) << 32L | lo


##################################################################
#                      FUNCTION XASSEMBLE64                      #
##################################################################
def xassemble64(lo,hi):
    long_value = assemble64(lo,hi)
    return struct.unpack('d',struct.pack('L',long_value))[0]


def packedint(long_value):
    hi,lo = ((long_value >> 32) & 0xffffffff,
             (long_value & 0xffffffff ))
    return struct.pack('!II',lo,hi)

def packedfloat(float_value):
    long_value = struct.unpack('L',struct.pack('d',float_value))[0]
    return packedint(long_value)

##################################################################
#               FUNCTION CREATE_TIMEKEY_FROM_TIMES               #
##################################################################
def create_timekey_from_times(array_of_times,framesizes=None,frames_per_file=1):
    # We pair up the times and framesizes
    info = [(time,size) for time,size in zip(array_of_times,framesizes)] if framesizes is not None else \
           [(time,4096) for time in array_of_times] 

    # Write header
    magic = 1145393995 #DESK
    key_record_size = struct.calcsize(ENTRY_FORMAT)

    header = struct.pack(HEADER_FORMAT,magic,frames_per_file,key_record_size)

    entries = [header]

    offset = 0
    last_t = array_of_times[0]-1.0 if len(array_of_times) > 0 else 0
    for chemicaltime,framesize in info:

        assert chemicaltime > last_t
        last_t = chemicaltime

        s  = packedfloat(chemicaltime)
        s += packedint(offset)
        s += packedint(framesize)

        entries.append(s)

    return ''.join(entries)


##################################################################
#               FUNCTION PARSE_TIMEKEY                           #
##################################################################
def parse_timekey(keys):
    # Read the header: 
    """
        typedef struct {
          //! \brief Magic number for frames.
          uint32_t magic;
          //! \brief Number of frames in each file
          uint32_t frames_per_file;
          //! \brief The size of each key record
          uint32_t key_record_size;
        } key_prologue_t;
        """
    n = struct.calcsize(HEADER_FORMAT)
    p = 0
    s = keys[p:p+n]
    p += n

    assert s,'The head better be intact'
    magic,frames_per_file,key_record_size = struct.unpack(HEADER_FORMAT,s)
    assert struct.pack('!I',magic) == 'DESK'

    actual_size = struct.calcsize(ENTRY_FORMAT)
    ret = []
    while 1:
        s = keys[p:p+key_record_size]
        if not s: break
        if len(s) < actual_size:
            raise ValueError,'Frame at %d is truncated to %d bytes'%(
                p,len(s))
        s = s[:actual_size]
        time_lo, time_hi, offset_lo, offset_hi, framesize_lo, framesize_hi = struct.unpack(ENTRY_FORMAT,s)
        chemicaltime = xassemble64(time_lo,time_hi)
        offset =  assemble64(offset_lo,offset_hi)
        framesize = assemble64(framesize_lo,framesize_hi)
        ret.append((chemicaltime, offset, framesize))
        p += key_record_size

    return frames_per_file, ret

##################################################################
#               FUNCTION PARSE_TIMES_FROM_TIMEKEY                #
##################################################################
def parse_times_from_timekey(keys):
    ff, ret = parse_timekey(keys)
    return [chemtime for chemtime,offset,framesize in ret]
    
def test():
    import framesettools,os
    os.system('rm -rf xyz.fs')
    fs = framesettools.FrameSet('xyz.fs','w')

    framesizes = []
    for i in range(10):
        frame = framesettools.Frame()
        frame.ABC = 3*i
        frame.XYZ = 'hello'

        fs.push_back(frame,i*10.0)
        framesizes.append( frame.__framesize__() )

    timekeys = open('xyz.fs/timekeys').read()

    times = parse_times_from_timekey(timekeys)
    timekeys2 = create_timekey_from_times(times,framesizes)
    assert timekeys == timekeys2
    return

if __name__ == '__main__':
    test()
    
    
