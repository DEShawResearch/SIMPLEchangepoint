#!/usr/bin/env desres-exec
#{
# desres-cleanenv $FRAMESET_SCRIPT_CLEANENV \
# -- python $0 "$@"
#}
# Copyright D. E. Shaw Research, 2004-2012.

"""
Usage: mv input.dtr/timekeys input.dtr/timekeys.old
       gen_timekeys.py input.dtr > input.dtr/timekeys

This script generates a timekeys file for a frameset trajectory by reading
all the frame files found in the directory and creating a timekeys file
that maps all the frames.

The new timekeys data is written to stdout.  

TODO: This script does not even try to handle or detect framesets with
multiple frames per file.  It assumes one frame per file.
"""

import warnings
warnings.warn("deprecated: Use rebuild_timekeys",DeprecationWarning)

from framesettools import Frame
import os, struct, sys

# spells DESK (DE Shaw Key) in network byte order
magic_timekey = 0x4445534b

# This is the callback for each file we encounter in the directory tree
def func(m, dirname, fnames):
  print >> sys.stderr, "Processing %d files in %s." % (len(fnames), dirname)
  for f in fnames:
    if not f.startswith('frame'): continue
    s=file(os.path.join(dirname,f)).read()
    frame = Frame(rawbytes=s)
    time = frame.CHEMICALTIME[0]
    if time in m:
      raise ValueError, "Duplicate time found in files %s and %s" % (
          f, m[time][2] )
    m[time] = (0,len(s),f) # offset, size, file name

def main(dir):
  # we build up a dictionary mapping chemical time to offset and size
  m={}
  os.path.walk(dir, func, m)
  print >>sys.stderr, "Found %d frames." % len(m)

  # Write the header: 
  """
    typedef struct {
      //! \brief Magic number for frames.
      uint32_t magic;
      //! \brief Number of frames in each file
      uint32_t frames_per_file;
      //! \brief The size of each key record
      uint32_t key_record_size;
    } key_prologue_t;
  """
  sys.stdout.write(struct.pack("!III", magic_timekey, 1, 6*4))

  # Write records:
  """
    typedef struct {
      //! \brief Time associated with this file (low bytes).
      uint32_t time_lo;
      //! \brief Time associated with this file (high bytes)
      uint32_t time_hi;
      //! \brief Zero in the 1 frame/file case (low bytes)
      uint32_t offset_lo;
      //! \brief Zero in the 1 frame/file case (high bytes)
      uint32_t offset_hi;
      //! \brief Number of bytes in frame (low bytes)
      uint32_t framesize_lo;
      //! \brief Number of bytes in frame (high bytes)
      uint32_t framesize_hi;
    } key_record_t;
  """
  times = m.keys()
  times.sort()
  for time in times:
    offset, size, filename = m[time]
    # split the double precision time value into low and high bytes.
    s = struct.pack("!d", time)
    time_hi, time_lo = struct.unpack("!II", s)
    # split up the size
    if type(size) == int:
      framesize_lo = size
      framesize_hi = 0
    elif type(size) == long:
      framesize_lo = int(size & 0xffffffff)
      framesize_hi = a >> 32
    # offset is assumed to be zero, since we have one frame per file
    offset_lo=0
    offset_hi=0

    # write the data
    sys.stdout.write(struct.pack("!IIIIII",
      time_lo, time_hi,
      offset_lo, offset_hi,
      framesize_lo, framesize_hi
      ))
  print >> sys.stderr, "Finished writing timekeys file."

if __name__=="__main__":
  if len(sys.argv) != 2: 
    print __doc__
    sys.exit(1)

  main(sys.argv[1])

