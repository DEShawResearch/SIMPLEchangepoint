/* 
Copyright 2012-2014, D. E. Shaw Research.
All rights reserved.

Redistribution and use in source and binary forms, with or without
modification, are permitted provided that the following conditions are
met:

* Redistributions of source code must retain the above copyright
  notice, this list of conditions, and the following disclaimer.

* Redistributions in binary form must reproduce the above copyright
  notice, this list of conditions, and the following disclaimer in the
  documentation and/or other materials provided with the distribution.

* Neither the name of D. E. Shaw Research nor the names of its
  contributors may be used to endorse or promote products derived from
  this software without specific prior written permission.

THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
"AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR
A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT
OWNER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,
SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT
LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE,
DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY
THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
(INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE
OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
*/

#include "Python.h"

/* Max pathname length */
#ifndef MAXPATHLEN
#if defined(PATH_MAX) && PATH_MAX > 1024
#define MAXPATHLEN PATH_MAX
#else
#define MAXPATHLEN 1024
#endif
#endif


#include <sys/types.h>
#include <sys/stat.h>
#include <unistd.h>

#include "numpy/arrayobject.h"

#include "FrameSet/Frame.hxx"
#include "FrameSet/ReaderFrame.hxx"
#include "FrameSet/FrameSetReader.hxx"
#include "FrameSet/FrameSetWriter.hxx"
#include <dessert/dessert.hpp>

// This seems stupid, but we need it for builds on echelon
// since _POSIX_C_SOURCE differences get in the way of
// important type definitions

#include "FrameSetExceptions.cxx"
#include "HumanTypename.cxx"
#include "BaseBlob.cxx"
#include "Blob.cxx"
#include "Frame.cxx"
#include "FrameSet.cxx"
#include "FrameSetWriter.cxx"
#include "FrameSetReader.cxx"
#include "FilelessReader.cxx"
#include "ReaderFrame.cxx"
#include "StackFrameSet.cxx"
#include "OverlayFrameSet.cxx"

// In a few places, Python declares arguments and struct members as
// char*, but we want to assign them from literal constants.  Without
// a const cast, this generates a warning in C++.  This is the required
// const cast with minimal typing.
#define CC(x) const_cast<char *>(x)

//----------------------------------------------------------------------
// Short
//----------------------------------------------------------------------
#if NPY_SIZEOF_SHORT == 2
typedef int16_t equivalent_to_short;
typedef uint16_t equivalent_to_ushort;
#else
#if NPY_SIZEOF_SHORT == 4
typedef int32_t equivalent_to_short;
typedef uint32_t equivalent_to_ushort;
#else
#if NPY_SIZEOF_SHORT == 8
typedef int64_t equivalent_to_short;
typedef uint64_t equivalent_to_ushort;
#else
typedef short equivalent_to_short;
typedef unsigned short equivalent_to_ushort;
#endif
#endif
#endif

//----------------------------------------------------------------------
// Int
//----------------------------------------------------------------------
#if NPY_SIZEOF_INT == 2
typedef int16_t equivalent_to_int;
typedef uint16_t equivalent_to_uint;
#else
#if NPY_SIZEOF_INT == 4
typedef int32_t equivalent_to_int;
typedef uint32_t equivalent_to_uint;
#else
#if NPY_SIZEOF_INT == 8
typedef int64_t equivalent_to_int;
typedef uint64_t equivalent_to_uint;
#else
typedef int equivalent_to_int;
typedef unsigned int equivalent_to_uint;
#endif
#endif
#endif

//----------------------------------------------------------------------
// Long
//----------------------------------------------------------------------
#if NPY_SIZEOF_LONG == 2
typedef int16_t equivalent_to_long;
typedef uint16_t equivalent_to_ulong;
#else
#if NPY_SIZEOF_LONG == 4
typedef int32_t equivalent_to_long;
typedef uint32_t equivalent_to_ulong;
#else
#if NPY_SIZEOF_LONG == 8
typedef int64_t equivalent_to_long;
typedef uint64_t equivalent_to_ulong;
#else
typedef long equivalent_to_long;
typedef unsigned long equivalent_to_ulong;
#endif
#endif
#endif

// for ntohl
#include <netinet/in.h>

#define CHECKNULL(obj) do { \
    if (obj->frameset==NULL) throw frameset::FrameSetException("operation on closed frameset", DESSERT_LOC); \
}  while (0)

#define CATCHCXXi \
  catch (const desres::dessert& e) {                     \
    PyErr_SetString(PyExc_RuntimeError,e.what(false));   \
    return -1; \
  } catch(const std::exception& e) { \
    PyErr_SetString(PyExc_RuntimeError,e.what()); \
    return -1; \
  }

/* for functions returning void */
#define CATCHCXXv \
  catch (const desres::dessert& e) {                     \
    PyErr_SetString(PyExc_RuntimeError,e.what(false));   \
    return; \
  } catch(const std::exception& e) { \
    PyErr_SetString(PyExc_RuntimeError,e.what()); \
    return; \
  }

#define CATCHCXX \
  catch (const desres::dessert& e) {                     \
    PyErr_SetString(PyExc_RuntimeError,e.what(false));   \
    return NULL; \
  } catch(const std::exception& e) {              \
    PyErr_SetString(PyExc_RuntimeError,e.what()); \
    return NULL; \
  }

/* FIXME: Why no Py_XDECREF in the dessert case? */
#define CATCHCXXANDKILL(x) \
  catch (const desres::dessert& e) {                     \
    PyErr_SetString(PyExc_RuntimeError,e.what(false));   \
    return NULL; \
  } catch(const std::exception& e) {              \
    Py_XDECREF(x); \
    PyErr_SetString(PyExc_RuntimeError,e.what()); \
    return NULL; \
  }

const char* DOCSTRING =
  "Quick Introduction to Framesets\n"
  "\n"
  "A frameset associates a collection of 1-dimensional fields associated\n"
  "with a particular time.  The data is internally typed to match\n"
  "standard C data types (char, unsigned char, float, double, int16_t,\n"
  "uint16_t, int32_t, uint32_t, int64_t, and uint64_t).\n"
  "\n"
  "Each bundle of data (or field) associated with a particular time is\n"
  "known as a \"frame.\"  A collection of frames at ascending times is\n"
  "known as a frame set.\n"
  "\n"
  "A frameset open for reading supports some primitive operations:\n"
  "\n"
  "   Get the number of frames in the collection\n"
  "   Fetch a frame object by index\n"
  "   Fetch a frame object by time (nearest, gt, ge, lt, le)\n"
  "   Fetch the times that are represented within this frameset\n"
  "\n"
  "A frameset open for writing/appending supports only a few primitive\n"
  "operations:\n"
  "\n"
  "   Append a frame/time pair to the end of the frameset\n"
  "   Rewind (remove frames from the end of a frameset)\n"
  "   Get the time associated with the last frame added\n"
  "\n"
  "Frame objects support operations to access fields:\n"
  "\n"
  "   Get the labels for all fields\n"
  "   Fetch a field by name\n"
  "   Get the type of a field by name\n"
  "   Get the length of a field by name\n"
  "   Add a new field\n"
  "   Serialize a frame to a \"bag of bytes\"\n"
  "\n"
  "On disk, framesets are actually directories filled with\n"
  "meta-information files and frame files.  The meta-information\n"
  "describes how the bags of bytes that represent serialized frames are\n"
  "laid out in the file system.  The meta-information files include the\n"
  "\".ddparams\" file which describes how frame files are hashed into\n"
  "numbered, nested sub-directories and the \"timekeys\" file which pairs\n"
  "time values with size/offset information to find each frame's\n"
  "serialized bytes.\n"
  "\n"
  "The framefiles contain bags of bytes that represent the serialized\n"
  "frames of the frameset.  Each framefile contains one or more frame\n"
  "bags per file.  The timekeys file provides a map to these files and\n"
  "an indicator of how many frames are packed into each file.  Putting\n"
  "multiple frames per file is more efficient for reading because of\n"
  "filesystem caching issues and directory backup.  If the number of\n"
  "framefiles being created is very large (greater than 100,000), the\n"
  "framefiles can be hashed into a deepdir structure that creates\n"
  "a nest of numbered subdirectories.\n"
  "\n"
  "\n"
  "Framesets also support a soft catenation mechanism for .stk files.\n"
  "These files are simply lists of frameset directories.\n"
  "\n"
  "The frameset package provides interfaces to access framesets and frames\n"
  "in C++ and Python.\n"
  "\n"
  "Example 1: Open an existing frameset and extract a field of doubles\n"
  "called POSITION from each frame.\n"
  "\n"
  "C++:\n"
  "\n"
  "#include <FrameSet/FrameSetReader.hxx>\n"
  "\n"
  "frameset::FrameSetReader reader(\"trajectory.dtr\");\n"
  "\n"
  "std::cout << \"Reader has \" << reader.size() << \" frames.\" << std::endl;\n"
  "int i=0;\n"
  "for(frameset::FrameSetReader::iterator p = reader.begin(); p != reader.end(); ++p,++i) {\n"
  "    frameset::Frame& frame = *p;\n"
  "\n"
  "    std::cout << \"Time is \" << p.time() << std::endl;\n"
  "\n"
  "    frameset::Blob<float> position = frame.get(\"POSITION\");\n"
  "    std::cout << \"position has \" << position.count() << \" elements of type \" << position.type() << std::endl;\n"
  "    float* pos = position; // Get the raw pointer\n"
  "    ...\n"
  "}\n"
  "\n"
  "\n"
  "Python:\n"
  "\n"
  "import framesettools\n"
  "\n"
  "reader = framesettools.FrameSet('trajectory.dtr')\n"
  "print 'Reader has',len(reader),'frames'\n"
  "for i,frame in enumerate(reader):\n"
  "   print 'Time is',reader.time(i)\n"
  "   position = frame.POSITION  # A numpy array!\n"
  "   print \"position has\",len(position),\"elements of type\",frame.__type__(\"POSITION\")\n"
  "\n"
  "\n"
  "Example 2:\n"
  "\n"
  "Create a new trajectory with individual POSITION and ENERGY fields and a\n"
  "TITLE field shared by all frames.\n"
  "\n"
  "C++:\n"
  "\n"
  "\n"
  "#include <FrameSet/FrameSetWriter.hxx>\n"
  "\n"
  "frameset::FrameSetWrite writer(\"trajectory.dtr\");\n"
  "\n"
  "frameset::Frame& meta = writer.meta(); // Common frame\n"
  "std::string title(\"Unobtainium folding example\");\n"
  "meta.set_values(\"TITLE\",title.begin(),title.end());\n"
  "writer.flush_meta(); // Push frame to disk\n"
  "\n"
  "frameset::Frame frame;\n"
  "std::vector<float> pos;\n"
  "double energy = 0.0;\n"
  "initialize_simulation(pos,energy)\n"
  "for(double time = 0.0; time < 10.0; time += 2.5) {\n"
  "   take_a_timestep(time,pos,energy);\n"
  "   frame.set_value(\"ENERGY\",energy); // A scalar\n"
  "   frame.set_values(\"POSITION\",pos.begin(),pos.end());\n"
  "   writer.push_back(frame,time);\n"
  "}\n"
  "writer.flush_keyfile(); // Sync timekeys file to disk\n"
  "\n"
  "\n"
  "Python:\n"
  "\n"
  "import framesettools,numpy\n"
  "\n"
  "writer = framesettools.FrameSet('trajectory.dtr','w')\n"
  "\n"
  "meta = writer.meta()\n"
  "meta.TITLE = \"Unobtainium folding example\"\n"
  "\n"
  "frame = framesettools.Frame()\n"
  "pos = numpy.zeros((120,3))\n"
  "energy = 0.0\n"
  "energy = initialize_simulation(pos,energy)\n"
  "for time in numpy.arange(0.0,10.0,2.5):\n"
  "    energy = take_a_timestep(time,pos,energy)\n"
  "    frame.POSITION = position\n"
  "    frame.ENERGY = energy\n"
  "    writer.push_back(frame,time)\n"
  "\n"
  "\n"
  "Example 3:\n"
  "\n"
  "Read frames from a soft catenation .stk file\n"
  "\n"
  "C++:\n"
  "#include <FrameSet/OverlayFrameSet.cxx>\n"
  "\n"
  "FILE* fp = fopen(\"example.stk\",\"r\");\n"
  "char line[MAXPATHLEN+1];\n"
  "fgets(line,sizeof(line),fp);\n"
  "line[strlen(line)-1] = NULL;  // Remove trailing \\n\n"
  "frameset::OverlayFrameSet reader(line);\n"
  "while(fgets(line,sizeof(line),fp)) {\n"
  "    line[strlen(line)-1] = NULL;  // Remove trailing \\n\n"
  "    reader.overlay(line)\n"
  "}\n"
  "\n"
  "\n"
  "Python:\n"
  "\n"
  "import framesettools\n"
  "reader = framesettools.FrameSet(\"example.stk\")\n"
  "\n"
  "Example 4:\n"
  "\n"
  "Creating a deepdir nest (10,10) for the frame files on write.\n"
  "\n"
  "\n"
  "#include <FrameSet/FrameSetWriter.hxx>\n"
  "frameset::FrameSetWrite writer(\"trajectory.dtr\",\"w\",10,10);\n"
  "\n"
  "import framesettools\n"
  "writer = framesettools.FrameSet(\"trajectory.dtr\",mode=\"w\",ndir1=10,ndir2=10)\n"
  "\n"
  "\n"
  "Example 5:\n"
  "\n"
  "Pack 64 frames per framefile.\n"
  "\n"
  "#include <FrameSet/FrameSetWriter.hxx>\n"
  "frameset::FrameSetWrite writer(\"trajectory.dtr\",\"w\",0,0,64);\n"
  "\n"
  "import framesettools\n"
  "writer = framesettools.FrameSet(\"trajectory.dtr\",\"w\",frames_per_file=64)\n"
  "\n"
  "Example 6:\n"
  "\n"
  "Open a frameset for catenation with time truncation\n"
  "\n"
  "#include <FrameSet/FrameSetWriter.hxx>\n"
  "frameset::FrameSetWrite writer(\"trajectory.dtr\",\"a\");\n"
  "writer.rewind(initial_time)\n"
  "\n"
  "import framesettools\n"
  "writer = framesettools.FrameSet(\"trajectory.dtr\",\"a\")\n"
  "writer.rewind(initial_time)\n"
  "\n"
  "Example 7:\n"
  "\n"
  "Open a trajectory for writing, but remove any prexisting directory\n"
  "\n"
  "#include <FrameSet/FrameSetWriter.hxx>\n"
  "frameset::FrameSetWrite writer(\"trajectory.dtr\",\"w!\");\n"
  "\n"
  "import framesettools\n"
  "writer = framesettools.FrameSet(\"trajectory.dtr\",\"w!\")\n"
  "\n"
  "Example 8:\n"
  "\n"
  "Look up a frame by time T and get position information\n"
  "\n"
  "C++\n"
  "\n"
  "double T = 35.5;\n"
  "\n"
  "#include <FrameSet/FrameSetReader.hxx>\n"
  "frameset::FrameSetReader reader(\"trajectory.dtr\");\n"
  "\n"
  "ssize_t index = reader.search_nearest(T);\n"
  "frameset::FrameSetReader::FramePtr frame = reader[index];\n"
  "double actual_time = reader.time(index);\n"
  "frameset::Blob<double> position = frame->get(\"POSITION\");\n"
  "\n"
  "[Note: You can also search_le, search_lt, search_ge, search_gt]\n"
  "\n"
  "Python:\n"
  "\n"
  "T = 35.5\n"
  "import framesettools\n"
  "reader = framesettools.FrameSet(\"trajectory.dtr\")\n"
  "\n"
  "frame = reader[reader.nearest(T)]\n"
  "position = frame.POSITION\n";

/*! \brief Container for a string
 * 
 * This container is used in creating frames from serialized bytes.
 * We need to keep alive the Python string to avoid copying the bytes
 * to another object.  This adaptor lets us build a boost smart pointer
 * that respects the Python reference count.
 */
class PythonStringContainer: public frameset::ReaderFrame::ContainerBase {
  PyObject* m_string;
  size_t m_size;
  char* m_data;
public:
  //! \brief Make container from Python string
  PythonStringContainer(PyObject* string=NULL)
    : m_string(string),
      m_size(0),
      m_data(NULL)
  {
    if (m_string) {
      Py_INCREF(m_string);
      m_size = PyString_Size(string);
      if (PyErr_Occurred()) {
        throw frameset::FrameSetException("cannot compute string size");
      }
      m_data = PyString_AsString(string);
      if (PyErr_Occurred()) {
        throw frameset::FrameSetException("cannot grab string pointer");
      }
    }
  }

  //! \brief Virtual destructor
  virtual ~PythonStringContainer() {
    Py_XDECREF(m_string);
  }

  //! \brief number of characters in string
  virtual size_t size() const {
    return m_size;
  }
  
  //! \brief raw data pointer
  virtual char* data() {
    return m_data;
  }

  //! \brief raw data pointer
  virtual const char* data() const {
    return m_data;
  }

};

// -----------------------------------------------
// Type object declarations
// -----------------------------------------------
static PyTypeObject  PyFrame_def;
static PyTypeObject* PyFrame_t = &PyFrame_def;
static PyObject*     PyFrame = (PyObject*)(&PyFrame_def);
/*! \brief Holds a frame object
 * 
 * Frame
 */
typedef struct {
  PyObject_HEAD
  //! \brief Pointer to actual frame
  frameset::FrameSetReader::FramePtr* frame;
} PyFrame_Object;

static PyTypeObject  PyFrameSet_def;
static PyTypeObject* PyFrameSet_t = &PyFrameSet_def;
static PyObject*     PyFrameSet = (PyObject*)(&PyFrameSet_def);
/*! \brief Holds a frameset object
 * 
 * FrameSet
 */
typedef struct {
  PyObject_HEAD
  //!\brief Pointer to actual frameset
  frameset::FrameSet* frameset;
  std::string * filename;
} PyFrameSet_Object;

static PyTypeObject  PyFrameSetIter_def;
static PyTypeObject* PyFrameSetIter_t = &PyFrameSetIter_def;
static PyObject*     PyFrameSetIter = (PyObject*)(&PyFrameSetIter_def);
/*! \brief Holds a frameset iterator
 * 
 * Frameset Iterator
 */
typedef struct {
  PyObject_HEAD
  //!\brief Pointer to Python frameset (keepalive)
  PyObject* frameset;
  //!\brief Current frame offset
  Py_ssize_t frameno;
  //!\brief Max frame offset
  Py_ssize_t framecount;
} PyFrameSetIter_Object;

static PyTypeObject  PyFrameIter_def;
static PyTypeObject* PyFrameIter_t = &PyFrameIter_def;
static PyObject*     PyFrameIter = (PyObject*)(&PyFrameIter_def);
/*! \brief Frame iterator object
 * 
 * Allows us to iterate across keys and values of a frame
 */
typedef struct {
  PyObject_HEAD
  //!\brief Pointer to actual frame
  PyObject* frame;
  //!\brief List of label strings
  PyObject* labels;
  //!\brief Current label offset
  Py_ssize_t labelno;
} PyFrameIter_Object;


/**************************************************************************/
/* LOCAL  **************      PyFrameSet_init      ************************/
/************************************************************************ **/
/*  */
/**************************************************************************/
static int PyFrameSet_init(PyObject* pySelf, PyObject* args, PyObject* kw) {
  PyFrameSet_Object* self = reinterpret_cast<PyFrameSet_Object*>(pySelf);
  static const char* kwlist[] = {"filename","mode","ndir1","ndir2","frames_per_file","timekeysdata","metaframedata",0};
  char* filename = NULL;
  const char* mode = "r";
  int ndir1 = 0;
  int ndir2 = 0;
  FILE* fp = NULL;
  Py_ssize_t frames_per_file = 1;
  const char* timekeysdata = NULL;
  int len_timekeysdata = 0;
  const char* metaframedata = NULL;
  int len_metaframedata = 0;

  if (!PyArg_ParseTupleAndKeywords(args,kw,"s|siinz#z#",const_cast<char **>(kwlist),
                                   &filename,&mode,
                                   &ndir1,&ndir2,
                                   &frames_per_file,
                                   &timekeysdata,&len_timekeysdata,
                                   &metaframedata,&len_metaframedata)) return -1;

  try {
    self->filename = new std::string(filename);

    // Default is to read files
    if (mode[0] == 'r' && mode[1] == '\0') {
      struct stat statbuf;
      
      // Special shortcut that avoids the filesystem if you have all the necessary info
      if ( timekeysdata != NULL ) {
        std::string timekeys(timekeysdata,len_timekeysdata);
        if (metaframedata) {
          std::string metaframe(metaframedata,len_metaframedata);
          self->frameset = new frameset::FilelessReader(filename,ndir1,ndir2,timekeys,metaframe);
        } else {
          self->frameset = new frameset::FilelessReader(filename,ndir1,ndir2,timekeys,"");
        }
      }

      // If it's a directory (normal frameset) or file (.stk)
      else {
        self->frameset = frameset::OverlayFrameSet::from_stk_file_or_directory(filename);
      }

    }

    // You can override the mode to write or append files
    else {
      self->frameset = new frameset::FrameSetWriter(filename,mode,ndir1,ndir2,frames_per_file);
    }
  } CATCHCXXi;

  return 0;
}

/**************************************************************************/
/* LOCAL  **************     PyFrameSet_dealloc    ************************/
/************************************************************************ **/
/*  */
/**************************************************************************/
static void PyFrameSet_dealloc(PyObject* pySelf) {
  PyFrameSet_Object* self = reinterpret_cast<PyFrameSet_Object*>(pySelf);
  try {
    delete self->frameset;
    delete self->filename;
  } CATCHCXXv;
}

static PyObject* PyFrameSet_name(PyObject* pySelf,void* closure) {
  PyFrameSet_Object* self = reinterpret_cast<PyFrameSet_Object*>(pySelf);
  return PyString_FromString(self->filename->c_str());
}

static PyObject* PyFrameSet_size(PyObject* pySelf,void* closure) {
  PyFrameSet_Object* self = reinterpret_cast<PyFrameSet_Object*>(pySelf);
  try {
    CHECKNULL(self);
    size_t size = self->frameset->size();
    return PyInt_FromSize_t(size);
  } CATCHCXX;
}

static PyObject* PyFrameSet_ndir1(PyObject* pySelf,void* closure) {
  PyFrameSet_Object* self = reinterpret_cast<PyFrameSet_Object*>(pySelf);
  try {
    CHECKNULL(self);
    int ndir1 = self->frameset->ndir1();
    return PyInt_FromLong(ndir1);
  } CATCHCXX;
}

static PyObject* PyFrameSet_ndir2(PyObject* pySelf,void* closure) {
  PyFrameSet_Object* self = reinterpret_cast<PyFrameSet_Object*>(pySelf);
  try {
    CHECKNULL(self);
    int ndir2 = self->frameset->ndir2();
    return PyInt_FromLong(ndir2);
  } CATCHCXX;
}

static PyObject* PyFrameSet_frames_per_file(PyObject* pySelf,void* closure) {
  PyFrameSet_Object* self = reinterpret_cast<PyFrameSet_Object*>(pySelf);
  try {
    CHECKNULL(self);
    size_t frames_per_file = self->frameset->frames_per_file();
    return PyInt_FromSize_t(frames_per_file);
  } CATCHCXX;
}

static PyObject* PyFrameSet_closed(PyObject* pySelf,void* closure) {
  PyFrameSet_Object* self = reinterpret_cast<PyFrameSet_Object*>(pySelf);
  return PyBool_FromLong( self->frameset==NULL );
}

static PyGetSetDef PyFrameSet_getset[] = {
    {CC("name"),PyFrameSet_name,NULL,CC("filename for this frameset"),NULL},
    {CC("size"),PyFrameSet_size,NULL,CC("Number of frames (also len())"),NULL},
    {CC("nframes"),PyFrameSet_size,NULL,CC("Number of frames (also len())"),NULL},
    {CC("ndir1"),PyFrameSet_ndir1,NULL,CC("Deep dir parameter 1"),NULL},
    {CC("ndir2"),PyFrameSet_ndir2,NULL,CC("Deep dir parameter 2"),NULL},
    {CC("frames_per_file"),PyFrameSet_frames_per_file,NULL,CC("Frame packing factor"),NULL},
    {CC("closed"),PyFrameSet_closed,NULL,CC("is this frameset closed?"),NULL},
  {0,0}
};

//! \brief Maps a / separated pathname into the hierarchical space.
//virtual std::string hierarchicalName(std::string path) const;
static PyObject* PyFrameSet_hierarchicalName(PyObject* pySelf,PyObject* args) {
  PyFrameSet_Object* self = reinterpret_cast<PyFrameSet_Object*>(pySelf);
  char* name;
  if (!PyArg_ParseTuple(args,"s",&name)) return NULL;

  try {
    CHECKNULL(self);
    std::string hierarchicalName = self->frameset->hierarchicalName(name);
    return PyString_FromString(hierarchicalName.c_str());
  } CATCHCXX;
}

//! \brief Maps a frame number to a filename
//virtual std::string framefile(size_t frameno) const;
static PyObject* PyFrameSet_framefile(PyObject* pySelf,PyObject* args) {
  PyFrameSet_Object* self = reinterpret_cast<PyFrameSet_Object*>(pySelf);
  Py_ssize_t offset = 0;
  if (!PyArg_ParseTuple(args,"n",&offset)) return NULL;

  try {
    CHECKNULL(self);
    std::string framefile = self->frameset->framefile(offset);
    return PyString_FromString(framefile.c_str());
  } CATCHCXX;
}

static PyObject* PyFrameSet_frameinfo(PyObject* pySelf,PyObject* args) {
  PyFrameSet_Object* self = reinterpret_cast<PyFrameSet_Object*>(pySelf);
  Py_ssize_t frameno = 0;
  if (!PyArg_ParseTuple(args,"n",&frameno)) return NULL;

  try {
    CHECKNULL(self);
    frameset::FrameSetReader* reader = dynamic_cast<frameset::FrameSetReader*>(self->frameset);
    if (!reader) {
      PyErr_SetString(PyExc_ValueError,"frameset not open for reading");
      return NULL;
    }
    std::string framefile = self->frameset->framefile(frameno);
    frameset::FrameSet::key_record_t key_record
      = reader->read_keyfile_entry(frameno);

    double time =
      frameset::Frame::assembleDouble(ntohl(key_record.time_lo),
                                      ntohl(key_record.time_hi));
    uint64_t u_offset =
      frameset::Frame::assemble64(ntohl(key_record.offset_lo),
                                  ntohl(key_record.offset_hi));
    uint64_t u_framesize =
      frameset::Frame::assemble64(ntohl(key_record.framesize_lo),
                                  ntohl(key_record.framesize_hi));

    Py_ssize_t offset = static_cast<Py_ssize_t>(u_offset);
    Py_ssize_t framesize = static_cast<Py_ssize_t>(u_framesize);

    return Py_BuildValue("s#dnn",
                         framefile.c_str(),framefile.size(),
                         time,
                         offset,
                         framesize);
  } CATCHCXX;
}

static PyObject * PyFrameSet_flush_meta(PyObject * pySelf,PyObject *) {
  PyFrameSet_Object* self = reinterpret_cast<PyFrameSet_Object*>(pySelf);
  try {
    CHECKNULL(self);
    frameset::FrameSetWriter * writer = dynamic_cast<frameset::FrameSetWriter *>(self->frameset);
    if (!writer) {
      PyErr_SetString(PyExc_ValueError,"frameset not open for writing");
      return NULL;
    }
    writer->flush_meta();
  } CATCHCXX;
  return Py_INCREF(Py_None), Py_None;
}

static PyObject * PyFrameSet_flush_keyfile(PyObject * pySelf,PyObject *) {
  PyFrameSet_Object* self = reinterpret_cast<PyFrameSet_Object*>(pySelf);
  try {
    CHECKNULL(self);
    frameset::FrameSetWriter * writer = dynamic_cast<frameset::FrameSetWriter *>(self->frameset);
    if (!writer) {
      PyErr_SetString(PyExc_ValueError,"frameset not open for reading");
      return NULL;
    }
    writer->flush_keyfile();
  } CATCHCXX;
  return Py_INCREF(Py_None), Py_None;
}

static PyObject * PyFrameSet_flush_framefile(PyObject * pySelf,PyObject *) {
  PyFrameSet_Object* self = reinterpret_cast<PyFrameSet_Object*>(pySelf);
  try {
    CHECKNULL(self);
    frameset::FrameSetWriter * writer = dynamic_cast<frameset::FrameSetWriter *>(self->frameset);
    if (!writer) {
      PyErr_SetString(PyExc_ValueError,"frameset not open for reading");
      return NULL;
    }
    writer->flush_framefile();
  } CATCHCXX;
  return Py_INCREF(Py_None), Py_None;
}

/*
fileinfo(index) --> filepath, offset, framesize, first, lastp1, filesize 
	- filepath is the full path name to the file that contains frame "index"
	- offset is the starting bytes of the frame in the file
	- framesize is the size (in case there are varible length frames in a file)
	- first is the lowest frame number contained in the same file
	- lastp1 is 1 plus the highest frame number contained in the file (lastp1 itself is not included 
	  in the file)
	- filesize is the size of the file
 */

static PyObject* PyFrameSet_fileinfo(PyObject* pySelf,PyObject* args) {
  PyFrameSet_Object* self = reinterpret_cast<PyFrameSet_Object*>(pySelf);
  Py_ssize_t frameno = 0;
  Py_ssize_t first = 0;
  Py_ssize_t last = 0;
  Py_ssize_t filesize = 0;
  if (!PyArg_ParseTuple(args,"n",&frameno)) return NULL;

  try {
    CHECKNULL(self);
    frameset::FrameSetReader* reader = dynamic_cast<frameset::FrameSetReader*>(self->frameset);
    if (!reader) {
      PyErr_SetString(PyExc_ValueError,"frameset not open for reading");
      return NULL;
    }
    std::string framefile = self->frameset->framefile(frameno);
    frameset::FrameSet::key_record_t key_record
      = reader->read_keyfile_entry(frameno);

    double time =
      frameset::Frame::assembleDouble(ntohl(key_record.time_lo),
                                      ntohl(key_record.time_hi));
    uint64_t u_offset =
      frameset::Frame::assemble64(ntohl(key_record.offset_lo),
                                  ntohl(key_record.offset_hi));
    uint64_t u_framesize =
      frameset::Frame::assemble64(ntohl(key_record.framesize_lo),
                                  ntohl(key_record.framesize_hi));

    Py_ssize_t offset = static_cast<Py_ssize_t>(u_offset);
    Py_ssize_t framesize = static_cast<Py_ssize_t>(u_framesize);


    // Back up the frameno until we change file
    first = frameno;
    for(Py_ssize_t i=frameno-1; i>=0; --i) {
      if (self->frameset->framefile(i) != framefile) {
        first = i+1;
        break;
      }
    }

    // Advance the frameno until we change file
    Py_ssize_t nframes = self->frameset->size();
    for(last=frameno+1; last<nframes; ++last) {
      if (self->frameset->framefile(last) != framefile) break;
    }


    if (last == frameno+1) {
      filesize = offset+framesize;
    } else {
      key_record = reader->read_keyfile_entry(last-1);

      u_offset = frameset::Frame::assemble64(ntohl(key_record.offset_lo),
                                             ntohl(key_record.offset_hi));
      u_framesize = frameset::Frame::assemble64(ntohl(key_record.framesize_lo),
                                                ntohl(key_record.framesize_hi));

      filesize = u_offset+u_framesize;
    }

    return Py_BuildValue("s#nnnnn",
                         framefile.c_str(),framefile.size(),
                         offset,
                         framesize,
                         first,
                         last,
                         filesize);
  } CATCHCXX;
}

static PyObject* PyFrameSet_metainfo(PyObject* pySelf,PyObject*) {
  PyFrameSet_Object* self = reinterpret_cast<PyFrameSet_Object*>(pySelf);

  try {
    CHECKNULL(self);
    std::string metapath = self->frameset->subfile("metadata");

    struct stat statbuf;
    if (stat(metapath.c_str(),&statbuf) != 0) {
      PyErr_SetFromErrno(PyExc_IOError);
      return NULL;
    }

    return Py_BuildValue("sn",
                         metapath.c_str(),
                         statbuf.st_size);
  } CATCHCXX;
}


//! \brief Time associated with a frame.
//virtual double time(size_t index) const;
static PyObject* PyFrameSet_time(PyObject* pySelf,PyObject* args) {
  PyFrameSet_Object* self = reinterpret_cast<PyFrameSet_Object*>(pySelf);
  Py_ssize_t offset = -1;
  frameset::FrameSetReader* reader = dynamic_cast<frameset::FrameSetReader*>(self->frameset);
  frameset::FrameSetWriter* writer = dynamic_cast<frameset::FrameSetWriter*>(self->frameset);

  try {
    CHECKNULL(self);
    if (reader) {
      if (!PyArg_ParseTuple(args,"|n",&offset)) return NULL;
      if (offset < 0) offset += self->frameset->size();
      return PyFloat_FromDouble(reader->time(offset));
    } else if (writer) {
      if (!PyArg_ParseTuple(args,"")) return NULL;
      return PyFloat_FromDouble(writer->time());
    } else {
      PyErr_SetString(PyExc_RuntimeError,"Frameset is neither reader nor writer");
      return NULL;
    }
  } CATCHCXX;
}

static PyObject* PyFrameSet_rewind(PyObject* pySelf,PyObject* args) {
  PyFrameSet_Object* self = reinterpret_cast<PyFrameSet_Object*>(pySelf);
  double rewind_time = 0.0;
  frameset::FrameSetReader* reader = dynamic_cast<frameset::FrameSetReader*>(self->frameset);
  frameset::FrameSetWriter* writer = dynamic_cast<frameset::FrameSetWriter*>(self->frameset);

  try {
    CHECKNULL(self);
    if (reader) {
      PyErr_SetString(PyExc_ValueError,"Frameset is not open for write nor append");
      return NULL;
    } else if (writer) {
      if (!PyArg_ParseTuple(args,"|d",&rewind_time)) return NULL;
      writer->rewind(rewind_time);
      return (Py_INCREF(Py_None), Py_None);
    } else {
      PyErr_SetString(PyExc_RuntimeError,"Frameset is neither reader nor writer");
      return NULL;
    }
  } CATCHCXX;
}

static PyObject* PyFrameSet_times(PyObject* pySelf,PyObject*) {
  PyFrameSet_Object* self = reinterpret_cast<PyFrameSet_Object*>(pySelf);
  frameset::FrameSetReader* reader = dynamic_cast<frameset::FrameSetReader*>(self->frameset);

  try {
    CHECKNULL(self);
    if (reader) {
      npy_intp dims = self->frameset->size();
      PyObject* result = PyArray_SimpleNew(1,&dims,NPY_DOUBLE);
      if (!result) return NULL;
      double* data = reinterpret_cast<double*>(PyArray_DATA(result));
      for(npy_intp i=0; i < dims; ++i) {
        data[i] = reader->time(i);
      }

      return result;
    } else {
      PyErr_SetString(PyExc_RuntimeError,"Frameset is not open for reading");
      return NULL;
    }
  } CATCHCXX;
}

static PyObject* PyFrameSet_nearest(PyObject* pySelf,PyObject* args) {
  PyFrameSet_Object* self = reinterpret_cast<PyFrameSet_Object*>(pySelf);
  frameset::FrameSetReader* reader = dynamic_cast<frameset::FrameSetReader*>(self->frameset);

  double target = 0.0;
  if (!PyArg_ParseTuple(args,"d",&target)) return NULL;

  try {
    CHECKNULL(self);
    if (reader) {
      return PyInt_FromSsize_t(reader->search_nearest(target));
    } else {
      PyErr_SetString(PyExc_RuntimeError,"Frameset is not open for reading");
      return NULL;
    }
  } CATCHCXX;
}

static PyObject* PyFrameSet_le(PyObject* pySelf,PyObject* args) {
  PyFrameSet_Object* self = reinterpret_cast<PyFrameSet_Object*>(pySelf);
  frameset::FrameSetReader* reader = dynamic_cast<frameset::FrameSetReader*>(self->frameset);

  double target = 0.0;
  if (!PyArg_ParseTuple(args,"d",&target)) return NULL;

  try {
    CHECKNULL(self);
    if (reader) {
      return PyInt_FromSsize_t(reader->search_le(target));
    } else {
      PyErr_SetString(PyExc_RuntimeError,"Frameset is not open for reading");
      return NULL;
    }
  } CATCHCXX;
}

static PyObject* PyFrameSet_lt(PyObject* pySelf,PyObject* args) {
  PyFrameSet_Object* self = reinterpret_cast<PyFrameSet_Object*>(pySelf);
  frameset::FrameSetReader* reader = dynamic_cast<frameset::FrameSetReader*>(self->frameset);

  double target = 0.0;
  if (!PyArg_ParseTuple(args,"d",&target)) return NULL;

  try {
    CHECKNULL(self);
    if (reader) {
      return PyInt_FromSsize_t(reader->search_lt(target));
    } else {
      PyErr_SetString(PyExc_RuntimeError,"Frameset is not open for reading");
      return NULL;
    }
  } CATCHCXX;
}

static PyObject* PyFrameSet_ge(PyObject* pySelf,PyObject* args) {
  PyFrameSet_Object* self = reinterpret_cast<PyFrameSet_Object*>(pySelf);
  frameset::FrameSetReader* reader = dynamic_cast<frameset::FrameSetReader*>(self->frameset);

  double target = 0.0;
  if (!PyArg_ParseTuple(args,"d",&target)) return NULL;

  try {
    CHECKNULL(self);
    if (reader) {
      return PyInt_FromSsize_t(reader->search_ge(target));
    } else {
      PyErr_SetString(PyExc_RuntimeError,"Frameset is not open for reading");
      return NULL;
    }
  } CATCHCXX;
}

static PyObject* PyFrameSet_gt(PyObject* pySelf,PyObject* args) {
  PyFrameSet_Object* self = reinterpret_cast<PyFrameSet_Object*>(pySelf);
  frameset::FrameSetReader* reader = dynamic_cast<frameset::FrameSetReader*>(self->frameset);

  double target = 0.0;
  if (!PyArg_ParseTuple(args,"d",&target)) return NULL;

  try {
    CHECKNULL(self);
    if (reader) {
      return PyInt_FromSsize_t(reader->search_gt(target));
    } else {
      PyErr_SetString(PyExc_RuntimeError,"Frameset is not open for reading");
      return NULL;
    }
  } CATCHCXX;
}

static int object_to_frame(PyObject* object,void* destination) {
  PyFrame_Object* frameo = reinterpret_cast<PyFrame_Object*>(object);
  if (!PyObject_TypeCheck(object,PyFrame_t)) {
    PyErr_SetString(PyExc_ValueError,"object is not a frame");
    return 0;
  }
  if (!destination) {
    PyErr_SetString(PyExc_RuntimeError,"Passed a null pointer");
    return 0;
  }
  *reinterpret_cast<frameset::Frame**>(destination) = frameo->frame->get();
  return 1;
}

//! \brief Push frame out to disk.
//void push_back(const Frame& frame,double time);
static PyObject* PyFrameSet_push_back(PyObject* pySelf,PyObject* args) {
  PyFrameSet_Object* self = reinterpret_cast<PyFrameSet_Object*>(pySelf);
  frameset::Frame* frame = NULL;
  try {
    CHECKNULL(self);
  } CATCHCXX;

  double time = 0.0;
  frameset::FrameSetWriter* writer = dynamic_cast<frameset::FrameSetWriter*>(self->frameset);

  if (!writer) {
    PyErr_SetString(PyExc_IOError,"FrameSet not open for writing");
    return NULL;
  }

  if (!PyArg_ParseTuple(args,"O&d",object_to_frame,&frame,&time)) return NULL;

  try {
    writer->push_back(*frame,time);
  } CATCHCXX;

  Py_INCREF(Py_None);
  return Py_None;
}

static PyObject* PyFrameSet_meta(PyObject* pySelf, PyObject*) {
  PyFrameSet_Object* self = reinterpret_cast<PyFrameSet_Object*>(pySelf);


  PyFrame_Object* result = (PyFrame_Object*)PyFrame_def.tp_new(&PyFrame_def,NULL,NULL);
  if (!result) return NULL;

  try {
    CHECKNULL(self);
    result->frame = new frameset::FrameSetReader::FramePtr;
    *(result->frame) = self->frameset->meta();
  } CATCHCXX;
  return (PyObject*)result;

}

static PyObject* PyFrameSet_iter(PyObject* pySelf) {
  PyFrameSet_Object* self = reinterpret_cast<PyFrameSet_Object*>(pySelf);
  try {
      CHECKNULL(self);
  } CATCHCXX;

  PyFrameSetIter_Object* iter = PyObject_New(PyFrameSetIter_Object,
                                             PyFrameSetIter_t);
  if (!iter) return NULL;

  Py_INCREF(iter->frameset = pySelf);
  iter->frameno = 0;
  iter->framecount = self->frameset->size();

  return reinterpret_cast<PyObject*>(iter);
}

static PyObject * PyFrameSet_close(PyObject * pySelf, PyObject *) {
  PyFrameSet_Object* self = reinterpret_cast<PyFrameSet_Object*>(pySelf);
  try {
    delete self->frameset;
  } CATCHCXX;
  self->frameset=NULL;
  return Py_INCREF(Py_None), Py_None;
}

static PyObject * PyFrameSet_enter(PyObject *pySelf, PyObject * args) {
  return Py_INCREF(pySelf), pySelf;
}

static PyObject * PyFrameSet_exit(PyObject *pySelf, PyObject * args) {
  PyFrameSet_Object* self = reinterpret_cast<PyFrameSet_Object*>(pySelf);
  try {
    CHECKNULL(self);
  } CATCHCXX;
  return PyFrameSet_close(pySelf,args);
}

static PyMethodDef PyFrameSet_methods[] = {
  {"close",PyFrameSet_close,METH_NOARGS,"Close the frameset"},
  {"hierarchicalName",PyFrameSet_hierarchicalName,METH_VARARGS,""},
  {"framefile",PyFrameSet_framefile,METH_VARARGS,""},
  {"frameinfo",PyFrameSet_frameinfo,METH_VARARGS,""},
  {"fileinfo",PyFrameSet_fileinfo,METH_VARARGS,""},
  {"metainfo",PyFrameSet_metainfo,METH_NOARGS,""},
  {"time",PyFrameSet_time,METH_VARARGS,"Last time entered"},
  {"times",PyFrameSet_times,METH_NOARGS,"A numpy array of all times in the file"},
  {"rewind",PyFrameSet_rewind,METH_VARARGS,"rewind(time)  Rewind a writer to a frame just before time"},
  {"nearest",PyFrameSet_nearest,METH_VARARGS,"Get offset nearest a chemical time"},
  {"le",PyFrameSet_le,METH_VARARGS,"Get offset less than or equal to a chemical time"},
  {"lt",PyFrameSet_lt,METH_VARARGS,"Get offset less than a chemical time"},
  {"ge",PyFrameSet_ge,METH_VARARGS,"Get offset greater than or equal to a chemical time"},
  {"gt",PyFrameSet_gt,METH_VARARGS,"Get offset greater than a chemical time"},
  {"push_back",PyFrameSet_push_back,METH_VARARGS,"push_back(frame,t)  Add a frame at time t"},
  {"append",PyFrameSet_push_back,METH_VARARGS,"append(frame,t)  An alias for push_back that is more pythonic"},
  {"meta",PyFrameSet_meta,METH_NOARGS,"meta()  Grab the frameset meta frame"},
  {"flush_meta",PyFrameSet_flush_meta,METH_NOARGS,"fsync the file descriptor associated with the metaframe"},
  {"flush_keyfile",PyFrameSet_flush_keyfile,METH_NOARGS,"fsync the file descriptor associated with the timekeys file"},
  {"flush_framefile",PyFrameSet_flush_framefile,METH_NOARGS,"fsync the file descriptor associated with an open frame file"},
  {"__enter__",PyFrameSet_enter,METH_VARARGS,"Enter a runtime context"},
  {"__exit__",PyFrameSet_exit,METH_VARARGS,"Exit a runtime context"},
  {0,0}
};

static Py_ssize_t frameset_length(PyObject* pySelf) {
  PyFrameSet_Object* self = reinterpret_cast<PyFrameSet_Object*>(pySelf);
  try {
    CHECKNULL(self);
  } CATCHCXXi;
  return self->frameset->size();
}

PyObject* frameset_item(PyObject* pySelf,Py_ssize_t offset) {
  PyFrameSet_Object* self = reinterpret_cast<PyFrameSet_Object*>(pySelf);
  frameset::FrameSetReader* reader = dynamic_cast<frameset::FrameSetReader*>(self->frameset);
  try {
      CHECKNULL(self);
    } CATCHCXX;

  if (!reader) {
    PyErr_SetString(PyExc_ValueError,"FrameSet is not open for reading");
    return NULL;
  }

  PyFrame_Object* result = (PyFrame_Object*)PyFrame_def.tp_new(&PyFrame_def,NULL,NULL);
  if (!result) return NULL;

  result->frame = new frameset::FrameSetReader::FramePtr;
  try {
    *(result->frame) = reader->at(offset);
  } CATCHCXX;
  return (PyObject*)result;
}

static PySequenceMethods PyFrameSet_sequence = {
  frameset_length, /* inquiry sq_length; */
  NULL, /* binaryfunc sq_concat; */
  NULL, /* intargfunc sq_repeat; */
  frameset_item, /* intargfunc sq_item; */
  NULL, /* intintargfunc sq_slice; */
  NULL, /* intobjargproc sq_ass_item; */
  NULL  /* intintobjargproc sq_ass_slice; */
};

#if 0
// class FrameSet

// class FrameSetReader
    //! \brief Fetch a frame object (range checked)
    virtual FramePtr at(size_t index) const;

    //! \brief Same as .at() method.
    FramePtr operator[](size_t index) const;


    //! \brief First frame.
    iterator begin();

    //! \brief Beyond last frame.
    iterator end();

    //! \brief True if pathname is a directory with a keyfile in it.
    static bool isaFrameSetDirectory(std::string path);

// class FrameSetWriter

#endif

//! \brief True if pathname is a directory with a keyfile in it.
//static bool isaFrameSetDirectory(std::string path);
static PyObject* isaFrameSetDirectory(PyObject* self, PyObject* args) {
  char* path = NULL;
  if (!PyArg_ParseTuple(args,"s",&path)) return NULL;

  try {
    long flag = frameset::FrameSetReader::isaFrameSetDirectory(path);
    return PyBool_FromLong(flag);
  } CATCHCXX;
}

static PyObject* directFrameAccess(PyObject*, PyObject* args) {
  const char* directory;
  int ndir1;
  int ndir2;
  Py_ssize_t frames_per_file;
  Py_ssize_t frame_index;
  Py_ssize_t frame_offset;
  Py_ssize_t frame_size;
  if ( !PyArg_ParseTuple(args,"siinnnn",&directory,&ndir1,&ndir2,&frames_per_file,&frame_index,&frame_offset,&frame_size) ) return NULL;

  frameset::FrameSet::FramePtr frame;
  try {
    frame = frameset::FrameSet::directFrameAccess(directory,ndir1,ndir2,frames_per_file,frame_index,frame_offset,frame_size);
  } CATCHCXX;

  PyFrame_Object* result = (PyFrame_Object*)PyFrame_def.tp_new(&PyFrame_def,NULL,NULL);
  if (!result) return NULL;

  result->frame = new frameset::FrameSetReader::FramePtr(frame);


  return (PyObject*)result;
}

/**************************************************************************/
/* LOCAL  **************      PyFrame_dealloc      ************************/
/**************************************************************************/
/* Create a new frame.  If we are given a file, we read that as the frame */
/* source.                                                                */
/**************************************************************************/
static int PyFrame_init(PyObject* pySelf, PyObject* args, PyObject* kw) {
  PyFrame_Object* self = reinterpret_cast<PyFrame_Object*>(pySelf);
  static const char* kwlist[] = {"filename","rawbytes",0};
  const char* filename = NULL;
  PyObject* rawbytes = NULL;

  if (!PyArg_ParseTupleAndKeywords(args,kw,"|sS",const_cast<char **>(kwlist),
                                   &filename,&rawbytes)) return -1;

  try {
    if (rawbytes) {
      boost::shared_ptr<frameset::ReaderFrame::ContainerBase>
      container(new PythonStringContainer(rawbytes));
      self->frame = new frameset::FrameSetReader::FramePtr
        (new frameset::ReaderFrame(container));
    } else if (filename) {
      self->frame = new frameset::FrameSetReader::FramePtr
        (new frameset::ReaderFrame(filename));
    } else {
      self->frame = new frameset::FrameSetReader::FramePtr
        (new frameset::Frame());
    }
  } CATCHCXXi;

  return 0;
}

/**************************************************************************/
/* LOCAL  **************      PyFrame_dealloc      ************************/
/**************************************************************************/
/* Destroy the frame object                                               */
/**************************************************************************/
static void PyFrame_dealloc(PyObject* pySelf) {
  PyFrame_Object* self = reinterpret_cast<PyFrame_Object*>(pySelf);
  try {
    delete self->frame;
  } CATCHCXXv;
}

static PyObject* PyFrame_has(PyObject* pySelf, PyObject* args) {
  PyFrame_Object* self = reinterpret_cast<PyFrame_Object*>(pySelf);
  char* arg = NULL;
  bool has = false;
  if (!PyArg_ParseTuple(args,"s",&arg)) return NULL;

  try {
    has = (*self->frame)->has(arg);    
  } CATCHCXX;

  return PyBool_FromLong(has);
}

static PyObject* PyFrame_knowsType(PyObject* pySelf, PyObject* args) {
  PyFrame_Object* self = reinterpret_cast<PyFrame_Object*>(pySelf);
  char* arg = NULL;
  bool knowsType = false;
  if (!PyArg_ParseTuple(args,"s",&arg)) return NULL;

  try {
    knowsType = (*self->frame)->knowsType(arg);    
  } CATCHCXX;

  return PyBool_FromLong(knowsType);
}

static PyObject* PyFrame_type(PyObject* pySelf, PyObject* args) {
  PyFrame_Object* self = reinterpret_cast<PyFrame_Object*>(pySelf);
  char* arg = NULL;
  std::string type;
  if (!PyArg_ParseTuple(args,"s",&arg)) return NULL;

  try {
    type = (*self->frame)->type(arg);    
  } CATCHCXX;

  return PyString_FromStringAndSize(type.c_str(),type.size());
}

static PyObject* PyFrame_count(PyObject* pySelf, PyObject* args) {
  PyFrame_Object* self = reinterpret_cast<PyFrame_Object*>(pySelf);
  char* arg = NULL;
  size_t result = 0;
  if (!PyArg_ParseTuple(args,"s",&arg)) return NULL;

  try {
    result = (*self->frame)->count(arg);    
  } CATCHCXX;

  return PyInt_FromSize_t(result);
}

static PyObject* PyFrame_elementsize(PyObject* pySelf, PyObject* args) {
  PyFrame_Object* self = reinterpret_cast<PyFrame_Object*>(pySelf);
  char* arg = NULL;
  size_t result = 0;
  if (!PyArg_ParseTuple(args,"s",&arg)) return NULL;

  try {
    result = (*self->frame)->elementsize(arg);    
  } CATCHCXX;

  return PyInt_FromSize_t(result);
}

static PyObject* PyFrame_nbytes(PyObject* pySelf, PyObject* args) {
  PyFrame_Object* self = reinterpret_cast<PyFrame_Object*>(pySelf);
  char* arg = NULL;
  size_t result = 0;
  if (!PyArg_ParseTuple(args,"s",&arg)) return NULL;

  try {
    result = (*self->frame)->nbytes(arg);    
  } CATCHCXX;

  return PyInt_FromSize_t(result);
}

static PyObject* PyFrame_framesize(PyObject* pySelf,PyObject* args) {
  PyFrame_Object* self = reinterpret_cast<PyFrame_Object*>(pySelf);

  size_t framesize = 0;

  try {
    framesize = (*self->frame)->framesize();
  } CATCHCXX;

  return PyInt_FromSize_t(framesize);
}

static PyObject* PyFrame_serialize(PyObject* pySelf,PyObject* args) {
  PyFrame_Object* self = reinterpret_cast<PyFrame_Object*>(pySelf);

  PyObject* serialize = NULL; 

  try {
    serialize = PyString_FromStringAndSize(NULL,(*self->frame)->framesize());
    if (!serialize) return NULL;
    (*self->frame)->serialize(PyString_AS_STRING(serialize));
  } CATCHCXXANDKILL(serialize);

  return serialize;
}

static PyObject* PyFrame_endianism(PyObject* pySelf,void* closure) {
  PyFrame_Object* self = reinterpret_cast<PyFrame_Object*>(pySelf);
  size_t result = 0;

  try {
    result = (*self->frame)->endianism();
  } CATCHCXX;

  return PyInt_FromSize_t(result);
}

static PyObject* PyFrame_machineEndianism(PyObject* pySelf,void* closure) {
  PyFrame_Object* self = reinterpret_cast<PyFrame_Object*>(pySelf);
  size_t result = 0;

  try {
    result = (*self->frame)->machineEndianism();
  } CATCHCXX;

  return PyInt_FromSize_t(result);
}

static PyObject* PyFrame_sameEndianism(PyObject* pySelf,void* closure) {
  PyFrame_Object* self = reinterpret_cast<PyFrame_Object*>(pySelf);
  long result = 0;

  try {
    result = (*self->frame)->sameEndianism();
  } CATCHCXX;

  return PyBool_FromLong(result);
}

static PyObject* PyFrame_labels(PyObject* pySelf,void* closure) {
  PyFrame_Object* self = reinterpret_cast<PyFrame_Object*>(pySelf);

  PyObject* labels = NULL;

  try {
    std::set<std::string> flabels;
    (*self->frame)->labels(flabels);
    labels = PyList_New(flabels.size());
    int i=0;
    for(std::set<std::string>::iterator p=flabels.begin();
        p!=flabels.end(); ++p){
      PyList_SET_ITEM(labels,i++,PyString_FromString(p->c_str()));
    }
  } CATCHCXXANDKILL(labels);

  return labels;
}


/**************************************************************************/
/* LOCAL  **************        blob_killer        ************************/
/**************************************************************************/
/* Destruction routine for PyCObject...                                   */
/**************************************************************************/
static void blob_killer(void* p) {
  delete reinterpret_cast<frameset::BaseBlob*>(p);
}

template<class T>
static PyObject* getattr(frameset::BaseBlob data,int typenum) {
  npy_intp dims = data.count();
  PyObject* result = PyArray_SimpleNewFromData(1,&dims,typenum,data.firstbyte());

  PyArrayObject* array = reinterpret_cast<PyArrayObject*>(result);
  frameset::BaseBlob* stash = new frameset::BaseBlob(data);
  PyArray_BASE(array) = PyCObject_FromVoidPtr(stash,blob_killer);

  return result;
}

static PyObject* PyFrame_getattr(PyObject* pySelf, char* attr) {
  PyFrame_Object* self = reinterpret_cast<PyFrame_Object*>(pySelf);

  // -----------------------------------------------
  // Maybe its a method...
  // -----------------------------------------------
  PyObject* result = Py_FindMethod(pySelf->ob_type->tp_methods,pySelf,attr);
  if (result) return result;
  PyErr_Clear();

  // -----------------------------------------------
  // Maybe its a getter...
  // -----------------------------------------------
  for(PyGetSetDef* getter = pySelf->ob_type->tp_getset; getter->get; ++getter) {
    if (strcmp(getter->name,attr) == 0) return getter->get(pySelf,NULL);
  }

  // -----------------------------------------------
  // Must be an attribute
  // -----------------------------------------------
  try {
    frameset::BaseBlob data = (*self->frame)->get(attr);
    std::string type = data.type();

    if (type == "char") {
      result = getattr<char>(data,NPY_CHAR);
    } else if (type == "int32_t") {
      result = getattr<int32_t>(data,NPY_INT32);
    } else if (type == "uint32_t") {
      result = getattr<uint32_t>(data,NPY_UINT32);
    } else if (type == "int64_t") {
      result = getattr<int64_t>(data,NPY_INT64);
    } else if (type == "uint64_t") {
      result = getattr<uint64_t>(data,NPY_UINT64);
    } else if (type == "float") {
      result = getattr<float>(data,NPY_FLOAT);
    } else if (type == "double") {
      result = getattr<double>(data,NPY_DOUBLE);
    } else if (type == "unsigned char") {
      result = getattr<unsigned char>(data,NPY_UBYTE);
    } else if (type == "short") {
      result = getattr<short>(data,NPY_SHORT);
    } else if (type == "unsigned short") {
      result = getattr<unsigned short>(data,NPY_USHORT);
    } else if (type == "int") {
      result = getattr<int>(data,NPY_INT);
    } else if (type == "unsigned int") {
      result = getattr<unsigned int>(data,NPY_UINT);
    } else if (type == "long") {
      result = getattr<long>(data,NPY_LONG);
    } else if (type == "unsigned long") {
      result = getattr<unsigned long>(data,NPY_ULONG);
    } else {
      throw frameset::FrameSetException("numpy pack for " + type + " not done yet");
    }

  } CATCHCXX;

  return result;
}

template<class T>
static void setattr(frameset::Frame* frame,char* attr,PyObject* array) {
  size_t size = PyArray_SIZE(array);

  if (PyArray_ISCARRAY(array)) {
    T* ptr = reinterpret_cast<T*>(PyArray_BYTES(array));
    frame->set_values(attr,ptr,ptr+size);
  } else {
    // Set up the data block for receive
    frameset::Blob<T> data(size);
    frame->set(attr,data);

    PyArrayIterObject *iter = NULL;
    iter = reinterpret_cast<PyArrayIterObject *>(PyArray_IterNew(array));
    while (iter->index < iter->size) {
      T* ptr = reinterpret_cast<T*>(iter->dataptr);
      data[iter->index] = *ptr;
      PyArray_ITER_NEXT(iter);
    }
    Py_DECREF(iter);
  }
}

static int PyFrame_setattr(PyObject* pySelf, char* attr, PyObject* value) {
  PyFrame_Object* self = reinterpret_cast<PyFrame_Object*>(pySelf);

  try {
    // Maybe we are just deleting an attribute
    if (!value) {
      if ((*self->frame)->has(attr)) (*self->frame)->del(attr);
      return 0;
    }

    // -----------------------------------------------
    // From Python, I know how to set basic items,
    // numpy values, and strings.
    // -----------------------------------------------
    if (PyInt_CheckExact(value)) {
      equivalent_to_long lval = PyInt_AS_LONG(value);
      (*self->frame)->set_value(attr,lval);
    } else if (PyFloat_CheckExact(value)) {
      (*self->frame)->set_value(attr,PyFloat_AS_DOUBLE(value));
    } else if (PyString_CheckExact(value)) {
      char* cptr = PyString_AS_STRING(value);
      (*self->frame)->set_values(attr,cptr,cptr+PyString_GET_SIZE(value));
    } else if (PyArray_Check(value)) {
      PyArrayObject* array = reinterpret_cast<PyArrayObject*>(value);
      switch(array->descr->type_num) {

      case NPY_BYTE: setattr<char>(self->frame->get(),attr,value); break;
      case NPY_UBYTE: setattr<unsigned char>(self->frame->get(),attr,value); break;

      case NPY_SHORT: setattr<equivalent_to_short>(self->frame->get(),attr,value); break;
      case NPY_USHORT: setattr<equivalent_to_ushort>(self->frame->get(),attr,value); break;

      case NPY_INT: setattr<equivalent_to_int>(self->frame->get(),attr,value); break;
      case NPY_UINT: setattr<equivalent_to_uint>(self->frame->get(),attr,value); break;

      case NPY_LONG: setattr<equivalent_to_long>(self->frame->get(),attr,value); break;
      case NPY_ULONG: setattr<equivalent_to_ulong>(self->frame->get(),attr,value); break;


#ifdef PY_LONG_LONG
      case NPY_LONGLONG: 
#if NPY_SIZEOF_LONGLONG == 2
        setattr<int16_t>(self->frame->get(),attr,value); break;
#else
#if NPY_SIZEOF_LONGLONG == 4
        setattr<int32_t>(self->frame->get(),attr,value); break;
#else
#if NPY_SIZEOF_LONGLONG == 8
        setattr<int64_t>(self->frame->get(),attr,value); break;
#else
        PyErr_SetString(PyExc_RuntimeError,"invalid numpy type");
        return -1;
#endif
#endif
#endif

      case NPY_ULONGLONG: 
#if NPY_SIZEOF_LONGLONG == 2
        setattr<uint16_t>(self->frame->get(),attr,value); break;
#else
#if NPY_SIZEOF_LONGLONG == 4
        setattr<uint32_t>(self->frame->get(),attr,value); break;
#else
#if NPY_SIZEOF_LONGLONG == 8
        setattr<uint64_t>(self->frame->get(),attr,value); break;
#else
        PyErr_SetString(PyExc_RuntimeError,"invalid numpy type");
        return -1;
#endif
#endif
#endif

#endif

      case NPY_FLOAT: setattr<float>(self->frame->get(),attr,value); break;
      case NPY_DOUBLE: setattr<double>(self->frame->get(),attr,value); break;
        //case NPY_CFLOAT: setattr<float>(self->frame->get(),attr,value); break;
        //case NPY_CDOUBLE: setattr<double>(self->frame->get(),attr,value); break;
      case NPY_CHAR: setattr<char>(self->frame->get(),attr,value); break;

      default:
        PyErr_SetString(PyExc_RuntimeError,"invalid numpy type");
        return -1;
      }
    } else {
      PyErr_SetString(PyExc_RuntimeError,"invalid type for a field");
      return -1;
    }
  } CATCHCXXi;
  return 0;
}

static PyObject* PyFrame_iter(PyObject* pySelf) {

  PyFrameIter_Object* iter = PyObject_New(PyFrameIter_Object,
                                             PyFrameIter_t);
  if (!iter) return NULL;

  Py_INCREF(iter->frame = pySelf);
  iter->labels = PyFrame_labels(pySelf,NULL);
  iter->labelno = 0;

  return reinterpret_cast<PyObject*>(iter);
}

static PyGetSetDef PyFrame_getset[] = {
    {CC("__labels__"),PyFrame_labels,NULL,CC("List of field names"),NULL},
    {CC("__endianism__"),PyFrame_endianism,NULL,CC("Endianism of the stored frame"),NULL},
    {CC("__machineEndianism__"),PyFrame_machineEndianism,NULL,CC("Endianism of this machine"),NULL},
    {CC("__sameEndianism__"),PyFrame_sameEndianism,NULL,CC("True if machine and frame have same endianism"),NULL},
  {0,0}
};

static PyMethodDef PyFrame_methods[] = {
  {"__has__",PyFrame_has,METH_VARARGS,"True iff frame has the field named"},
  {"__knowsType__",PyFrame_knowsType,METH_VARARGS,"True iff frame understands the named type"},

  {"__framesize__",PyFrame_framesize,METH_NOARGS,"number of bytes required for serialize"},
  {"__serialize__",PyFrame_serialize,METH_NOARGS,"string representation of the frame"},

  {"__type__",PyFrame_type,METH_VARARGS,"Type of the field named"},
  {"__count__",PyFrame_count,METH_VARARGS,"Number of elements in field named"},
  {"__elementsize__",PyFrame_elementsize,METH_VARARGS,"Element size of item in field named"},
  {"__nbytes__",PyFrame_nbytes,METH_VARARGS,"Number of bytes in field named"},
  {0,0}
};

static void PyFrameSetIter_dealloc(PyObject* pySelf) {
  PyFrameSetIter_Object* self = reinterpret_cast<PyFrameSetIter_Object*>(pySelf);
  Py_XDECREF(self->frameset);
}

static PyObject* PyFrameSetIter_iternext(PyObject* pySelf) {
  PyFrameSetIter_Object* self = reinterpret_cast<PyFrameSetIter_Object*>(pySelf);
  try {
      CHECKNULL(self);
  } CATCHCXX;


  // Quit when we run out of frames
  if (self->frameno >= self->framecount) return NULL;

  return PySequence_GetItem(self->frameset,self->frameno++);
}

static void PyFrameIter_dealloc(PyObject* pySelf) {
  PyFrameIter_Object* self = reinterpret_cast<PyFrameIter_Object*>(pySelf);
  Py_XDECREF(self->frame);
  Py_XDECREF(self->labels);
}

static PyObject* PyFrameIter_iternext(PyObject* pySelf) {
  PyFrameIter_Object* self = reinterpret_cast<PyFrameIter_Object*>(pySelf);
  if (self->labelno >= PyList_GET_SIZE(self->labels)) return NULL;

  PyObject* key /*borrow*/ = PyList_GET_ITEM(self->labels,self->labelno++);

  PyObject* value /*owned*/ = PyObject_GetAttr(self->frame,key);
  if (!value) return NULL;

  return Py_BuildValue("ON",key,value);
}

static PyMethodDef methods[] = {
  {"isaFrameSetDirectory",isaFrameSetDirectory,METH_VARARGS,"True if the named directory is structured as a frameset"},
  {"directFrameAccess",directFrameAccess,METH_VARARGS,"directFrameAccess(directory,ndir1,ndir2,frames_per_file,index,offset,size) Returns a frame object from metainfo"},
  {0,0}
};

extern "C"
void initframesettools(void) {
  PyObject* module = Py_InitModule3("framesettools",methods,DOCSTRING);
  if (!module) return;

  // Secret handshake to set up numpy
  import_array();
  if (PyErr_Occurred()) return;
  
  PyFrame_def.tp_name = "Frame";
  PyFrame_def.tp_basicsize = sizeof(PyFrame_Object);
  PyFrame_def.tp_new = PyType_GenericNew;
  PyFrame_def.tp_init = PyFrame_init;
  PyFrame_def.tp_dealloc = PyFrame_dealloc;
  PyFrame_def.tp_flags = Py_TPFLAGS_DEFAULT | Py_TPFLAGS_BASETYPE;
  PyFrame_def.tp_iter = PyFrame_iter;
  PyFrame_def.tp_methods = PyFrame_methods;
  PyFrame_def.tp_setattr = PyFrame_setattr;
  PyFrame_def.tp_getattr = PyFrame_getattr;
  PyFrame_def.tp_getset = PyFrame_getset;
  if (PyType_Ready(PyFrame_t)) return;
  Py_INCREF(PyFrame);
  PyObject_SetAttrString(module,"Frame",PyFrame);

  PyFrameIter_def.tp_name = "FrameIter";
  PyFrameIter_def.tp_basicsize = sizeof(PyFrameIter_Object);
  PyFrameIter_def.tp_new = PyType_GenericNew;
  PyFrameIter_def.tp_dealloc = PyFrameIter_dealloc;
  PyFrameIter_def.tp_flags = Py_TPFLAGS_DEFAULT | Py_TPFLAGS_BASETYPE;
  PyFrameIter_def.tp_iternext = PyFrameIter_iternext;
  if (PyType_Ready(PyFrameIter_t)) return;
  Py_INCREF(PyFrameIter);
  PyObject_SetAttrString(module,"FrameIter",PyFrameIter);

  PyFrameSet_def.tp_name = "FrameSet";
  PyFrameSet_def.tp_basicsize = sizeof(PyFrameSet_Object);
  PyFrameSet_def.tp_new = PyType_GenericNew;
  PyFrameSet_def.tp_init = PyFrameSet_init;
  PyFrameSet_def.tp_dealloc = PyFrameSet_dealloc;
  PyFrameSet_def.tp_flags = Py_TPFLAGS_DEFAULT | Py_TPFLAGS_BASETYPE;
  PyFrameSet_def.tp_iter = PyFrameSet_iter;
  PyFrameSet_def.tp_getset = PyFrameSet_getset;
  PyFrameSet_def.tp_methods = PyFrameSet_methods;
  PyFrameSet_def.tp_as_sequence = &PyFrameSet_sequence;
  if (PyType_Ready(PyFrameSet_t)) return;
  Py_INCREF(PyFrameSet);
  PyModule_AddObject(module,"FrameSet",PyFrameSet);

  PyFrameSetIter_def.tp_name = "FrameSetIter";
  PyFrameSetIter_def.tp_basicsize = sizeof(PyFrameSetIter_Object);
  PyFrameSetIter_def.tp_new = PyType_GenericNew;
  PyFrameSetIter_def.tp_dealloc = PyFrameSetIter_dealloc;
  PyFrameSetIter_def.tp_flags = Py_TPFLAGS_DEFAULT | Py_TPFLAGS_BASETYPE;
  PyFrameSetIter_def.tp_iternext = PyFrameSetIter_iternext;
  if (PyType_Ready(PyFrameSetIter_t)) return;
  Py_INCREF(PyFrameSetIter);
  PyObject_SetAttrString(module,"FrameSetIter",PyFrameSetIter);

}
