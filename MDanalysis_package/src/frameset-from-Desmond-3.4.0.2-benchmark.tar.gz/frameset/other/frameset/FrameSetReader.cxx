/* 
Copyright 2012-2014, D. E. Shaw Research.
All rights reserved.

Redistribution and use in source and binary forms, with or without
modification, are permitted provided that the following conditions are
met:

* Redistributions of source code must retain the above copyright
  notice, this list of conditions, and the following disclaimer.

* Redistributions in binary form must reproduce the above copyright
  notice, this list of conditions, and the following disclaimer in the
  documentation and/or other materials provided with the distribution.

* Neither the name of D. E. Shaw Research nor the names of its
  contributors may be used to endorse or promote products derived from
  this software without specific prior written permission.

THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
"AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR
A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT
OWNER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,
SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT
LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE,
DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY
THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
(INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE
OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
*/

// NOTE:  Cannot use ::ntohl or ::htonl since under optimization
// they are turned into efficient macros

#include "FrameSet/FrameSetReader.hxx"
#include "FrameSet/FrameSetExceptions.hxx"
#include "FrameSet/ReaderFrame.hxx"

#include <iostream> // TODO: remove
using std::cout;
using std::endl;

#include <fcntl.h>
#include <sys/types.h>
#include <sys/stat.h>

#ifdef DESRES_OS_Windows
#include <io.h>
#include <Windows.h>
#else
#include <netinet/in.h>
#define O_BINARY 0
#endif

namespace frameset {
  /*!
   * This is for opening "virtual" readers like FilelessReader
   */
  FrameSetReader::FrameSetReader(const std::string& path,bool)
    : FrameSet(path,"v"), m_keyfile_fd(-2)
  {
    // We opened in "virtual" mode, change it to read-only
    m_mode = "r";
  }


  /*!
   * A frameset iterator tracks the parent frameset and the current
   * frame.  The dereference call handles problems with out of
   * bounds reference.
   */
  FrameSetReader::iterator::iterator(const FrameSetReader& parent, size_t frameno)
    : m_parent(parent),
      m_frameno(frameno)
  {
  }

  /*!
   * Dereferencing simply asks the parent to retrieve a frame.
   * We cache the actual frame to support multiple requests.
   * Here, this also insures that the frame& remains alive
   * as long as the iterator does.
   */
  Frame& FrameSetReader::iterator::operator*() {
    return *(operator->());
  }

  /*!
   * Dereferencing simply asks to retrieve a frame from either
   * the parent or a local cached copy.
   */
  FrameSetReader::FramePtr FrameSetReader::iterator::operator->() {
    if ( m_frame.get() == NULL) {
      m_frame = m_parent.at(m_frameno);
    }
    return m_frame;
  }

  /*!
   * Iterators are equal if they are the same object or if the
   * parents and framenumbers are the same.
   */
  bool FrameSetReader::iterator::operator==(const iterator& other) const {
    return (this == &other) || ((&m_parent == &(other.m_parent) &&
                                 m_frameno == other.m_frameno));
  }

  /*!
   * Simply the ! of operator==() (i.e. the objects are different
   * and framenumbers are different).
   */
  bool FrameSetReader::iterator::operator!=(const iterator& other) const {
    return ! operator==(other);
  }

  /*!
   * Pre-increment.  We update the iterator in place.
   */
  FrameSetReader::iterator& FrameSetReader::iterator::operator++() {
    m_frame.reset(); // Frame pointer is no long valid!
    ++m_frameno;
    return *this;
  }

  /*!
   * Post-increment.  We update the iterator in place, but return
   * a copy of the original.
   */
  FrameSetReader::iterator FrameSetReader::iterator::operator++(int) {
    iterator copy = *this;
    operator++();
    return copy;
  }
  
  /*!
   * The .time() method simply defers to the parent.
   * The parent handles all range checking.
   */
  double FrameSetReader::iterator::time() const {
    return m_parent.time(m_frameno);
  }

  /*!
   * The reader fetchs timekey data to set size and
   * internal offset information.
   */
  FrameSetReader::FrameSetReader(std::string path) 
    : FrameSet(path,"r"),
      m_keyfile_fd(-1)
  {

    // -----------------------------------------------
    // Open the timekey file and read in the time
    // and offset information.
    // -----------------------------------------------
    std::string keyfile_path = keyfile();
    m_keyfile_fd = ::open(keyfile_path.c_str(),O_RDONLY|O_BINARY);
    if (m_keyfile_fd.file() < 0) throw IoErrnoException(keyfile_path);

    // -----------------------------------------------
    // Read in the prologue
    // -----------------------------------------------
    key_prologue_t prologue = read_keyfile_prologue();
    m_frames_per_file = ntohl(prologue.frames_per_file);

    // -----------------------------------------------
    // We simply calculate the number of frames there
    // must be, don't actually read in the times unless
    // we are doing a time operation!
    // -----------------------------------------------
    off_t keyfile_size = ::lseek(m_keyfile_fd.file(),0,SEEK_END);
    if (keyfile_size < 0) throw IoErrnoException(keyfile_path);

    m_nframes = (keyfile_size - sizeof(prologue))/sizeof(key_record_t);
  }

  /*!
   * On destruction, we must release the keyfile file descriptor.
   * This is done with an AutoClosingFD, so we don't need
   * to explicitly close it.
   */
  FrameSetReader::~FrameSetReader() {
  }

  /*!
   * We use the at() method so that we might more closely resemble
   * the semantics of std::vector<>.  This method throws a range
   * error if the index is not in the bounds of accessable frames.
   */
  FrameSetReader::FramePtr FrameSetReader::at(size_t index) const {
    // Make sure we are referencing in range
    RangeError::check(index,size());

    // OK, here we assume the file offset is 0 because
    // one frame per file is on.  We would need to read
    // in the actual keyfile data to get real offsets
    // but the framefile() call would properly map
    // the frameno to the right file (since it divides
    // by the frames_per_file number).
    off_t offset = 0;
    size_t framesize = 0;
    if (m_frames_per_file != 1) {
      key_record_t entry = read_keyfile_entry(index);
      offset = Frame::assemble64(ntohl(entry.offset_lo),
                                 ntohl(entry.offset_hi));
      framesize = Frame::assemble64(ntohl(entry.framesize_lo),
                                   ntohl(entry.framesize_hi));
    }

    // Construct a frame from the appropriate file
    FramePtr result(new ReaderFrame(framefile(index),offset,framesize));

    // Some of the more static information is stored in the "meta"
    // data frame.  We use John's cool new "master frame" idea to
    // add that to the frame we just built.
    result->set_default_frame(meta());

    return result;
  }

  /*!
   * This is equivalent to the at() method.  That is, it indexes
   * into the frame set to grab a frame.  Unlike std::vector<>'s
   * operator[], however, this one will throw a range exception
   * if the index is out of bounds.
   */
  FrameSetReader::FramePtr FrameSetReader::operator[](size_t index) const {
    return at(index);
  }

  FrameSet::key_prologue_t FrameSetReader::read_keyfile_prologue() const {
    key_prologue_t prologue;

    if (::lseek(m_keyfile_fd.file(),0,SEEK_SET) < 0) {
      throw IoErrnoException("cannot rewind keyfile");  /* GCOV-IGNORE */
    }

    if (nointr_read(m_keyfile_fd.file(),&prologue,sizeof(prologue))
        != sizeof(prologue)) {
      throw IoException("keyfile must be truncated");  /* GCOV-IGNORE */
    }

    if (ntohl(prologue.magic) != s_magic_timekey) {
      throw FrameSetException("keyfile magic number incorrect");  /* GCOV-IGNORE */
    }

    if (ntohl(prologue.key_record_size) != sizeof(key_record_t)) {
      throw FrameSetException("Key record changed size");  /* GCOV-IGNORE */
    }
    return prologue;
  }

  /*!
   * Seek into the keyfile and pull out the particular entry.
   */
  FrameSet::key_record_t FrameSetReader::read_keyfile_entry(size_t index) const {
    // -----------------------------------------------
    // Make sure we're in range so that we get a range
    // error instead of an I/O error on the read.
    // -----------------------------------------------
    RangeError::check(index,size());

    // We lseek to the appropriate location and read the
    // time/offset key there.
    off_t offset = sizeof(key_prologue_t) + index*sizeof(key_record_t);
    if (::lseek(m_keyfile_fd.file(),offset,SEEK_SET) < 0) {
      throw IoErrnoException("keytimes");  /* GCOV-IGNORE */
    }

    // -----------------------------------------------
    // Read the entry there.
    // -----------------------------------------------
    key_record_t entry;
    ssize_t n = nointr_read(m_keyfile_fd.file(),&entry,sizeof(entry));
    if ( n  != sizeof(entry) ) {
      throw IoErrnoException("keytimes");  /* GCOV-IGNORE */
    }

    return entry;
  }

  /*!
   * Go to the keyfile and fetch the time for this record.
   */
  double FrameSetReader::time(size_t index) const {
    key_record_t entry = read_keyfile_entry(index);

    // -----------------------------------------------
    // Convert back to a double.
    // -----------------------------------------------
    return Frame::assembleDouble(ntohl(entry.time_lo),
                                 ntohl(entry.time_hi));
  }

  /*!
   * Reference to the first frame (if any) that can
   * be read from this frameset.
   */
  FrameSetReader::iterator FrameSetReader::begin() {
    return iterator(*this,0);
  }

  /*!
   * Reference to the first frame (if any) that can
   * be read from this frameset.
   */
  FrameSetReader::iterator FrameSetReader::begin() const {
    return iterator(*this,0);
  }

  /*!
   * Reference beyond the last frame that can
   * be read from this frameset.
   */
  FrameSetReader::iterator FrameSetReader::end() {
    return iterator(*this,size());
  }

  /*!
   * Reference beyond the last frame that can
   * be read from this frameset.
   */
  FrameSetReader::iterator FrameSetReader::end() const {
    return iterator(*this,size());
  }

  ssize_t FrameSetReader::search_nearest(double target) const {
    ssize_t left, right;
    binary_search(target,left,right);

    if (left < 0) return right;
    if (right >= (ssize_t)size()) return left;

    double time_left = time(left);
    double time_right = time(right);

    if (target-time_left < time_right-target) return left;
    return right;
  }

  ssize_t FrameSetReader::search_le(double target) const {
    ssize_t left, right;
    binary_search(target,left,right);

    return left;
  }

  ssize_t FrameSetReader::search_lt(double target) const {
    ssize_t left, right;
    binary_search(target, left, right);
    if(left<0 || time(left) < target)
      return left;
    return left-1;
  }
    
  ssize_t FrameSetReader::search_ge(double target) const {
    ssize_t left, right;
    binary_search(target,  left, right);
    return right;
  }

  ssize_t FrameSetReader::search_gt(double target) const {
    ssize_t left, right;
    binary_search(target,  left, right);
    if( right >= (ssize_t)size() || time(right) > target )
      return right;
    else
      return right+1;
  }

  void FrameSetReader::binary_search(double target, ssize_t& left, ssize_t& right) const {
    // TODO: would be faster to copy values out instead of using references directly
    ssize_t N = size();
    ssize_t mid;

    // No need to special-case N==0.  The logic is sound anyway so long as
    // we use ssize_t (to allow negative values)

    left = 0;
    right = N-1;
    while(left <= right) {
      mid = left + ((right-left)/2);
      double mid_time = time(mid);
      if (target > mid_time) {
        left = mid + 1;
      } else if (target < mid_time) {
        right = mid - 1;
      } else {
        // Unlikely, but it is an exact match!
        left = right = mid;
        return;
      }
    }

    // Left and right are swapped on exit to the loop, so
    // swap back to expected order.
    mid = left;
    left = right;
    right = mid;
  }

  /*!
   * See if a path points to a directory and that directory
   * contains the "timekeys" file.
   */
  bool FrameSetReader::isaFrameSetDirectory(std::string path) {
    struct stat statbuf;
    std::string timekeypath = path + s_sep + "timekeys";
    return stat(timekeypath.c_str(),&statbuf) == 0;
  }
}

