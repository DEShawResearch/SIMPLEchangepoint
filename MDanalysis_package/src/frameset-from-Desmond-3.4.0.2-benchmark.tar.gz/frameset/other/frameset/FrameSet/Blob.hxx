/* 
Copyright 2012-2014, D. E. Shaw Research.
All rights reserved.

Redistribution and use in source and binary forms, with or without
modification, are permitted provided that the following conditions are
met:

* Redistributions of source code must retain the above copyright
  notice, this list of conditions, and the following disclaimer.

* Redistributions in binary form must reproduce the above copyright
  notice, this list of conditions, and the following disclaimer in the
  documentation and/or other materials provided with the distribution.

* Neither the name of D. E. Shaw Research nor the names of its
  contributors may be used to endorse or promote products derived from
  this software without specific prior written permission.

THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
"AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR
A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT
OWNER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,
SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT
LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE,
DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY
THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
(INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE
OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
*/

#ifndef BLOB_HXX
#define BLOB_HXX

#include "BaseBlob.hxx"
#include "HumanTypename.hxx"

#include <string>
#include <iterator>

#include "boost/shared_array.hpp"

#include <inttypes.h>

namespace frameset {

  /*! \brief A typed view of the data in BaseBlob 
   *
   * A typed blob shares the same underlying pointer as an
   * untyped basic blob, but it is able to return raw pointers
   * of the appropriate type.  See the copy constructor and
   * assignment operator to see how type safety is enforced
   * by comparing the type name.
   */
  template <class ScalarType>
  class Blob : public BaseBlob {

    //! \brief A view of the data that appears to be ScalarType*
    boost::shared_array<ScalarType> m_typedData;

    //! \brief Tie the lifetime of other_data to this object.
    void link_typed_data_to(const boost::shared_array<char>& other_data);

  public:
    //! \brief Build a data blob and associated meta data
    Blob(size_t count=0);

    //! \brief Copy c'tor will cast!
    Blob(const BaseBlob&);

    //! \brief Assignment works (dynamic type safety check)
    Blob& operator=(const BaseBlob&);

    //! \brief Access to shared storage.
    boost::shared_array<ScalarType> typedData();
    //! \brief Access to shared storage.
    const boost::shared_array<ScalarType> typedData() const;

    //! \brief Random access.
    ScalarType& at(uint64_t);
    //! \brief Random access.
    const ScalarType& at(uint64_t) const;
    //! \brief Random access.
    ScalarType& operator[](uint64_t);
    //! \brief Random access.
    const ScalarType& operator[](uint64_t) const;

    // Forward definition
    class iterator;
    class const_iterator;

    //! \brief Begining of internal data
    iterator begin();
    //! \brief Begining of internal data
    const_iterator begin() const;

    //! \brief End of internal data
    iterator end();
    //! \brief End of internal data
    const_iterator end() const;

    //! \brief Field iterator
    class iterator 
      : public std::iterator<std::forward_iterator_tag,
                             ScalarType,
                             ssize_t>
    {
    protected:
      ScalarType* m_low;      //!< \brief Beginning of legal data
      ScalarType* m_current;  //!< \brief Current value (may be out of range)
      ScalarType* m_high;     //!< \brief 1 beyond legal data
    public:
      // TODO: Add the rest of the iterator operators (many)

      iterator(ScalarType* low=NULL, ScalarType* high=NULL, ScalarType* current=NULL);

      const ScalarType* low() const;
      const ScalarType* high() const;
      const ScalarType* current() const;

      iterator& operator++();
      iterator operator++(int);

      //! \brief TBD
      bool operator==(const iterator& other) const;
      //! \brief TBD
      bool operator!=(const iterator& other) const;

      //! \brief TBD
      bool operator==(const typename Blob<ScalarType>::const_iterator& other) const;
      //! \brief TBD
      bool operator!=(const typename Blob<ScalarType>::const_iterator& other) const;

      //! \brief TBD
      ScalarType& operator*();
      //! \brief TBD
      const ScalarType& operator*() const;

      //! \brief TBD
      ssize_t operator-(const iterator& other) const;
      //! \brief TBD
      ssize_t operator-(const const_iterator& other) const;

      //! \brief TBD
      ScalarType* operator->();
      //! \brief TBD
      const ScalarType* operator->() const;
    };

    //! \brief Field iterator
    class const_iterator
      : public std::iterator<std::forward_iterator_tag,
                             ScalarType,
                             ssize_t>
    {
    protected:
      const ScalarType* m_low;      //!< \brief Beginning of legal data
      const ScalarType* m_current;  //!< \brief Current value (may be out of range)
      const ScalarType* m_high;     //!< \brief 1 beyond legal data
    public:
      // TODO: Add the rest of the iterator operators (many)

      const_iterator (const ScalarType* low=NULL, const ScalarType* high=NULL, const ScalarType* current=NULL);
      const_iterator(const typename Blob<ScalarType>::iterator&);

      const ScalarType* low() const;
      const ScalarType* high() const;
      const ScalarType* current() const;

      const_iterator& operator++();
      const_iterator operator++(int);

      bool operator==(const const_iterator& other) const;
      bool operator!=(const const_iterator& other) const;

      bool operator==(const typename Blob<ScalarType>::iterator& other) const;
      bool operator!=(const typename Blob<ScalarType>::iterator& other) const;

      ScalarType& operator*();
      const ScalarType& operator*() const;

      ssize_t operator-(const const_iterator& other) const;

      ScalarType* operator->();
      const ScalarType* operator->() const;
    };
  };

}

#endif
