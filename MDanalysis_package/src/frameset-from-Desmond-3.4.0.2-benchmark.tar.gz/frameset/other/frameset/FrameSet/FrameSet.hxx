/* 
Copyright 2012-2014, D. E. Shaw Research.
All rights reserved.

Redistribution and use in source and binary forms, with or without
modification, are permitted provided that the following conditions are
met:

* Redistributions of source code must retain the above copyright
  notice, this list of conditions, and the following disclaimer.

* Redistributions in binary form must reproduce the above copyright
  notice, this list of conditions, and the following disclaimer in the
  documentation and/or other materials provided with the distribution.

* Neither the name of D. E. Shaw Research nor the names of its
  contributors may be used to endorse or promote products derived from
  this software without specific prior written permission.

THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
"AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR
A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT
OWNER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,
SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT
LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE,
DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY
THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
(INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE
OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
*/

#ifndef FRAMESET_HXX
#define FRAMESET_HXX

#include <string>
#include "boost/shared_ptr.hpp"

#ifdef DESRES_OS_Windows
#include <io.h>
#else
#include <unistd.h>
#endif
#include <errno.h>
#include <FrameSet/FrameSetExceptions.hxx>

namespace frameset {
  class Frame;

  /*! \brief A collection of frames
   *
   * Frames coordinate information about the collection and
   * centralizes common activities shared by read sets and
   * write sets.
   */
  class FrameSet {
    // Suppress the compiler's desire to create a copy c'tor
    FrameSet(const FrameSet&); 

  public:

    /*! \brief A shared_ptr to a Frame object.
     * 
     * We use a boost shared_ptr to address lifetime issues.
     * Having iterators return a frame reference would be
     * bad since the frameset doesn't actually have the
     * frame in memory anywhere until it is demanded
     * through the iterator.
     */
    typedef boost::shared_ptr<Frame> FramePtr;

    /*! \brief Access a frame directly from metainfo
     *
     * Using externally stored meta-info, grab a frame from
     * disk.
     */
    static FramePtr directFrameAccess(const std::string& directory,
                                      int ndir1,int ndir2,
                                      size_t frames_per_file,
                                      size_t frame_index,
                                      size_t frame_offset,
                                      size_t frame_size);
                                 

    // TODO: Fix the structure so new writers can be built
  protected:
    //! \brief Base directory (full path)
    std::string m_directory;

    //! \brief Static frame data (metadata frame)
    FramePtr m_meta;

  protected:   

    //! \brief Number of frames held by this frameset.
    size_t m_nframes;

    //! \brief DeepDir parameter.
    int m_ndir1;

    //! \brief DeepDir parameter.
    int m_ndir2;

    //! \brief Number of frames to pack into a file.
    size_t m_frames_per_file;

    //! \brief Mode this frameset was opened under
    std::string m_mode;

    //! \brief / on unix, \ on windows
    static const char s_sep;

    //! \brief Magic number for timekey file.
    static const uint32_t s_magic_timekey;

  public:

    //! \brief whether we should flush metaframe on exit
    bool m_flush_meta;

    //! \brief The prologue bits in the key entry file.
    typedef struct {
      //! \brief Magic number for frames.
      uint32_t magic;  
      //! \brief Number of frames in each file
      uint32_t frames_per_file; 
      //! \brief The size of each key record
      uint32_t key_record_size;
    } key_prologue_t;


    //! \brief Representation of a key record on disk.
    typedef struct {
      //! \brief Time associated with this file (low bytes).
      uint32_t time_lo;
      //! \brief Time associated with this file (high bytes)
      uint32_t time_hi;
      //! \brief Zero in the 1 frame/file case (low bytes)
      uint32_t offset_lo;
      //! \brief Zero in the 1 frame/file case (high bytes)
      uint32_t offset_hi;
      //! \brief Number of bytes in frame (low bytes)
      uint32_t framesize_lo;
      //! \brief Number of bytes in frame (high bytes)
      uint32_t framesize_hi;
    } key_record_t;
  protected:
    //! \brief Read data, accounting for EINTR
    static ssize_t nointr_read(int fp, void* buf, size_t count);

    //! \brief Write data, accounting for EINTR
    static ssize_t nointr_write(int fp, const void* buf, size_t count);

    //! \brief Fsync file, accounting for EINTR
    static int nointr_fsync(int fd);

    //! \brief Name of the timekey file
    std::string keyfile() const;

  public:
    //! \brief Construct a top-level directory.
    FrameSet(std::string directory = "", std::string mode="r",
             int ndir1=0,int ndir2=0,size_t frames_per_file=1);

    //! \brief Standard destructor.
    virtual ~FrameSet();

    //! \brief Push current meta frame to persistent storage
    virtual void flush_meta() const;

    //! \brief Push already-serialized meta to storage
    virtual void flush_serialized_meta(const void *buf, size_t len) const;

    //! \brief Returns the current frame object for the central store
    FramePtr meta() const;

    //! \brief Name of the top level directory.
    virtual const std::string& name() const;

    //! \brief Maps a / separated pathname into the hierarchical space.
    virtual std::string hierarchicalName(std::string path) const;


    //! \brief Figure out where a subfile lays (e.g. .../metadata)
    virtual std::string subfile(std::string path) const;

    //! \brief Maps a frame number to a filename
    virtual std::string framefile(size_t frameno) const;

    //! \brief Number of frames written so far.
    size_t size() const;

    //! \brief  Number of frames written so far.
    size_t nframes() const;

    //! \brief Deep dir parameter
    int ndir1() const;

    //! \brief Deep dir parameter
    int ndir2() const;

    //! \brief Frame packing factor
    size_t frames_per_file() const;

    //! \brief mode string
    std::string mode() const;

    //! \brief Works like rm -rf
    static void recursivelyRemove(std::string path);

    //! \brief TBD
    class AutoClosingFD {
      int m_fd;
      AutoClosingFD(const AutoClosingFD&); // No copy c'tor
      void close() {
        if (m_fd >= 0) {
          while(1) {
            if (::fsync(m_fd) == 0 && ::close(m_fd) == 0) break;
            if (errno == EINTR) continue;
            ::close(m_fd);  // even if fsync failed
            throw ErrnoException("close",DESSERT_LOC);
          }
        }
      }
    public:
      //! \brief Create an autoclose object
      AutoClosingFD(int fd=-1) : m_fd(fd) {}
      //! \brief Close the file object on destruction
      ~AutoClosingFD() { close(); }
      //! \brief Return the real file descriptor
      int file() const { return m_fd; }
      //! \brief Assignment operator closes current and inserts new
      AutoClosingFD& operator=(int fd) { close(); m_fd = fd; return *this; }
    };

  };

  // True iff the path exists
  bool exists(const std::string &path);

  // True iff the path exists and is a regular file
  bool is_regular(const std::string &path);

  // True iff the path exists and is a directory
  bool is_directory(const std::string &path);}

#endif
