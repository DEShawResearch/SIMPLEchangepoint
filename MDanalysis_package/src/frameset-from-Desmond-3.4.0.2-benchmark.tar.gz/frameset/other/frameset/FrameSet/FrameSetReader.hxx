/* 
Copyright 2012-2014, D. E. Shaw Research.
All rights reserved.

Redistribution and use in source and binary forms, with or without
modification, are permitted provided that the following conditions are
met:

* Redistributions of source code must retain the above copyright
  notice, this list of conditions, and the following disclaimer.

* Redistributions in binary form must reproduce the above copyright
  notice, this list of conditions, and the following disclaimer in the
  documentation and/or other materials provided with the distribution.

* Neither the name of D. E. Shaw Research nor the names of its
  contributors may be used to endorse or promote products derived from
  this software without specific prior written permission.

THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
"AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR
A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT
OWNER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,
SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT
LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE,
DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY
THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
(INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE
OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
*/

#ifndef FRAMSETREADER_HXX
#define FRAMSETREADER_HXX

#include "FrameSet.hxx"
#include "Frame.hxx"

#include <string>
#include <vector>
#include <iterator>


namespace frameset {

  /*! \brief A frameset capable of reading frames from a directory set.
   *
   * A FrameSetReader pulls frameset metadata from the the directory
   * and coordianates iterators that allow access to frames backed
   * by files in that directory.
   */
  class FrameSetReader : public FrameSet {
    //! \brief The set of times represented by this frameset
    std::vector<double> m_times;

    //! \brief The offsets within framefiles to find data
    std::vector<off_t> m_offsets;

    //! \brief File descriptor to the keytime association file.
    AutoClosingFD m_keyfile_fd;

    // Suppress the compiler's desire to create a copy c'tor
    FrameSetReader(const FrameSetReader&); 

  protected:
    //! \brief binary search for a time. 
    void binary_search(double target, ssize_t& left, ssize_t& right) const;


    FrameSetReader(const std::string&,bool);

  public:

    /*! \brief Iterator that accesses an internal frame.
     *
     * The iterator also exposes the time associatd with a
     * frame.  The "key" time is associated with the frameset,
     * not with the frame (though it may have its own internal
     * notion of time as well).
     *
     * TODO: Change from forward_iterator_tag to
     * random_access_iterator_tag when I add --, +, - operators.
     */
    class iterator : public std::iterator<std::forward_iterator_tag,FramePtr> {
      const FrameSetReader& m_parent;
      FramePtr m_frame; //!< \brief Caches the frame
      size_t m_frameno;
    public:
      //! \brief The iterator references a frame in the parent
      iterator(const FrameSetReader& parent,size_t frameno);

      //! \brief Dereference yields a Frame&
      Frame& operator*();

      //! \brief -> yields a pointer-like object to a frame.
      FramePtr operator->();

      //! \brief Comparison for equality.
      bool operator==(const iterator& other) const;

      //! \brief Comparison for inequality.
      bool operator!=(const iterator& other) const;

      //! \brief Increment in place.
      iterator& operator++();

      //! \brief Increment in place and return next location.
      iterator operator++(int);

      //! \brief Time associated with this????
      double time() const;
    };

    //! \brief Build a reader with files at path.
    FrameSetReader(std::string path);

    //! \brief Standard destructor.
    ~FrameSetReader();

    //! \brief Fetch a frame object (range checked)
    virtual FramePtr at(size_t index) const;

    //! \brief Same as .at() method.
    FramePtr operator[](size_t index) const;

    //! \brief Time associated with a frame.
    virtual double time(size_t index) const;

    //! \brief First frame.
    iterator begin();

    //! \brief First frame.
    iterator begin() const;

    //! \brief Beyond last frame.
    iterator end();

    //! \brief Beyond last frame.
    iterator end() const;

    //! \brief Largest frame offset that is less than or equal t
    //!    returns -1 (out of range) if t is less than time(0)
    ssize_t search_le(double t) const;

    //! \brief Largest frame offset that is strictly less than t
    //!    returns -1 (out of range) if t is less than or equal to time(0)
    ssize_t search_lt(double t) const;

    //! \brief Smallest frame offset that is greater than or equal to t
    //!    returns size() (out of range) if t is greater than time(size()-1)
    ssize_t search_ge(double t) const;

    //! \brief Smallest frame offset that is strictly greater than t
    //!    returns size() (out of range) if t is greater than or equal to time(size()-1)
    ssize_t search_gt(double t) const;

    //! \brief Offset of the frame with time nearest to t
    ssize_t search_nearest(double t) const;
    
    //! \brief Read the header from the keyfile
    FrameSet::key_prologue_t read_keyfile_prologue() const;

    //! \brief Read an entry from the keyfile at a particular location.
    virtual FrameSet::key_record_t read_keyfile_entry(size_t index) const;

    //! \brief True if pathname is a directory with a keyfile in it.
    static bool isaFrameSetDirectory(std::string path);
  };

}

#endif
