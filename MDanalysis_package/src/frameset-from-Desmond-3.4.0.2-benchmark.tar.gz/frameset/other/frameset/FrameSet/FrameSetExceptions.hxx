/* 
Copyright 2012-2014, D. E. Shaw Research.
All rights reserved.

Redistribution and use in source and binary forms, with or without
modification, are permitted provided that the following conditions are
met:

* Redistributions of source code must retain the above copyright
  notice, this list of conditions, and the following disclaimer.

* Redistributions in binary form must reproduce the above copyright
  notice, this list of conditions, and the following disclaimer in the
  documentation and/or other materials provided with the distribution.

* Neither the name of D. E. Shaw Research nor the names of its
  contributors may be used to endorse or promote products derived from
  this software without specific prior written permission.

THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
"AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR
A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT
OWNER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,
SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT
LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE,
DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY
THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
(INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE
OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
*/

#ifndef FRAMESETEXCEPTIONS_HXX
#define FRAMESETEXCEPTIONS_HXX

#include <sstream>
#include <exception>
#include <dessert/dessert.hpp>
#include <stdint.h>

namespace frameset {

  //! \brief Common exception type
  class FrameSetException: public desres::dessert {
  public:
    //! \brief Report this message
    FrameSetException(const std::string& msg);

    //! \brief Report a message with file and line number
    FrameSetException(const std::string& msg, const char* file, int lineno, const char* func);

    //! \brief Required, conforming destructor
    virtual ~FrameSetException() throw();
  };

  //! \brief Used to indicate that code isn't finished here.
  class NotImplementedException : public FrameSetException {
  public:
    NotImplementedException(const char* file, size_t line, const char* func);
    virtual ~NotImplementedException() throw();
  };

  //! \brief Capture the errno when exception is thrown.
  class ErrnoException : public FrameSetException {
    int m_errno;
  public:
    ErrnoException(const std::string& msg = "");
    ErrnoException(const std::string& msg, const char* file, size_t line, const char* func);
    virtual ~ErrnoException() throw();
    int error() const;
  };


  //! \brief Indicates some kind of I/O problem.
  class IoException : public FrameSetException {
  public:
    IoException(const std::string& msg = "");
    IoException(const std::string& msg, const char* file, size_t line, const char* func);
    virtual ~IoException() throw();
  };

  //! \brief Just like an IoException, but adds errno information.
  class IoErrnoException : public IoException {
  public:
    IoErrnoException(const std::string& msg = "");
    IoErrnoException(const std::string& msg, const char* file, size_t line,const char* func);
    virtual ~IoErrnoException() throw();
  };

  //! \brief Attribute errors indicate a missing label.
  class AttributeError : public FrameSetException {
    std::string m_attr;
  public:
    //! \brief Construct from an attribute
    AttributeError(const std::string& attr);

    //! \brief Construct along with file line information
    AttributeError(const std::string& attr, const char* file, size_t line, const char* func);

    //! \brief Required overload (default d'tor is malformed).
    virtual ~AttributeError() throw();

    //! \brief Name of invalid attribute
    std::string attribute() const;
  };

  //! \brief TypeSafety violation (e.g. assign to wrong kind of Blob<>)
  class TypeSafetyError : public FrameSetException {
  public:
    //! \brief with message
    TypeSafetyError(const std::string& msg="");

    //! \brief Construct along with file line information
    TypeSafetyError(const std::string& msg, const char* file, size_t line,const char* func);

    //! \brief Required overload (default d'tor is malformed).
    virtual ~TypeSafetyError() throw();
  };

  //! \brief Some kind of bounds violation.
  class BoundsError : public FrameSetException {
  public:
    BoundsError(const std::string& msg="");
    virtual ~BoundsError() throw();
  };

  //! \brief Indicates an attempt to dereference non-dereferenceable object.
  class DereferenceError : public BoundsError {
  public:
    DereferenceError(const std::string& msg="");
    ~DereferenceError() throw();
  };

  //! \brief Range errors
  class RangeError : public BoundsError {
    //! \brief Index causing exception.
    uint64_t m_idx;

    //! \brief Maximum acceptable range
    uint64_t m_max;
  public:
    //! \brief with bounds
    RangeError(uint64_t idx, uint64_t max);

    //! \brief Construct along with file line information
    RangeError(uint64_t idx, uint64_t max, const char* file, size_t line, const char* func);

    //! \brief Required overload (default d'tor is malformed).
    virtual ~RangeError() throw();

    //! \brief Bad index causing throw.
    uint64_t badIndex() const;

    //! \brief Maximum index allowed.
    uint64_t maxIndex() const;

    static void check(uint64_t idx, uint64_t max);
    static void check(uint64_t idx, uint64_t max, const char* file, size_t line, const char* func);
  };

}
#endif
