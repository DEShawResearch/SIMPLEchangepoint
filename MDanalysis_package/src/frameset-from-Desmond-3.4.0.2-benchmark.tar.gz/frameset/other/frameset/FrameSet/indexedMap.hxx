/* 
Copyright 2012-2014, D. E. Shaw Research.
All rights reserved.

Redistribution and use in source and binary forms, with or without
modification, are permitted provided that the following conditions are
met:

* Redistributions of source code must retain the above copyright
  notice, this list of conditions, and the following disclaimer.

* Redistributions in binary form must reproduce the above copyright
  notice, this list of conditions, and the following disclaimer in the
  documentation and/or other materials provided with the distribution.

* Neither the name of D. E. Shaw Research nor the names of its
  contributors may be used to endorse or promote products derived from
  this software without specific prior written permission.

THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
"AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR
A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT
OWNER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,
SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT
LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE,
DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY
THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
(INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE
OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
*/

#ifndef _IndexedMap_dot_Hpp_
#define _IndexedMap_dot_Hpp_


#include <map>
#include <vector>

#include "FrameSet/FrameSetExceptions.hxx"

namespace frameset {

/*!
  IndexedMap: a class to provide "bidirectional" mapping from objects of
  type T to integer indices.  The idea is that you 'insert' T's
  into the Indexer.  "New" ones are assigned an increasing index.  You
  can ask for the index with [], which takes either an integer
  argument (returning a T) or a T argument (returning an int).

  See also indexer.hpp, which requires that T support hashing.
  This implementation requires that T be 'map-able', i.e., that
  it have a weak ordering, be default-constructable, etc.
*/
template <typename T>
class IndexedMap {
public:
  // First, a couple of types:
  typedef std::vector<T> vector_type;  //!< TBD
  typedef typename vector_type::const_iterator const_iterator;  //!< TBD
  typedef typename vector_type::size_type size_type;  //!< TBD
  typedef std::map<T,size_type> map_type;  //!< TBD

  //! \brief Insertion requires special handling:
  size_type insert(const T& t){
    typename map_type::iterator p = m_umap.find(t);
    if( p == m_umap.end() ){
      size_type idx = m_vec.size();
      m_umap[t] = idx;
      m_vec.push_back(t);
      return idx;
    }else{
      return p->second;
    }
  }

  //! TBD
  const T& at(size_type i) const{
    return m_vec.at(i);
  }

  // operator[] works on both int and T.
  // FIXME - these are ambiguous if T is int!
  //! \brief indexed access
  const T& operator[](size_type i) const{
    return at(i);
  }

  //! \brief indexed access
  size_type at(const T& t) const {
    typename map_type::const_iterator p = m_umap.find(t);
    if (p == m_umap.end())
      throw frameset::BoundsError("requested key-value pair not present");
    return p->second;
  }

  //! \brief indexed access
  size_type operator[](const T& t) const {
    return at(t);
  }

  // The non-const versions are not provided on purpose because
  // the caller cannot legally write into the vector.
  
  //! \brief iterator access
  const_iterator begin() const{return m_vec.begin(); }
  //! \brief iterator access
  const_iterator end() const{ return m_vec.end(); }

  //! \brief Number of bytes
  size_type size() const{ return m_vec.size(); }
  
  //! \brief Number of elements
  size_type count(const T& t) const{ return m_umap.count(t); }

  //! \brief Standard container 'swap'.  
  void swap( IndexedMap<T>& other ){
    m_umap.swap(other.m_umap);
    m_vec.swap(other.m_vec);
  }

  /*!
    Finally, provide access to the underlying vector and map.
    Is this sufficient, instead of explicitly implmenting every
    single public member?  If you want one of the other features of
    either the vector or the map representation, you can get at it
    through, e.g., vec().data() or map().lower_bound().  Only const
    references are provided because the caller cannot legally
    alter the contents without breaking the semantics of the
    indexedMap.
  */
  const vector_type& vec() const { return m_vec; }

  //! Access the map
  const map_type& map() const { return m_umap; }
protected:
  //! \brief TBD
  map_type m_umap;
  //! \brief TBD
  vector_type m_vec;
};

} // namespace frameset

#endif
