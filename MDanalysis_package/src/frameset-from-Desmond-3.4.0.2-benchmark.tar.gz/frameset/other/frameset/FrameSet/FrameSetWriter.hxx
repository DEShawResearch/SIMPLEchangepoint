/* 
Copyright 2012-2014, D. E. Shaw Research.
All rights reserved.

Redistribution and use in source and binary forms, with or without
modification, are permitted provided that the following conditions are
met:

* Redistributions of source code must retain the above copyright
  notice, this list of conditions, and the following disclaimer.

* Redistributions in binary form must reproduce the above copyright
  notice, this list of conditions, and the following disclaimer in the
  documentation and/or other materials provided with the distribution.

* Neither the name of D. E. Shaw Research nor the names of its
  contributors may be used to endorse or promote products derived from
  this software without specific prior written permission.

THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
"AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR
A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT
OWNER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,
SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT
LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE,
DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY
THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
(INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE
OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
*/

#ifndef FRAMESETWRITER_HXX
#define FRAMESETWRITER_HXX

#include "FrameSet.hxx"
#include "Frame.hxx"

#include <string>

namespace frameset {
  /*! \brief An object that can write framesets to disk.
   *
   * A frameset write adds a frame push_back method and a current
   * time check.
   */
  class FrameSetWriter : public FrameSet {
    //! \brief File descriptor to the timekey/offset file.
    AutoClosingFD m_keyfile_fd;

    //! \brief current offset into framefile
    uint64_t m_framefile_offset;

    //! \brief File descriptor to the "in-progress" frame
    AutoClosingFD m_framefile_fd;

    //! \brief Synchronize every frame write to disk
    bool m_sync;

    //! \brief worker function for writing frames to disk
    virtual void write_frame(const Frame *frame, const void *buf, size_t len, double time);

  protected:
    //! \brief The chemical time of the last frame written.
      double m_chemical_time;

    // Suppress the compiler's desire to create a copy c'tor
    FrameSetWriter(const FrameSetWriter&); 

  public:
    FrameSetWriter();
    FrameSetWriter(std::string dirname,std::string mode="w!",
                   int ndir1=0,int ndir2=0,size_t frames_per_file=1,bool sync=0);

    //! \brief Destructor needs to close the timekey file.
    virtual ~FrameSetWriter();

    //! \brief Push frame out to disk.
    virtual void push_back(const Frame& frame,double time);

    //! \brief Push an already serialized frame out to disk
    virtual void push_back(const void *buf, size_t len, double time);

    //! \brief Flush the timekey/offset file to disk.
    virtual void flush_keyfile();

    //! \brief Flush the file descriptor associated with the current frame.
    //  If there is no open frame file descriptor, this does nothing; if
    //  there was a problem with the flush, an exception is thrown.
    //
    // NOTE: I don't understand why there are flush() methods in the FrameSet
    // base class that get inherited by FrameSetReader.  This flush method
    // lives in FrameSetWriter only.
    void flush_framefile();

    //! \brief The last chemical time written to the file.
    double time() const;

    //! \brief Remove elements from the keyfile (rewind the time)
    virtual void rewind(double rewind_before_time);
  };
}
#endif
