/* 
Copyright 2012-2014, D. E. Shaw Research.
All rights reserved.

Redistribution and use in source and binary forms, with or without
modification, are permitted provided that the following conditions are
met:

* Redistributions of source code must retain the above copyright
  notice, this list of conditions, and the following disclaimer.

* Redistributions in binary form must reproduce the above copyright
  notice, this list of conditions, and the following disclaimer in the
  documentation and/or other materials provided with the distribution.

* Neither the name of D. E. Shaw Research nor the names of its
  contributors may be used to endorse or promote products derived from
  this software without specific prior written permission.

THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
"AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR
A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT
OWNER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,
SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT
LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE,
DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY
THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
(INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE
OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
*/

#ifndef BaseBLOB_HXX
#define BaseBLOB_HXX

#include "HumanTypename.hxx"
#include "FrameSetExceptions.hxx"

#include <string>
#include <iterator>

#include "boost/shared_array.hpp"

#ifdef DESRES_OS_Windows

#define __BYTE_ORDER 1234

#elif defined(DESRES_OS_Darwin)

#define __LITTLE_ENDIAN 1234
#define __BIG_ENDIAN 1234

#if defined(__LITTLE_ENDIAN__)
#define __BYTE_ORDER 1234
#endif

#if defined(__BIG_ENDIAN__)
#define __BYTE_ORDER 1234
#endif

#endif

#include <inttypes.h>

namespace frameset {

  /*! \brief A generic blob of data.  Carries type and size information.
   *
   * This data item is generic in that it can hold data of any type.  It
   * does maintain type information in terms of element size and the name
   * of the type.
   */
  class BaseBlob {

  protected: // icc9.0 requires this class to be protected, not private!

    //! \brief Used to adapt funny cast of smart pointer to char.
    template<class P> struct smart_pointer_deleter {
    private:
      //! \brief Maintains a reference to a smart pointer of type P
      const P* m_p;
    public:
      //! \brief Create keep-alive reference to smart pointer
      smart_pointer_deleter(const P & p) { m_p = new P(p); }
      //! \brief This is called when the holder wants to delete.
      void operator()(void const *) {try{const P* t = m_p; m_p = 0; delete t;} catch (...) {}}
    };

  protected:
    //! \brief Name of the true type of the data.
    std::string m_type;
    //! \brief Number of items (0 or more) in this data chunk.
    uint64_t m_count;
    //! \brief Size of individual elements of this type.
    uint32_t m_elementsize;
    //! \brief Actual data under storage.
    boost::shared_array<char> m_data;

    //! \brief Endianism of the data
    int m_endianism;

    //! \brief Setup a blob for a particular type element
    void setup_type(uint64_t count, std::string type, uint32_t elementsize);
  public:
    //! \brief Construct a char blob from a size
    BaseBlob(uint64_t count = 0);

    //! \brief Build a blob from its subcomponents
    BaseBlob(std::string type, uint64_t count, uint32_t elementsize, 
             boost::shared_array<char> data,int endianism=__BYTE_ORDER);

    //! \brief Share data with a user shared_array<T>
    template<class T>
    inline BaseBlob(uint64_t count,boost::shared_array<T> data);

    //! \brief Copy data from a user T*
    template<class T>
    inline BaseBlob(uint64_t count,const T* data);
    
    //! \brief Reallocate and clear out all memory
    void reset();

    //! \brief Shrink or extend the data section
    void resize(uint64_t newcount);

    //! \brief Raw data.
    boost::shared_array<char> data();
    //! \brief Raw data.
    const boost::shared_array<char> data() const;

    //! \brief Name of type held by this blob
    std::string type() const;

    //! \brief Number of elements in this blob
    uint64_t count() const;

    //! \brief Size of a single element in this blob.
    uint32_t elementsize() const;

    //! \brief Number of bytes required to hold this blob
    uint64_t nbytes() const;

    //! \brief Iterate over contents as bytes.
    char* firstbyte();
    //! \brief Iterate over contents as bytes.
    const char* firstbyte() const;

    //! \brief Iterate over contents as bytes.
    char* endbytes();
    //! \brief Iterate over contents as bytes.
    const char* endbytes() const;
  };


  /*!
   * The boost shared array is wrapped in type converter
   * to keep the reference count on it alive while letting
   * the BaseBlob hold a char* alias to it.
   */
  template<class T>
  BaseBlob::BaseBlob(uint64_t count,boost::shared_array<T> data)
    : m_count(count), m_elementsize(sizeof(T)), m_endianism(__BYTE_ORDER)
  {
    T dummy;
    m_type = humanTypename(dummy);

    // TODO: Put many comments here as it is quite confusing
    // as to how boost implements it's very clever, but oh
    // so tricky custom deleter function.  The point here
    // is that when m_data gets deleted, it will trigger a
    // delete on the original shared_array.
    boost::shared_array<char> px(reinterpret_cast<char*>(data.get()),
                                 smart_pointer_deleter< boost::shared_array<T> >(data));

    m_data = px;
  }

  /*!
   * The data is copied into a boost shared_array of the appropriate
   * type.  If the data pointer is null, the data is left uninitialized.
   */
  template<class T>
  BaseBlob::BaseBlob(uint64_t count,const T* data)
    : m_count(count), m_endianism(__BYTE_ORDER)
  {
    T dummy;
    m_type = humanTypename(dummy);
    m_elementsize = sizeof(dummy);
    boost::shared_array<T> values(new T[count]);

    // Only copy the data if we have some.
    if (data != NULL) {
      for(uint64_t ii=0; ii<count; ++ii) {
        values[ii] = data[ii];  // Safer to invoke copy c'tor
      }
    }

    // Adapt the T* array to char to hold the data.
    boost::shared_array<char> px(reinterpret_cast<char*>(values.get()),
                                 smart_pointer_deleter< boost::shared_array<T> >(values));

    m_data = px;
  }

}

#endif
