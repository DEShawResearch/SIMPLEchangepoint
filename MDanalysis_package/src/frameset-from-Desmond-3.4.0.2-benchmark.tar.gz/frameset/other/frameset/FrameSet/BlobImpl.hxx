/* 
Copyright 2012-2014, D. E. Shaw Research.
All rights reserved.

Redistribution and use in source and binary forms, with or without
modification, are permitted provided that the following conditions are
met:

* Redistributions of source code must retain the above copyright
  notice, this list of conditions, and the following disclaimer.

* Redistributions in binary form must reproduce the above copyright
  notice, this list of conditions, and the following disclaimer in the
  documentation and/or other materials provided with the distribution.

* Neither the name of D. E. Shaw Research nor the names of its
  contributors may be used to endorse or promote products derived from
  this software without specific prior written permission.

THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
"AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR
A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT
OWNER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,
SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT
LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE,
DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY
THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
(INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE
OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
*/

#include "FrameSet/Blob.hxx"
#include "FrameSet/FrameSetExceptions.hxx"
#include <iostream>

#include "EndianConvert.hxx"

namespace frameset {
  /*!
   * Build a typed blob with room for count elements.
   */
  template <class ScalarType>
  Blob<ScalarType>::Blob(size_t count) {
    ScalarType dummy;
    setup_type(count,humanTypename(dummy),sizeof(dummy));
    link_typed_data_to(m_data);
  }

  /*!
   * Tie the lifetime of the typed data viewport into the lifetime
   * of the specified shared array.  This ensures that the data
   * remains valid for the lifetime of this object even if all
   * other shared_array references disappear.
   */
  template <class ScalarType>
  void Blob<ScalarType>::link_typed_data_to(const boost::shared_array<char>& other_data) {
    // -----------------------------------------------
    // We will construct our internal shared array from its
    // raw pointer.
    // -----------------------------------------------
    const char* data_ptr = other_data.get();
    const ScalarType* const_ptr =
      reinterpret_cast<const ScalarType*>(data_ptr);
    ScalarType* ptr = const_cast<ScalarType*>(const_ptr);

    // -----------------------------------------------
    // We build an adapter so that our shared array
    // keeps the original's alive until we deallocate
    // -----------------------------------------------
    boost::shared_array<ScalarType>
      px(ptr,
         smart_pointer_deleter<const boost::shared_array<char> >(other_data));
    m_typedData = px;
  }

  /*!
   * Copying a blob requires that dynamic typesafety checks
   * be made.  This is equivalent to calling the assignment
   * operator.
   */
  template <class ScalarType>
  Blob<ScalarType>::Blob(const BaseBlob& other)
  {
    operator=(other);
  }

  /*!
   * The assignment operator must make sure that the two
   * items have the same humanTypeName before allowing the
   * casting of an untyped blob into this typed blob.
   */
  template <class ScalarType>
  Blob<ScalarType>& Blob<ScalarType>::operator=(const BaseBlob& other) {
    ScalarType dummy;

    // -----------------------------------------------
    // Copy over the basic structure from the other
    // object
    // -----------------------------------------------
    BaseBlob& self = *this;
    self = other;

    // -----------------------------------------------
    // We must have the right type
    // -----------------------------------------------
    if (other.type() != humanTypename(dummy)) {
      // TODO: Fix the functionality of operator <<()
      // so that it doesn't copy away the derived type
      //     throw TypeSafetyError() << "type mismatch..."
      std::stringstream error;
      error << "type mismatch, expected ";
      error << other.type();
      error << " got ";
      error << humanTypename(dummy);
      throw TypeSafetyError(error.str());
    }

    // -----------------------------------------------
    // Hmmm... if this machine's endianism and size matches
    // the other machine's, we just link our data
    // to theirs (no copy)
    // -----------------------------------------------
    if (m_endianism == __BYTE_ORDER && other.elementsize() == sizeof(dummy)) {
      link_typed_data_to(other.data());
    }

    // -----------------------------------------------
    // Have to do some kind of conversion
    // -----------------------------------------------
    else {
      //BaseBlob converted = convert<ScalarType>(other);
      throw FrameSetException("endianism conversion not implemented");
    }

    return *this;
  }

  /*!
   * Return the raw shared array that underpins this typed
   * view of the data.
   */
  template <class ScalarType>
  boost::shared_array<ScalarType> Blob<ScalarType>::typedData() {
    return m_typedData;
  }

  /*!
   * Return the raw shared array that underpins this typed
   * view of the data.
   */
  template <class ScalarType>
  const boost::shared_array<ScalarType> Blob<ScalarType>::typedData() const {
    return m_typedData;
  }

  /*!
   * Retrieve subelement of blob.  Range checked.
   */
  template <class ScalarType>
  ScalarType& Blob<ScalarType>::at(uint64_t index) {
    return operator[](index);
  }

  /*!
   * Retrieve subelement of blob.  Range checked.
   */
  template <class ScalarType>
  const ScalarType& Blob<ScalarType>::at(uint64_t index) const {
    return operator[](index);
  }

  /*!
   * Retrieve subelement of blob.  Range checked.
   */
  template <class ScalarType>
  ScalarType& Blob<ScalarType>::operator[](uint64_t index) {
    if (m_typedData.get() == NULL) throw FrameSetException("Null storage");
    RangeError::check(index,m_count,DESSERT_LOC);
    return m_typedData[index];
  }

  /*!
   * Retrieve subelement of blob.  Range checked.
   */
  template <class ScalarType>
  const ScalarType& Blob<ScalarType>::operator[](uint64_t index) const {
    if (m_data.get() == NULL) throw FrameSetException("Null storage");
    RangeError::check(index,m_count,DESSERT_LOC);
    return m_typedData[index];
  }

  /*!
   * Iterator that references the 0'th element.
   */
  template <class ScalarType>
  typename Blob<ScalarType>::iterator Blob<ScalarType>::begin() {
    return iterator(m_typedData.get(),m_typedData.get()+m_count);
  }

  /*!
   * Iterator that references the 0'th element.
   */
  template <class ScalarType>
  typename Blob<ScalarType>::const_iterator Blob<ScalarType>::begin() const {
    return const_iterator(m_typedData.get(),m_typedData.get()+m_count);
  }

  /*!
   * Iterator that references past the last element.
   */
  template <class ScalarType>
  typename Blob<ScalarType>::iterator Blob<ScalarType>::end() {
    return iterator(m_typedData.get()+m_count,m_typedData.get()+m_count);
  }

  /*!
   * Iterator that references past the last element.
   */
  template <class ScalarType>
  typename Blob<ScalarType>::const_iterator Blob<ScalarType>::end() const {
    return const_iterator(m_typedData.get()+m_count,m_typedData.get()+m_count);
  }


  /*!
   * Constructs an iterator object that spans the data in a blob.
   */
  template <class ScalarType>
  Blob<ScalarType>::iterator::iterator(ScalarType* low, ScalarType* high, ScalarType* current)
    : m_low(low), m_current(current), m_high(high)
  {
    if (!m_high) m_high = m_low;
    if (!m_current) m_current = m_low;
  }

  /*!
   * The low bound of the iterator.
   */
  template <class ScalarType> const ScalarType* Blob<ScalarType>::iterator::low() const {
    return m_low;
  }

  /*!
   * One past the end of the iterable values.
   */
  template <class ScalarType> const ScalarType* Blob<ScalarType>::iterator::high() const {
    return m_high;
  }

  /*!
   * Current value being referenced by this iterator (may
   * be out of range, this isn't an error until a dereference
   * actually takes place).
   */
  template <class ScalarType> const ScalarType* Blob<ScalarType>::iterator::current() const {
    return m_current;
  }
  

  /*!
   * Pre-increment will advance the pointer in place.
   */
  template <class ScalarType>
  typename Blob<ScalarType>::iterator& Blob<ScalarType>::iterator::operator++() {
    if (m_current == NULL) throw DereferenceError("dereferencing null pointer");
    m_current++;
    return *this;
  }

  /*!
   * Post-increment will advance the pointer in place, but returns
   * a copy of the current value.
   */
  template <class ScalarType>
  typename Blob<ScalarType>::iterator Blob<ScalarType>::iterator::operator++(int) {
    iterator copy = *this;
    operator++();
    return copy;
  }

  /*!
   * Iterators are the same if they are coincident or if they point to the same
   * current value.
   */
  template <class ScalarType>
  bool Blob<ScalarType>::iterator::operator==(const typename Blob<ScalarType>::iterator& other) const {
    if (this == &other) return true;
    return (m_current == other.current());
  }

  /*!
   * != is implemented simply as the not of operator==()
   */
  template <class ScalarType>
  bool Blob<ScalarType>::iterator::operator!=(const typename Blob<ScalarType>::iterator& other) const {
    return ! operator==(other);
  }

  /*!
   * It is reasonable to compare iterators with const_iterator bounds so
   * long as we are simply comparing internal pointers.
   */
  template <class ScalarType>
  bool Blob<ScalarType>::iterator::operator==(const typename Blob<ScalarType>::const_iterator& other) const {
    return (m_current == other.current());
  }

  /*!
   * It is reasonable to compare iterators with const_iterator bounds so
   * long as we are simply comparing internal pointers.
   */
  template <class ScalarType>
  bool Blob<ScalarType>::iterator::operator!=(const typename Blob<ScalarType>::const_iterator& other) const {
    return ! operator==(other);
  }

  /*!
   * Before dereferencing, we must range check the current
   * referenced value to see if it is inside the valid
   * range for this iterator.
   */
  template <class ScalarType>
  ScalarType& Blob<ScalarType>::iterator::operator*() {
    if (m_current == NULL) {
      throw DereferenceError("dereferencing null pointer");
    }
    if (m_current < m_low) {
      throw BoundsError("iterator references below valid data");
    }
    if (m_current >= m_high) {
      throw BoundsError("iterator references above valid data");
    }

    return *m_current;
  }

  /*!
   * Before dereferencing, we must range check the current
   * referenced value to see if it is inside the valid
   * range for this iterator.
   */
  template <class ScalarType>
  const ScalarType& Blob<ScalarType>::iterator::operator*() const {
    if (m_current == NULL) {
      throw DereferenceError("invalid null reference");
    }
    if (m_current < m_low) {
      throw BoundsError("iterator references below valid data");
    }
    if (m_current >= m_high) {
      throw BoundsError("iterator references above valid data");
    }

    return *m_current;
  }

  /*!
   * Subtraction simply operators on the internal current
   * pointer without regards for bounds checking.  Bounds
   * are checked prior to a dereferencing operation.
   */
  template <class ScalarType>
  ssize_t Blob<ScalarType>::iterator::operator-(const typename Blob<ScalarType>::iterator& other) const {
    if (m_high != other.high()) throw FrameSetException("incomparable");
    return m_current - other.current();
  }

  /*!
   * Subtraction simply operators on the internal current
   * pointer without regards for bounds checking.  Bounds
   * are checked prior to a dereferencing operation.
   */
  template <class ScalarType>
  ssize_t Blob<ScalarType>::iterator::operator-(const const_iterator& other) const {
    if (m_high != other.high()) throw FrameSetException("incomparable");
    return m_current - other.current();
  }

  /*!
   * Dereference, but return a internal pointer.
   */
  template <class ScalarType>
  ScalarType* Blob<ScalarType>::iterator::operator->() {
    return & operator*();
  }

  /*!
   * Dereference, but return a internal pointer.
   */
  template <class ScalarType>
  const ScalarType* Blob<ScalarType>::iterator::operator->() const {
    return & operator*();
  }

  /*!
   * TODO: not implemented
   */
  template <class ScalarType>
  Blob<ScalarType>::const_iterator::const_iterator(const ScalarType* begin, const ScalarType* end, const ScalarType* current) {
    throw NotImplementedException(DESSERT_LOC);
  }

  /*!
   * TODO: not implemented
   */
  template <class ScalarType>
  Blob<ScalarType>::const_iterator::const_iterator(const typename Blob<ScalarType>::iterator&) {
    throw NotImplementedException(DESSERT_LOC);
  }

  /*!
   * TODO: not implemented
   */
  template <class ScalarType> const ScalarType* Blob<ScalarType>::const_iterator::low() const {
    return m_low;
  }

  /*!
   * TODO: not implemented
   */
  template <class ScalarType> const ScalarType* Blob<ScalarType>::const_iterator::high() const {
    return m_high;
  }

  /*!
   * TODO: not implemented
   */
  template <class ScalarType> const ScalarType* Blob<ScalarType>::const_iterator::current() const {
    return m_current;
  }
  
  /*!
   * TODO: not implemented
   */
  template <class ScalarType>
  typename Blob<ScalarType>::const_iterator& Blob<ScalarType>::const_iterator::operator++() {
    throw NotImplementedException(DESSERT_LOC);
  }

  /*!
   * TODO: not implemented
   */
  template <class ScalarType>
  typename Blob<ScalarType>::const_iterator Blob<ScalarType>::const_iterator::operator++(int) {
    throw NotImplementedException(DESSERT_LOC);
  }

  /*!
   * TODO: not implemented
   */
  template <class ScalarType>
  bool Blob<ScalarType>::const_iterator::operator==(const const_iterator& other) const {
    if (this == &other) return true;
    throw NotImplementedException(DESSERT_LOC);
  }

  /*!
   * TODO: not implemented
   */
  template <class ScalarType>
  bool Blob<ScalarType>::const_iterator::operator!=(const const_iterator& other) const {
    throw NotImplementedException(DESSERT_LOC);
  }

  /*!
   * TODO: not implemented
   */
  template <class ScalarType>
  bool Blob<ScalarType>::const_iterator::operator==(const typename Blob<ScalarType>::iterator& other) const {
    throw NotImplementedException(DESSERT_LOC);
  }

  /*!
   * TODO: not implemented
   */
  template <class ScalarType>
  bool Blob<ScalarType>::const_iterator::operator!=(const typename Blob<ScalarType>::iterator& other) const {
    throw NotImplementedException(DESSERT_LOC);
  }

  /*!
   * TODO: not implemented
   */
  template <class ScalarType>
  ScalarType& Blob<ScalarType>::const_iterator::operator*() {
    throw NotImplementedException(DESSERT_LOC);
  }

  /*!
   * TODO: not implemented
   */
  template <class ScalarType>
  const ScalarType& Blob<ScalarType>::const_iterator::operator*() const {
    throw NotImplementedException(DESSERT_LOC);
  }

  /*!
   * TODO: not implemented
   */
  template <class ScalarType>
  ssize_t Blob<ScalarType>::const_iterator::operator-(const const_iterator& other) const {
    throw NotImplementedException(DESSERT_LOC);
  }

  /*!
   * TODO: not implemented
   */
  template <class ScalarType>
  ScalarType* Blob<ScalarType>::const_iterator::operator->() {
    throw NotImplementedException(DESSERT_LOC);
  }

  /*!
   * TODO: not implemented
   */
  template <class ScalarType>
  const ScalarType* Blob<ScalarType>::const_iterator::operator->() const {
    throw NotImplementedException(DESSERT_LOC);
  }

}

