/* 
Copyright 2012-2014, D. E. Shaw Research.
All rights reserved.

Redistribution and use in source and binary forms, with or without
modification, are permitted provided that the following conditions are
met:

* Redistributions of source code must retain the above copyright
  notice, this list of conditions, and the following disclaimer.

* Redistributions in binary form must reproduce the above copyright
  notice, this list of conditions, and the following disclaimer in the
  documentation and/or other materials provided with the distribution.

* Neither the name of D. E. Shaw Research nor the names of its
  contributors may be used to endorse or promote products derived from
  this software without specific prior written permission.

THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
"AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR
A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT
OWNER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,
SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT
LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE,
DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY
THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
(INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE
OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
*/

#ifndef FRAMESET_OVERLAYFRAMESET_HXX
#define FRAMESET_OVERLAYFRAMESET_HXX
#endif

#include "FrameSetReader.hxx"

namespace frameset {
  //! \brief Overlay frames in time
  class OverlayFrameSet : public FrameSetReader {
  private:
    std::vector<boost::shared_ptr<FrameSetReader> > m_overlays;

    // m_goodframes.size() == m_overlays.size()+1
    std::vector<size_t> m_goodframes;

    const FrameSetReader& owner(size_t& index) const;
  public:
    //! \brief Start with an initial reader
    OverlayFrameSet(const std::string& base);

    //! \brief D'tor
    virtual ~OverlayFrameSet();

    // Overloaded virtuals
    virtual std::string framefile(size_t frameno) const;
    virtual FrameSet::key_record_t read_keyfile_entry(size_t index) const;
    virtual FramePtr at(size_t index) const;
    virtual double time(size_t index) const;

    //! \brief Extend the overlay with a reader object
    void overlay(const boost::shared_ptr<FrameSetReader>& part);

    //! \brief Open filename as a reader and overlay
    void overlay(const std::string& filename);

    //! \brief Open a reader from .STK formatted file
    static OverlayFrameSet* from_stk_file(const std::string& source);

    //! \brief Open a reader from .STK formatted file or normal frameset
    static FrameSet* from_stk_file_or_directory(const std::string& source);
  };
}
