/* 
Copyright 2012-2014, D. E. Shaw Research.
All rights reserved.

Redistribution and use in source and binary forms, with or without
modification, are permitted provided that the following conditions are
met:

* Redistributions of source code must retain the above copyright
  notice, this list of conditions, and the following disclaimer.

* Redistributions in binary form must reproduce the above copyright
  notice, this list of conditions, and the following disclaimer in the
  documentation and/or other materials provided with the distribution.

* Neither the name of D. E. Shaw Research nor the names of its
  contributors may be used to endorse or promote products derived from
  this software without specific prior written permission.

THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
"AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR
A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT
OWNER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,
SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT
LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE,
DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY
THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
(INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE
OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
*/

#ifndef READERFRAME_HXX
#define READERFRAME_HXX

#include "FrameSet.hxx"
#include "Frame.hxx"

namespace frameset {

  /*! \brief A version of Frame that lazily reads data from a file.
   *
   * TODO: It looks like ReaderFrame should be templated
   * on its data container.  The data container object
   * can mmap it from a file, read it into a buffer,
   * be backed by a vector<char>, whatever.  It just has
   * to provide writable bytes in memory.  This means
   * that I could write a string-frame parser, for example.
   * Need to think about how to deal with data containers
   * that only provide const char* access (e.g. std::string
   * or mmap with only PROT_READ), but I think I can
   * use traits to make that work.
  */
  class ReaderFrame : public Frame {
  public:
    //! \brief Data container adapter to allow boost pointers
    class ContainerBase {
    public:
      //! \brief virtual destructor
      virtual ~ContainerBase();
      //! \brief Number of bytes in this container.
      virtual size_t size() const = 0;
      //! \brief Raw data handle for this container.
      virtual char* data() = 0;
      //! \brief Raw data handle for this container.
      virtual const char* data() const = 0;
    };
  protected:
    //! \brief Data container... can be anything with this interface.
    class Container : public ContainerBase {
      //! \brief File descriptor that is mapped to memory
      FrameSet::AutoClosingFD m_fd;
      //! \brief Pointer to mapped memory.
      void* m_mapping;
      //! \brief Number of bytes being mapped.
      size_t m_size;
    public:
      //! \brief Empty container with no memory mapped.
      Container();
      //! \brief Container mapping a file into memory.
      Container(std::string filename, off_t offset,size_t filesize=0);
      //! \brief Destroying a container should release its mmap'd data.
      virtual ~Container();
      //! \brief Number of bytes in this container.
      virtual size_t size() const;
      //! \brief Raw data handle for this container.
      virtual char* data();
      //! \brief Raw data handle for this container.
      virtual const char* data() const;
    };

    //! \brief Make sure data, meta, and typecode are up to date
    void lazy_load() const;

    //! \brief Accessor to private meta-data.
    virtual meta_map_t& meta();
    //! \brief Accessor to private meta-data.
    virtual const meta_map_t& meta() const;

    //! \brief Accessor to private data map.
    virtual data_map_t& data();
    //! \brief Accessor to private data map.
    virtual const data_map_t& data() const;

    //! \brief Accessor to private typecodes map.
    virtual typecode_imap_t& typecodes();
    //! \brief Accessor to private typecodes map.
    virtual const typecode_imap_t& typecodes() const;

    /*! \brief Holds a reference to the mapped or read data
     * The data reference can then be passed to smart
     * pointers that represent fields so that the data
     * representing them doesn't vanish when the frame
     * does (unmap or free() as appropriate).
     */
    boost::shared_ptr<ContainerBase> m_container;

  private:

    //! \brief True iff we have read the file information in.
    bool m_loaded;

    //! \brief The endianism read from the actual frame.
    uint32_t m_endianism;

  public:
    //! \brief Build from a container
    ReaderFrame(boost::shared_ptr<ContainerBase>);

    //! \brief Create a blank reader frame.
    //    ReaderFrame();

    //! \brief Create a frame associated with a particular file.
    ReaderFrame(std::string filename, off_t offset=0,size_t filesize=0);

    //! \brief Destroy a frame.
    virtual ~ReaderFrame();

    //! \brief Endianism of this frame (1234 == Little, 4321 = Big, 3412 = Pdp)
    virtual uint32_t endianism() const;

  };

}
#endif
