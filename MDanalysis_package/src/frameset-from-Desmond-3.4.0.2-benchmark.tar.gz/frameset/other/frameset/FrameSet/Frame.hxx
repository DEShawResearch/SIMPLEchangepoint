/* 
Copyright 2012-2014, D. E. Shaw Research.
All rights reserved.

Redistribution and use in source and binary forms, with or without
modification, are permitted provided that the following conditions are
met:

* Redistributions of source code must retain the above copyright
  notice, this list of conditions, and the following disclaimer.

* Redistributions in binary form must reproduce the above copyright
  notice, this list of conditions, and the following disclaimer in the
  documentation and/or other materials provided with the distribution.

* Neither the name of D. E. Shaw Research nor the names of its
  contributors may be used to endorse or promote products derived from
  this software without specific prior written permission.

THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
"AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR
A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT
OWNER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,
SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT
LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE,
DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY
THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
(INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE
OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
*/

#ifndef FRAME_HXX
#define FRAME_HXX

#include "Blob.hxx"
#include "FrameSetExceptions.hxx"
#include "indexedMap.hxx"

#include <iostream> // TODO: remove debug
#include <map>
#include <set>
#include <vector>
#include <string>

#include "boost/shared_ptr.hpp"

#include <inttypes.h>

namespace frameset {
  /*! \brief fletcher's checksum
   *
   * See RFC 1146 for Fletcher's Checksum (http://tools.ietf.org/html/rfc1146)
   */
  uint32_t fletcher( uint16_t *data, size_t len );

  /*! \brief Abstracts access to meta, typecode, and data maps.
   *
   * We abstract access to the data storage so that FrameReaders
   * can create frames that do a lazy fetch of the meta_map,
   * data_map, and typecode_list.  Since that data is private,
   * it can only be accessed with the meta(), data(), and typecodes()
   * methods.  By overriding these virtuals, a derived class can
   * interpose requirements for reading these elements (e.g. read
   * the file only on demand, or just make sure the meta-data
   * is current, etc...).
   */
  class FrameInfo {
  public:
    //! \brief Basic destructor.
    virtual ~FrameInfo();
  protected:

    //! \brief Internal meta structure.
    typedef struct {
      uint32_t type;            //!< \brief Typecode for the data's type.
      uint32_t elementsize;     //!< \brief Size of one type element.
      uint64_t count;           //!< \brief Number of elements in the field.
    } meta_t;

    /*! \brief Maps label to meta-data about field
     *
     * My reasoning for splitting the meta data from the
     * blob data (which holds the same information!) was
     * that on reading a frame, it probably made sense
     * to restore the meta-data separately so that users
     * could ask questions about what containers are present
     * and their types and sizes.  As implemented currently,
     * however, I mmap in the full file and can create the
     * data fields with no read cost (the pages don't map
     * into memory until demanded by a reader/writer of
     * the field).  I will likely want to rethink this part
     * of the implementation.  Changing it would not change
     * the disk footprint nor the API.
     */     
    typedef std::map<std::string,meta_t> meta_map_t;
    
    //! \brief Maps label to data held representing a field.
    typedef std::map<std::string,BaseBlob> data_map_t;

    //! \brief List of field element types
    typedef IndexedMap<std::string> typecode_imap_t;

    //! \brief Accessor to private meta-data.
    virtual meta_map_t& meta();
    //! \brief Accessor to private meta-data.
    virtual const meta_map_t& meta() const;

    //! \brief Accessor to private data map.
    virtual data_map_t& data();
    //! \brief Accessor to private data map.
    virtual const data_map_t& data() const;

    //! \brief Accessor to private typecodes map.
    virtual typecode_imap_t& typecodes();
    //! \brief Accessor to private typecodes map.
    virtual const typecode_imap_t& typecodes() const;

  private:

    //! \brief Maps typename to typecode.
    typecode_imap_t m_typecodes;

    //! \brief Meta information about data (type, element count)
    meta_map_t m_meta;

    //! \brief The bytes associated with a label.
    data_map_t m_data;
  };

  //! \brief Container for temporally associated data.
  class Frame : protected FrameInfo {
  protected:
    //! \brief Bytes required to hold the header block.
    uint64_t compute_header_size() const;
    //! \brief Bytes required to hold the typenames.
    uint64_t compute_typename_size() const;
    //! \brief Bytes required to hold meta information
    uint64_t compute_meta_size() const;
    //! \brief Bytes required to hold labels.
    uint64_t compute_label_size() const;
    //! \brief Bytes required to hold scalar (count 0 or 1) fields.
    uint64_t compute_scalar_size() const;
    //! \brief Bytes required to hold non-scalar fields.
    uint64_t compute_field_size() const;
    //! \brief Bytes required to hold the CRC value.
    uint64_t compute_crc_size() const;
    //! \brief Bytes required to hold padding to pagesize boundary.
    uint64_t compute_padding_size(uint64_t) const;

    //! \brief Compute internal sizes, offsets, and full framesize.
    uint64_t compute_blocksizes(uint64_t& size_header_block,
                                uint64_t& offset_header_block,
                                uint64_t& size_typename_block,
                                uint64_t& offset_typename_block,
                                uint64_t& size_meta_block,
                                uint64_t& offset_meta_block,
                                uint64_t& size_label_block,
                                uint64_t& offset_label_block,
                                uint64_t& size_scalar_block,
                                uint64_t& offset_scalar_block,
                                uint64_t& size_field_block,
                                uint64_t& offset_field_block,
                                uint64_t& size_crc_block,
                                uint64_t& offset_crc_block,
                                uint64_t& size_padding_block,
                                uint64_t& offset_padding_block) const;

    //! \brief Lookup typecode associated with a type name.
    //void add_typecode(const std::string& type);
    //    uint32_t typecode(std::string type);
    //! \brief Lookup typecode associated with a type name.
    //uint32_t typecode(std::string type) const;

    // No reachable path to this function, so commenting out
    // //! \brief Find the meta entry associated with a label
    // meta_t& lookup_meta(const std::string& label, bool chase);

    //! \brief Find the meta entry associated with a label
    const meta_t& lookup_meta(const std::string& label, bool chase) const;

    /*! \brief Header opening block.
     *
     * We check this first so that we can catch malformed
     * files.
     */
    typedef struct {
      uint32_t magic;           //!< \brief Magic number
      uint32_t version;         //!< \brief Version of creator
      uint32_t framesize_lo;    //!< \brief bytes in frame (low)
      uint32_t framesize_hi;    //!< \brief bytes in frame (high)
    } required_header_t;

    //! \brief Header structure within file.
    typedef struct {
      required_header_t required; //!< \brief 4 word mini-header

      uint32_t size_header_block; //!< \brief Size of this header
      uint32_t unused0;         //!< \brief not used in current implementation
      uint32_t irosetta;        //!< \brief 32-bit integer rosetta value.
      float    frosetta;        //!< \brief 32-bit float rosetta

      uint32_t drosetta_lo;     //!< \brief 64-bit float rosetta (low)
      uint32_t drosetta_hi;     //!< \brief 64-bit float rosetta (high)
      uint32_t lrosetta_lo;     //!< \brief 64-bit integer rosetta (low)
      uint32_t lrosetta_hi;     //!< \brief 64-bit integer rosetta (high)

      uint32_t endianism;       //!< \brief Endianism of writer machine.
      uint32_t nlabels;         //!< \brief Number of labeled fields.
      uint32_t size_meta_block; //!< \brief Number of bytes of meta information (padded)
      uint32_t size_typename_block; //!< \brief Number of bytes of typenames (padded)

      uint32_t size_label_block; //!< \brief Number of bytes to store label strings (padded)
      uint32_t size_scalar_block; //!< \brief Number of bytes of scalar storage (padded)
      uint32_t size_field_block_lo; //!< \brief Number of bytes of field storage (padded)
      uint32_t size_field_block_hi; //!< \brief Number of bytes of field storage (padded)

      uint32_t size_crc_block;  //!< \brief Size of the trailing CRC field (unused!)
      uint32_t size_padding_block; //!< \brief Number of ignored bytes to pad to pagesize boundary.
      uint32_t unused1;         //!< \brief Not used in current implementation.
      uint32_t unused2;         //!< \brief Not used in current implementation.

    } header_t;

    /*! \brief Meta structure within file.
     *
     * On disk, we save the information needed to restore the
     * meta table, but we split items into 32 bit chunks that
     * can be stored in network byte order.
     */
    typedef struct {
      uint32_t type;            //!< \brief Typecode for this type.
      uint32_t elementsize;     //!< \brief Number of bytes in an element
      uint32_t count_lo;        //!< \brief Number of elements (low)
      uint32_t count_hi;        //!< \brief Number of elements (high)
    } metadisk_t;


    //! \brief Pointer to the "next" frame in the list, used by
    //         accessor (get/has/list) methods.  Not used by mutator (set/del)
    //         methods.
    //
    // FIXME - const??
    boost::shared_ptr<Frame> m_more_data;

  public:

    //! \brief Frame's magic number
    static const uint32_t s_magic;
    //! \brief Frame's version.
    static const uint32_t s_version;
    //! \brief Frame's rounding blocksize.
    static const uint32_t s_blocksize;
    //! \brief Frame's alignment wordsize.
    static const uint32_t s_alignsize;
    //! \brief A 32 bit integer rosetta to determine endianism.
    static const uint32_t s_irosetta;
    //! \brief A 64 bit integer rosetta to determine endianism (low 32 bits).
    static const uint32_t s_lrosetta_lo;
    //! \brief A 64 bit integer rosetta to determine endianism (high 32 bits).
    static const uint32_t s_lrosetta_hi;
    //! \brief A float for endianism and floating point format.
    static const float s_frosetta;
    //! \brief A double for endianism and floating point format.
    static const double s_drosetta;

    //! \brief Round an integer up to next border'd boundary.
    static uint64_t alignInteger(const uint64_t& x, unsigned border);

  public:

    //! \brief Extract low 32 bits of a 32 bit int.
    static uint32_t lobytes(const uint32_t& x);

    //! \brief Extract high 32 bits of a 32 bit int.
    static uint32_t hibytes(const uint32_t& x);
    
    //! \brief Extract low 32 bits of a 64 bit int.
    static uint32_t lobytes(const uint64_t& x);

    //! \brief Extract high 32 bits of a 64 bit int.
    static uint32_t hibytes(const uint64_t& x);
    
    //! \brief Extract low 32 bits of a 64 bit double.
    static uint32_t lobytes(const double& x);

    //! \brief Extract high 32 bits of a 64 bit double.
    static uint32_t hibytes(const double& x);

    //! \brief Reassemble a 64 bit int from its parts.
    static uint64_t assemble64(uint32_t lo, uint32_t hi);

    //! \brief Reassemble a 64 bit double from its parts.
    static double assembleDouble(uint32_t lo, uint32_t hi);

    //! \brief an empty frame.
    Frame();

    //! \brief Releases frame's hold on data blobs.
    virtual ~Frame();

    //! \brief Add a pointer to a frame with 'more' data
    void set_default_frame(boost::shared_ptr<Frame> more);

    //! \brief Get the pointer to a frame with 'more' data
    boost::shared_ptr<Frame> get_default_frame();

    //! \brief Get the pointer to a frame with 'more' data
    const boost::shared_ptr<Frame> get_default_frame() const;

    //! \brief Set via raw data.
    void set(std::string label, const BaseBlob& blob);
    
    //! \brief Add a scalar to the frame.
    template<class ScalarType>
    inline void set_value(std::string title,const ScalarType& item);

    //! \brief Add a field from iterators.
    template<class Iterator>
    inline void set_values(std::string title,Iterator begin, Iterator end);

    //! \brief Add a field from iterator and size.
    template<class Iterator>
    inline void set_values(std::string title,Iterator begin, size_t count);

    //! \brief Get the typed, raw data .
    BaseBlob get(std::string label, bool chase=true);

    //! \brief Get the typed, raw data .
    const BaseBlob get(std::string label, bool chase=true) const;
    
    //! \brief Get the typed, raw data .
    template<class T>
    inline Blob<T> getv(std::string label, bool chase=true);

    //! \brief Get the typed, raw data .
    template<class T>
    inline const Blob<T> getv(std::string label, bool chase=true) const;
    
    //! \brief Get a scalar value from the frame.
    template<class ScalarType>
    inline void get_value(std::string title,ScalarType& target, bool chase=true) const;

    //! \brief Get a field using iterator and optional size (iterator may just be a pointer).
    template<class value_type, class OutputIterator>
    inline OutputIterator get_values(std::string title,OutputIterator begin, bool chase=true) const;

    //! \brief Remove a field.
    void del(std::string title);

    //! \brief True iff a field exists under this name.
    bool has(std::string title, bool chase=true) const;

    //! \brief True iff the frame has elements of this type.
    bool knowsType(std::string type, bool chase=true) const;

    //! \brief Call result.insert() for each of the known types.
    void types(std::set<std::string> &result, bool chase=true) const;

    //! \brief Call result.insert() for each of the known labels.
    void labels(std::set<std::string> &result, bool chase=true) const;

    //! \brief Endianism of this frame (1234 == Little, 4321 = Big, 3412 = Pdp)
    virtual uint32_t endianism() const;

    //! \brief Endianism of this machine.
    static uint32_t machineEndianism();

    //! \brief True iff frame has same endianism as the current machine.
    bool sameEndianism() const;

    //! \brief Type associated with the named field.
    std::string type(std::string label, bool chase=true) const;

    //! \brief Number of items (0 or more) for the named field.
    uint64_t count(std::string label, bool chase=true) const;

    //! \brief Number of bytes required to store an element of the named field
    uint32_t elementsize(std::string label, bool chase=true) const;

    //! \brief Number of bytes required to store the named field.
    uint64_t nbytes(std::string label, bool chase=true) const;

    //! \brief Number of bytes required to hold the serialization of the frame.
    uint64_t framesize() const;

    //! \brief Bytes that represent the serialization of the frame.
    boost::shared_array<char> bytes() const;

    //! \brief Write the serialization into the specified bytes.
    void serialize(void* data) const;
  };

  /*!
   * This is a convenience function.  It is defined to be *precisely*
   * Blob<ScalarType> data(1);
   * data[0] = item;
   * set(title,data);
   */
  template<class ScalarType>
  inline void Frame::set_value(std::string title,const ScalarType& item) {
    Blob<ScalarType> data(1);
    data[0] = item;
    set(title,data);
  }

  /*!
   * This is a convenience function.  It is defined to create a blob
   * of the appropriate size, to copy elements from begin to end into
   * the blob, and to call set() with the label and that new blob.
   */
  template<class Iterator>
  void Frame::set_values(std::string title,Iterator begin, Iterator end) {
    // Iterator traits must be defined and it must have value_type
    // which will be true for pointers and input_iterators
    typedef typename std::iterator_traits<Iterator>::value_type value_type;

    // Have to support subtraction to get field size
    uint64_t count = static_cast<uint64_t>(end-begin);

    Blob<value_type> data(count);
    uint64_t ii = 0;
    for(Iterator p = begin; p != end; ++p) {
      data[ii++] = *p;
    }

    set(title,data);
  }

  /*!
   * This is a convenience function.  It is defined to be precisely:
   *
   * Blob<value_type> data(count);
   * for(uint64_t ii = 0; ii<count; ++ii) data[ii] = *begin++;
   * set(title,data);
   */
  template<class Iterator>
  void Frame::set_values(std::string title,Iterator begin, size_t count) {
    // Iterator traits must be defined and it must have value_type
    // which will be true for pointers and input_iterators
    typedef typename std::iterator_traits<Iterator>::value_type value_type;

    Blob<value_type> data(count);
    
    for(uint64_t ii = 0; ii<count; ++ii) {
      data[ii] = *begin++;
    }

    set(title,data);
  }

  /*!
   * This convenience function is the partner to set_value.  It is
   * precisely:
   *
   * Blob<ScalarType> data = get(title);
   * if (data.count() != 1) throw Exception(__FILE__,__LINE__,"not a scalar");
   * target = data[0];
   */
  template<class ScalarType>
  void Frame::get_value(std::string title,ScalarType& target, bool chase) const  {
    Blob<ScalarType> data = get(title, chase);
    if (data.count() != 1) throw ::frameset::FrameSetException(title + " is not a scalar");
    target = data[0];
  }

  /*!
   * This convenience function is trickier to define concisely.  The
   * issue is that output iterators are not required to define their
   * value_type as is the case for pointers and input iterators.
   * The first implication of this is that one is required to supply
   * the value_type at the call site,
   *    fp->get_values<uint32_t>("FOO",oiter)
   * I think I can probably get around this eventually so that
   * well formed iterators can avoid respecifying it, but it likely
   * documents the use better, so we may just leave it in place.
   */
  template<class value_type, class OutputIterator>
  OutputIterator Frame::get_values(std::string title,OutputIterator begin, bool chase) const  {
    Blob<value_type> data = get(title, chase);

    // Use faster STL copy in lieu of explicit loop
    return std::copy(data.begin(),data.end(),begin);
  }


  /*!
   * We provide getv<T>() to do a get and return an appropriately
   * typed Blob<T> object.  It allows you to create operation
   * chains:
   *    f->getv<char>("TITLE").begin(); // This works...
   *    f->get("TITLE").begin();        // This does not since
   *                                    // BaseBlob has no begin()
   */
  template<class T>
  Blob<T> Frame::getv(std::string label, bool chase) {
    return get(label, chase);
  }

  /*!
   * We provide getv<T>() to do a get and return an appropriately
   * typed Blob<T> object.  It allows you to create operation
   * chains:
   *    f->getv<char>("TITLE").begin(); // This works...
   *    f->get("TITLE").begin();        // This does not since
   *                                    // BaseBlob has no begin()
   */
  template<class T>
  const Blob<T> Frame::getv(std::string label, bool chase) const {
    return get(label, chase);
  }
}

#endif
