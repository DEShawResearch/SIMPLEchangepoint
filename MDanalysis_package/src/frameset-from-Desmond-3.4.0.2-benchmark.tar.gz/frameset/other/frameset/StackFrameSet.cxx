/* 
Copyright 2012-2014, D. E. Shaw Research.
All rights reserved.

Redistribution and use in source and binary forms, with or without
modification, are permitted provided that the following conditions are
met:

* Redistributions of source code must retain the above copyright
  notice, this list of conditions, and the following disclaimer.

* Redistributions in binary form must reproduce the above copyright
  notice, this list of conditions, and the following disclaimer in the
  documentation and/or other materials provided with the distribution.

* Neither the name of D. E. Shaw Research nor the names of its
  contributors may be used to endorse or promote products derived from
  this software without specific prior written permission.

THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
"AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR
A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT
OWNER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,
SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT
LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE,
DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY
THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
(INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE
OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
*/

#include "FrameSet/StackFrameSet.hxx"
#include "FrameSet/FrameSetExceptions.hxx"

#include <list>

#include <sys/types.h>
#include <cstring>

#include <boost/filesystem.hpp>
namespace bfs = boost::filesystem;

namespace frameset {
  /*!
   * 
   */
  StackFrameSet::StackFrameSet(const std::string& base)
    : FrameSetReader(base)
  {
  }

  /*!
   * 
   */
  StackFrameSet::~StackFrameSet() {
  }

  /*!
   * 
   */
  FrameSetReader::FramePtr StackFrameSet::at(size_t index) const {
    // -----------------------------------------------
    // Create a new frame and catenate the contents
    // from all matching labels
    // -----------------------------------------------
    FramePtr result(new Frame);
    Frame& frame = *result;

    FramePtr frame_0 = FrameSetReader::at(index);
    std::set<std::string> labels;
    frame_0->labels(labels);
    for(std::set<std::string>::iterator p = labels.begin();
        p != labels.end(); ++p) {
      BaseBlob field_0 = frame_0->get(*p);
      std::string type = field_0.type();
      size_t elementsize = field_0.elementsize();

      // -----------------------------------------------
      // Start with a copy of field_0's data
      // -----------------------------------------------
      BaseBlob merged(type,field_0.count(),field_0.elementsize(),
                      field_0.data());

      for(std::vector<boost::shared_ptr<FrameSetReader> >::const_iterator q = m_stackers.begin();
          q != m_stackers.end(); ++q) {
        FramePtr frame_n = (*q)->at(index);

        if (frame_n->has(*p)) {
          // -----------------------------------------------
          // Make sure field_n conforms to field_0
          // -----------------------------------------------
          BaseBlob field_n = frame_n->get(*p);
          std::string type_n = field_n.type();
          size_t elementsize_n = field_n.elementsize();
          if (type_n != type || elementsize_n != elementsize) {
            throw FrameSetException("heterogeneous types in Stack",DESSERT_LOC);  /* GCOV-IGNORE */
          }

          // -----------------------------------------------
          // Resize the field to hold combined field
          // -----------------------------------------------
          uint64_t offset = merged.nbytes();
          merged.resize(merged.count()+field_n.count());
          ::memcpy(merged.data().get()+offset,
                   field_n.data().get(),field_n.nbytes());
        }
        
      }

      // -----------------------------------------------
      // Set the merged field into the result frame
      // -----------------------------------------------
      frame.set(*p,merged);
    }
    return result;
  }

  /*!
   * 
   */
  void StackFrameSet::overlay(const boost::shared_ptr<FrameSetReader>& part) {
    m_stackers.push_back(part);
  }

  /*!
   * Starting with a pattern like foo.dir/parts_*, create
   * a stacked frameset from the sub framesets found.
   * The argument is just a prefix
   */
  StackFrameSet* StackFrameSet::fromcollection(const std::string& directory,
                                               const std::string& prefix) {
    std::list<std::string> sorted;
    const char SEP = '/';

    // -----------------------------------------------
    // Select those files in the directory that start with pattern
    // We need to sort to insure that frame 0 comes first since
    // it has some extra information (the title, etc...)
    // Since the list is pretty small, we just use insertion
    // sort.
    // -----------------------------------------------

    // -----------------------------------------------
    // Grab entries that start with prefix
    // -----------------------------------------------
    for ( bfs::directory_iterator itr(directory); itr != bfs::directory_iterator(); ++itr ) {
      std::string entry = itr->path().filename().string();
      if (entry.size() >= prefix.size() &&
          entry.substr(0,prefix.size()) == prefix) {
        std::list<std::string>::iterator p = sorted.begin();
        while(p != sorted.end() && *p < entry) ++p;
        sorted.insert(p,entry);
      }
    }
    if (sorted.begin() == sorted.end()) return NULL;

    // -----------------------------------------------
    // Take the sorted list and create the base and
    // overlay the remaining files.
    // -----------------------------------------------
    std::list<std::string>::iterator p = sorted.begin();
    StackFrameSet* frameset = new StackFrameSet(directory + SEP + *p);
    for(++p; p != sorted.end(); ++p) {
      try {
        boost::shared_ptr<FrameSetReader> part
          (new FrameSetReader(directory + SEP + *p));
        frameset->overlay(part);
      } catch (...) {  /* GCOV-IGNORE */
        delete frameset;  /* GCOV-IGNORE */
        throw;  /* GCOV-IGNORE */
      }
    }
    return frameset;
  }


}
