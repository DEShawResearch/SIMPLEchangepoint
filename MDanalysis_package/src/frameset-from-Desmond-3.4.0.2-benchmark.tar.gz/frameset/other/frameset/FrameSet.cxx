/* 
Copyright 2012-2014, D. E. Shaw Research.
All rights reserved.

Redistribution and use in source and binary forms, with or without
modification, are permitted provided that the following conditions are
met:

* Redistributions of source code must retain the above copyright
  notice, this list of conditions, and the following disclaimer.

* Redistributions in binary form must reproduce the above copyright
  notice, this list of conditions, and the following disclaimer in the
  documentation and/or other materials provided with the distribution.

* Neither the name of D. E. Shaw Research nor the names of its
  contributors may be used to endorse or promote products derived from
  this software without specific prior written permission.

THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
"AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR
A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT
OWNER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,
SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT
LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE,
DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY
THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
(INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE
OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
*/

#include "FrameSet/FrameSet.hxx"
#include "FrameSet/ReaderFrame.hxx"
#include "FrameSet/FrameSetExceptions.hxx"

#include "DeepDir/DeepDir.hpp"

#include <sstream>
#include <iomanip>

#include <cerrno>
#ifdef DESRES_OS_Windows
#else
#include <sys/types.h>
#include <dirent.h>
#define O_BINARY 0
#endif

#include <boost/filesystem.hpp>
namespace bfs = boost::filesystem;

#include <sys/types.h>
#include <sys/stat.h>
#include <fcntl.h>

static const char sep = '/';

#include <iostream>
using std::cout;
using std::endl;

namespace frameset {

  /*!
   * This machine's filename separator character.
   */
    const char FrameSet::s_sep = sep;

  class CharStarContainer : public ReaderFrame::ContainerBase {
    boost::shared_ptr<char> m_data;
    size_t m_size;
  public:
    CharStarContainer(size_t size) : m_data(new char[size]),m_size(size) {}
    virtual ~CharStarContainer() {}

    virtual size_t size() const { return m_size; }
    virtual char* data() { return m_data.get(); }
    virtual const char* data() const { return m_data.get(); }
  };
    
  FrameSet::FramePtr FrameSet::directFrameAccess(const std::string& directory,
                                                 int ndir1,int ndir2,
                                                 size_t frames_per_file,
                                                 size_t frameno,
                                                 size_t frame_offset,
                                                 size_t frame_size) {
    if (!directory.size()) throw FrameSetException("no directory specified for directFrameAccess",DESSERT_LOC);


    // ------------------------------------------------------------------------
    // Now we have to predict the frame entry
    // ------------------------------------------------------------------------
    size_t framefile = frameno/frames_per_file;
    std::ostringstream filename;
    filename << "frame" << std::setfill('0') << std::setw(9) << framefile;
    std::string framepath = ::DDfullpath(directory,filename.str(),ndir1,ndir2);

    // ------------------------------------------------------------------------
    // Open the file and read the requested bytes
    // ------------------------------------------------------------------------
    int fd = ::open(framepath.c_str(),O_RDONLY|O_BINARY);
    if (fd < 0) throw IoErrnoException(framepath,DESSERT_LOC);


    boost::shared_ptr<CharStarContainer> data(new CharStarContainer(frame_size));
    int status = nointr_read(fd,data.get()->data(),frame_size);
    ::close(fd);
    if ( status < 0 ) throw IoErrnoException(framepath,DESSERT_LOC);

    FramePtr result(new ReaderFrame(data));

    // ------------------------------------------------------------------------
    // Now, append the metaframe (if it exists)
    // ------------------------------------------------------------------------
    std::string metadata_file(directory);
    if (metadata_file[metadata_file.size()-1] != sep) metadata_file += sep; // Make sure it ends with a seperator
    metadata_file += "metadata";
    struct stat statbuf;
    FramePtr meta;
    if (::stat(metadata_file.c_str(),&statbuf) == 0) {
      meta = FramePtr(new ReaderFrame(metadata_file));
      result->set_default_frame(meta);
    }

    return result;
  }


  /*!
   * We are going forward with one frame per file, but this will
   * help document where we make assumptions about it.
   */
  //const size_t FrameSet::s_frames_per_file = 1;

  /*!
   * Magic number that spells DESK (DE Shaw Key) in network
   * byte order at the head of key files.
   */
  const uint32_t FrameSet::s_magic_timekey = 0x4445534b;

  /*!
   * Read a file and deal with interrupts that report an
   * EINTR in errno.
   */
  ssize_t FrameSet::nointr_read(int fd, void* v, size_t count) {
    char* buffer = reinterpret_cast<char*>(v);
    ssize_t bytes_read = 0;
    while(bytes_read < count) {
      ssize_t n = ::read(fd,buffer+bytes_read,count-bytes_read);
      if (n == 0) return bytes_read;
      if (n < 0) {
        if (errno == EINTR) continue;
        return n;
      }
      bytes_read += n;
    }
    return bytes_read;
  }

  /*!
   * Writes can be interrupted by signals too.  If it happens,
   * we just restart the write.
   */
  ssize_t FrameSet::nointr_write(int fd, const void* v, size_t count) {
    const size_t original_count = count;
    const char * buf = reinterpret_cast<const char *>(v);
    while (count) {
      ssize_t n = ::write(fd, buf, count);
      if (n<0) {
          if (errno==EINTR) continue;
          return n;
      }
      buf += n;
      count -= n;
    }
    return original_count;
  }

  /*!
   * Fsync a file, handling interruptions
   */
  int FrameSet::nointr_fsync(int fd) {
      int ret;
      do {
          ret = ::fsync(fd);
          if (ret == 0) break;
      } while (errno == EINTR);
      return ret;
  }

  /*!
   * Path to toplevel keyfile
   */
  std::string FrameSet::keyfile() const {
    return m_directory + s_sep + "timekeys";
  }



  /*!
   * Create/test existance of the underlying directory depending
   * on mode.  We use the DeepDir parameters ndir1,ndir2 to
   * set the depth of nesting of subdirectories that will hold
   * the frame files.  The default of 0 will cause FrameSet
   * to build all frames directly under the main directory.
   */
  FrameSet::FrameSet(std::string directory, std::string mode,
                     int ndir1,int ndir2,size_t frames_per_file)
    : m_directory(directory),
      m_nframes(0),
      m_ndir1(ndir1),
      m_ndir2(ndir2),
      m_frames_per_file(frames_per_file),
      m_mode(mode),
      m_flush_meta(true)
  {
    struct stat statbuf;

    // -----------------------------------------------
    // Canonicalize the directory name by removing
    // trailing separators
    // -----------------------------------------------
    while(m_directory.size() > 0 && m_directory[m_directory.size()-1] == s_sep) {
      m_directory.erase(m_directory.size()-1);
    }

    // -----------------------------------------------
    // The ``blank'' FrameSet doesn't set up a directory
    // -----------------------------------------------
    if (m_directory.size() == 0) return;

    // Don't allow 0 for fpf, that will cause divide by zero
    if (m_frames_per_file == 0) m_frames_per_file = 1;

    // -----------------------------------------------
    // Convert the pathname to an absolute name.  This
    // will protect us if the user changes the
    // working directory during execution.
    // -----------------------------------------------
    if ( m_directory[0] != s_sep) {
      m_directory = bfs::system_complete(m_directory).string();
    }

    // -----------------------------------------------
    // For read, the directory must already exist
    // and be a real directory (if a symlink, then
    // the symlink must point to a directory).
    // -----------------------------------------------
    if (mode.size() == 0) {
      throw FrameSetException("invalid mode",DESSERT_LOC);
    } else if (mode[0] == 'r') {
      if (::stat(m_directory.c_str(),&statbuf) != 0) {
        throw IoErrnoException(m_directory,DESSERT_LOC);
      }
      if (! is_directory(m_directory) ) {
        throw FrameSetException(m_directory + " not a directory",DESSERT_LOC);
      }

      DDgetparams(m_directory,&m_ndir1,&m_ndir2);
    }

    // -----------------------------------------------
    // For append, we create it if it doesn't exist.
    // If it does exist, it must be a directory (or a
    // link to a subdirectory.
    // -----------------------------------------------
    else if (mode[0] == 'a') {
      if (::stat(m_directory.c_str(),&statbuf) != 0) {
        try {
          ::DDmkdir(m_directory,NULL,0777,m_ndir1,m_ndir2);
        } catch(...) {
          throw IoErrnoException(m_directory,DESSERT_LOC);
        }

      } else if (! is_directory(m_directory) ) {
        throw FrameSetException(m_directory + " not a directory",DESSERT_LOC);
      }
      DDgetparams(m_directory,&m_ndir1,&m_ndir2);
    }

    // -----------------------------------------------
    // For write, remove any prior file in the way
    // before creating the directory.
    // -----------------------------------------------
    else if (mode[0] == 'w') {
      if (mode.size() > 1 && mode[1] == '!') recursivelyRemove(m_directory);
      try {
        ::DDmkdir(m_directory,NULL,0777,m_ndir1,m_ndir2);
      } catch(...) {
        throw IoErrnoException(m_directory,DESSERT_LOC);
      }
    }


    // ------------------------------------------------------------------------
    // If we open in "virtual" mode, the new constructor will add the
    // deepdir info
    // ------------------------------------------------------------------------
    else if (mode[0] = 'v') {
    }

    // -----------------------------------------------
    // otherwise, its an illegal mode
    // -----------------------------------------------
    else {
      throw FrameSetException("invalid mode",DESSERT_LOC);
    }


    // -----------------------------------------------
    // Open the metaframe (or create an empty frame if
    // there is no metaframe).
    // -----------------------------------------------
    if ( mode[0] == 'v' ) {
      m_meta = FramePtr(new Frame());
    } else {
      std::string metadata_file = subfile("metadata");
      if (::stat(metadata_file.c_str(),&statbuf) == 0) {
        m_meta = FramePtr(new ReaderFrame(metadata_file));
      } else {
        m_meta = FramePtr(new Frame());
      }
    }
  }

  /*!
   * Boring destructor.
   */
  FrameSet::~FrameSet() {
    flush_meta();
  }

  /*!
   * Write out this frameset's metaframe to disk
   */
  void FrameSet::flush_meta() const {
      if (m_mode != "r" && m_flush_meta) {
          boost::shared_array<char> bytes = m_meta->bytes();
          flush_serialized_meta(bytes.get(), m_meta->framesize());
      }
  }

  /*!
   * Write out serialized metaframe
   */
  void FrameSet::flush_serialized_meta(const void *buf, size_t len) const {
    int fd = -1;
    if (!buf) {
        throw FrameSetException("Empty meta buffer", DESSERT_LOC);
    }
    try {
      if (m_mode != "r") {
        std::string metadata_file = subfile("metadata");
        std::string metadata_bu = subfile("metadata.bu");
        std::string metadata_temp = subfile("metadata.tmp");

        // Write into temp file
        fd = ::open(metadata_temp.c_str(),O_CREAT|O_WRONLY|O_TRUNC|O_BINARY,0666);
        if (fd < 0) throw IoErrnoException("open:" + metadata_temp,DESSERT_LOC);

        if (nointr_write(fd, buf, len) < 0) {
          throw IoErrnoException("nointr_write: " + metadata_temp,DESSERT_LOC);
        }
        if (nointr_fsync(fd) != 0 || close(fd) != 0) {
          throw IoErrnoException(metadata_file,DESSERT_LOC);
        }
        fd = -1;

        // Rename metadata file (keeps alive the mmap)
        // Note that old framesets do not require a metadata, so we ignore errors here
        ::unlink(metadata_bu.c_str());
        ::rename(metadata_file.c_str(),metadata_bu.c_str());
        if (::rename(metadata_temp.c_str(),metadata_file.c_str()) < 0) {
          throw IoErrnoException("mv "+metadata_temp+" "+metadata_file,
                                 DESSERT_LOC);
        }

      }
    } catch(...) { /* GCOV-IGNORE */
      if (fd >= 0) close(fd); /* GCOV-IGNORE */
      throw; /* GCOV-IGNORE */
    }
  }

  FrameSet::FramePtr FrameSet::meta() const {
    return m_meta;
  }

  /*!
   * Recover the initial directory name.  Perhaps
   */
  const std::string& FrameSet::name() const {
    if (m_directory.size() == 0) {
      throw FrameSetException("uninitialized FrameSet");
    }
    return m_directory;
  }

  /*!
   * Map a subfile into the directory space
   */
  std::string FrameSet::hierarchicalName(std::string path) const {
    if (m_directory.size() == 0) {
      throw FrameSetException("uninitialized FrameSet");
    }

    //return m_directory + s_sep + path;
    return ::DDfullpath(m_directory,path,m_ndir1,m_ndir2);
  }

  /*!
   * Map a subfile into the directory space
   */
  std::string FrameSet::subfile(std::string path) const {
    if (m_directory.size() == 0) {
      throw FrameSetException("uninitialized FrameSet");
    }

    return m_directory + s_sep + path;
  }

  /*!
   * Return the filename containing the indicated frame.
   */
  std::string FrameSet::framefile(size_t frameno) const {
    // -----------------------------------------------
    // With one frame per file, the frame number is
    // the file number.
    // -----------------------------------------------
    unsigned int frame_file = frameno / m_frames_per_file;

    std::ostringstream filename;
    filename << "frame" << std::setfill('0') << std::setw(9) 
             << frame_file;
    return hierarchicalName(filename.str());
  }

  /*!
   * Number of frames held by this frameset.
   */
  size_t FrameSet::size() const {
    return m_nframes;
  }

  /*!
   * Remove a file or directory.  For directories,
   * we recurse through subfiles and remove those
   * before attempting the ::rmdir();
   */
  void FrameSet::recursivelyRemove(std::string path) {
#if !defined(DESRES_OS_Windows)
    {
      bfs::path ap(path);
      if ( ! ap.has_root_directory() ) ap = bfs::current_path()/ap;
      // Wake up the disk ...
      DIR* dp = ::opendir(bfs::absolute(ap).parent_path().c_str());
      if ( dp ) {
	::closedir(dp);
      }
    }
#endif
    if ( bfs::exists(path) ) {
      if ( bfs::is_directory(path) ) {
	bfs::remove_all(path);
      } else {
	bfs::remove(path);
      }
    }
  }


  bool exists(const std::string &path) {
    return bfs::exists(path);
  }

  bool is_regular(const std::string &path) {
    return bfs::is_regular_file(path);
  }

  bool is_directory(const std::string &path) {
    return bfs::is_directory(path);
  }
  
  /*!
   * Number of frames held by this frameset.
   */
  size_t FrameSet::nframes() const {
    return m_nframes;
  }

  int FrameSet::ndir1() const { return m_ndir1; }
  int FrameSet::ndir2() const { return m_ndir2; }
  size_t FrameSet::frames_per_file() const { return m_frames_per_file; }
  std::string FrameSet::mode() const { return m_mode; }

}
