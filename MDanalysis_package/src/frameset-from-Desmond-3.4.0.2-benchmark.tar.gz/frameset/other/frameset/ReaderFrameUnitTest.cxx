/* 
Copyright 2012-2014, D. E. Shaw Research.
All rights reserved.

Redistribution and use in source and binary forms, with or without
modification, are permitted provided that the following conditions are
met:

* Redistributions of source code must retain the above copyright
  notice, this list of conditions, and the following disclaimer.

* Redistributions in binary form must reproduce the above copyright
  notice, this list of conditions, and the following disclaimer in the
  documentation and/or other materials provided with the distribution.

* Neither the name of D. E. Shaw Research nor the names of its
  contributors may be used to endorse or promote products derived from
  this software without specific prior written permission.

THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
"AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR
A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT
OWNER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,
SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT
LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE,
DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY
THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
(INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE
OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
*/

#include "FrameSet/FrameSetWriter.hxx"
#include "FrameSet/FrameSetReader.hxx"
#include "FrameSet/ReaderFrame.hxx"
#include "UnitTestCommon.hxx"

#include <iostream>
#include <cstring>

//! \brief Used to create frames from fixed strings
class TestStringContainer: public frameset::ReaderFrame::ContainerBase {
  size_t m_size;
  char* m_data;
public:
  //! \brief Make container from string
  TestStringContainer(std::string string)
    : m_size(0),
      m_data(NULL)
  {
    m_size = string.size();
    m_data = new char[m_size];
    memcpy(m_data,string.c_str(),m_size);
  }

  //! \brief Virtual destructor
  virtual ~TestStringContainer() {
  }

  //! \brief number of characters in string
  virtual size_t size() const {
    return m_size;
  }
  
  //! \brief raw data pointer
  virtual char* data() {
    return m_data;
  }

  //! \brief raw data pointer
  virtual const char* data() const {
    return m_data;
  }

};

//! \brief Test class
class IgnoreProtection : public frameset::ReaderFrame {
public:
  //! \brief TBD
  static void test_protected() {
    Container c;
    const Container& const_c = c;
    c.data();
    const_c.data();
  }
};

//! \brief Mini header for frame... enough to check version and size
typedef struct {
  uint32_t magic;           //!< \brief Magic number
  uint32_t version;         //!< \brief Version of creator
  uint32_t framesize_lo;    //!< \brief bytes in frame (low)
  uint32_t framesize_hi;    //!< \brief bytes in frame (high)
} required_header_t;

//! \brief Frame header block
typedef struct {
  required_header_t required; //!< \brief 4 word mini-header

  uint32_t size_header_block; //!< \brief Size of this header
  uint32_t unused0;         //!< \brief not used in current implementation
  uint32_t irosetta;        //!< \brief 32-bit integer rosetta value.
  float    frosetta;        //!< \brief 32-bit float rosetta

  uint32_t drosetta_lo;     //!< \brief 64-bit float rosetta (low)
  uint32_t drosetta_hi;     //!< \brief 64-bit float rosetta (high)
  uint32_t lrosetta_lo;     //!< \brief 64-bit integer rosetta (low)
  uint32_t lrosetta_hi;     //!< \brief 64-bit integer rosetta (high)

  uint32_t endianism;       //!< \brief Endianism of writer machine.
  uint32_t nlabels;         //!< \brief Number of labeled fields.
  uint32_t size_meta_block; //!< \brief Number of bytes of meta information (padded)
  uint32_t size_typename_block; //!< \brief Number of bytes of typenames (padded)

  uint32_t size_label_block; //!< \brief Number of bytes to store label strings (padded)
  uint32_t size_scalar_block; //!< \brief Number of bytes of scalar storage (padded)
  uint32_t size_field_block_lo; //!< \brief Number of bytes of field storage (padded)
  uint32_t size_field_block_hi; //!< \brief Number of bytes of field storage (padded)

  uint32_t size_crc_block;  //!< \brief Size of the trailing CRC field (unused!)
  uint32_t size_padding_block; //!< \brief Number of ignored bytes to pad to pagesize boundary.
  uint32_t unused1;         //!< \brief Not used in current implementation.
  uint32_t unused2;         //!< \brief Not used in current implementation.

} header_t;

static void create_bad_frame(const std::string& s, const std::string& msg) {
  boost::shared_ptr<TestStringContainer> badframe(new TestStringContainer(s));

  try {
    frameset::ReaderFrame frame(badframe);
    frame.framesize();
  } catch(const frameset::FrameSetException& e) {
    std::string context = e.what();
    if (context.find(msg) == std::string::npos) throw;
  }
}

int main(void) {
  // Coverage
  IgnoreProtection::test_protected();

  // Create a frame from a string that is too short
  create_bad_frame("",
                   "file too short to hold required header");

  // Create a frame with a bad magic number
  create_bad_frame("this has no magic number",
                   "invalid magic number");

  // Create a frame big enough to hold a good magic number,
  // bad version and sizes, but otherwise truncated
  create_bad_frame("DESM................",
                   "truncated frame");

  // Same, but with frame size of zero
  create_bad_frame(std::string("DESM....\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0",16),
                   "invalid framesize");

  return 0;
}

