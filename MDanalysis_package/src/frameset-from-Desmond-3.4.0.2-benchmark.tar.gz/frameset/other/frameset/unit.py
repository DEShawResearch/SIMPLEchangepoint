#!/usr/bin/env python
# Copyright D. E. Shaw Research, 2004-2012.

import sys, os
sys.path.insert(0, '%s/../lib/python' % os.path.dirname(__file__))

import shutil
import unittest
import framesettools as FS

class FlushMetaTest(unittest.TestCase):
    def setUp(self):
        self.path='foobar.fs'
        self.trj = FS.FrameSet(self.path, 'w', frames_per_file=32)
        
    def tearDown(self):
        shutil.rmtree(self.path, ignore_errors=True)

    def test_flush_meta(self):
        self.assertFalse(os.path.isfile(os.path.join(self.path, 'metadata')))
        self.trj.flush_meta()
        # Note that we need to be sure the destructor files before we execute
        # tearDown, since otherwise the destructor will throw an exception 
        # when it tries to flush the metadata frame and finds that the 
        # directory structure has been torn down.
        del self.trj
        self.assertTrue(os.path.isfile(os.path.join(self.path, 'metadata')))

    def test_flush_meta2(self):
        self.trj.push_back(FS.Frame(), 0.0)
        self.test_flush_meta()

class ContextManagerTest(unittest.TestCase):
    def setUp(self):
        self.path='a.dtr'

    def assertHasFile(self, name):
        self.assertTrue(os.path.isfile(os.path.join(self.path, name)))

    def tearDown(self):
        shutil.rmtree(self.path, ignore_errors=True)

    def test1(self):
        with FS.FrameSet(self.path, 'w!', frames_per_file=32) as trj: pass
        self.assertHasFile('timekeys')
        self.assertHasFile('metadata')

    def test2(self):
        with FS.FrameSet(self.path, 'w!', frames_per_file=32) as trj:
            trj.push_back(FS.Frame(), 0.0)
            trj.push_back(FS.Frame(), 1.0)
        self.assertHasFile('timekeys')
        self.assertHasFile('metadata')
        self.assertHasFile('frame000000000')

    def test_exception_handling(self):
        with self.assertRaises(RuntimeError):
            with FS.FrameSet(self.path, 'w!', frames_per_file=32) as trj:
                trj.push_back(FS.Frame(), 0.0)
                trj.push_back(FS.Frame(), 0.0)
        self.assertHasFile('timekeys')
        self.assertHasFile('metadata')
        self.assertHasFile('frame000000000')

    def test_exception_handling2(self):
        with self.assertRaises(RuntimeError):
            with FS.FrameSet(self.path, 'w!', frames_per_file=32) as trj:
                raise RuntimeError
        self.assertHasFile('timekeys')
        self.assertHasFile('metadata')

    def test3(self):
        trj=FS.FrameSet(self.path, 'w!', frames_per_file=32)
        with trj: pass
        self.assertHasFile('metadata')

class NullTest(unittest.TestCase):
    def setUp(self):
        self.path='c.dtr'
        with FS.FrameSet(self.path, 'w!') as self.trj: pass

    def tearDown(self):
        shutil.rmtree(self.path, ignore_errors=True)

    def testClose(self):
        self.trj.close()
        self.trj.close()
        self.trj.close()

    def testNull(self): 

        # ok to get name
        #with self.assertRaises(RuntimeError): self.trj.name
        self.trj.name
        with self.assertRaises(RuntimeError): self.trj.size
        with self.assertRaises(RuntimeError): self.trj.nframes
        with self.assertRaises(RuntimeError): self.trj.ndir1
        with self.assertRaises(RuntimeError): self.trj.ndir2
        with self.assertRaises(RuntimeError): self.trj.frames_per_file
        with self.assertRaises(RuntimeError): self.trj.hierarchicalName('foo')
        with self.assertRaises(RuntimeError): self.trj.framefile(32)
        with self.assertRaises(RuntimeError): self.trj.frameinfo(64)
        with self.assertRaises(RuntimeError): self.trj.flush_meta()
        with self.assertRaises(RuntimeError): self.trj.flush_keyfile()
        with self.assertRaises(RuntimeError): self.trj.flush_framefile()
        with self.assertRaises(RuntimeError): self.trj.fileinfo(16)
        with self.assertRaises(RuntimeError): self.trj.metainfo()
        with self.assertRaises(RuntimeError): self.trj.time()
        with self.assertRaises(RuntimeError): len(self.trj)
        with self.assertRaises(RuntimeError): self.trj.meta()
        with self.assertRaises(RuntimeError): self.trj.append(FS.Frame(),0)
        
        with self.assertRaises(RuntimeError): self.trj.le(1)
        with self.assertRaises(RuntimeError): self.trj.ge(1)
        with self.assertRaises(RuntimeError): self.trj.lt(1)
        with self.assertRaises(RuntimeError): self.trj.gt(1)
        with self.assertRaises(RuntimeError): self.trj.nearest(1)

        with self.assertRaises(RuntimeError):
            with self.trj: pass

        with self.assertRaises(RuntimeError): 
            for f in self.trj:
                pass

class NullTest2(unittest.TestCase):
    def setUp(self):
        self.path='c.dtr'
    def test1(self):
        with FS.FrameSet(self.path, 'w!') as self.trj:
            self.trj.push_back(FS.Frame(), 0.0)
            it=self.trj.__iter__()
        with self.assertRaises(RuntimeError):
            it.next()

    def test2(self):
        trj=FS.FrameSet(self.path, 'w!')
        self.assertEqual(self.path, trj.name)
        self.assertFalse(trj.closed)
        trj.close()
        self.assertTrue(trj.closed)
        self.assertEqual(self.path, trj.name)

    def tearDown(self):
        shutil.rmtree(self.path, ignore_errors=True)


def run_tests(): 
    unittest.main()

if __name__=="__main__": 
    run_tests()

