/* 
Copyright 2012-2014, D. E. Shaw Research.
All rights reserved.

Redistribution and use in source and binary forms, with or without
modification, are permitted provided that the following conditions are
met:

* Redistributions of source code must retain the above copyright
  notice, this list of conditions, and the following disclaimer.

* Redistributions in binary form must reproduce the above copyright
  notice, this list of conditions, and the following disclaimer in the
  documentation and/or other materials provided with the distribution.

* Neither the name of D. E. Shaw Research nor the names of its
  contributors may be used to endorse or promote products derived from
  this software without specific prior written permission.

THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
"AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR
A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT
OWNER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,
SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT
LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE,
DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY
THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
(INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE
OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
*/

// NOTE:  Cannot use ::ntohl or ::htonl since under optimization
// they are turned into efficient macros

#include "FrameSet/ReaderFrame.hxx"

#include <iomanip>

#include <iostream> // TODO: remove
using std::cout;
using std::endl;

#include <cerrno>
#include <cstring>
#ifdef DESRES_OS_Windows
#include <Windows.h>
#include <fcntl.h>
#else
#include <netinet/in.h>
#include <sys/fcntl.h>
#define O_BINARY 0
#endif
#include <sys/types.h>
#include <sys/stat.h>

/*! \brief a boost::shared_ptr<> keepalive class
 * 
 * This is an adaptor class that allows boost::share_xxxx to hold an
 * object alive so long as the boost object is alive.
 *
 * TODO: Refactor this keepalive out of this implementation and
 * merge with smart_pointer_deleter<> class.
 *
 * TODO: Why is it that I get a double delete if I add delete
 * in the destructor?
 */
template<class P> struct keep_alive {
private:
  //! \brief Pointer to co-structure.
  const P* m_p;
public:
  //! \brief Keeps smart pointer p alive.
  keep_alive(const P & p) { m_p = new P(p); }
  //! \brief Called when its time to delete p's container.
  void operator()(void const *) {try{delete m_p; m_p = 0;} catch (...) {}}
};

// -----------------------------------------------
// On unix, we mmap.  On windoze, we just read
// -----------------------------------------------
#ifndef WIN32
#include <sys/mman.h>
#else
#define PROT_READ (0)
#define PROT_WRITE (0)
#define MAP_PRIVATE (0)
#define MAP_FAILED ((void*)-1)
static void* mmap(void *start, size_t length, int prot , int flags, int fd, off_t offset) {
  ::_lseek(fd,offset,SEEK_SET);
  start = ::malloc(length);
  // TODO: interrupting read problem
  ::read(fd,reinterpret_cast<char*>(start),length);
  return start;
}

static int munmap(void *start, size_t length) {
  ::free(start);
  return 0;
}
#endif

namespace frameset {
  
  /*!
   * Nothing to destroy in base class
   */
  ReaderFrame::ContainerBase::~ContainerBase() {
  }

  /*!
   * A blank mapping container.
   */
  ReaderFrame::Container::Container()
    : m_fd(-1),
      m_mapping(NULL),
      m_size(0)
  {
  }

  /*!
   * A mapping container that will map in filesize bytes of file
   * filename starting at offset.  If the filesize is negative,
   * we will use the real filesize as a guide to how much to map
   * in.  On windows, a stub for mmap actually reads the data
   * into a buffer.
   */
  ReaderFrame::Container::Container(std::string filename, off_t offset,size_t filesize) 
    : m_fd(-1),
      m_mapping(NULL),
      m_size(filesize)
  {
    m_fd = ::open(filename.c_str(),O_RDONLY|O_BINARY);
    if (m_fd.file() < 0) {
      throw FrameSetException(filename + ": " + ::strerror(errno)); /* GCOV-IGNORE */
    }

    struct stat statbuf;
    if (::fstat(m_fd.file(),&statbuf) < 0) {
      throw FrameSetException(filename + ": " + strerror(errno),DESSERT_LOC);  /* GCOV-IGNORE */
    }

    // ------------------------------------------------------------------------
    // If we don't specify a size, just use the fstat size.  If we do, make sure
    // that it falls into the fstat size.
    // ------------------------------------------------------------------------
    if (m_size == 0) {
      m_size = statbuf.st_size - offset;
    } else if ( statbuf.st_size < (offset+filesize)) {
      throw FrameSetException(filename + ": file was truncated",DESSERT_LOC);  /* GCOV-IGNORE */
    }

    // -----------------------------------------------
    // Map the file into our process space
    // -----------------------------------------------
    m_mapping = ::mmap(0,m_size,PROT_READ|PROT_WRITE,MAP_PRIVATE,m_fd.file(),offset);
    if (m_mapping == MAP_FAILED) {
      throw FrameSetException(filename + ": " + strerror(errno),DESSERT_LOC);  /* GCOV-IGNORE */
    }
  }

  /*!
   * When we destroy a mmap container, we must unmap the data
   * and close the file descriptor.
   */
  ReaderFrame::Container::~Container() {
    // unmap before closing file
    if (m_mapping) {
      ::munmap(m_mapping,m_size);
      m_mapping = NULL;
    }
  }

  /*!
   * Number of bytes maintained by the map container.
   */
  size_t ReaderFrame::Container::size() const {
    return m_size;
  }

  /*!
   * Pointer to the raw data held by the map container.
   */
  char* ReaderFrame::Container::data() {
    return reinterpret_cast<char*>(m_mapping);
  }

  /*!
   * Pointer to the raw data held by the map container.
   */
  const char* ReaderFrame::Container::data() const {
    return reinterpret_cast<const char*>(m_mapping);
  }

  /*!
   * Build a reader
   *
   * We map this file into memory.  Note that the
   * implementation is free to simply read it into
   * a chunk of memory if it does not support mmap
   */
  ReaderFrame::ReaderFrame(std::string filename, off_t offset,size_t filesize)
    : m_container(new Container(filename,offset,filesize)),
      m_loaded(false),
      m_endianism(0)
  {
  }

  /*!
   * Build a read frame from bytes in a container
   */
  ReaderFrame::ReaderFrame(boost::shared_ptr<ContainerBase> container)
    : m_container(container),
      m_loaded(false),
      m_endianism(0)
  {
  }

  /*!
   * Deleting will dereference the internal map handle
   * and release the file and storage unless we passed
   * ownership off to a still living blob.
   */
  ReaderFrame::~ReaderFrame() {
  }

  /*!
   * The endianism for data stored in the frame.
   */
  uint32_t ReaderFrame::endianism() const {
    lazy_load();
    return m_endianism;
  }

  /*!
   * The lazy_load handles deferred loading of data
   * from the file.  We don't bother with the actual
   * processing until this is invoked (by the methods
   * that fetch meta, data, and typecodes).  It also
   * sets m_endianism;
   */
  void ReaderFrame::lazy_load() const {
    if (m_loaded) return;

    // We cast away constness to update the data
    ReaderFrame* that = const_cast<ReaderFrame*>(this);

    // -----------------------------------------------
    // We call some routines that will recursively
    // invoke lazy_load(), so we set the flag true
    // here before we try the recursion.
    // -----------------------------------------------
    that->m_loaded = true;

    // -----------------------------------------------
    // First, make sure we mapped enough bytes to
    // cover the mini-header (magic, version, framesize)
    // -----------------------------------------------
    size_t available_bytes = m_container->size();
    char* base = that->m_container->data();
    if ( available_bytes < sizeof(required_header_t)) {
      throw FrameSetException("file too short to hold required header",DESSERT_LOC); /* GCOV-IGNORE */
    }

    // -----------------------------------------------
    // Make sure this is a real frame
    // -----------------------------------------------
    required_header_t* required_header = reinterpret_cast<required_header_t*>(base);
    if ( ntohl(required_header->magic) != s_magic ) {
      std::stringstream error;
      error << "invalid magic number "
            << ntohl(required_header->magic)
            << " expected " << s_magic;
      throw FrameSetException(error.str());
    }

    uint64_t framesize = assemble64(ntohl(required_header->framesize_lo),
                                    ntohl(required_header->framesize_hi));
    if (framesize > available_bytes) {
      throw FrameSetException("truncated frame",DESSERT_LOC);
    }
    if (framesize < sizeof(header_t)) {
      throw FrameSetException("invalid framesize",DESSERT_LOC);
    }

    // -----------------------------------------------
    // OK, now we can load the real header.  Note that
    // as versions change, the size of the header
    // will grow, that is why we encode the header
    // size from the writer's point of view and use
    // that as the basis for further offsets.
    // -----------------------------------------------
    header_t* header = reinterpret_cast<header_t*>(base);

    uint32_t size_header_block = ntohl(header->size_header_block);
    //uint32_t frames_irosetta = header->irosetta;
    //float    frames_frosetta = header->frosetta;

    //uint32_t frames_drosetta_lo = header->drosetta_lo;
    //uint32_t frames_drosetta_hi = header->drosetta_hi;
    //uint32_t frames_lrosetta_lo = header->lrosetta_lo;
    //uint32_t frames_lrosetta_hi = header->lrosetta_hi;

    //double   frames_drosetta = assembleDouble(frames_drosetta_lo, frames_drosetta_hi);
    //uint64_t frames_lrosetta = assemble64(frames_lrosetta_lo, frames_lrosetta_hi);
    uint32_t frames_endianism = ntohl(header->endianism);
    uint32_t frames_nlabels = ntohl(header->nlabels);
    uint32_t size_meta_block = ntohl(header->size_meta_block);
    uint32_t size_typename_block = ntohl(header->size_typename_block);

    uint32_t size_label_block = ntohl(header->size_label_block);
    uint32_t size_scalar_block = ntohl(header->size_scalar_block);
    uint32_t size_field_block_lo = ntohl(header->size_field_block_lo);
    uint32_t size_field_block_hi = ntohl(header->size_field_block_hi);
    uint64_t size_field_block = assemble64(size_field_block_lo,
                                           size_field_block_hi);

    //uint32_t size_crc_block = ntohl(header->size_crc_block);
    //uint32_t size_padding_block = ntohl(header->size_padding_block);

    // -----------------------------------------------
    // Deal with endianism issues here....
    // -----------------------------------------------
    that->m_endianism = frames_endianism;

    // -----------------------------------------------
    // Compute offsets
    // -----------------------------------------------
    uint64_t offset_header_block = 0;
    uint64_t offset_meta_block = offset_header_block + size_header_block;
    uint64_t offset_typename_block = offset_meta_block + size_meta_block;
    uint64_t offset_label_block = offset_typename_block + size_typename_block;
    uint64_t offset_scalar_block = offset_label_block + size_label_block;
    uint64_t offset_field_block = offset_scalar_block + size_scalar_block;
    uint64_t offset_crc_block = offset_field_block + size_field_block;

    if (offset_crc_block > framesize) {
      throw FrameSetException("malformed header yielded invalid block sizes");
    }

    // -----------------------------------------------
    // Use the offsets to set pointers into the block
    // -----------------------------------------------
    metadisk_t* diskmeta  = reinterpret_cast<metadisk_t*>(base+offset_meta_block);
    char*       typenames = reinterpret_cast<char*>(base+offset_typename_block);
    char*       labels    = reinterpret_cast<char*>(base+offset_label_block);
    char*       scalars   = reinterpret_cast<char*>(base+offset_scalar_block);
    char*       fields    = reinterpret_cast<char*>(base+offset_field_block);
    uint32_t*   crc       = reinterpret_cast<uint32_t*>(base+offset_crc_block);

    if (*crc != 0) {
      uint32_t frame_crc = fletcher(reinterpret_cast<uint16_t*>(base),offset_crc_block/2);
      if (frame_crc != *crc) {
        throw FrameSetException("Checksum did not match");
      }
    }


    // -----------------------------------------------
    // First, unpack the typenames into the typename
    // list so that we can verify the typecode fields
    // in the meta data.
    // -----------------------------------------------

    // Is this necessary now that we've got an indexedMap?
    std::map<uint32_t,std::string> typecode_to_typename;
    while(*typenames) {
      if (typenames >= labels) {
        throw FrameSetException("malformed typename block.  Missing null byte");
      }
      std::string type(typenames);
      uint32_t code = that->typecodes().insert(type);
      typecode_to_typename[code] = type;

      typenames += type.size()+1;
    }

    // -----------------------------------------------
    // Now, we unpack the meta and field information
    // -----------------------------------------------
    for(size_t ii=0; ii<frames_nlabels; ++ii) {
      // Pull out the label
      std::string label(labels);
      labels += label.size()+1;

      // Pull out the typecode, elementsize, and count
      uint32_t code = ntohl(diskmeta[ii].type);
      uint32_t elementsize = ntohl(diskmeta[ii].elementsize);
      uint32_t count_lo = ntohl(diskmeta[ii].count_lo);
      uint32_t count_hi = ntohl(diskmeta[ii].count_hi);
      uint64_t count = assemble64(count_lo,count_hi);
      uint64_t nbytes = elementsize*count;


      // Convert the typecode to a typename (may fail!)
      std::map<uint32_t,std::string>::iterator type_p = typecode_to_typename.find(code);
      if (type_p == typecode_to_typename.end()) {
        throw FrameSetException("Invalid typecode in metadata");
      }
      const std::string& type = (*type_p).second;

      char* addr = 0;

      // TODO: Set a copy threshold in which small
      // things are copied into blobs instead of
      // referencing the large data map.
      if (count <= 1) {
        addr = scalars;
        scalars += alignInteger(nbytes,s_alignsize);
      } else {
        addr = fields;
        fields += alignInteger(nbytes,s_alignsize);
      }

      // Craft a shared_array<char> that points here AND
      // shares this frame's container to maintain data
      // lifetime.
      boost::shared_array<char> data(addr,
                                     keep_alive<boost::shared_ptr<ContainerBase> >(m_container));

      BaseBlob blob(type,count,elementsize,data,frames_endianism);
      that->set(label,blob);
    }
  }

  /*!
   * Meta data requires that the file be loaded and
   * processed.
   */
  FrameInfo::meta_map_t& ReaderFrame::meta() {
    lazy_load();
    return FrameInfo::meta();
  }

  /*!
   * Meta data requires that the file be loaded and
   * processed.
   */
  const FrameInfo::meta_map_t& ReaderFrame::meta() const  {
    lazy_load();
    return FrameInfo::meta();
  }

  /*!
   * Field data requires that the file be loaded and
   * processed.
   */
  FrameInfo::data_map_t& ReaderFrame::data() {
    lazy_load();
    return FrameInfo::data();
  }

  /*!
   * Field data requires that the file be loaded and
   * processed.
   */
  const FrameInfo::data_map_t& ReaderFrame::data() const {
    lazy_load();
    return FrameInfo::data();
  }

  /*!
   * Typecode data requires that the file be loaded and
   * processed.
   */
  FrameInfo::typecode_imap_t& ReaderFrame::typecodes() {
    lazy_load();
    return FrameInfo::typecodes();
  }

  /*!
   * Typecode data requires that the file be loaded and
   * processed.
   */
  const FrameInfo::typecode_imap_t& ReaderFrame::typecodes() const {
    lazy_load();
    return FrameInfo::typecodes();
  }


}
