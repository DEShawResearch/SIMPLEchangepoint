/* 
Copyright 2012-2014, D. E. Shaw Research.
All rights reserved.

Redistribution and use in source and binary forms, with or without
modification, are permitted provided that the following conditions are
met:

* Redistributions of source code must retain the above copyright
  notice, this list of conditions, and the following disclaimer.

* Redistributions in binary form must reproduce the above copyright
  notice, this list of conditions, and the following disclaimer in the
  documentation and/or other materials provided with the distribution.

* Neither the name of D. E. Shaw Research nor the names of its
  contributors may be used to endorse or promote products derived from
  this software without specific prior written permission.

THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
"AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR
A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT
OWNER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,
SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT
LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE,
DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY
THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
(INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE
OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
*/

#include "FrameSet/HumanTypename.hxx"
#include <cassert>
#include <string>
#include <inttypes.h>

/*
 char
 unsigned char
 float
 double
 int16_t
 int32_t
 int64_t
 uint16_t
 uint32_t
 uint64_t
 */

// -----------------------------------------------
// Test adding a user defined type
// -----------------------------------------------

/*! \brief test structure
 * 
 * Used only to test adding a new structure type
 */
typedef struct {
  //! \brief x component
  float x;
  //! \brief y component
  float y;
  //! \brief z component
  float z;
} xyz_t;
namespace frameset {
  template<> const char* humanTypename(const xyz_t&) {
    return "xyz_t";
  }
}


int main(void) {
  char char_val = 0;
  unsigned char uchar_val = 0;
  float float_val = 0;
  double double_val = 0;
  int16_t int16_val = 0;
  int32_t int32_val = 0;
  int64_t int64_val = 0;
  uint16_t uint16_val = 0;
  uint32_t uint32_val = 0;
  uint64_t uint64_val = 0;
  xyz_t xyz_val = {0.0,0.0,0.0};

  const char& const_char_val = char_val;
  const unsigned char& const_uchar_val = uchar_val;
  const float& const_float_val = float_val;
  const double& const_double_val = double_val;
  const int16_t& const_int16_val = int16_val;
  const int32_t& const_int32_val = int32_val;
  const int64_t& const_int64_val = int64_val;
  const uint16_t& const_uint16_val = uint16_val;
  const uint32_t& const_uint32_val = uint32_val;
  const uint64_t& const_uint64_val = uint64_val;
  const xyz_t& const_xyz_val = xyz_val;

  std::string char_name = frameset::humanTypename(char_val);
  assert(char_name == "char");

  std::string uchar_name = frameset::humanTypename(uchar_val);
  assert(uchar_name == "unsigned char");

  std::string float_name = frameset::humanTypename(float_val);
  assert(float_name == "float");

  std::string double_name = frameset::humanTypename(double_val);
  assert(double_name == "double");

  std::string int16_name = frameset::humanTypename(int16_val);
  assert(int16_name == "int16_t");

  std::string int32_name = frameset::humanTypename(int32_val);
  assert(int32_name == "int32_t");

  std::string int64_name = frameset::humanTypename(int64_val);
  assert(int64_name == "int64_t");

  std::string uint16_name = frameset::humanTypename(uint16_val);
  assert(uint16_name == "uint16_t");

  std::string uint32_name = frameset::humanTypename(uint32_val);
  assert(uint32_name == "uint32_t");

  std::string uint64_name = frameset::humanTypename(uint64_val);
  assert(uint64_name == "uint64_t");

  std::string xyz_name = frameset::humanTypename(xyz_val);
  assert(xyz_name == "xyz_t");

  std::string const_char_name = frameset::humanTypename(const_char_val);
  assert(const_char_name == "char");

  std::string const_uchar_name = frameset::humanTypename(const_uchar_val);
  assert(const_uchar_name == "unsigned char");

  std::string const_float_name = frameset::humanTypename(const_float_val);
  assert(const_float_name == "float");

  std::string const_double_name = frameset::humanTypename(const_double_val);
  assert(const_double_name == "double");

  std::string const_int16_name = frameset::humanTypename(const_int16_val);
  assert(const_int16_name == "int16_t");

  std::string const_int32_name = frameset::humanTypename(const_int32_val);
  assert(const_int32_name == "int32_t");

  std::string const_int64_name = frameset::humanTypename(const_int64_val);
  assert(const_int64_name == "int64_t");

  std::string const_uint16_name = frameset::humanTypename(const_uint16_val);
  assert(const_uint16_name == "uint16_t");

  std::string const_uint32_name = frameset::humanTypename(const_uint32_val);
  assert(const_uint32_name == "uint32_t");

  std::string const_uint64_name = frameset::humanTypename(const_uint64_val);
  assert(const_uint64_name == "uint64_t");

  std::string const_xyz_name = frameset::humanTypename(const_xyz_val);
  assert(const_xyz_name == "xyz_t");

  return 0;
}
