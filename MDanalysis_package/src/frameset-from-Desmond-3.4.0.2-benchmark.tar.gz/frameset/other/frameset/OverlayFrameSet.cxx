/* 
Copyright 2012-2014, D. E. Shaw Research.
All rights reserved.

Redistribution and use in source and binary forms, with or without
modification, are permitted provided that the following conditions are
met:

* Redistributions of source code must retain the above copyright
  notice, this list of conditions, and the following disclaimer.

* Redistributions in binary form must reproduce the above copyright
  notice, this list of conditions, and the following disclaimer in the
  documentation and/or other materials provided with the distribution.

* Neither the name of D. E. Shaw Research nor the names of its
  contributors may be used to endorse or promote products derived from
  this software without specific prior written permission.

THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
"AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR
A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT
OWNER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,
SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT
LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE,
DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY
THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
(INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE
OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
*/

#include <FrameSet/OverlayFrameSet.hxx>
#include <FrameSet/FrameSetExceptions.hxx>
#include <dessert/dessert.hpp>

#include <list>

#include <stdio.h>
#include <string.h>
#include <fcntl.h>
#include <sys/types.h>
#include <sys/stat.h>

#ifndef MAXPATHLEN
#define MAXPATHLEN (4096)
#endif

namespace frameset {
  /*!
   * 
   */
  OverlayFrameSet::OverlayFrameSet(const std::string& base)
    : FrameSetReader(base)
  {
    m_goodframes.push_back( size() );
  }

  OverlayFrameSet::~OverlayFrameSet() {
  }

  const FrameSetReader& OverlayFrameSet::owner(size_t& index) const {
    size_t save_index = index;

    //std::cerr <<"Find owner for " << save_index << std::endl;

    const FrameSetReader* own = this;
    size_t n = m_overlays.size();
    //std::cerr << "n is " << n << std::endl;
    for(size_t i = 0; i<n; ++i) {
      size_t good = m_goodframes.at(i);
      if (index < good) return *own;
      index -= good;
      //std::cerr << "  index is now " << index << " at overlay " << i << std::endl;
      own = m_overlays[i].get();
    }
    
    // Perhaps it is in the last frame
    if (index < m_goodframes.at(n)) return *own;
    throw RangeError(save_index,size()); /* GCOV-IGNORE */
  }

  /*!
   * 
   */
  FrameSetReader::FramePtr OverlayFrameSet::at(size_t index) const {
    const FrameSetReader& own = owner(index);

    // This may not work if owner's derived type is not FrameSetReader
    return own.FrameSetReader::at(index);

  }

  /*!
   * 
   */
  double OverlayFrameSet::time(size_t index) const {
    const FrameSetReader& own = owner(index);

    // This may not work if owner's derived type is not FrameSetReader
    return own.FrameSetReader::time(index);
  }

  /*!
   * 
   */
  void OverlayFrameSet::overlay(const boost::shared_ptr<FrameSetReader>& part) {
    // Adding a file of size zero has no effect.  just don't bother with it
    size_t new_frames = part->size();
    if (new_frames == 0) return;

    // OK.. we have a new part to add.  Find out which is the
    // last "good frame" in the current set.
    double first_time = part->time(0);
    ssize_t last_good = search_lt(first_time);

    size_t number_to_remove = size()-(last_good+1);

    typedef std::reverse_iterator<std::vector<size_t>::iterator> reverse;
    for(reverse rfirst(m_goodframes.end()), rlast(m_goodframes.begin());
        number_to_remove > 0 && rfirst != rlast;
        rfirst++) {
      if (number_to_remove > *rfirst) {
        number_to_remove -= *rfirst;
        *rfirst = 0;
      } else {
        *rfirst -= number_to_remove;
        number_to_remove = 0;
        break;
      }
    }

    // The "size" of the new system is the number in the
    // old system upto the new time (last_good+1) plus the
    // number of frames we are adding
    m_nframes = (last_good+1) + new_frames;
    m_goodframes.push_back(new_frames);
    m_overlays.push_back(part);
  }

  void OverlayFrameSet::overlay(const std::string& filename) {
    FrameSetReader *frameset = new FrameSetReader(filename);
    boost::shared_ptr<FrameSetReader> part(frameset);
    overlay(part);
  }


  std::string OverlayFrameSet::framefile(size_t frameno) const {
    const FrameSetReader& own = owner(frameno);
    return own.FrameSetReader::framefile(frameno);
  }
   
  FrameSet::key_record_t OverlayFrameSet::read_keyfile_entry(size_t index) const {
    const FrameSetReader& own = owner(index);
    return own.FrameSetReader::read_keyfile_entry(index);
  }


  OverlayFrameSet* OverlayFrameSet::from_stk_file(const std::string& source) {
    FILE* fp = fopen(source.c_str(),"r");
    if (!fp) {
      throw FrameSetException(source + ": " + strerror(errno),DESSERT_LOC);
    }
    try { 
      char line[MAXPATHLEN+1];
      if (!fgets(line,sizeof(line),fp)) {
        throw FrameSetException(source + ": file is empty",DESSERT_LOC);
      }
      line[strlen(line)-1] = '\0';  // Remove trailing \n
      OverlayFrameSet* reader = new OverlayFrameSet(line);
      while(fgets(line,sizeof(line),fp)) {
        line[strlen(line)-1] = '\0';  // Remove trailing \n
        reader->overlay(line);
      }
      return reader;
    } catch(...) {
      fclose(fp);
      throw;
    }
  }


  /*! 
   * Create a new frameset as either a STK or normal frameset.
   * Returns a new'd pointer that must be delete'd.
  */
  FrameSet* OverlayFrameSet::from_stk_file_or_directory(const std::string& source) {
    // If it is a directory, try the normal frameset reader
    if ( frameset::is_directory(source) ) return new FrameSetReader(source);

    // Otherwise, try the STK reader
    return from_stk_file(source);
  }

}
