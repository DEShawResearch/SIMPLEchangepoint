#!/usr/bin/env desres-exec
#{
# desres-cleanenv $FRAMESET_SCRIPT_CLEANENV \
# -- python $0 "$@"
#}
# Copyright D. E. Shaw Research, 2004-2012.

from framesettools import FrameSet,Frame
from numpy import all,array
from optparse import OptionParser
import sys,os

class TimeBar:
    def __init__(self,n,ticks=50):
	self.__n = n
        self.__ticks = ticks
        self.__count = 0
        w,m = n // ticks, n % ticks
        self._at = [i*w + (i < m) - 1 for i in xrange(ticks)]
	return

    def tick(self):
        self.__count += 1
        while self._at and self.__count > self._at[0]:
            sys.stdout.write('.')
            sys.stdout.flush()
            del self._at[0]
        return

def framepairs(A,B):
    n = len(A)
    assert n == len(B)
    for i in xrange(n):
        yield i,A[i],B[i]
    return


def sameframe(A,B):
    # ------------------------------------------------------------------------
    # Labels must be the same
    # ------------------------------------------------------------------------
    label_A = A.__labels__
    label_B = B.__labels__
    if label_A != label_B:
        sA = set(label_A)
        sB = set(label_B)
        msg = ''
        if sA.difference(sB): msg += 'missing labels %s '%(','.join(sA.difference(sB)))
        if sB.difference(sA): msg += 'extra labels %s '%(','.join(sB.difference(sA)))
        return False,msg
        
    # ------------------------------------------------------------------------
    # Values for each field must match exactly
    # ------------------------------------------------------------------------
    for label in label_A:
        attr_A = getattr(A,label)
        attr_B = getattr(B,label)
        if not all(attr_A == attr_B): return False,'Miscompare for label %s'%label

    return True,''

def verify_framesets_the_same(A,B,verbose=False):
    fs_A = FrameSet(A)
    fs_B = FrameSet(B)

    # ------------------------------------------------------------------------
    # Lengths must be the same
    # ------------------------------------------------------------------------
    if len(fs_A) != len(fs_B): return False,'Lengths are different'

    # ------------------------------------------------------------------------
    # Times must be the same (OK to do floating point == here as they must
    # really be the same!)
    # ------------------------------------------------------------------------
    if not all(fs_A.times() == fs_B.times()): return False,'Time miscompare'
        
    # ------------------------------------------------------------------------
    # The metaframes should be the same (very old versions do not have metadata)
    # ------------------------------------------------------------------------
    meta_A_path = os.path.join(A,'metadata')
    meta_B_path = os.path.join(B,'metadata')
    if os.path.exists(meta_A_path):
        mA = open(meta_A_path).read()
        mB = open(meta_B_path).read()
        if mA != mB: return False,'Metafiles miscompare'

    # ------------------------------------------------------------------------
    # Frames must match
    # ------------------------------------------------------------------------
    T = TimeBar(len(fs_A))
    for i,frame_A,frame_B in framepairs(fs_A,fs_B):
        same,msg = sameframe(frame_A,frame_B)
        if not same:
            return False,'Frame data mismatch for frame %d: %s'%(i,msg)
        if verbose: T.tick()

    return True,''
    


if __name__ == '__main__':
    parser = OptionParser("verify_framesets_the_same.py [options] A-frameset B-frameset")
    parser.add_option('-c','--check',action='store_true',default=False,help='Verify after writing')
    parser.add_option('-v','--verbose',action='store_true',default=False,help='Show more info')

    opts,args = parser.parse_args()
    if len(args) != 2:
        parser.print_help(sys.stderr)
        print >>sys.stderr,"Must call with A-frameset B-framset"
        sys.exit(1)

    A,B = args

    if opts.verbose: print 'Verifying'
    same,msg = verify_framesets_the_same(A,B,opts.verbose)
    if opts.verbose: print
    if not same: sys.exit(msg)
    
