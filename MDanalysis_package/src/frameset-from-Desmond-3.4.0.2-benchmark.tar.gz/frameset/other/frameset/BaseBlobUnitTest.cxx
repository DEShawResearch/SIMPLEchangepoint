/* 
Copyright 2012-2014, D. E. Shaw Research.
All rights reserved.

Redistribution and use in source and binary forms, with or without
modification, are permitted provided that the following conditions are
met:

* Redistributions of source code must retain the above copyright
  notice, this list of conditions, and the following disclaimer.

* Redistributions in binary form must reproduce the above copyright
  notice, this list of conditions, and the following disclaimer in the
  documentation and/or other materials provided with the distribution.

* Neither the name of D. E. Shaw Research nor the names of its
  contributors may be used to endorse or promote products derived from
  this software without specific prior written permission.

THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
"AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR
A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT
OWNER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,
SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT
LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE,
DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY
THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
(INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE
OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
*/

#include "FrameSet/BaseBlob.hxx"
#include "FrameSet/FrameSetExceptions.hxx"
#include <vector>
#include <cassert>
#include <iostream>
#include <cstring>

int main(void) {
  try {
    // -----------------------------------------------
    // Constructors
    // -----------------------------------------------
    frameset::BaseBlob blob1;
    assert(blob1.type() == "char");
    assert(blob1.count() == 0);
    assert(blob1.elementsize() == sizeof(char));
    assert(blob1.nbytes() == 0);

    frameset::BaseBlob blob2(12);
    assert(blob2.type() == "char");
    assert(blob2.count() == 12);
    assert(blob2.elementsize() == sizeof(char));
    assert(blob2.nbytes() == 12);

    const size_t NUINT32 = 2;
    uint32_t fvalues[NUINT32] = {11,22};
    frameset::BaseBlob blob3(NUINT32,fvalues);
    assert(blob3.type() == "uint32_t");
    assert(blob3.count() == NUINT32);
    assert(blob3.elementsize() == sizeof(uint32_t));
    assert(blob3.nbytes() == NUINT32*sizeof(uint32_t));

    const size_t NDOUBLES = 10;
    boost::shared_array<double> doubles(new double[NDOUBLES]);
    for(size_t ii=0;ii<NDOUBLES;++ii) {
      doubles[ii] = 11*ii+0.5;
    }
    frameset::BaseBlob blob4(NDOUBLES,doubles);
    assert(blob4.type() == "double");
    assert(blob4.count() == NDOUBLES);
    assert(blob4.elementsize() == sizeof(double));
    assert(blob4.nbytes() == NDOUBLES*sizeof(double));

    const size_t NFLOATS = 100;
    const float* null_float = NULL;
    frameset::BaseBlob blob5(NFLOATS,null_float);
    assert(blob5.type() == "float");
    assert(blob5.count() == NFLOATS);
    assert(blob5.elementsize() == sizeof(float));
    assert(blob5.nbytes() == NFLOATS*sizeof(float));

    // -----------------------------------------------
    // Not much in the way of methods...
    // -----------------------------------------------
    blob5.reset();

    blob5.resize(NFLOATS+1);
    assert(blob5.count() == NFLOATS+1);
    blob5.resize(NFLOATS-1);
    assert(blob5.count() == NFLOATS-1);
    blob5.resize(0);
    assert(blob5.count() == 0);

    // -----------------------------------------------
    // Make sure the m_data allocate works for size 0
    // -----------------------------------------------
    frameset::BaseBlob blob6(0);

    // -----------------------------------------------
    // Raw, char* based iterators
    // -----------------------------------------------
    std::string hello("hello world!");
    std::copy(hello.begin(),hello.end(),blob2.firstbyte());

    char buf[13];
    ::memcpy(buf,blob2.firstbyte(),blob2.nbytes());
    buf[12] = 0;
    assert(buf == hello);

    std::vector<char> hello2(12);
    std::copy(blob2.firstbyte(),blob2.endbytes(),hello2.begin());
    std::string hello3(&(hello2[0]),12);
    assert(hello3 == hello);

  } catch (std::exception& e) {
    std::cerr << e.what() << std::endl;
    return 1;
  }
  return 0;
}

