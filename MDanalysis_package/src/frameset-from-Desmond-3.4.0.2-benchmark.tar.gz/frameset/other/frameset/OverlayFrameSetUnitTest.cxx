/* 
Copyright 2012-2014, D. E. Shaw Research.
All rights reserved.

Redistribution and use in source and binary forms, with or without
modification, are permitted provided that the following conditions are
met:

* Redistributions of source code must retain the above copyright
  notice, this list of conditions, and the following disclaimer.

* Redistributions in binary form must reproduce the above copyright
  notice, this list of conditions, and the following disclaimer in the
  documentation and/or other materials provided with the distribution.

* Neither the name of D. E. Shaw Research nor the names of its
  contributors may be used to endorse or promote products derived from
  this software without specific prior written permission.

THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
"AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR
A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT
OWNER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,
SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT
LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE,
DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY
THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
(INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE
OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
*/

#include "FrameSet/FrameSetWriter.hxx"
#include "FrameSet/FrameSetReader.hxx"
#include "FrameSet/OverlayFrameSet.hxx"
#include "UnitTestCommon.hxx"

#include <iostream>

#include <sys/stat.h>
#include <sys/types.h>

#ifdef DESRES_OS_Windows
#include <direct.h>
#define mkdir(a,b) _mkdir((a))
#endif

void write_frameset(int i, std::string dir,size_t low, size_t hi) {
  frameset::FrameSetWriter writer(dir);
  frameset::Frame F;

  for(size_t time = low; time <= hi; ++time) {
    uint32_t step = 100*i + time;
    F.set_value("STEP",step);
    writer.push_back(F,(double)time);
  }
}

void checktime(frameset::FrameSetReader& reader, uint32_t* answers) {
  for(size_t i=0; i<reader.size(); ++i) {
    frameset::FrameSetReader::FramePtr fptr = reader.at(i);
    assert(fptr.get() != NULL);

    uint32_t step;
    fptr->get_value("STEP",step);
    if (step != answers[i]) {
      std::cerr << "Expected " << answers[i] << " got " << step << std::endl;
    }
    assert(step == answers[i]);
  }
}

int main(void) {
  try {
    // -----------------------------------------------
    // Make a few simple framesets
    // -----------------------------------------------
    frameset::FrameSet::recursivelyRemove("collection.dir");
    ::mkdir("collection.dir",0777);
    write_frameset(0,"collection.dir/0_10.fst",0,10);
    write_frameset(2,"collection.dir/11_15.fst",11,15);
    write_frameset(3,"collection.dir/8_15.fst",8,15);
    write_frameset(4,"collection.dir/13_20.fst",13,20);
    write_frameset(5,"collection.dir/8_20.fst",8,20);
    write_frameset(6,"collection.dir/8_9.fst",8,9);


    // -----------------------------------------------
    // Build without overlay
    // -----------------------------------------------
    {
      frameset::OverlayFrameSet overlay("collection.dir/0_10.fst");

      // Must be right size with continous time
      assert(overlay.size() == 11);
      for(size_t time = 0; time < overlay.size(); ++time) {
        assert(overlay.time(time) == (double)time);
      }
      uint32_t steps[] = {0,1,2,3,4,5,6,7,8,9,10,11};
      checktime(overlay,steps);
    }

    // -----------------------------------------------
    // Build with simple overlay (no overlap)
    // -----------------------------------------------
    {
      frameset::OverlayFrameSet overlay("collection.dir/0_10.fst");
      overlay.overlay("collection.dir/11_15.fst");

      // Must be right size with continous time
      assert(overlay.size() == 16);
      for(size_t time = 0; time < overlay.size(); ++time) {
        assert(overlay.time(time) == (double)time);
      }
      uint32_t steps[] = {0,1,2,3,4,5,6,7,8,9,10,
                          211,212,213,214,215};
      checktime(overlay,steps);
    }

    // -----------------------------------------------
    // Build with overlay (overlap)
    // -----------------------------------------------
    {
      frameset::OverlayFrameSet overlay("collection.dir/0_10.fst");
      overlay.overlay("collection.dir/8_15.fst");

      // Must be right size with continous time
      assert(overlay.size() == 16);
      for(size_t time = 0; time < overlay.size(); ++time) {
        assert(overlay.time(time) == (double)time);
      }
      uint32_t steps[] = {0,1,2,3,4,5,6,7,
                          308,309,310,311,312,313,314,315};
      checktime(overlay,steps);
    }

    // -----------------------------------------------
    // Fancier overlay
    // -----------------------------------------------
    {
      frameset::OverlayFrameSet overlay("collection.dir/0_10.fst");
      overlay.overlay("collection.dir/8_15.fst");
      overlay.overlay("collection.dir/13_20.fst");

      // Must be right size with continous time
      assert(overlay.size() == 21);
      for(size_t time = 0; time < overlay.size(); ++time) {
        assert(overlay.time(time) == (double)time);
      }
      uint32_t steps[] = {0,1,2,3,4,5,6,7,
                          308,309,310,311,312,
                          413,414,415,416,417,418,419,420};
      checktime(overlay,steps);
    }

    // -----------------------------------------------
    // Fancier overlay that rims out a trajectory
    // -----------------------------------------------
    {
      frameset::OverlayFrameSet overlay("collection.dir/0_10.fst");
      overlay.overlay("collection.dir/8_15.fst");
      overlay.overlay("collection.dir/8_20.fst");

      // Must be right size with continous time
      assert(overlay.size() == 21);
      for(size_t time = 0; time < overlay.size(); ++time) {
        assert(overlay.time(time) == (double)time);
      }
      uint32_t steps[] = {0,1,2,3,4,5,6,7,
                          508,509,510,511,512,513,514,515,516,517,518,519,520};
      checktime(overlay,steps);
    }

    // -----------------------------------------------
    // Fancier overlay that totally removes a partial
    // -----------------------------------------------
    {
      frameset::OverlayFrameSet overlay("collection.dir/0_10.fst");
      overlay.overlay("collection.dir/11_15.fst");
      overlay.overlay("collection.dir/8_9.fst");

      // Must be right size with continous time
      assert(overlay.size() == 10);
      for(size_t time = 0; time < overlay.size(); ++time) {
        assert(overlay.time(time) == (double)time);
      }
      uint32_t steps[] = {0,1,2,3,4,5,6,7,608,609};
      checktime(overlay,steps);
    }

    // -----------------------------------------------
    // Kitchen sink
    // -----------------------------------------------
    {
      frameset::OverlayFrameSet overlay("collection.dir/0_10.fst");
      overlay.overlay("collection.dir/8_9.fst");
      overlay.overlay("collection.dir/11_15.fst");
      overlay.overlay("collection.dir/13_20.fst");

      // Must be right size with continous time (hole at 10)
      assert(overlay.size() == 20);
      for(size_t time = 0; time < overlay.size(); ++time) {
        if (time < 10) {
          assert(overlay.time(time) == (double)time);
        } else {
          assert(overlay.time(time) == (double)time+1);
        }
      }
      uint32_t steps[] = {0,1,2,3,4,5,6,7,
                          608,609,
                          211,212,
                          413,414,415,416,417,418,419,420};
      checktime(overlay,steps);
    }

    // -----------------------------------------------
    // Truncating several
    // -----------------------------------------------
    {
      frameset::OverlayFrameSet overlay("collection.dir/0_10.fst");
      overlay.overlay("collection.dir/11_15.fst");
      overlay.overlay("collection.dir/13_20.fst");
      overlay.overlay("collection.dir/8_9.fst");

      // Must be right size with continous time
      assert(overlay.size() == 10);
      for(size_t time = 0; time < overlay.size(); ++time) {
        assert(overlay.time(time) == (double)time);
      }
      uint32_t steps[] = {0,1,2,3,4,5,6,7,
                          608,609};
      checktime(overlay,steps);
    }



    frameset::FrameSet::recursivelyRemove("collection.dir");
  } catch (std::exception& e) {
    std::cerr << e.what() << std::endl;
    return 1;
  }
  return 0;
}
