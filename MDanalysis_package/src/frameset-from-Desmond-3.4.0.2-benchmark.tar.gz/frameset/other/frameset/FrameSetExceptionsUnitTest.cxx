/* 
Copyright 2012-2014, D. E. Shaw Research.
All rights reserved.

Redistribution and use in source and binary forms, with or without
modification, are permitted provided that the following conditions are
met:

* Redistributions of source code must retain the above copyright
  notice, this list of conditions, and the following disclaimer.

* Redistributions in binary form must reproduce the above copyright
  notice, this list of conditions, and the following disclaimer in the
  documentation and/or other materials provided with the distribution.

* Neither the name of D. E. Shaw Research nor the names of its
  contributors may be used to endorse or promote products derived from
  this software without specific prior written permission.

THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
"AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR
A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT
OWNER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,
SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT
LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE,
DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY
THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
(INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE
OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
*/

#include "FrameSet/FrameSetExceptions.hxx"
#include <cassert>

#include <iostream>

int main(void) {
  std::string file = __FILE__;

  // -----------------------------------------------
  // Simple construction
  // -----------------------------------------------
  frameset::AttributeError a("foo");
  frameset::AttributeError a1("bar",__FILE__,222,"main");
  frameset::TypeSafetyError ts("something bad");
  frameset::TypeSafetyError ts1("something bad",__FILE__,333,"main");
  frameset::RangeError re(100,99);
  frameset::RangeError re1(100,99,__FILE__,444,"main");
#ifdef _MSC_VER
  frameset::NotImplementedException noti(__FILE__,__LINE__,__FUNCSIG__);
#elif defined(_GNUC_)
  frameset::NotImplementedException noti(__FILE__,__LINE__,__PRETTY_FUNCTION__);
#else
  frameset::NotImplementedException noti(__FILE__,__LINE__,"(unknown)");
#endif
  frameset::ErrnoException  errnoe("message");
  frameset::IoException ioe("message");
  frameset::IoErrnoException ioerrnoe("message");
  frameset::DereferenceError derefe("message");
  

  // -----------------------------------------------
  // About the only methods to test are what()
  // attribute() [for AttributeError],
  // and badIndex()/maxIndex() [for RangeError]
  //
  // NOTE: Since the change to dessert, the
  // what has unpredictable stack information,
  // so don't bother testing those anymore.
  // -----------------------------------------------
  //assert(a.what() == std::string("attribute error - foo"));
  assert(a.attribute() == std::string("foo"));
  //assert(a1.what() == file + ":222: attribute error - bar");
  assert(a1.attribute() == std::string("bar"));
  //assert(ts.what() == std::string("something bad"));
  //assert(ts1.what() == file + ":333: something bad");
  //assert(re.what() == std::string("Index 100 greater-eq than 99"));
  assert(re.badIndex() == 100);
  assert(re.maxIndex() == 99);
  //assert(re1.what() == file + ":444: Index 100 greater-eq than 99");
  assert(re1.badIndex() == 100);
  assert(re1.maxIndex() == 99);

  // -----------------------------------------------
  // Test the class static range check convenience
  // functions.
  // -----------------------------------------------
  bool threw_exception = false;
  bool threw_wrong_exception = false;
  try {
    frameset::RangeError::check(10,10);
  } catch (frameset::RangeError& re) {
    threw_exception = true;
  } catch (...) {
    threw_exception = true;
    threw_wrong_exception = true;
  }
  assert(threw_exception);
  assert(! threw_wrong_exception);

  threw_exception = false;
  threw_wrong_exception = false;
  try {
    frameset::RangeError::check(10,10,__FILE__,__LINE__,"main");
  } catch (frameset::RangeError& re) {
    threw_exception = true;
  } catch (...) {
    threw_exception = true;
    threw_wrong_exception = true;
  }
  assert(threw_exception);
  assert(! threw_wrong_exception);

  return 0;
}
