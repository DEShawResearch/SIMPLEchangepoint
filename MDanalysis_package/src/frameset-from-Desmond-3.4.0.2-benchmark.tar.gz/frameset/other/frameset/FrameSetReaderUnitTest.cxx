/* 
Copyright 2012-2014, D. E. Shaw Research.
All rights reserved.

Redistribution and use in source and binary forms, with or without
modification, are permitted provided that the following conditions are
met:

* Redistributions of source code must retain the above copyright
  notice, this list of conditions, and the following disclaimer.

* Redistributions in binary form must reproduce the above copyright
  notice, this list of conditions, and the following disclaimer in the
  documentation and/or other materials provided with the distribution.

* Neither the name of D. E. Shaw Research nor the names of its
  contributors may be used to endorse or promote products derived from
  this software without specific prior written permission.

THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
"AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR
A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT
OWNER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,
SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT
LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE,
DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY
THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
(INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE
OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
*/

#include "FrameSet/FrameSetWriter.hxx"
#include "FrameSet/FrameSetReader.hxx"
#include "FrameSet/ReaderFrame.hxx"
#include "UnitTestCommon.hxx"

#include <iostream>
#include <cfloat>
#include <cmath>
#include <cstdlib>

#include <boost/math/special_functions.hpp>
using namespace boost::math;

#ifdef DESRES_OS_Windows
inline double drand48() { return double(rand())/RAND_MAX; }
#endif

int main(void) {
  try {
    // -----------------------------------------------
    // Cannot read a non-existant directory
    // -----------------------------------------------
    frameset::FrameSet::recursivelyRemove("nonexistant.dir");
    MUST_THROW(frameset::FrameSetException, {
        frameset::FrameSetReader reader("nonexistant.dir");
      });

    // -----------------------------------------------
    // Write a small frameset.  Note use of {} to
    // set lifetime of the writer.
    // -----------------------------------------------
    {
      frameset::FrameSetWriter writer("sample.dir");
      frameset::Frame F;

      F.set_values("TITLE","hello world!",12);
      uint32_t step = 111;
      F.set_value("STEP",step);

      writer.push_back(F,0.0);
    }

    // -----------------------------------------------
    // Read it back in!  Again, we use {} so that
    // the reader and writer fall out of scope and
    // release their file handles.
    // -----------------------------------------------
    {
      assert(frameset::FrameSetReader::isaFrameSetDirectory("sample.dir"));
      frameset::FrameSetReader reader("sample.dir");
      assert(reader.size() == 1);

      assert(reader.begin() != reader.end());

      // -----------------------------------------------
      // Some coverage checks...
      // -----------------------------------------------
      reader.begin()++;
      reader.end();

      // -----------------------------------------------
      // Get a frame and check its contents
      // -----------------------------------------------
      frameset::FrameSetReader::FramePtr frame = reader.at(0);
      uint32_t mystep;
      frame->get_value("STEP",mystep);
      assert(mystep == 111);

      // -----------------------------------------------
      // Check out of bounds range check
      // -----------------------------------------------
      MUST_THROW(frameset::RangeError,{
          reader.at(10);
        });

      // -----------------------------------------------
      // We can almost use std::copy to copy framesets,
      // but since push_back requires a time, that
      // won't work.
      // -----------------------------------------------
      frameset::FrameSet::recursivelyRemove("output.dir");
      frameset::FrameSetWriter output("output.dir");
      for(frameset::FrameSetReader::iterator p = reader.begin();
          p != reader.end(); ++p) {
        frameset::Frame& frame = *p;

        // This way uses an untyped "get()" that casts
        // the untyped blob into a Blob<char>
        frameset::Blob<char> blob = frame.get("TITLE");
        std::string title(blob.begin(),blob.end());
        assert(title == "hello world!");

        // You can also use an output iterator
        size_t nchars = frame.nbytes("TITLE");
        std::vector<char> title2(nchars);
        frame.get_values<char>("TITLE",title2.begin());
        assert(title == std::string(&title2[0],nchars));

        // You can use a normal pointer
        char title3[256];
        assert(nchars < sizeof(title3));
        frame.get_values<char>("TITLE",title3);
        title3[nchars] = 0;
        assert(title == title3);

        // You can use an output adapter
        std::vector<char> title5;
        frame.get_values<char>("TITLE",std::back_inserter(title5));
        assert(title5.size() == nchars);
        assert(title == std::string(&title5[0],nchars));

        // Do the normal frame push back...
        double time = p.time();
        output.push_back(frame,time);
      }
      assert(output.size() == reader.size());
    }

    // -----------------------------------------------
    // Clean up if we got this far.
    // -----------------------------------------------
    frameset::FrameSet::recursivelyRemove("output.dir");
    frameset::FrameSet::recursivelyRemove("sample.dir");

    // -----------------------------------------------
    // A larger example...
    // -----------------------------------------------
    {
      const int nframes = 10;
      {
        frameset::FrameSetWriter frameset("larger.dir");
        frameset::Frame F;
        F.set_values("TITLE","hello world!",12);
        double time = 0;
        for(int i=0; i<nframes; ++i) {
          F.set_value("STEP",i);
          frameset.push_back(F,time);

          // Increment by a nasty number that isn't
          // floating point nice.
          time += 1.0/3.0;
        }
      }
      frameset::FrameSetReader larger("larger.dir");
      assert(larger.size() == nframes);

      // -----------------------------------------------
      // We can fetch times directly from the frameset
      // -----------------------------------------------
      assert(larger.time(0) == 0.0);
      assert(0.3 < larger.time(1) && larger.time(1) < 0.4);
      assert(0.6 < larger.time(2) && larger.time(2) < 0.7);
      MUST_THROW(frameset::RangeError,{
          larger.time(100);
        });


      // -----------------------------------------------
      // We can search for some times nearest a target
      // -----------------------------------------------
      assert(larger.time(0) == 0.0);
      assert(larger.search_nearest(-1.0) == 0);
      assert(larger.search_nearest(0.0) == 0);
      assert(larger.search_nearest(0.1) == 0);
      assert(larger.search_nearest(0.2) == 1);
      assert(larger.search_nearest(0.33) == 1);
      assert(larger.search_nearest(0.34) == 1);
      assert(larger.search_nearest(0.4) == 1);
      assert(larger.search_nearest(2+nframes/3.0) == nframes-1);
      for(ssize_t i=0; i<(ssize_t)nframes; ++i) {
        assert(larger.search_nearest(i/3.0) == i);
      }
      assert(larger.search_le(-1.0) == -1);
      assert(larger.search_le(0.0) == 0);
      assert(larger.search_le(0.1) == 0);
      assert(larger.search_le(0.3) == 0);
      assert(larger.search_le(1.1) == 3);
      for(int i=0; i<1000; ++i){
          double target = drand48() * nframes/3.;
          uint32_t idx = larger.search_le(target);
          assert(larger.time(idx) <= target);
          assert(idx == nframes-1 || larger.time(idx+1) > target);
          // May not be true because of roundoff.
          //assert(larger.search_le(target) == (int)(target*3.0));
      }
      // Check the corner cases at and near each of the stored
      // values:
      for(ssize_t i=0; i<(ssize_t)nframes; ++i){
          double ti = larger.time(i);
          assert( larger.search_lt(ti) == (i-1) );
          assert( larger.search_le(ti) == i );
          assert( larger.search_gt(ti) == (i+1) );
          assert( larger.search_ge(ti) == i );
          assert( larger.search_nearest(ti) == i );

          double tiplus = nextafter(ti, DBL_MAX);
          assert( larger.search_lt(tiplus) == i );
          assert( larger.search_le(tiplus) == i );
          assert( larger.search_gt(tiplus) == (i+1) );
          assert( larger.search_ge(tiplus) == (i+1) );
          assert( larger.search_nearest(tiplus) == i );

          double timinus = nextafter(ti, -DBL_MAX);
          assert( larger.search_lt(timinus) == (i-1) );
          assert( larger.search_le(timinus) == (i-1) );
          assert( larger.search_gt(timinus) == i );
          assert( larger.search_ge(timinus) == i );
          assert( larger.search_nearest(timinus) == i );
      }
    }

    // Cleanup
    frameset::FrameSet::recursivelyRemove("larger.dir");
  } catch (std::exception& e) {
    std::cerr << e.what() << std::endl;
    return 1;
  }
  return 0;
}
