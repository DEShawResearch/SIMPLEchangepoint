/* 
Copyright 2012-2014, D. E. Shaw Research.
All rights reserved.

Redistribution and use in source and binary forms, with or without
modification, are permitted provided that the following conditions are
met:

* Redistributions of source code must retain the above copyright
  notice, this list of conditions, and the following disclaimer.

* Redistributions in binary form must reproduce the above copyright
  notice, this list of conditions, and the following disclaimer in the
  documentation and/or other materials provided with the distribution.

* Neither the name of D. E. Shaw Research nor the names of its
  contributors may be used to endorse or promote products derived from
  this software without specific prior written permission.

THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
"AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR
A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT
OWNER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,
SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT
LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE,
DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY
THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
(INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE
OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
*/

#include <cstdio>
#include <cstring>
#include <sys/types.h>
#include <sys/stat.h>
#include <fcntl.h>
#if defined(DESRES_OS_Windows) || defined(DESRES_OS_MINGW_GCC4)
#include <Windows.h>
#else
#define O_BINARY 0
#include <unistd.h>
#include <netinet/in.h>
#endif

#include <string>
#include <map>

#include <boost/filesystem.hpp>
namespace bfs = boost::filesystem;

#include "FrameSet/ReaderFrame.hxx"


/*! \brief Offset/Size pair for rebuilding timekeys files
 *
 * Used internally by rebuild_timekeys
 */
struct offset_size { 
  uint32_t offset,framesize;
  offset_size(uint32_t o=0, uint32_t s=0) : offset(o),framesize(s) {}
};

// ------------------------------------------------------------------------
// Global data... just to easy this way
// ------------------------------------------------------------------------
int ndir1 = 0;
int ndir2 = 0;
int fpf = 0;
std::map<double,offset_size> keys;

// ------------------------------------------------------------------------
// The Frame interface requires one of these containers that handle
// data lifetime... a bit overkill here, but useful
// ------------------------------------------------------------------------
class ContainerString : public frameset::ReaderFrame::ContainerBase {
  char* m_p; 
  size_t m_n;
  size_t m_offset;

  ContainerString(const ContainerString&);
  ContainerString& operator=(const ContainerString&);
public:
  //! \brief Build with a new[]'d pointer and size
  ContainerString(char* p,size_t n)  : m_p(p), m_n(n), m_offset(0) {}

  //! \brief Kill the pointer
  virtual ~ContainerString() {delete[] m_p;}

  //! \brief Number of bytes in this container.
  virtual size_t size() const { return m_n; }

  //! \brief Raw data handle for this container.
  virtual char* data() { return m_p+m_offset; }

  //! \brief Raw data handle for this container.
  virtual const char* data() const { return m_p; }

  //! \brief Current data offset in "file"
  size_t offset() const { return m_offset; }

  //! \brief Update data offset and return true if at end-of-file
  bool eof(size_t size) {
    if (m_n <= size) return true;
    m_offset += size;
    m_n -= size;
    return false;
  }

};

// ------------------------------------------------------------------------
// exit with status
// ------------------------------------------------------------------------
static void dead(const char* msg,const char* a0) {
  fprintf(stderr,"ERROR:");
  fprintf(stderr,msg,a0);
  perror("");
  exit(1);
}
static void dead(const char* msg) {
  fprintf(stderr,"ERROR: %s\n",msg);
  exit(1);
}  


// ------------------------------------------------------------------------
// Process a subdirectory
//
// We are looking for frameDDDDDDDD files and HHH directories 
// (D = [0-9], H = [0-a]).  We look in the frame files to figure out
// the times (from a field entry) and how many frames per file we
// are using.
//
// We look at the directories (hex numbers) to figure out the DeepDir
// parameters.
// ------------------------------------------------------------------------
void process_directory(const std::string& dirname,int level) {
  for ( bfs::directory_iterator ditr(dirname); ditr != bfs::directory_iterator(); ++ditr) {
    const std::string name = ditr->path().string();
    // Skip . files (including directory)
    if (name == "." || name == "..") continue;

    std::string fullpath = dirname + '/'+ name;

    int len = name.size();
    if ( bfs::is_regular_file(fullpath) && std::strncmp(name.c_str(),"frame",5) == 0 && isdigit(name[len-1])) {
      int frameno = -1;
      sscanf(name.c_str(),"frame%d", &frameno);

      // Stat the file
      struct stat statbuf; stat(fullpath.c_str(),&statbuf);
      // Read the frame bytes into memory
      char* p = new char[statbuf.st_size];
      int fp = ::open(fullpath.c_str(),O_RDONLY|O_BINARY);
      if (!fp) dead("Cannot open file %s",fullpath.c_str());
      ::read(fp,p,statbuf.st_size);
      ::close(fp);

      boost::shared_ptr<ContainerString> container( new ContainerString(p,statbuf.st_size) );

      for ( int frames_in_this_file=1;;frames_in_this_file++ ) {
        if (frames_in_this_file > fpf) fpf = frames_in_this_file;

        frameset::ReaderFrame frame(container);

        frameset::Blob<double> timeblob;
        double time = 0.0;

        try {
          timeblob = frame.get("TIME");
          time = timeblob[0];
        } catch (const std::exception&) {
          try {
            timeblob = frame.get("CHEMICALTIME");
            time = timeblob[0];
          } catch (const std::exception&) {
            try {
              timeblob = frame.get("PHYSICALTIME");
              time = timeblob[0];
            } catch (const std::exception&) {
              try {
                timeblob = frame.get("CHEMICAL_TIME");
                time = timeblob[0];
              } catch (const std::exception&) {
                try {
                  timeblob = frame.get("PHYSICAL_TIME");
                  time = timeblob[0];
                } catch (const std::exception&) {
                  dead("NO TIME IN FRAME");
                }
              }
            }
          }
        }
        keys[time] = offset_size(container->offset(),frame.framesize());
        if (container->eof(frame.framesize())) break;
      } 

    }

    // ------------------------------------------------------------------------
    // Maybe its a directory...
    // 
    // Check if it's a HHH (all hex digit) directory and use that to back figure
    // the DeepDir numbers
    // ------------------------------------------------------------------------
    else if ( bfs::is_directory(fullpath) ) {
      if (isxdigit(name[0])) {
        int offset;
        sscanf(name.c_str(),"%x",&offset);

        if (level == 0 && offset+1 > ndir1) ndir1 = offset+1;
        if (level == 1 && offset+1 > ndir2) ndir2 = offset+1;
      }

      process_directory(fullpath,level+1);
    }

  }
}


int main(int argc, const char** argv) {

  if (argc != 2) {
    fprintf(stderr,
            "usage: %s frameset-directory\n\nRecreate a timekeys from contents of the underlying frames\n"
            "Writes a file called \"timekeys\" in the current working directory\n",argv[0]);
    exit(1);
  }

  const char* frameset = argv[1];

  // Scan for times and back figure frames per file and deepdir parameters
  process_directory(frameset,0);


  int fd = ::open("timekeys",O_RDWR|O_TRUNC|O_CREAT,0666);
  frameset::FrameSet::key_prologue_t prologue;

  // ------------------------------------------------------------------------
  // Write out the prologue
  // ------------------------------------------------------------------------
  // TODO: Make this a public number
  //prologue.magic = htonl(frameset::FrameSet::s_magic_timekey);
  uint32_t s_magic_timekey = 0x4445534b;
  prologue.magic = htonl(s_magic_timekey);
  prologue.frames_per_file = htonl(fpf);
  prologue.key_record_size = htonl(sizeof(frameset::FrameSet::key_record_t));

  int n = ::write(fd,&prologue,sizeof(prologue));
  if (n != sizeof(prologue)) throw "write failure";


  // ------------------------------------------------------------------------
  // Write out each time/offset/size record
  //
  // Times are guaranteed to be in order
  // ------------------------------------------------------------------------
  double last_time = -1.0;
  int nframes = 0;
  for(std::map<double,offset_size>::iterator p = keys.begin(), en = keys.end(); p != en; ++p) {
    nframes ++;
    double time = (*p).first;
    offset_size data = (*p).second;
    if (time < last_time) throw "times don't increase";
    last_time = time;

    frameset::FrameSet::key_record_t timekey;
    timekey.time_lo = htonl(frameset::Frame::lobytes(time));
    timekey.time_hi = htonl(frameset::Frame::hibytes(time));
    timekey.offset_lo = htonl(frameset::Frame::lobytes(data.offset));
    timekey.offset_hi = htonl(frameset::Frame::hibytes(data.offset));
    timekey.framesize_lo = htonl(frameset::Frame::lobytes(data.framesize));
    timekey.framesize_hi = htonl(frameset::Frame::hibytes(data.framesize));

    int n = ::write(fd,&timekey,sizeof(timekey));
    if (n != sizeof(timekey)) throw "write failure";

  }

  if ( ::close(fd) != 0 ) throw "bad close";

  return 0;
}
