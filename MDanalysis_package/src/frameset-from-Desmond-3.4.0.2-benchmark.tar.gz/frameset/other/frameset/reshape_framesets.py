#!/usr/bin/env desres-exec
#{
# desres-cleanenv $FRAMESET_SCRIPT_CLEANENV \
# -- python $0 "$@"
#}
# Copyright D. E. Shaw Research, 2004-2012.

from framesettools import FrameSet,Frame
from numpy import array
import os
import glob

def main(BLOCKSIZE,*args,**kw):
    uselinks = kw.get('uselinks',False)
    
    assert args

    # Make a read frameset for every filename given
    fsets = [FrameSet(x) for x in args]

    # We will use the extention from the first to choose the extension for all reshaped
    ext = os.path.splitext(args[0])[-1]

    # This is a map from time to frameset object
    timemap = {}
    for fs in fsets:
        for i,t in enumerate(fs.times()):
            timemap[t] = (fs,i)

    # We want the unique set of times represented by the framesets
    # This is just the keys of the timemap!
    times = timemap.keys()
    times.sort()
    ntimes = len(times)


    # We generate new blocks
    frame = Frame()
    for block in range(0,ntimes,BLOCKSIZE):
        blockno = block/BLOCKSIZE
        blocktimes = times[block:block+BLOCKSIZE]

        # We build a new frameset to do our pushbacks
        new_framesetname = 'reshaped%04d%s'%(blockno,ext)
        nfs = FrameSet(new_framesetname,'w!')

        # We create empty stub frames
        for t in blocktimes:
            nfs.push_back(frame,t)

        # We need to copy over the relevant metaframe info...
        masterfs,frameno = timemap[blocktimes[0]]
        for key in masterfs.meta().__labels__:
            setattr(nfs.meta(),key,getattr(masterfs.meta(),key))
        
        # We are done with the frameset... we delete it to close it
        del nfs

        # For every file in the old frameset that is not a frame we must
        # transport it to the new frameset as a move or a link...
        for filename in glob.glob(os.path.join(masterfs.name,'*')) + glob.glob(os.path.join(masterfs.name,'not_hashed','*')):
            dirname,basename = os.path.split(filename)
            if basename.startswith('frame0'): continue
            if basename == 'not_hashed': continue
            if basename == 'metadata': continue
            if basename == 'timekeys': continue

            new_filename = os.path.join(new_framesetname,filename[len(masterfs.name)+1:])

            try: os.unlink(new_filename)
            except: pass

            if uselinks:
                os.symlink(filename,new_filename)
            else:
                os.rename(filename,new_filename)

        # We need to map over the actual frames associated with the data
        for i,t in enumerate(blocktimes):
            fs,frameno = timemap[t]
            framefile = fs.frameinfo(frameno)[0]
            framepath = os.path.join(new_framesetname,'frame%09d'%i)

            # Kill the placeholder frame and replace with the actual frame
            # or a link to the frame
            os.unlink(framepath)
            if uselinks:
                os.symlink(framefile,framepath)
            else:
                os.rename(framefile,framepath)


if __name__ == '__main__':
    import sys
    try:
        i = sys.argv.index('--move_frames')
        del sys.argv[i]
        uselinks = False
    except ValueError:
        uselinks = True
    main(int(sys.argv[1]),uselinks=uselinks,*sys.argv[2:])
