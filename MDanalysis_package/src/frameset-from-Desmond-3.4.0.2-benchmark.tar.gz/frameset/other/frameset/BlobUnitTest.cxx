/* 
Copyright 2012-2014, D. E. Shaw Research.
All rights reserved.

Redistribution and use in source and binary forms, with or without
modification, are permitted provided that the following conditions are
met:

* Redistributions of source code must retain the above copyright
  notice, this list of conditions, and the following disclaimer.

* Redistributions in binary form must reproduce the above copyright
  notice, this list of conditions, and the following disclaimer in the
  documentation and/or other materials provided with the distribution.

* Neither the name of D. E. Shaw Research nor the names of its
  contributors may be used to endorse or promote products derived from
  this software without specific prior written permission.

THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
"AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR
A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT
OWNER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,
SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT
LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE,
DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY
THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
(INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE
OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
*/

#include "FrameSet/Blob.hxx"
#include "FrameSet/FrameSetExceptions.hxx"
#include <vector>
#include <cassert>
#include <iostream>

int main(void) {
  try {
    // -----------------------------------------------
    // Set up some generic blobs to manipulate as
    // typed blobs below...
    // -----------------------------------------------
    frameset::BaseBlob blob1;

    frameset::BaseBlob blob2(12);

    const size_t NUINT32 = 2;
    uint32_t ivalues[NUINT32] = {11,22};
    frameset::BaseBlob blob3(NUINT32,ivalues);

    const size_t NDOUBLES = 10;
    boost::shared_array<double> doubles(new double[NDOUBLES]);
    for(size_t ii=0;ii<NDOUBLES;++ii) {
      doubles[ii] = 11*ii+0.5;
    }
    frameset::BaseBlob blob4(NDOUBLES,doubles);

    const size_t NFLOATS = 100;
    const float* null_float = NULL;
    frameset::BaseBlob blob5(NFLOATS,null_float);

    // -----------------------------------------------
    // Typed blobs (first by casting)
    // -----------------------------------------------
    frameset::Blob<char>     cblob = blob2;
    assert(cblob.type() == "char");
    assert(cblob.count() == 12);
    assert(cblob.elementsize() == sizeof(char));
    assert(cblob.nbytes() == 12);
    assert(cblob.type() == blob2.type());
    assert(cblob.count() == blob2.count());
    assert(cblob.elementsize() == blob2.elementsize());
    assert(cblob.nbytes() == blob2.nbytes());

    frameset::Blob<uint32_t> iblob = blob3;
    assert(iblob.type() == "uint32_t");
    assert(iblob.count() == 2);
    assert(iblob.elementsize() == sizeof(uint32_t));
    assert(iblob.nbytes() == 2*sizeof(uint32_t));
    assert(iblob.type() == blob3.type());
    assert(iblob.count() == blob3.count());
    assert(iblob.elementsize() == blob3.elementsize());
    assert(iblob.nbytes() == blob3.nbytes());

    frameset::Blob<double>   dblob = blob4;
    assert(dblob.type() == "double");
    assert(dblob.count() == NDOUBLES);
    assert(dblob.elementsize() == sizeof(double));
    assert(dblob.nbytes() == NDOUBLES*sizeof(double));
    assert(dblob.type() == blob4.type());
    assert(dblob.count() == blob4.count());
    assert(dblob.elementsize() == blob4.elementsize());
    assert(dblob.nbytes() == blob4.nbytes());

    // -----------------------------------------------
    // Try invalid cast
    // -----------------------------------------------
    bool threw_exception = false;
    bool threw_wrong_exception = false;
    try {
      frameset::Blob<double> badblob = blob1;
    } catch ( frameset::TypeSafetyError& e ) {
      threw_exception = true;
    } catch (...) {
      threw_exception = true;
      threw_wrong_exception = true;
    }
    assert(threw_exception);
    assert(! threw_wrong_exception);

    // -----------------------------------------------
    // The other way to make a typed blob is to give
    // the c'tor the count.
    // -----------------------------------------------
    frameset::Blob<uint32_t> userblob(3);
    assert(userblob.type() == "uint32_t");
    assert(userblob.count() == 3);

    // -----------------------------------------------
    // Data is supposed to be linked to original data
    // -----------------------------------------------
    assert(iblob[0] == 11); // copied in
    assert(iblob[1] == 22);

    assert(dblob[1] == 11.5); // Shared with ``doubles''

    // Changing shared_array changes blob...
    assert(dblob[1] != 0.0);
    doubles[1] = 0;
    assert(dblob[1] == 0.0);

    // Changing blob changes shared_array
    assert(doubles[0] != 11);
    dblob[0] = 11.0;
    assert(doubles[0] == 11.0);

    // A new shared array is linked to both the blob
    // and the original shared_array.
    boost::shared_array<double> linked = dblob.typedData();
    assert(doubles[2] == 22.5);
    assert(dblob[2] == 22.5);
    assert(linked[2] == 22.5);

    // Changing this new array changes the blob and the
    // original data set.
    linked[2] = 22;
    assert(doubles[2] == 22);
    assert(dblob[2] == 22);
    assert(linked[2] == 22);

    // Coverage to touch the const version...
    const frameset::Blob<double>& const_dblob = blob4;
    const boost::shared_array<double> const_linked = 
      const_dblob.typedData();
    assert(doubles[2] == 22);
    assert(const_dblob[2] == 22);
    assert(const_linked[2] == 22);


    // -----------------------------------------------
    // Iteration with std::copy
    // -----------------------------------------------
    uint32_t myints[2];
    std::copy(iblob.begin(),iblob.end(),myints);
    assert(myints[0] == 11);
    assert(myints[1] == 22);

    // -----------------------------------------------
    // Assignment
    // -----------------------------------------------
    frameset::Blob<float> lhs;
    bool caught_typesafety;
    try {
      lhs = iblob;
      caught_typesafety = false;
    } catch (const frameset::TypeSafetyError&) {
      caught_typesafety = true;
    }
    assert(caught_typesafety);
    
  } catch (std::exception& e) {
    std::cerr << e.what() << std::endl;
    return 1;
  }
  return 0;
}
