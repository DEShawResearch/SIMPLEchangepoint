/* 
Copyright 2012-2014, D. E. Shaw Research.
All rights reserved.

Redistribution and use in source and binary forms, with or without
modification, are permitted provided that the following conditions are
met:

* Redistributions of source code must retain the above copyright
  notice, this list of conditions, and the following disclaimer.

* Redistributions in binary form must reproduce the above copyright
  notice, this list of conditions, and the following disclaimer in the
  documentation and/or other materials provided with the distribution.

* Neither the name of D. E. Shaw Research nor the names of its
  contributors may be used to endorse or promote products derived from
  this software without specific prior written permission.

THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
"AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR
A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT
OWNER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,
SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT
LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE,
DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY
THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
(INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE
OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
*/

#include <dump_utils.hxx>
#include <FrameSet/Frame.hxx>
#include <iostream>
#include <sstream>
#include <iomanip>
#include <vector>

using std::cout;
using std::cerr;
using std::endl;
using frameset::Frame;
using frameset::BaseBlob;
using frameset::Blob;

static std::string repr(char c) {
  if (isprint(c) && c != '"') {
    std::string s(&c,1);
    return s;
  }

  std::ostringstream str;
  str << "\\" << std::setw(3) << std::setfill('0') << std::setbase(8) << ((unsigned)c);
  return str.str();
}

/*!
 * 
 */
static void display(bool hexfloat,size_t max,const Frame& frame, const std::string& label) {

  BaseBlob data = frame.get(label);
  size_t count = data.count();
  std::string type = data.type();

  // -----------------------------------------------
  // We start with dimension and type information
  // -----------------------------------------------
  cout << '[' << count << " x " << type << "]=";

  // -----------------------------------------------
  // We may choose to truncate the field.
  // -----------------------------------------------
  size_t displaying = (max && count > max)?(max):(count);

  // -----------------------------------------------
  // Do type specific processing...
  // -----------------------------------------------
  if ( type == "char") {
    Blob<char> typed_data = data;
    cout << " \"";
    for(size_t i=0;i<displaying;++i) cout << repr(typed_data[i]);
    if (displaying != count) cout << "...";
    cout << '"';
    displaying = count;
  } else if ( type == "unsigned char") {
    Blob<unsigned char> typed_data = data;
    cout << " \"";
    for(size_t i=0;i<displaying;++i) cout << repr(typed_data[i]);
    if (displaying != count) cout << "...";
    cout << '"';
    displaying = count;
  } else if ( type == "float") {
    Blob<float> typed_data = data;
    if (hexfloat) {
      for(size_t i=0;i<displaying;++i) {
        char hex[32];
        cout << ' ' << hexdump(hex,typed_data[i]);
      }
    } else {
      int p = cout.precision(numeric_limits0x<float>::max_digits10);
      for(size_t i=0;i<displaying;++i) cout << ' ' << typed_data[i];
      cout.precision(p);
    }
  } else if ( type == "double") {
    Blob<double> typed_data = data;
    if (hexfloat) {
      for(size_t i=0;i<displaying;++i) {
        char hex[32];
        cout << ' ' << hexdump(hex,typed_data[i]);
      }
    } else {
      int p = cout.precision(numeric_limits0x<double>::max_digits10);
      for(size_t i=0;i<displaying;++i) cout << ' ' << typed_data[i];
      cout.precision(p);
    }
  } else if ( type == "int16_t") {
    Blob<int16_t> typed_data = data;
    for(size_t i=0;i<displaying;++i) cout << ' ' << typed_data[i];
  } else if ( type == "int32_t") {
    Blob<int32_t> typed_data = data;
    for(size_t i=0;i<displaying;++i) cout << ' ' << typed_data[i];
  } else if ( type == "int64_t") {
    Blob<int64_t> typed_data = data;
    for(size_t i=0;i<displaying;++i) cout << ' ' << typed_data[i];
  } else if ( type == "uint16_t") {
    Blob<uint16_t> typed_data = data;
    for(size_t i=0;i<displaying;++i) cout << ' ' << typed_data[i];
  } else if ( type == "uint32_t") {
    Blob<uint32_t> typed_data = data;
    for(size_t i=0;i<displaying;++i) cout << ' ' << typed_data[i];
  } else if ( type == "uint64_t") {
    Blob<uint64_t> typed_data = data;
    for(size_t i=0;i<displaying;++i) cout << ' ' << typed_data[i];
  } else {
    cout << " ...";
    displaying  = count;
  }

  if (displaying != count) cout << " ...";
}

static char comma(size_t i) {
  if (i) return ',';
  return ' ';
}

void dump_frame(const Frame& frame,
                const std::set<std::string>& match,
                const std::set<std::string>& match_not,
                size_t max,
                bool hexfloat) {
  // -----------------------------------------------
  // For every label...
  // -----------------------------------------------
  std::set<std::string> labels;
  frame.labels(labels);
  for(std::set<std::string>::iterator fieldp = labels.begin();
      fieldp != labels.end(); ++fieldp) {
          
    // If we are using a "match list", we have to have it
    if (match.size() > 0 && match.find(*fieldp) == match.end()) {
      continue;
    }

    // If we are using a "matchnot list", we must not have it
    if (match_not.size() > 0 && match_not.find(*fieldp) != match_not.end()) {
      continue;
    }

    cout << "    " << *fieldp;
    display(hexfloat,max,frame,*fieldp);
    cout << endl;
  }
}

static void json_display(bool hexfloat,const Frame& frame, const std::string& label) {

  BaseBlob data = frame.get(label);
  size_t count = data.count();
  std::string type = data.type();

  // -----------------------------------------------
  // Do type specific processing...
  // -----------------------------------------------
  if ( type == "char") {
    Blob<char> typed_data = data;
    cout << " \"";
    for(size_t i=0;i<count;++i) cout << repr(typed_data[i]);
    cout << '"';
  } else if ( type == "unsigned char") {
    Blob<unsigned char> typed_data = data;
    cout << " \"";
    for(size_t i=0;i<count;++i) cout << repr(typed_data[i]);
    cout << '"';
  } else if ( type == "float") {
    cout << '[';
    Blob<float> typed_data = data;
    if (hexfloat) {
      for(size_t i=0;i<count;++i) {
        char hex[32];
        cout << comma(i) << hexdump(hex,typed_data[i]);
      }
    } else {
      int p = cout.precision(numeric_limits0x<float>::max_digits10);
      for(size_t i=0;i<count;++i) cout << comma(i) << typed_data[i];
      cout.precision(p);
    }
    cout << " ]";
  } else if ( type == "double") {
    cout << '[';
    Blob<double> typed_data = data;
    if (hexfloat) {
      for(size_t i=0;i<count;++i) {
        char hex[32];
        cout << comma(i) << hexdump(hex,typed_data[i]);
      }
    } else {
      int p = cout.precision(numeric_limits0x<double>::max_digits10);
      for(size_t i=0;i<count;++i) cout << comma(i) << typed_data[i];
      cout.precision(p);
    }
    cout << " ]";
  } else if ( type == "int16_t") {
    cout << '[';
    Blob<int16_t> typed_data = data;
    for(size_t i=0;i<count;++i) cout << comma(i) << typed_data[i];
    cout << " ]";
  } else if ( type == "int32_t") {
    cout << '[';
    Blob<int32_t> typed_data = data;
    for(size_t i=0;i<count;++i) cout << comma(i) << typed_data[i];
    cout << " ]";
  } else if ( type == "int64_t") {
    cout << '[';
    Blob<int64_t> typed_data = data;
    for(size_t i=0;i<count;++i) cout << comma(i) << typed_data[i];
    cout << " ]";
  } else if ( type == "uint16_t") {
    cout << '[';
    Blob<uint16_t> typed_data = data;
    for(size_t i=0;i<count;++i) cout << comma(i) << typed_data[i];
    cout << " ]";
  } else if ( type == "uint32_t") {
    cout << '[';
    Blob<uint32_t> typed_data = data;
    for(size_t i=0;i<count;++i) cout << comma(i) << typed_data[i];
    cout << " ]";
  } else if ( type == "uint64_t") {
    cout << '[';
    Blob<uint64_t> typed_data = data;
    for(size_t i=0;i<count;++i) cout << comma(i) << typed_data[i];
    cout << " ]";
  } else {
  }

}

void dump_json_frame(double time,
                     const Frame& frame,
                     const std::set<std::string>& match,
                     const std::set<std::string>& match_not,
                     bool hexfloat) {

  // -----------------------------------------------
  // Find labels we care about
  // -----------------------------------------------
  std::set<std::string> labels;
  std::vector<std::string> good_labels;
  frame.labels(labels);
  for(std::set<std::string>::iterator fieldp = labels.begin();
      fieldp != labels.end(); ++fieldp) {
          
    // If we are using a "match list", we have to have it
    if (match.size() > 0 && match.find(*fieldp) == match.end()) {
      continue;
    }

    // If we are using a "matchnot list", we must not have it
    if (match_not.size() > 0 && match_not.find(*fieldp) != match_not.end()) {
      continue;
    }

    good_labels.push_back(*fieldp);
  }


  cout << "  {" << endl;
  int p = cout.precision(numeric_limits0x<double>::max_digits10);
  cout << "    " << "\"frametime\"" << ": " << time;
  cout.precision(p);

  for(std::vector<std::string>::iterator fieldp = good_labels.begin();
      fieldp != good_labels.end(); ++fieldp) {

    cout << ',' << endl << "    \"" << *fieldp << "\": ";
    json_display(hexfloat,frame,*fieldp);
  }


  cout << endl;
  cout << "  }";
}
