/* 
Copyright 2012-2014, D. E. Shaw Research.
All rights reserved.

Redistribution and use in source and binary forms, with or without
modification, are permitted provided that the following conditions are
met:

* Redistributions of source code must retain the above copyright
  notice, this list of conditions, and the following disclaimer.

* Redistributions in binary form must reproduce the above copyright
  notice, this list of conditions, and the following disclaimer in the
  documentation and/or other materials provided with the distribution.

* Neither the name of D. E. Shaw Research nor the names of its
  contributors may be used to endorse or promote products derived from
  this software without specific prior written permission.

THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
"AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR
A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT
OWNER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,
SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT
LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE,
DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY
THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
(INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE
OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
*/

#include "FrameSet/FrameSetReader.hxx"

#include <iostream>
#include <vector>
#include <string>
#include <cassert>


#include <sys/types.h>
#include <sys/stat.h>
#ifdef DESRES_OS_Windows
#define WINDOWS_FS
#include <fcntl.h>
#include <Windows.h>
#else
#include <netinet/in.h>
#include <unistd.h>
#endif
#include <cstdio>

using frameset::FrameSetReader;
using frameset::Frame;

using std::vector;
using std::cout;
using std::cerr;
using std::endl;
using std::string;

int main(int argc, char** argv) {
  int status = 0;
  bool fixme = false;

  for(int argno=1; argno<argc; ++argno) {
    std::string arg = argv[argno];
    if (arg == "--fix") {
      fixme = true;
    } else if (arg == "--help") {
      cerr << argv[0] << " [--fix] [--help] fs fs fs ..." << endl;
      cerr << endl;
      cerr << "Check the status of all listed framesets and their keyfiles." << endl;
      cerr << "If --fix is specified, then the keyfile will be truncated to" << endl;
      cerr << "reflect the last good frame found." << endl;
      return 0;
    } else {
      try {
        if (FrameSetReader::isaFrameSetDirectory(arg)) {
          FrameSetReader reader(arg);

          // Read the prologue
          FrameSetReader::key_prologue_t prologue = reader.read_keyfile_prologue();
          assert(sizeof(FrameSetReader::key_record_t) ==
                 ntohl(prologue.key_record_size));

          size_t frames_per_file = ntohl(prologue.frames_per_file);

          unsigned last_good_frame = -1;
          size_t size = reader.size();
          for(unsigned frameno = 0; frameno < size;) {
            // Verify the frame file
            std::string framefile = reader.framefile(frameno);
            struct stat framefile_stat;
            int stat_status = stat(framefile.c_str(),&framefile_stat);

            for(unsigned i=0; frameno < size && i < frames_per_file; ++i, ++frameno) {
              FrameSetReader::key_record_t record = reader.read_keyfile_entry(frameno);

              // Maybe the frame doesn't exist any longer
              if (stat_status < 0 ) {
                cerr << "Frame " << frameno << " of " << arg << " has no data" << endl;
                frameno = size; // No more processing
                status = 1;
                continue;
              }
              uint64_t offset = Frame::assemble64(ntohl(record.offset_lo),
                                                  ntohl(record.offset_hi));
              uint64_t framesize = Frame::assemble64(ntohl(record.framesize_lo),
                                                     ntohl(record.framesize_hi));

              // What about a partial write?
              if ( framefile_stat.st_size < (ssize_t)(offset+framesize) ) {
                cerr << "Frame " << frameno << " of " << arg << " is truncated" << endl;
                frameno = size; // No more processing
                status = 1;
                continue;
              }

              // If it survives the checks, it's a good frame
              last_good_frame = frameno;
            }
          }

          if (fixme && last_good_frame != (size-1)) {
            std::string keyfile = arg+"/timekeys";
            cerr << arg << " only good through " << last_good_frame 
                 << " of " << size << " frames" << endl;
            size_t goodbytes = sizeof(FrameSetReader::key_prologue_t)+
              (last_good_frame+1)*sizeof(FrameSetReader::key_record_t);
            cerr << "Truncate " << keyfile << " to " << goodbytes << " bytes" << endl;
#ifdef WINDOWS_FS
	    {
	      int fd;
	      fd = ::_open(keyfile.c_str(), O_RDWR|O_BINARY);
	      _chsize(fd, goodbytes);
	      ::_close(fd);
	    }
#else
            if (truncate(keyfile.c_str(),goodbytes)) {
              perror(keyfile.c_str());
            }
#endif
          }

        } else {
          cerr << argv[argno] << " is not a frameset" << endl;
          status = 1;
          break;
        }
      } catch(const std::exception& e) {
        cerr << argv[argno] << endl;
        cerr << e.what() << endl;
        status = 1;
      }
    }
  }

  return status;
}
