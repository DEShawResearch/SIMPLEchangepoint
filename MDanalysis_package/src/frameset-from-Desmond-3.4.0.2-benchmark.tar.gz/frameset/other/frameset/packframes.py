#!/usr/bin/env desres-exec
#{
# desres-cleanenv $FRAMESET_SCRIPT_CLEANENV \
# -- python $0 "$@"
#}
# Copyright D. E. Shaw Research, 2004-2012.

from framesettools import FrameSet,Frame
from optparse import OptionParser
from verify_framesets_the_same import verify_framesets_the_same,TimeBar
import sys

def frametime(fs):
    times = fs.times()
    for i in xrange(len(fs)):
        yield i,fs[i],times[i]
    return


def packframes(input,output,fpf,verbose=False):
    fs_in = FrameSet(input)
    fs_out = FrameSet(output,mode='w!',frames_per_file=fpf)

    meta_in = fs_in.meta()
    meta_out = fs_out.meta()

    # Copy the meta frame info
    for attr in meta_in.__labels__: setattr( meta_out, attr, getattr(meta_in,attr) )

    T = TimeBar(len(fs_in))
    for i,frame,time in frametime(fs_in):
        fs_out.push_back(frame,time)
        if verbose: T.tick()
    return


if __name__ == '__main__':

    parser = OptionParser("packframes.py [options] input-frameset output-frameset frames_per_file")
    parser.add_option('-c','--check',action='store_true',default=False,help='Verify after writing')
    parser.add_option('-v','--verbose',action='store_true',default=False,help='Show more info')
    
    opts,args = parser.parse_args()
    if len(args) != 3:
        parser.print_help(sys.stderr)
        print >>sys.stderr,"Must call with input-frameset output-framset frames_per_file"
        sys.exit(1)

    input,output,fpf = args
    fpf = int(fpf)

    if opts.verbose: print 'Copying...'
    packframes(input,output,fpf,opts.verbose)
    if opts.verbose: print
    
    if opts.check:
        if opts.verbose: print 'Checking...'
        same,msg = verify_framesets_the_same(input,output,opts.verbose)
        if opts.verbose: print
        if not same: sys.exit("%s and %s did not verify properly: %s"%(input,output,msg))
