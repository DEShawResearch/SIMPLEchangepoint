/* 
Copyright 2012-2014, D. E. Shaw Research.
All rights reserved.

Redistribution and use in source and binary forms, with or without
modification, are permitted provided that the following conditions are
met:

* Redistributions of source code must retain the above copyright
  notice, this list of conditions, and the following disclaimer.

* Redistributions in binary form must reproduce the above copyright
  notice, this list of conditions, and the following disclaimer in the
  documentation and/or other materials provided with the distribution.

* Neither the name of D. E. Shaw Research nor the names of its
  contributors may be used to endorse or promote products derived from
  this software without specific prior written permission.

THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
"AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR
A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT
OWNER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,
SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT
LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE,
DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY
THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
(INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE
OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
*/

#include "FrameSet/Blob.hxx"
#include "FrameSet/FrameSetExceptions.hxx"
#include <iostream>
#include <cstring>

namespace frameset {
  /*!
   * Make a very simple blob out of characters.  We use a
   * separate constructor here because type and elementsize
   * are intimately linked, so we should not specify one without
   * the other.  If you need to specify the type, see the fully
   * qualified constructor.
   */
  BaseBlob::BaseBlob(uint64_t count) 
    : m_type("char"), m_count(count), m_elementsize(1),
      m_data(new char[count]), m_endianism(__BYTE_ORDER)
  {
  }

  /*!
   * Construct a blob from its basic parts.  This requires that you
   * know the elementsize of the named type.
   */
  BaseBlob::BaseBlob(std::string type, uint64_t count, uint32_t elementsize, 
                     boost::shared_array<char> data, int endianism)
    : m_type(type), m_count(count), m_elementsize(elementsize), m_data(data),
      m_endianism(endianism)
  {
  }

  /*!
   * This protected constructor is used by derived classes that
   * can fully and safely specify type and element size.
   */
  void BaseBlob::setup_type(uint64_t count, std::string type, uint32_t elementsize)
  {
    m_count = count;
    m_type = type;
    m_elementsize = elementsize;
    m_data = boost::shared_array<char>(new char[count*elementsize]);
    
    // DESRESAnton#297, Zero out the memory we allocated
    memset(m_data.get(),0,count*elementsize);
  }

  /*!
   * Clear data.
   */
  void BaseBlob::reset() {
    m_data.reset();
    m_count = 0;
  }

  /*!
   * 
   */
  void BaseBlob::resize(uint64_t newcount) {
    // Allocate fresh storage
    uint64_t newsize = m_elementsize*newcount;
    boost::shared_array<char> replacement(new char[newsize]);
    //std::cerr << "new dims: " << newcount << "(" << newsize << ")" << std::endl;
    //std::cerr << "I have nbytes() " << nbytes() << std::endl;
    //std::cerr << "replacement.get() " << (void*)replacement.get() << std::endl;
    //std::cerr << "m_data.get() " << (void*)m_data.get() << std::endl;

    // Copy old data forward.
    if (nbytes() < newsize) {
      //std::cerr << "nbytes() < newsize " << nbytes() << ' ' << newsize << std::endl;
      ::memcpy(replacement.get(),m_data.get(),nbytes());
    } else {
      //std::cerr << "NOT nbytes() < newsize " << nbytes() << ' ' << newsize << std::endl;
      ::memcpy(replacement.get(),m_data.get(),newsize);
    }

    // Replace data and count information
    m_data = replacement;
    m_count = newcount;
  }

  /*!
   * Returns a shared array to the data held by the blob.
   */
  boost::shared_array<char> BaseBlob::data() {
    return m_data;
  }

  /*!
   * Returns a shared array to the data held by the blob.
   */
  const boost::shared_array<char> BaseBlob::data() const {
    return m_data;
  }

  /*!
   * Returns the name of the true element type.
   */
  std::string BaseBlob::type() const {
    return m_type;
  }

  /*!
   * Returns the number of elements in the internal array.
   * This count may be zero (but it's unsigned, so never
   * negative).
   */
  uint64_t BaseBlob::count() const {
    return m_count;
  }

  /*!
   * Returns the size of an individual element in th earray.
   */
  uint32_t BaseBlob::elementsize() const {
    return m_elementsize;
  }

  /*!
   * Number of bytes used to store this array (simply
   * count*element size).
   */
  uint64_t BaseBlob::nbytes() const {
    return m_count*m_elementsize;
  }

  /*!
   * The first byte of storage.  It could be NULL.
   */
  char* BaseBlob::firstbyte() {
    return m_data.get();
  }

  /*!
   * The first byte of storage. It could be NULL.
   */
  const char* BaseBlob::firstbyte() const {
    return m_data.get();
  }

  /*!
   * One past the last byte of storage (or NULL if
   * there is no storage defined).
   */
  char* BaseBlob::endbytes() {
    if (m_data == NULL) return NULL;
    return m_data.get() + m_count*m_elementsize;
  }

  /*!
   * One past the last byte of storage (or NULL if
   * there is no storage defined).
   */
  const char* BaseBlob::endbytes() const {
    if (m_data == NULL) return NULL;
    return m_data.get() + m_count*m_elementsize;
  }
}
