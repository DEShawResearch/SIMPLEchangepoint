/* 
Copyright 2012-2014, D. E. Shaw Research.
All rights reserved.

Redistribution and use in source and binary forms, with or without
modification, are permitted provided that the following conditions are
met:

* Redistributions of source code must retain the above copyright
  notice, this list of conditions, and the following disclaimer.

* Redistributions in binary form must reproduce the above copyright
  notice, this list of conditions, and the following disclaimer in the
  documentation and/or other materials provided with the distribution.

* Neither the name of D. E. Shaw Research nor the names of its
  contributors may be used to endorse or promote products derived from
  this software without specific prior written permission.

THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
"AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR
A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT
OWNER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,
SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT
LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE,
DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY
THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
(INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE
OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
*/

#include "FrameSet/ReaderFrame.hxx"
#include "FrameSet/FilelessReader.hxx"

#ifdef DESRES_OS_Windows
#include <Windows.h>
#else
#include <netinet/in.h> // For ntohl
#endif

namespace frameset {

  class StringContainer : public ReaderFrame::ContainerBase {
    std::string m_data;

  public:
    StringContainer(const std::string& data)
      : m_data(data)
    {
    }

    virtual ~StringContainer() {}

    virtual size_t size() const { return m_data.size(); }
    virtual char* data() { return const_cast<char*>(m_data.data()); }
    virtual const char* data() const { return m_data.data(); }
  };

  FilelessReader::FilelessReader(const std::string& path, int ndir1, int ndir2, const std::string& timekeysinfo, const std::string& metaframeinfo)
    : FrameSetReader(path,true),m_timekeysinfo(timekeysinfo)
  {
    // Set the deep dir info directly
    m_ndir1 = ndir1;
    m_ndir2 = ndir2;

    // Read in timekeys information
    FrameSet::key_prologue_t prologue = read_keyfile_prologue();
    m_frames_per_file = ntohl(prologue.frames_per_file);

    // We calculate the number of actual records in the keyfile
    m_nframes = (m_timekeysinfo.size() - sizeof(prologue))/sizeof(key_record_t);

    // We may need to replace the empty, default metaframe data with that provided here
    if (metaframeinfo.size()) {
      boost::shared_ptr<frameset::ReaderFrame::ContainerBase> container(new StringContainer(metaframeinfo));
      
      m_meta = frameset::FrameSetReader::FramePtr(new frameset::ReaderFrame(container));
    }

  }

  FilelessReader::~FilelessReader() {
  }

  FrameSet::key_prologue_t FilelessReader::read_keyfile_prologue() const {

    // String better be big enough
    if ( m_timekeysinfo.size() < sizeof(FrameSet::key_prologue_t) ) throw IoException("keyfile is truncated");

    FrameSet::key_prologue_t const* prologue = reinterpret_cast<FrameSet::key_prologue_t const*>(m_timekeysinfo.data());

    if (ntohl(prologue->magic) != s_magic_timekey) {
      throw FrameSetException("keyfile magic number incorrect");  /* GCOV-IGNORE */
    }

    if (ntohl(prologue->key_record_size) != sizeof(key_record_t)) {
      throw FrameSetException("Key record changed size");  /* GCOV-IGNORE */
    }
    return *prologue;
  }

  FrameSet::key_record_t FilelessReader::read_keyfile_entry(size_t index) const {
    FrameSet::key_record_t const* records = 
      reinterpret_cast<FrameSet::key_record_t const*>(m_timekeysinfo.data()+sizeof(FrameSet::key_prologue_t));

    return records[index];
  }


}
