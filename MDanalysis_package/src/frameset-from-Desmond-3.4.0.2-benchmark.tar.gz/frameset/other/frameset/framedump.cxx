/* 
Copyright 2012-2014, D. E. Shaw Research.
All rights reserved.

Redistribution and use in source and binary forms, with or without
modification, are permitted provided that the following conditions are
met:

* Redistributions of source code must retain the above copyright
  notice, this list of conditions, and the following disclaimer.

* Redistributions in binary form must reproduce the above copyright
  notice, this list of conditions, and the following disclaimer in the
  documentation and/or other materials provided with the distribution.

* Neither the name of D. E. Shaw Research nor the names of its
  contributors may be used to endorse or promote products derived from
  this software without specific prior written permission.

THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
"AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR
A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT
OWNER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,
SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT
LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE,
DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY
THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
(INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE
OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
*/

#include "dump_utils.hxx"
#include "FrameSet/ReaderFrame.hxx"
#include <iostream>
#include <vector>
#include <set>
#include <sys/types.h>
#include <sys/stat.h>
#ifdef DESRES_OS_Windows
#else
#include <unistd.h>
#endif
#include <cstdio>

using std::cout;
using std::cerr;
using std::endl;
using frameset::Frame;
using frameset::ReaderFrame;

int main(int argc, char** argv) {
  size_t max = 0;
  std::vector<std::string> framefiles;
  std::set<std::string> match;
  std::set<std::string> match_not;
  bool hexfloat = false;
  bool json = false;

  // -----------------------------------------------
  // Argument processing...
  // -----------------------------------------------
  for(int argno=1; argno<argc; ++argno) {
    std::string arg = argv[argno];
    if (arg.compare(0,6,"--max=") == 0) {
      std::istringstream input(arg.substr(6));
      input >> max;
    } else if (arg.compare(0,8,"--match=") == 0) {
      if (match_not.size() != 0) {
        cerr << "Cannot use match and matchnot together" << endl;
        return 1;
      }
      match.insert(arg.substr(8));
    } else if (arg.compare(0,11,"--matchnot=") == 0) {
      if (match.size() != 0) {
        cerr << "Cannot use match and matchnot together" << endl;
        return 1;
      }
      match_not.insert(arg.substr(11));
    } else if (arg == "--hexfloat") {
      hexfloat = true;
    } else if (arg == "--json") {
      json = true;
    } else if (arg == "--help" || arg == "--usage") {
      cerr << "framedump [--match=xxx] [--matchnot=xxx] [--max=n]"
        "frame frame..." << endl;

      cerr << endl;
      cerr << "Use --match=xxx --match=yyy to pull out selected fields" << endl;
      cerr << "Use --matchnot=exclude to discard unwanted fields" << endl;
      cerr << "Use --max to set a ceiling on the number of elements displayed" << endl;
      cerr << "Use --hexfloat to dump floats in hex format" << endl;
      cerr << "Use --json to dump in json compatible format (--max ignored)" << endl;
      return 1;
    } else {
      framefiles.push_back(arg);
    }
  }

  try {

    // -----------------------------------------------
    // For every frame file...
    // -----------------------------------------------
    for(std::vector<std::string>::iterator p = framefiles.begin();
        p != framefiles.end(); ++p) {

      // Make sure it exists and give a better error if not
      struct stat statbuf;
      if ( stat((*p).c_str(),&statbuf) != 0 ) {
        perror((*p).c_str());
        return 1;
      }

      ReaderFrame frame(*p);

      if (json) {
        dump_json_frame(0.0,frame,match,match_not,hexfloat);
      } else {
        cout << "{" << endl;
        dump_frame(frame,match,match_not,max,hexfloat);
        cout << "}" << endl;
      }
    }
  } catch (std::exception& e) {
    cerr << e.what() << endl;
    return 1;
  }

  return 0;
}
      
