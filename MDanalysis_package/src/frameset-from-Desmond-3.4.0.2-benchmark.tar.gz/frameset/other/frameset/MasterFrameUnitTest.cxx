/* 
Copyright 2012-2014, D. E. Shaw Research.
All rights reserved.

Redistribution and use in source and binary forms, with or without
modification, are permitted provided that the following conditions are
met:

* Redistributions of source code must retain the above copyright
  notice, this list of conditions, and the following disclaimer.

* Redistributions in binary form must reproduce the above copyright
  notice, this list of conditions, and the following disclaimer in the
  documentation and/or other materials provided with the distribution.

* Neither the name of D. E. Shaw Research nor the names of its
  contributors may be used to endorse or promote products derived from
  this software without specific prior written permission.

THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
"AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR
A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT
OWNER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,
SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT
LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE,
DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY
THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
(INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE
OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
*/

#include "FrameSet/FrameSetWriter.hxx"
#include "FrameSet/FrameSetReader.hxx"
#include "FrameSet/FrameSetExceptions.hxx"
#include "UnitTestCommon.hxx"

#include <iostream>
#include <exception>
#include <string>
#include <cassert>

int main(void) {
  try {
    // Create a small frameset to read below...
    {
      frameset::FrameSetWriter frameset("fs.dir");
      frameset.meta()->set_value("STATIC",static_cast<uint32_t>(3));

      frameset::Frame f;

      f.set_value("FOOBAR",static_cast<uint32_t>(10));
      frameset.push_back(f,1);

      f.set_value("FOOBAR",static_cast<uint32_t>(20));
      frameset.push_back(f,2);
    }

    // We reopen for reading
    frameset::FrameSetReader frameset("fs.dir");
    
    // The first frame should have the FOOBAR and STATIC fields
    uint32_t value;

    // Old API
    frameset[0]->get_value("FOOBAR",value);
    assert(value == 10);

    frameset[0]->get_value("STATIC",value);
    assert(value == 3);

    frameset[1]->get_value("FOOBAR",value);
    assert(value == 20);

    frameset[1]->get_value("STATIC",value);
    assert(value == 3);

    // New API
    frameset[0]->get_value("FOOBAR",value,false);
    assert(value == 10);

    bool throws;
    try {
      frameset[0]->get_value("STATIC",value,false);
      throws = false;
    } catch (...) {
      throws = true;
    }
    assert(throws);

    frameset[1]->get_value("FOOBAR",value,false);
    assert(value == 20);

    try {
      frameset[1]->get_value("STATIC",value,false);
      throws = false;
    } catch (...) {
      throws = true;
    }
    assert(throws);


  } catch (std::exception& e) {
    std::cerr << e.what() << std::endl;
    return 1;
  }
 
  //frameset::FrameSet::recursivelyRemove("fs.dir");
  return 0;
}
