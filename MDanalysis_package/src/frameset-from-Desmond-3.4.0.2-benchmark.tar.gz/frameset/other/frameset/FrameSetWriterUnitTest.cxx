/* 
Copyright 2012-2014, D. E. Shaw Research.
All rights reserved.

Redistribution and use in source and binary forms, with or without
modification, are permitted provided that the following conditions are
met:

* Redistributions of source code must retain the above copyright
  notice, this list of conditions, and the following disclaimer.

* Redistributions in binary form must reproduce the above copyright
  notice, this list of conditions, and the following disclaimer in the
  documentation and/or other materials provided with the distribution.

* Neither the name of D. E. Shaw Research nor the names of its
  contributors may be used to endorse or promote products derived from
  this software without specific prior written permission.

THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
"AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR
A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT
OWNER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,
SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT
LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE,
DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY
THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
(INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE
OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
*/

#include "FrameSet/FrameSetWriter.hxx"
#include "UnitTestCommon.hxx"
#include <cassert>
#include <iostream>

static void write_frames(double time,uint32_t nsteps, frameset::FrameSetWriter& frameset) {
  frameset::Frame F;
  std::string title = "test frame";
  F.set_values("TITLE",title.begin(),title.end());

  for (uint32_t step = 0; step < nsteps; ++step) {
    F.set_value("STEP",step);

    frameset.push_back(F,time);
    assert(frameset.time() == time);
    time += 0.5;
  }
}

int main(void) {
  const uint32_t nsteps = 10;

  try {

    {
      // -----------------------------------------------
      // Create an empty frameset (cannot actuall write)
      // -----------------------------------------------
      frameset::FrameSetWriter blank;
    }

    {
      // -----------------------------------------------
      // Create a frameset...
      // -----------------------------------------------
      frameset::FrameSetWriter frameset("sample.dir");
      frameset::FrameSet& base = frameset; // FrameSetWriter isa FrameSet
      
      // -----------------------------------------------
      // ... and push some frames into it
      // -----------------------------------------------
      write_frames(0.0,nsteps,frameset);
      assert(frameset.size() == nsteps);
      assert(base.size() == nsteps);
      frameset.flush_keyfile();

      // -----------------------------------------------
      // If we try to push_back a frame at an earlier
      // time, it should fail.
      // -----------------------------------------------
      frameset::Frame F;
      F.set_values("TITLE","hello",5);
      size_t before_nframes = frameset.size();
      double before_time = frameset.time();
      MUST_THROW(frameset::FrameSetException,{
          frameset.push_back(F,0.0);
        });
      // Make sure the set didn't appear to advance
      assert(before_nframes == frameset.size());
      assert(before_time == frameset.time());
    }

    // -----------------------------------------------
    // See if we can append to the sample.dir
    // -----------------------------------------------
    {
      frameset::FrameSetWriter append("sample.dir","a");
      assert(append.size() == nsteps);

      // Make sure we cannot append a smaller time
      MUST_THROW(frameset::FrameSetException,{
          write_frames(0.0,1,append);
        });

      write_frames(nsteps*0.5,nsteps,append);
      assert(append.size() == 2*nsteps);

      write_frames(11.1,1,append);

      // Rewind and try the append again
      append.rewind(0.0);
      assert(append.size() == 0);
      write_frames(0.0,1,append);
      assert(append.size() == 1);
    }

    // -----------------------------------------------
    // Create a new frameset testing multiple frames/file
    // This is for DESRES#
    // -----------------------------------------------
    {
      frameset::FrameSetWriter multiple("multiple.dir","w!",0,0,3);
      
      // Stick a round number of frames in and try the rewind...
      write_frames(0.0,6,multiple);
      assert(multiple.size() == 6);

      // Rewind from an even boundary to an even frame boundary
      multiple.rewind(1.5);
      assert(multiple.size() == 3);
      write_frames(1.5,3,multiple);
      assert(multiple.size() == 6);

      // Rewind from an even boundary to an odd boundary
      multiple.rewind(0.5);
      assert(multiple.size() == 1);
      write_frames(0.5,4,multiple);
      assert(multiple.size() == 5);

      // Rewind from an odd boundary to an even boundary
      multiple.rewind(1.5);
      assert(multiple.size() == 3);
      write_frames(1.5,2,multiple);
      assert(multiple.size() == 5);

      // Rewind from an odd boundary to an odd boundary
      multiple.rewind(1.0);
      assert(multiple.size() == 2);
      write_frames(1.0,3,multiple);
      assert(multiple.size() == 5);

      // Do a spurious rewind to a time after end-of-file
      multiple.rewind(1000.0);
      assert(multiple.size() == 5);
      write_frames(1000.0,1,multiple);
      assert(multiple.size() == 6);
    }

    {
      // -----------------------------------------------
      // Create a frameset with invalid mode
      // -----------------------------------------------
      try {
        frameset::FrameSetWriter naughty("sample.dir","r");
      } catch( const frameset::FrameSetException&) {}
    }

    frameset::FrameSet::recursivelyRemove("sample.dir");
  } catch (std::exception& e) {
    std::cerr << e.what() << std::endl;
    return 1;
  }
  return 0;

}
