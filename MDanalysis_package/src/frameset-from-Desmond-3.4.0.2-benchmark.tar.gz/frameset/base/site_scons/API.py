# Copyright D. E. Shaw Research, 2004-2012.

import sys, os
from SCons.Script import Import, Export, Flatten, Delete, Chmod
import SCons.Action
import SCons.Node
ActionFactory = SCons.Action.ActionFactory

# shared build: libDesmond.so contains both desmond_objs and program_objs
# static build: libDesmond.a contains desmond_objs; link line gets program_objs
desmond_objs = []
program_objs = []
Export('desmond_objs')
Export('program_objs')

from desmond import desmond_link, desmond_progs, desmond_tests, extra_objs

def handle_external_libs(env,kwds, with_desmond=True):
  ''' Replace LIBS with Desmond + $EXTERNAL_LIBS '''
  key='EXTERNAL_LIBS'
  env['LIBS']=env.get(key,[])
  if 'LIBS' in kwds: 
    del kwds['LIBS']
  if key in kwds:
    env['LIBS'].extend(kwds[key])
    del kwds[key]
  if with_desmond:
    env['LIBS'].extend(['Desmond'])

def add_python_extension(env, name, *args, **kwds):
    if not env['WITH_PYTHON']: return
    if env['STATIC']:
        print "NOT building Python extension %s due to static build" % name
    else:
        prefix=kwds.get('prefix', '')
        kwds.update(LIBPREFIX='')
        env=env.Clone()
        handle_external_libs(env,kwds)
        env.Append( CCFLAGS=['$PYTHON_CC_FLAGS'],)
        lib=env.SharedLibrary('$OBJDIR/lib/python/%s/%s' % (prefix, name), 
                *args, **kwds)
        env.Requires(lib, '$OBJDIR/lib/libDesmond.so')
        if env['PREFIX'] is not None:
            tgt='$PREFIX/lib/python/%s' % prefix
            env.Install(tgt, lib)
            env.Alias('install', tgt)

def desmond_script_func( dst, src, numpy ):
    ''' Take the lines that start with # in dest and replace
    @PYTHON@ with sys.executable wherever it appears.
    '''
    SCons.Node.FS.invalidate_node_memos(dst)
    s=file(src).read()
    out=file(dst, 'w')
    in_header=True
    for line in s.split('\n'):
        line=line.replace('@PYTHON@', sys.executable)
        line=line.replace('@NUMPY_PREFIX@', numpy )
        print >> out, line
    out.close()

def desmond_script_strfunc( dst, src, numpy ):
    return "%s->%s: desres->desmond" % (src, dst)

DesmondCopyScript=ActionFactory( desmond_script_func, desmond_script_strfunc )

def add_script( env, name, src=None ):
  if src is None: src=name
  name=os.path.basename(name)
  prog=env.Command('$OBJDIR/bin/%s'%name, src, [
      Delete("$TARGET"),
      DesmondCopyScript("$TARGET", "$SOURCE", "$NUMPY_PREFIX"),
      Chmod("$TARGET", 0755)])

  if env['PREFIX'] is not None:
    tgt=os.path.join(env['PREFIX'], 'bin')
    env.InstallAs(os.path.join(tgt, name), prog)
    env.Alias('install', tgt)
  return prog 

def add_object(env, *args, **kwds):
    if kwds.pop('UNARCHIVABLE', False):
        return add_program_objs(env,args,kwds)
    if env['STATIC']:
        return env.StaticObject(*args, **kwds)
    else:
        return env.SharedObject(*args, **kwds)

'''
Some modules call AddLibrary twice, with and without archive=True. 
'''
library_list=set()
external_libs=set()

# Puts object files in 'desmond_objs'
# Puts external libs in external_libs
def add_library(env, name, *args, **kwds):
    if name in library_list: return
    library_list.add(name)
    if not isinstance(name, str):
        raise ValueError, "AddLibrary: expected name to be string, got %s" % type(name)
    external_libs.update( kwds.pop('EXTERNAL_LIBS', []) )
    Import('desmond_objs')
    for a in Flatten(args):
        if isinstance(a,str):
            a=env.AddObject(a, **kwds)
        desmond_objs.append(a)
    Export('desmond_objs')
    #for key in ('LIBS', 'LIBPATH', 'RPATH', 'LINKFLAGS'):
        #for src in (kwds, env):
            #desmond_link.setdefault(key, set()).update(src.get(key,[]))

# Put objects in 'program_objs'
def add_program_objs(env, *args, **kwds):
    env=env.Clone()
    handle_external_libs(env,kwds)
    Import('program_objs')
    result=list()
    for a in Flatten(args):
        if isinstance(a,str):
            a=env.AddObject(a, **kwds)
        result.append(a)
    program_objs.extend(result)
    Export('program_objs')
    for key in ('LIBS', 'LIBPATH', 'RPATH', 'LINKFLAGS'):
        for src in (kwds, env):
            desmond_link.setdefault(key, set()).update(src.get(key,[]))
    return result

def add_plugin(env, name, *args, **kwds):
    if env['STATIC']:
        return add_program_objs(env,*args,**kwds)
    env=env.Clone()
    env.Replace(LIBPREFIX='', LDMODULESUFFIX='.so')
    env.Append(LINKFLAGS='$LINKFLAGS_PLUGIN')

    if 'EXTERNAL_LIBS' in kwds or 'EXTERNAL_LIBS' in env:
      # This is a plugin that we don't want to link into libDesmond.
      handle_external_libs(env,kwds, with_desmond=False)
      lib=env.LoadableModule('$OBJDIR/lib/plugin/%s' % name, *args, **kwds)
      if env['PREFIX'] is not None:
          tgt='$PREFIX/lib/plugin'
          env.Install(tgt, lib)
          env.Alias('install', tgt)
    else:
      # Just add the plugin's object files to libDesmond
      # Munge the name to avoid clashes with names of actual libraries.
      add_library( env, "%s_plugin" % name, *args, **kwds )

def add_super_library(env):
    Import('desmond_objs')
    Import('program_objs')

    if env['STATIC']:
        # static build: build a libDesmond.a out of desmond_objs
        # put program_objs on the command line
        extra_objs[:] = program_objs
        lib=env.StaticLibrary('$OBJDIR/lib/Desmond',desmond_objs)
    else:
        # shared build: build a libDesmond.so and link against it
        env=env.Clone()
        env.Append( LINKFLAGS=env["EXTRA_LINK_FLAGS"].split() )
        env.AppendUnique( LIBS=list(external_libs) )
        extra_objs[:] = []
        lib=env.SharedLibrary('$OBJDIR/lib/Desmond',desmond_objs+program_objs)
        if env['PREFIX'] is not None:
            tgt='$PREFIX/lib'
            env.Install(tgt, lib)
            env.Alias('install', tgt)

def add_program(env, name, *args, **kwds):
    env=env.Clone()
    handle_external_libs(env,kwds)
    objs=[]
    for a in Flatten(args):
        if isinstance(a,str):
            a=env.AddObject(a, **kwds)
        objs.append(a)
    desmond_progs.append((name, objs, kwds))

def add_unit_test(env, name, *args, **kwds):
    env=env.Clone()
    handle_external_libs(env,kwds)
    objs=[]
    for a in Flatten(args):
        if isinstance(a,str):
            a=env.AddObject(a, **kwds)
        objs.append(a)
    desmond_tests.append((name, objs, kwds))

def add_doxygen(env, *args, **kwds):
  #print "SKIPPING DOXYGEN:", args
  pass

def Customize(env):

    # rename the old AddLibrary to AddSharedLibrary
    env.AddMethod( env.AddLibrary.method, 'AddSharedLibrary' )

    env.AddMethod( add_object, 'AddObject' )
    env.AddMethod( add_library, 'AddLibrary' )
    env.AddMethod( add_program_objs, 'AddProgramObjs' )
    env.AddMethod( add_plugin, 'AddPlugin' )
    env.AddMethod( add_super_library, 'AddSuperLibrary' )
    env.AddMethod( add_program, 'AddProgram' )
    env.AddMethod( add_unit_test, 'AddUnitTest' )
    env.AddMethod( add_unit_test, 'AddExecutable' )
    env.AddMethod( add_python_extension, 'AddPythonExtension' )
    env.AddMethod( add_doxygen, 'AddDoxygen' )
    env.AddMethod( add_script, 'AddScript' )

    if env['STATIC']:
        env['OBJDIR'] = env['OBJDIR'].rstrip('/\\')
        env['OBJDIR'] += '.static'

