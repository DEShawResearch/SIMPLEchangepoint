# Copyright D. E. Shaw Research, 2004-2012.

"""
The Platform class implements platform specific compiler,
linker, options and path settings, providing a compact
and abstract interface to the calling SConstruct script
"""

import os
import subprocess
import re

def find_in_path(cmd):
  '''
  return the absolute path to cmd in $PATH, or None if not found
  '''
  PATH=os.environ.get('PATH')
  if PATH:
    for part in PATH.split(':'):
      candidate = os.path.join(part, cmd)
      if os.path.isfile(candidate) or os.path.islink(candidate):
        return candidate
  return None

# >>> a = subprocess.Popen('cl', shell=True, stdin=None, stdout=subprocess.PIPE,stderr=subprocess.PIPE
# )
# >>> print a.communicate()[1]
# Microsoft (R) 32-bit C/C++ Optimizing Compiler Version 15.00.21022.08 for 80x86
# Copyright (C) Microsoft Corporation.  All rights reserved.


# >>> a = subprocess.Popen('icl', shell=True, stdin=None, stdout=subprocess.PIPE,stderr=subprocess.PIP
# E)
# >>> print a.communicate()[1]
# Intel(R) C++ Compiler Professional for applications running on IA-32, Version 11.1    Build 20090511
#  Package ID: w_cproc_p_11.1.035
# Copyright (C) 1985-2009 Intel Corporation.  All rights reserved.

# icl: command line error: no files specified; for help type "icl /help"

def compiler_version(env):
    ver = ''
    comp=env.get('CC')
    if comp == 'cl' or comp == 'icl':
        c = comp
        t1 = subprocess.Popen(c, stdin=None, stdout=subprocess.PIPE, stderr=subprocess.PIPE).communicate()[1]
        tm = re.search(r'Version (\d+\.\d+)', t1)
        if tm: 
            ver = tm.group(1)
        else: 
            print 'ERROR: unable to parse for compiler version string'
            env.Exit(1)
    elif comp in ('icc', 'opencc', 'gcc', 'cc'):
        for comp in ('icc', 'opencc', 'gcc', 'cc'):
            c = comp
            comp = find_in_path(c)
            if comp: break
        if not comp: return '', ''
        ver=os.popen('%s -dumpversion' % comp).read().strip()
    else:
        c = comp.split(' ')[0]
    if not (len(ver.split('\n'))==1 and len(ver)): ver = ''
    return (c,ver)

class Platform:
    """
    abstract platform base class
    """
    def __init__(self,osname,pfname,machname,idname):
        self._osname = osname
        self._pfname = pfname
        self._machname = machname
        self._idname = idname

    def setupEnv(self,env):
        """
        setup scons environment with all necessary components
        """
        isrogue = 1
        if 'PRODUCT_SOURCE' in os.environ:
            product_source = os.environ['PRODUCT_SOURCE']
            if product_source.startswith('p4:'):
                isrogue = 0
        # Allow version of the form a.b.c.d-suffix.  The a.b.c.d part will
        # make it into DESMOND_HEXVERSION, while the suffix will find its
        # way only into DESMOND_PROVENANCE.
        ver=env['DESMOND_VERSION'].split('-')[0]
        splt=ver.split('.')
        if len(splt)!= 4:
            print "ERROR: DESMOND_VERSION malformed %s" % ver
            print "ERROR: expecting A.B.C.D-suffix format"
            print "ERROR: with the -suffix optional"
            env.Exit(1)
        # For convenience?  Maybe for lame reasons, we allow some
        # shorthands like '3.x' and such.
        hexd = []
        if splt[1] == 'x':
            hexd = ['03', 'ff', 'ff', 'ff']
        elif splt[2] == 'x':
            hexd = ['03', '00', 'ff', 'ff']
        else:
            for dig in splt:
                id = int(dig)
                if id < 0 or id > 255:
                    print "ERROR: DESMOND_VERSION malformed %s, %d" % (ver,id)
                    env.Exit(1)
                hexd.append('%02x'%id)
        while len(hexd) < 4: hexd.append('00')
        cppdef=[]
        cppdef.append('__STDC_CONSTANT_MACROS')
        cppdef.append('DESMOND_HEXVERSION_HI=0x%s'%''.join(hexd[:4]))
        cppdef.append('DESMOND_PROVENANCE=\\"%s\\"' % ver)
        cppdef.append('DESMOND_ISROGUE=%d'%isrogue)
        cppdef.append('DESMOND_BUILDCLASS=\\"%s\\"'%env["BUILDCLASS"])
        cppdef.append('DESMOND_UNAME_KERNEL=\\"%s\\"'%env["DESRES_OS"])
        cppdef.append('DESMOND_UNAME_PROCESSOR=\\"%s\\"' %env["DESRES_ISA"])
        cppdef.append('RESTRICT=__restrict')
        cppdef.append('BOOST_FILESYSTEM_VERSION=3')
        cppdef.append('BOOST_FILESYSTEM_NO_DEPRECATED')
        if env["BUILDCLASS"]=="ReleaseDbl":
            cppdef.append('DOUBLE_PRECISION_SCALARS')
        env.AppendUnique(CPPDEFINES=cppdef)

    def getMachine(self):
        return self._machname

    def getName(self):
        return self._idname


class PosixPlatform(Platform):
    """
    common base class for all posix platforms
    """
    def __init__(self,osname,pfname,machname,idname):
        Platform.__init__(self,osname,pfname,machname,idname)

    def setupEnv(self,env):
        Platform.setupEnv(self,env)

        (comp,ver) = compiler_version(env)

        cppdef=[]
        cppdef.append('STATIC_INLINE=static inline')
        if not env['MONOBUILD']:
          cppdef.append('_XOPEN_SOURCE=600')
          cppdef.append('_ISOC99_SOURCE')
        cppdef.append('DESRES_OS_%s'%env["DESRES_OS"])
        cppdef.append('DESRES_ISA_%s'%env["DESRES_ISA"])
        if env["BUILDCLASS"]=="Release":
            cppdef.append('QUAD_ACCELERATION_SSE')
        env.Append(CPPDEFINES=cppdef)
        
        cflags=[]
        cflags.append('-pthread')
        cflags.append('-g')
        if comp == 'gcc':
          if env['BUILDCLASS'] != 'Debug':
            cflags.append('-O2')
            cflags.append('-fno-strict-aliasing')
            cflags.append('-funroll-loops')
          else:
            cflags.append('-O0')
          cflags.append('-march=core2')
          cflags.append('-mfpmath=sse')
          cflags.append('-Wall')
          cflags.append('-pedantic')
          cflags.append('-Wno-parentheses')
          cflags.append('-Wno-long-long')
        elif comp == 'icc':
          cflags.append('-O2')
          if ver > "10.1" :
            cflags.append('-axSSE3,SSSE3')
            i_static = '-static-intel'
          else:
            cflags.append('-axTP')
            i_static = '-i_static'
          cflags.append('-ip')
	  # fp-model strict kills all performance advantage
	  # over gcc, but presently is necessary for stable simulations
          cflags.append(['-fp-model', 'strict'])
          cflags.append('-funroll-loops')
          cflags.append('-restrict')
	elif comp == 'opencc':
          if env['BUILDCLASS'] != 'Debug':
            cflags.append('-O2')
            cflags.append('-fno-strict-aliasing')
            cflags.append('-funroll-loops')
          else:
            cflags.append('-O0')
	  cflags.append('-march=core')
	  cflags.append('-OPT:Olimit=0')
	  cflags.append('-msse')
	  env['LINKFLAGS'] = ['$__RPATH' ]

        ccflags = cflags[:]
        env.Append(CFLAGS=cflags, CCFLAGS=ccflags)
        if not env['MONOBUILD']:
          env.Append(CFLAGS=['-std=c99'])
        
        env.Append(LINKFLAGS=['-g'])
        env.Append(LINKFLAGS=['-pthread'])
        if comp == 'icc':
	    env.Append(LINKFLAGS=[i_static])

        env.Append(LIBS=["dl","pthread"])
	env.Append(LIBS= 'boost_filesystem' + env['BOOST_LIBS_SUFFIX'])
	env.Append(LIBS= 'boost_system' + env['BOOST_LIBS_SUFFIX'])
	if env['USE_BFD'] :
	    env.Append(LIBS= ['bfd', 'dl', 'iberty'])

        # insert compiler version just before buildclass.
        comps=env['OBJDIR'].split('/')
	
        prefix=comps[:-1]
        suffix=comps[-1:]
        if ver: ver='-%s' % ver
        env['OBJDIR']='/'.join(prefix + ['%s%s'%(comp, ver)] + suffix)

class LinuxPlatform(PosixPlatform):
    """
    linux platform implementation
    """
    def __init__(self,osname,pfname,machname,idname):
        PosixPlatform.__init__(self,osname,pfname,machname,idname)


class DarwinPlatform(PosixPlatform):
    """
    mac osx platform implementation
    """
    def __init__(self,osname,pfname,machname,idname):
        PosixPlatform.__init__(self,osname,pfname,machname,idname)

    def setupEnv(self,env):
        PosixPlatform.setupEnv(self,env)
        env.Append(LINKFLAGS_PLUGIN=['-undefined dynamic_lookup'.split()])

class Win32Platform(Platform):
    """
    windows platform implementation
    """
    def __init__(self,osname,pfname,machname,idname):
        Platform.__init__(self,osname,pfname,machname,idname)

    def setupEnv(self,env):
        Platform.setupEnv(self,env)

        (comp,ver) = compiler_version(env)

        cppdef=[]
        cppdef.append('STATIC_INLINE=static __inline')
        cppdef.append('DESRES_OS_Windows')
	if env['TARGET_ARCH'] == 'x86':
	  cppdef.append('ssize_t=int')
	elif env['TARGET_ARCH'] == 'x86_64':
	  cppdef.append('ssize_t=long long')
        cppdef.append('mode_t=int')
        cppdef.append('DESRES_DESSERT_PORTABLE')
        cppdef.append('DESMOND_NOAFFINITY')
        cppdef.append('DESRES_READ_TIMESTEP2')
        if env["BUILDCLASS"] == "Release":
          cppdef.append('QUAD_ACCELERATION_SSE')
        cppdef.append('__SSE__')
        cppdef.append('__SSE2__')
        cppdef.append('__SSE3__')

        env.Append(CPPDEFINES=cppdef)
        
        env.Append(CPPPATH=['#/port/win32'])

	cflags=[]
        if comp == 'icl':
          if env['BUILDCLASS'] != 'Debug':
            if ver > "10.1" :
              cflags.append('/QaxSSE3,SSSE3')
            else:
              cflags.append('/QaxTP')
            cflags.append('/Qunroll')
            cflags.append('/Qrestrict')
            cflags.append('/O3')
          else:
            cflags.append('/Od')
        else:
	  cflags.append('/MD')
	  if env['TARGET_ARCH'] != 'x86_64':
            cflags.append('/arch:SSE2')
          if env['BUILDCLASS'] != 'Debug':
            cflags.append('/O2')
          else:
            cflags.append('/Od')
            cflags.append('/Zi')
        if env['TARGET_ARCH'] == 'x86_64':
          cflags.append('/fp:strict')
        elif env['TARGET_ARCH'] == 'x86':
          cflags.append('/fp:precise')

        ccflags=cflags[:]
        ccflags.append('/EHs')
        env.Append(CFLAGS=cflags, CCFLAGS=ccflags)

        env.Append(LINKFLAGS=[])
	env.Append(LINKFLAGS=['/DYNAMICBASE'])
        if env['BUILDCLASS'] == 'Debug':
          env.Append(LINKFLAGS = ['/DEBUG', '/fixed:no', '/incremental:no'])
        env.Append(LIBS=['ws2_32'])

        # insert compiler version just before buildclass.
        comps=env['OBJDIR'].split('\\')
	
        prefix=comps[:-1]
        suffix=comps[-1:]
        env['OBJDIR']='\\'.join(prefix + ['%s%s'%(comp, ver)] + suffix)

	# We don't support building dlls on windows yet.
	if not env.get('STATIC'):
		print "ERROR: Windows builds require 'STATIC=True' option"
		env.Exit(1)
	

def GetPlatform():
    """
    platform factory method
    """
    import sys, string, platform

    osname = string.lower(os.name)
    pfname = string.lower(sys.platform)
    machname = platform.machine()

    if(osname == "posix"):
        if(string.find(pfname,"linux")>=0):
            if platform.architecture()[0]=='64bit':
                machname="x86_64"
            else:
                machname="i586"
            print "Identified linux (%s) platform"%machname
            return LinuxPlatform(osname,pfname,machname,"Linux")
        elif(string.find(pfname,"darwin")>=0):
            print "Identified osx platform"
            return DarwinPlatform(osname,pfname,machname,"macosx")
        else:
            print "Identified generic posix platform"
            return PosixPlatform(osname,pfname,machname,"posix")
    elif(osname == "nt" or pfname== "win32"):
        print "Identified Win32 platform"
        return Win32Platform(osname,pfname,machname,"win32")
    else:
        raise "Unknown Platform (%s,%s)"%(osname,pfname)

def Customize(env):
    GetPlatform().setupEnv(env)

