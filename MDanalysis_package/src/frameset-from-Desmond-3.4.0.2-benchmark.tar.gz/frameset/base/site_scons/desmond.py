# Copyright D. E. Shaw Research, 2004-2012.

import sys, os

desmond_link = {}
desmond_progs = []
desmond_tests = []
extra_objs = []

import SCons.Script as Script
import desres, API, Platform, Configure

def Customize(env,MonoBuild=False):
    env['MONOBUILD']=MonoBuild
    # We really must must must stick provenance information in a header
    # file and not do this this way.  It is was dangerous.  -Ross
    try:
      env["DESMOND_VERSION"] = "3.4.0.2"
    except KeyError:
      print "Please set DESMOND_VERSION in the environment"
      env.Exit(1)

    opts = Script.Variables(Script.GetOption('user-config'))
    opts.Add("EXTRA_INCLUDE_PATH","extra include paths","")
    opts.Add("EXTRA_LIBRARY_PATH","extra library search paths","")
    opts.Add("EXTRA_C_FLAGS","extra flags for c compiler","")
    opts.Add("EXTRA_CC_FLAGS","extra flags for c++ compiler","")
    opts.Add("EXTRA_LINK_FLAGS","extra flags for linker","")
    opts.Add("EXTRA_LIBS","extra libraries to include at link time","")
    
    opts.Add("BOOST_PREFIX", "location of boost installation", os.getenv('BOOST_PREFIX') )
    opts.Add("BOOST_LIBS_SUFFIX","postfix for boost libraries","")
    
    opts.Add("WITH_PYTHON", "build Python extensions?", os.getenv("WITH_PYTHON"))
    opts.Add("PYTHON_CC_FLAGS", "extra compile flags for Python extensions", os.getenv('PYTHON_CC_FLAGS'))
    opts.Add("NUMPY_PREFIX", "location of NumPy installation", os.getenv("NUMPY_PREFIX"))
    
    opts.Add("CC","path to C compiler")
    opts.Add("CXX","path to C++ compiler")
    
    opts.Add(Script.EnumVariable("THREADS", 'Thread implementation',None, ['POSIX', 'BOOST', 'NO']))
    opts.Add("THREAD_AFFINITY", "sched_setaffinity() available?", None)
    
    opts.Add("USE_POSIX_MEMALIGN", "posix_memalign() available?", None)
    opts.Add("USE_BFD", "Use bfd library?", False)
    opts.Add("USE_BACKTRACE", "Use backtrace from glibc?", True)

    if MonoBuild:
        opts.Add("WITH_MPI", "build MPI destriers?", os.getenv("WITH_MPI"))

    opts.Add("MPICXX", "MPI compiler/linker")
    opts.Add("MPI_CPPFLAGS", "Compile flags for MPI modules", os.getenv("MPI_CPPFLAGS"))
    opts.Add("MPI_LDFLAGS", "Link flags for MPI modules", os.getenv("MPI_LDFLAGS"))
    opts.Add("WITH_INFINIBAND", "build MPI-IB destrier?", os.getenv("WITH_INFINIBAND"))
    opts.Add("IB_CPPFLAGS", "Compile flags for IB modules", os.getenv("IB_CPPFLAGS"))
    opts.Add("IB_LDFLAGS", "Link flags for IB modules", os.getenv("IB_LDFLAGS"))

    
    opts.Add(Script.BoolVariable('STATIC', 'Set to true for static build (default for Windows)',
                          sys.platform == 'win32'))
    
    opts.Update(env)
    desres.Customize(env)
    if MonoBuild:
        API.Customize(env)
    Platform.Customize(env)
    env.SConsignFile('%s/.sconsign' % (env['OBJDIR'].strip('#')))
    
    env.AppendUnique(
        CPPPATH=env["EXTRA_INCLUDE_PATH"].split(),
        LIBPATH=env["EXTRA_LIBRARY_PATH"].split(),
        RPATH=env["EXTRA_LIBRARY_PATH"].split(),
        CFLAGS=env["EXTRA_C_FLAGS"].split(),
        CCFLAGS=env["EXTRA_CC_FLAGS"].split(),
        LIBS=env["EXTRA_LIBS"].split()
        )

    if sys.platform != 'win32':
        env.Replace(LINK='$CXX')
    else:
        if env['CC'] == 'icl':
            env.Replace(LINK = 'xilink')
            env.Replace(AR = 'xilib')
    
    Configure.ConfigureMain(env)

def build_progs(env):
    myenv=env.Clone()
    # Add external libraries that were brought in by submodules
    for key, val in desmond_link.items():
        val=list(val)
        myenv.AppendUnique( **{key:val} )

    prgenv = myenv.Clone()
    prgenv.AppendUnique(LIBS=['Desmond'])

    for name, args, kwds in desmond_progs:
        prog=prgenv.Program('$OBJDIR/bin/%s' % name, extra_objs+args, **kwds)
        if prgenv['PREFIX'] is not None:
            tgt='$PREFIX/bin'
            prgenv.Install(tgt, prog)
            prgenv.Alias('install', tgt)
    for name, args, kwds in desmond_tests:
        prog=prgenv.Program('$OBJDIR/unit-tests/%s' % name, extra_objs+args, **kwds)
        alias=prgenv.Alias('test', [prog], prog[0].path)
        prgenv.AlwaysBuild(alias)

def build(MonoBuild=False):
    Script.AddOption('--user-config', dest='user-config', nargs=1, 
            type='string', action='store', help='customization file')
    if sys.platform == 'win32':
        if not os.getenv('DESRES_TARGET_ARCH'):
	    print >> sys.stderr, "DESRES_TARGET_ARCH environment variable not set"
	    env.Exit(1)
        env = Script.Environment(ENV=os.environ, TARGET_ARCH = os.getenv('DESRES_TARGET_ARCH'))
    else:
        env = Script.Environment(ENV=os.environ)

    # enforce environment definition of BUILDCLASS
    # if not os.getenv('BUILDCLASS'):
    #    print >> sys.stderr, "BUILDCLASS environment variable not set"
    #    env.Exit(1)
    Customize(env, MonoBuild=MonoBuild)
    Script.Export('env')
    env.SConscript('SConscript', variant_dir=env['OBJDIR'], duplicate=0)
    if MonoBuild:
        build_progs(env)

    # install our scons files
    if env.get('PREFIX'):
        tgt=os.path.join(env['PREFIX'], 'scons')
        env.Install(tgt, env.Flatten([
                env.Glob('site_scons/*.py'),
                ]))
        env.Alias('install', tgt)
    
