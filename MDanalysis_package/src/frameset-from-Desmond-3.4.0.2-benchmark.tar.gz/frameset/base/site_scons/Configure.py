# Copyright D. E. Shaw Research, 2004-2012.

import copy, sys

def check_compiler( _context ):
    _context.Message( "Checking if compiler compiles... " )
    listing = """
        extern \"C\" int main( int c, char** v ) 
        { 
        	return 0; 
        }

        """
    ret = _context.TryCompile( listing, '.cc' )	
    _context.Result( ret )
    return ret

def check_version( _context, _version, _header, pretty_version=None ):
    nice_version_string = pretty_version
    if not nice_version_string: 
      nice_version_string = ".".join( [str( v[1] ) for v in _version] )
    _context.Message( "Checking if version of %s is equal or above %s... "%( _header, nice_version_string ) )	    
    version_check = " && ".join( ["%s >= %s" % ( k[0], str( k[1] ) ) for k in _version] )
    listing = """
        #include <%s>
        #if %s
        //Everything is fine.
        #else
        #error Version too low
        #endif
        extern \"C\" int main( int c, char** v ) 
        { 
        	return 0; 
        }

        """ % ( _header, version_check )
    ret = _context.TryCompile( listing, '.cc' )	
    _context.Result( ret )
    return ret


def ConfigureMain(env):

    ### Boost configuration
    boost_thread = ''
    if sys.platform != 'win32':
        boost_thread = 'boost_thread' + env["BOOST_LIBS_SUFFIX"]

    conf = env.Configure( custom_tests={'CheckCompiler' : check_compiler } )
    if not conf.CheckCompiler( ):
        print "Error: Compiler doesn't appear to be able to compile a test program"
        env.Exit(1)
    conf.Finish()

    # Locate Boost header files
    if env.get('BOOST_PREFIX'):
        env.AppendUnique( CPPPATH=['$BOOST_PREFIX/include'],
                          LIBPATH=['$BOOST_PREFIX/lib'],
                          RPATH=['$BOOST_PREFIX/lib'], )

    elif env.get('BOOST_INCLUDE_PATH') and env.get('BOOST_LIBRARY_PATH'):
        env.AppendUnique( CPPPATH=['$BOOST_INCLUDE_PATH'],
                          LIBPATH=['$BOOST_PREFIX/lib'],
                            RPATH=['$BOOST_PREFIX/lib'], )
                           
    else:
        conf = env.Configure( custom_tests={'CheckVersion' : check_version } )
        if not conf.CheckVersion( [ ['BOOST_VERSION',104500] ], 
                                  'boost/version.hpp', 
                                  pretty_version='1.45.0' ):
            print "Error: Boost version must be at least 1.45.0"
            env.Exit(1)
        conf.Finish()

    ### Thread configuration
    if env.get('THREADS') is None:
        conf=env.Configure()
        if conf.CheckLibWithHeader('pthread', 'pthread.h', 'c', 'pthread_spinlock_t;'):
            env['THREADS']='POSIX'
        elif conf.CheckLibWithHeader(boost_thread, 'boost/thread.hpp', 'c++'):
            env['THREADS']='BOOST'
        else:
            env['THREADS']='NO'
        conf.Finish()
    if not env['THREADS'] in ['POSIX', 'BOOST', 'NO']:
        print "Error: THREADS(%s) must be one of 'POSIX', 'BOOST', 'NO', or unset'", env['THREADS']
	env.Exit(1)
    env.Append(CPPDEFINES = 'DESRES_%s_THREADS'%env['THREADS'])
    if env['THREADS'] and env['THREADS'] == 'BOOST':
        env.AppendUnique(LIBS = 'boost_thread' + env['BOOST_LIBS_SUFFIX']);

    ### Thread affinity
    if env.get('THREAD_AFFINITY') is None:
        conf=env.Configure()
        env['THREAD_AFFINITY']=conf.CheckFunc('sched_setaffinity', '#include <sched.h>')
        conf.Finish()

    # On Windows, for reasons as yet unexplained, don't explicitly list the 
    # boost libraries.
    if sys.platform == 'win32':
	libs=[x for x in env['LIBS'] if not x.startswith('boost')]
        env.Replace(LIBS=libs)

    ### Python extensions
    if env.get('WITH_PYTHON') is not False:
        pyenv=env.Clone()
        pyenv.Append(CCFLAGS='$PYTHON_CC_FLAGS')
        conf=pyenv.Configure()
        env['WITH_PYTHON']=conf.CheckCHeader('Python.h')
        conf.Finish()
    if not env['WITH_PYTHON']:
        print "NOT building Python extensions or executables."
